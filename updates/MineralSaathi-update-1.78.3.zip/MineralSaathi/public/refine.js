'use strict';
// ✨ Refine a typed note — free, on this PC, no API key:
//   1. the AI built into the browser (Microsoft Edge / Google Chrome on-device model: Rewriter or Prompt API), when this PC has it;
//   2. otherwise an offline tidy-up: spaces, capital letters, full stops and common short forms (rcvd → received, pls → please …).
const REFINE_SHORT = { rcvd: 'received', recd: 'received', rcv: 'receive', pls: 'please', plz: 'please', pymt: 'payment', pmt: 'payment', qty: 'quantity', smpl: 'sample', smpls: 'samples',
  nr: 'no response', 'n/r': 'no response', nrr: 'no response', cb: 'call back', cbl: 'call back later', tmrw: 'tomorrow', tmr: 'tomorrow', tom: 'tomorrow', wk: 'week', mnth: 'month',
  msg: 'message', nxt: 'next', mt: 'MT', mts: 'MT', kgs: 'kg', rs: 'Rs.',  ord: 'order', reqd: 'required', req: 'requirement', govt: 'government', b4: 'before', bcz: 'because', coz: 'because', abt: 'about', thru: 'through', u: 'you', ur: 'your',
  r: 'are', n: 'and', wd: 'would', shd: 'should', cud: 'could', asap: 'as soon as possible', fyi: 'for your information', w: 'with', wo: 'without', tbd: 'to be decided', approx: 'approximately', mob: 'mobile', no: 'no' };
function refineOffline(t) {
  let s = String(t || '').replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  if (s === s.toUpperCase() && /[A-Z]{4}/.test(s)) s = s.toLowerCase();       // typed in CAPITALS → normal letters
  s = s.replace(/\b([A-Za-z/]+)\b/g, (w) => { const k = w.toLowerCase(); return REFINE_SHORT[k] && k !== 'no' ? REFINE_SHORT[k] : w; });
  s = s.replace(/\s+([,.!?;:])/g, '$1').replace(/([,.!?;:])(?=[A-Za-z])/g, '$1 ').replace(/\.{2,}/g, '.').replace(/,{2,}/g, ',');
  s = s.split('\n').map(line => {
    line = line.trim(); if (!line) return line;
    line = line.replace(/(^|[.!?]\s+)([a-z])/g, (m, a, b) => a + b.toUpperCase()).replace(/\bi\b/g, 'I');
    if (!/[.!?:)]$/.test(line)) line += '.';
    return line;
  }).join('\n');
  return s;
}
const REFINE_CTX = 'Notes of a sales call by an Indian mineral company (diatomaceous earth, bentonite, gypsum …) with a customer about samples, orders, rates and payment. Rewrite the note in clear, short, correct business English. Keep every fact, name, number, date, rate and quantity exactly. Do not add anything new. Plain text only, no heading.';
async function refineAI(text, onStatus) {
  if (self.Rewriter) {
    const a = await Rewriter.availability({ tone: 'as-is', format: 'plain-text', length: 'as-is' }).catch(() => 'unavailable');
    if (a !== 'unavailable') {
      const rw = await Rewriter.create({ tone: 'as-is', format: 'plain-text', length: 'as-is', sharedContext: REFINE_CTX,
        monitor(m) { m.addEventListener('downloadprogress', e => onStatus && onStatus(`Getting the AI model ready… ${Math.round(e.loaded * 100)}%`)); } });
      try { return { text: (await rw.rewrite(text, { context: 'Make it clear and correct; keep all facts.' })).trim(), how: 'AI built into the browser' }; } finally { rw.destroy && rw.destroy(); }
    }
  }
  if (self.LanguageModel) {
    const a = await LanguageModel.availability().catch(() => 'unavailable');
    if (a !== 'unavailable') {
      const lm = await LanguageModel.create({ initialPrompts: [{ role: 'system', content: REFINE_CTX }],
        monitor(m) { m.addEventListener('downloadprogress', e => onStatus && onStatus(`Getting the AI model ready… ${Math.round(e.loaded * 100)}%`)); } });
      try { return { text: (await lm.prompt('Rewrite this note:\n\n' + text)).trim(), how: 'AI built into the browser' }; } finally { lm.destroy && lm.destroy(); }
    }
  }
  return null;
}
// a "✨ Refine" button for a textarea; ↶ Undo puts the typed text back
function refineButton(ta, label) {
  const bar = document.createElement('div'); bar.className = 'row'; bar.style.cssText = 'gap:6px;margin-top:4px;align-items:center';
  bar.innerHTML = `<button type="button" class="small sec" data-rf>✨ Refine${label ? ' ' + label : ''}</button><button type="button" class="small sec" data-undo hidden>↶ Undo</button><span class="hint" data-rfs></span>`;
  ta.after(bar);
  let before = null; const st = $('[data-rfs]', bar), undo = $('[data-undo]', bar), btn = $('[data-rf]', bar);
  btn.onclick = async () => {
    const t = ta.value.trim(); if (!t) return toast('Type the note first, then press Refine.', true);
    btn.disabled = true; st.textContent = 'Refining…';
    let r = null;
    try { r = await refineAI(t, s => { st.textContent = s; }); } catch (e) { r = null; }
    if (!r || !r.text) r = { text: refineOffline(t), how: 'offline tidy-up (no AI in this browser)' };
    before = ta.value; ta.value = r.text; ta.dispatchEvent(new Event('input', { bubbles: true }));
    undo.hidden = false; btn.disabled = false; st.textContent = `Refined — ${r.how}. Check it before saving.`;
  };
  undo.onclick = () => { if (before != null) { ta.value = before; ta.dispatchEvent(new Event('input', { bubbles: true })); } undo.hidden = true; st.textContent = 'Your text is back.'; };
}
