'use strict';
/* Mineral Saathi — Marketing (Sampark Saathi) screens.
   Marketing data lives in its own file (marketing.db); items, companies, printers and the other settings
   are the shared Mineral Saathi ones. Uses the helpers of app.js ($, GET, POST, PAGES, SETTINGS …). */

const MKT_LISTS = [
  ['sample_size', 'Sample size', '100 gm, 500 gm, 1 kg …'],
  ['courier', 'Courier / sent by', 'India Post, DHL, Blue Dart …'],
  ['response', 'Call response', 'Called, no response, not reachable …'],
  ['followup_reason', 'Follow-up reason', 'Why the next call is made'],
  ['templates', 'WhatsApp messages', 'Ready texts for the Communication screen']
];
const MKT_PAGES = {
  calls: ["Today's Calls", 4, 'Calls due today (or any date), overdue calls in red; click a call to open Communication.'],
  new: ['New Sample Dispatch', 2, 'Customer, dispatch and its samples.'],
  leads: ['Enquiries', 2, 'All enquiries with search by ref. no., company, name, mobile and city, with their samples and calls.'],
  comm: ['Communication', 4, 'History, WhatsApp messages with QR, log the response and plan the next call (Google Calendar).'],
  quick: ['Quick Sticker', 4, 'A 4×6 QR sticker for a walk-in or phone enquiry.'],
  letters: ['Letters', 4, 'Letter Pad, Bus and blank envelope with the sender from Settings → Companies.'],
  reports: ['Marketing Reports', 5, 'Samples by month, grade and courier; pending and overdue calls; enquiries that became buyers.'],
  lists: ['Marketing Lists', 1, '']
};
const TPL_FIELDS = ['{name}', '{company}', '{ref}', '{courier}', '{tracking_no}', '{tracking_link}'];

// show or hide the 📣 Marketing menu (Settings → Marketing)
async function mktMenu() {
  try { const s = await GET('/api/mkt/status'); $('#nav-mkt').hidden = !s.settings.enabled; return s; } catch { return null; }
}
mktMenu();

PAGES.mkt = async (el, arg) => {
  const [page, sub] = String(arg || 'calls').split(':');
  const def = MKT_PAGES[page] || MKT_PAGES.calls;
  $('#title').textContent = def[0];
  const st = await GET('/api/mkt/status');
  if (!st.ok) {
    el.innerHTML = `<div class="card" style="max-width:720px"><h3>⚠ Marketing data cannot be opened</h3>
      <p style="white-space:pre-line">${esc(st.problem || '')}</p><p class="hint">File: ${esc(st.file)}</p></div>`;
    return;
  }
  if (page === 'lists') return mktListsPage(el, sub || 'sample_size');
  if (page === 'new') return mktSampleForm(el, sub || '');
  if (page === 'calls') return mktCalls(el, sub);
  if (page === 'comm') return mktComm(el, sub || '');
  if (page === 'quick') return mktQuick(el);
  if (page === 'letters') return mktLetters(el, sub || 'PAD');
  if (page === 'leads') return sub ? mktLeadPage(el, Number(sub)) : mktLeadsList(el);
  if (page === 'reports') return mktReports(el);
  el.innerHTML = `<div class="card" style="max-width:720px"><h3>${esc(def[0])}</h3><p>${esc(def[2])}</p>
    <p><span class="badge amber">Coming in phase ${def[1]}</span></p>
    <p class="hint">Marketing data so far: ${st.counts.leads} enquiries · ${st.counts.samples} samples · ${st.counts.follow_ups_pending} calls pending.</p></div>`;
};

// ---------- Marketing Lists ----------
async function mktListsPage(box, key) {
  if (!MKT_LISTS.some(x => x[0] === key)) key = 'sample_size';
  if (key === 'templates') return mktTemplatesPage(box);
  const lists = await GET('/api/mkt/lists');
  const tpls = await GET('/api/mkt/templates');
  const def = MKT_LISTS.find(x => x[0] === key);
  const rows = lists[key] || [];
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide(key, lists, tpls)}
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="mlf" class="row" style="margin-bottom:14px">
        <label style="flex:1">New value<input name="value" autocomplete="off"></label>
        <button type="submit" id="mlsave">Add</button><button type="button" class="sec" id="mlcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>Value</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="2" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table>
      <p class="hint" style="margin-top:12px">Grade, mesh, colour, bag type, bag weight, packing type and unit are not kept here — Marketing uses
        <a href="#/itemlists">Master → Item List</a>, the same lists as billing.</p></div></div>`;
  const f = $('#mlf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault();
    await guard(() => editing ? PUT('/api/mkt/lists/' + editing, { value: f.value.value }) : POST('/api/mkt/lists', { list_key: key, value: f.value.value }));
    toast(editing ? 'Updated' : 'Added'); mktListsPage(box, key);
  };
  $('#mlcancel', box).onclick = () => mktListsPage(box, key);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value;
      $('#mlsave', box).textContent = 'Update'; $('#mlcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Samples and calls that already use it keep it.')) { await guard(() => DEL('/api/mkt/lists/' + rm.dataset.rm)); mktListsPage(box, key); }
  };
}

function mktListSide(key, lists, tpls) {
  return `<div class="card listside" style="padding:8px">${MKT_LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/mkt/lists:${k}')">
    <b>${t}</b><span class="badge grey">${k === 'templates' ? tpls.length : (lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>`;
}

// ---------- WhatsApp message templates ----------
function mktFill(body) {   // example of a filled message
  const ex = { '{name}': 'RAMESH KUMAR', '{company}': 'ABC MINERALS', '{ref}': '434', '{courier}': 'DHL', '{tracking_no}': 'RR123456789IN',
    '{tracking_link}': 'https://t.17track.net/en#nums=RR123456789IN' };
  return TPL_FIELDS.reduce((s, k) => s.split(k).join(ex[k]), body);
}
async function mktTemplatesPage(box) {
  const [lists, tpls] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/templates')]);
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide('templates', lists, tpls)}
    <div class="card"><h3>WhatsApp messages <span class="hint">— ready texts for the Communication screen</span></h3>
      <form id="mtf" class="grid" style="grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <label>Name<input name="name" autocomplete="off"></label>
        <div class="hint" style="align-self:end">Words filled in by themselves: ${TPL_FIELDS.map(x => `<code data-ins="${x}" style="cursor:pointer" title="Click to add">${x}</code>`).join(' ')}</div>
        <label style="grid-column:1/3">Message<textarea name="body" rows="5"></textarea></label>
        <div style="grid-column:1/3" class="row"><button type="submit" id="mtsave">Add</button><button type="button" class="sec" id="mtcancel" hidden>Cancel</button></div>
        <div style="grid-column:1/3" id="mtprev" class="hint" hidden></div>
      </form>
      <table class="t"><thead><tr><th style="width:190px">Name</th><th>Message</th><th style="width:150px"></th></tr></thead><tbody>
      ${tpls.map(t => `<tr><td><b>${esc(t.name)}</b></td><td style="white-space:pre-line">${esc(t.body)}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${t.id}">Edit</button> <button class="small sec" data-rm="${t.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="3" class="muted">No messages yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#mtf', box); let editing = null;
  const prev = () => { const p = $('#mtprev', box); p.hidden = !f.body.value.trim(); p.innerHTML = '<b>Example:</b><br>' + esc(mktFill(f.body.value)).replace(/\n/g, '<br>'); };
  f.body.oninput = prev;
  f.onsubmit = async e => {
    e.preventDefault(); const d = { name: f.name.value, body: f.body.value };
    await guard(() => editing ? PUT('/api/mkt/templates/' + editing, d) : POST('/api/mkt/templates', d));
    toast(editing ? 'Updated' : 'Added'); mktTemplatesPage(box);
  };
  $('#mtcancel', box).onclick = () => mktTemplatesPage(box);
  box.onclick = async e => {
    const ins = e.target.closest('[data-ins]'), ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ins) { const t = f.body, a = t.selectionStart ?? t.value.length; t.value = t.value.slice(0, a) + ins.dataset.ins + t.value.slice(t.selectionEnd ?? a); t.focus(); prev(); }
    if (ed) { const t = tpls.find(x => x.id === Number(ed.dataset.ed)); editing = t.id; f.name.value = t.name; f.body.value = t.body; prev();
      $('#mtsave', box).textContent = 'Update'; $('#mtcancel', box).hidden = false; f.name.focus(); }
    if (rm && confirm('Remove this message?')) { await guard(() => DEL('/api/mkt/templates/' + rm.dataset.rm)); mktTemplatesPage(box); }
  };
}

// ---------- Settings → Marketing ----------
SETTINGS.marketing = async box => {
  const [s, st] = await Promise.all([GET('/api/mkt/settings'), GET('/api/mkt/status')]);
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  box.innerHTML = `<div class="grid g2" style="align-items:start">
    <div class="card"><h3>📣 Marketing</h3>
      <form id="mkf" class="grid" style="gap:12px">
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="enabled" style="width:auto" ${s.enabled ? 'checked' : ''}> Show the Marketing menu</label>
        ${field({ name: 'default_firm', label: 'Sender on Marketing papers (Settings → Companies)', type: 'select', options: s.firms.map(x => [x.code, x.name]) }, s.default_firm)}
        ${field({ name: 'followup_days', label: 'Days until the first “Did the sample arrive?” call', type: 'number' }, s.followup_days)}
        ${field({ name: 'tracking_url', label: 'Tracking link — {tracking_no} is replaced by the number' }, s.tracking_url)}
        ${field({ name: 'next_ref', label: 'First Ref No. for new enquiries (your Excel ended at 433)', type: 'number' }, s.next_ref)}
        <h4 style="margin:6px 0 0">On the printed papers</h4>
        ${field({ name: 'signer', label: 'Name under “Thank you” and as sender on postal forms' }, s.signer)}
        ${field({ name: 'sender_digipin', label: 'Sender Digipin (postal forms)' }, s.sender_digipin)}
        ${field({ name: 'delivery_time', label: 'Delivery time (sample sticker, cover letter)' }, s.delivery_time)}
        ${field({ name: 'min_order_kg', label: 'Minimum order when the rate is per KG' }, s.min_order_kg)}
        ${field({ name: 'min_order_mt', label: 'Minimum order when the rate is per MT' }, s.min_order_mt)}
        ${field({ name: 'gst_note', label: 'Under the rate (e.g. PLUS 5% GST + FREIGHT)' }, s.gst_note)}
        ${field({ name: 'payment_terms', label: 'Payment terms (cover letter)' }, s.payment_terms)}
        <div class="row"><button type="submit">Save</button></div>
      </form>
      <p class="hint">The Google Calendar link is in <a href="#/settings/data">Settings → Data Location</a>.</p>
      <p class="hint">These are settings, saved with the other Mineral Saathi settings. Companies, printers, backup and data location are the same for billing and Marketing.</p></div>
    <div class="card"><h3>Marketing data</h3>
      ${st.ok ? `<p><span class="badge PM">Open</span> &nbsp;${esc(st.file)} · ${kb(st.size)}</p>
        <table class="t"><tbody>
          <tr><td>Enquiries</td><td class="num">${st.counts.leads}</td></tr>
          <tr><td>Samples</td><td class="num">${st.counts.samples}</td></tr>
          <tr><td>Calls pending</td><td class="num">${st.counts.follow_ups_pending}</td></tr>
          <tr><td>Calls and messages logged</td><td class="num">${st.counts.communications}</td></tr>
          <tr><td>Quick stickers</td><td class="num">${st.counts.quick_stickers}</td></tr></tbody></table>`
        : `<p><span class="badge red">Cannot open</span></p><p style="white-space:pre-line">${esc(st.problem || '')}</p>`}
      <p class="hint" style="margin-top:10px">Kept in its own file next to mineral.db — never mixed with billing data. It is in every backup
        (Marketing_yyyy-mm-dd.db) and moves with the data when the data location changes.</p></div></div>`;
  $('#mkf', box).onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    await guard(() => PUT('/api/mkt/settings', { enabled: f.enabled.checked, default_firm: f.default_firm.value, followup_days: f.followup_days.value,
      tracking_url: f.tracking_url.value, next_ref: f.next_ref.value,
      ...Object.fromEntries(['signer', 'sender_digipin', 'delivery_time', 'min_order_kg', 'min_order_mt', 'gst_note', 'payment_terms'].map(k => [k, f[k].value])) }));
    toast('Saved'); await mktMenu();
  };
};

// ---------- Settings → Data Location: Google Calendar link (Marketing follow-up calls) ----------
{
  const dataPage = SETTINGS.data;
  SETTINGS.data = async box => {
    await dataPage(box);
    const s = await GET('/api/mkt/settings');
    const card = document.createElement('div'); card.className = 'card';
    card.innerHTML = `<h3>📅 Google Calendar <span class="hint">— Marketing follow-up calls and Orders Book</span></h3>
      <p class="hint">The Apps Script web-app link (ends with <code>/exec</code>). Every planned call is sent to Google Calendar with the customer's phone and WhatsApp link. Every order in the Orders Book shows on the calendar from 3 days before its dispatch date until the dispatch date.</p>
      <div class="row"><label style="flex:1">Calendar link<input id="calurl" value="${esc(s.calendar_url)}" placeholder="https://script.google.com/macros/s/…/exec" autocomplete="off"></label>
        <button id="calsave">Save</button><button class="sec" id="caltest">Test connection</button></div>
      <p class="hint" style="margin-top:8px">Test connection creates one event 10 minutes from now named “Mineral Saathi — test connection”; delete it afterwards.</p>
      <div id="calres" style="margin-top:8px" hidden></div>`;
    box.appendChild(card);
    const inp = $('#calurl', card), res = $('#calres', card);
    const show = (ok, msg, reply) => { res.hidden = false;
      res.innerHTML = `<span class="badge ${ok ? 'PM' : 'red'}">${ok ? '✓ Connected' : '✕ Not connected'}</span> ${esc(msg)}${reply ? `<br><span class="hint">Google replied: ${esc(reply)}</span>` : ''}`; };
    $('#calsave', card).onclick = async () => { await guard(() => PUT('/api/mkt/settings', { calendar_url: inp.value })); toast(inp.value.trim() ? 'Calendar link saved' : 'Calendar link removed'); };
    $('#caltest', card).onclick = async () => {
      const b = $('#caltest', card); b.disabled = true; b.textContent = 'Testing…'; res.hidden = true;
      try { const r = await guard(() => POST('/api/mkt/calendar/test', { url: inp.value })); show(r.ok, r.message, r.reply); }
      catch { /* message shown */ } finally { b.disabled = false; b.textContent = 'Test connection'; }
    };
  };
}

// =====================================================================
// Phase 2 — enquiries and samples
// =====================================================================
// =====================================================================
// Enquiries and dispatches — a dispatch holds one or more samples, like an invoice holds items
// =====================================================================
const MKT_UPPER = 'style="text-transform:uppercase"';
const mktOpts = (vals, blank = true) => [...(blank ? [''] : []), ...vals];
const mktDue = d => { if (!d) return '<span class="muted">—</span>'; const t = today();
  return d < t ? `<span class="badge red">${dmy(d)} · late</span>` : d === t ? `<span class="badge amber">${dmy(d)} · today</span>` : dmy(d); };
// the courier's own tracking link (Master → Logistics → Postage & Couriers), else the general one
const mktLinkTpl = (ms, courier) => (ms.courier_links || {})[String(courier || '').trim().toUpperCase()] || ms.tracking_url;
const mktTrack = (url, no) => no ? (url ? `<a href="${esc(url.split('{tracking_no}').join(encodeURIComponent(no)))}" target="_blank" rel="noopener">${esc(no)}</a>` : esc(no)) : '';
const mktName = l => esc(l.company || l.buyer_name || '');
const LEAD_KEYS = ['gst', 'name', 'buyer_name', 'email', 'mobile1', 'mobile2', 'address', 'pincode', 'city', 'state', 'digipin', 'note'];
const LINE_KEYS = ['item_name', 'colour', 'mesh', 'form', 'grade', 'sample_size', 'rate', 'unit', 'bag_type', 'packing_type', 'liner', 'bag_weight', 'note'];

// the enquiry fields: GSTIN first, with "Get details from GST" (the company box is called "name" so the GST helper fills it)
function mktLeadFields(l = {}) {
  return `<div class="grid g2" style="gap:10px">
    <label class="span2">GSTIN <span class="hint">— first, to fill the rest from the GST portal</span><input name="gst" value="${esc(l.gst)}" ${MKT_UPPER} autocomplete="off" maxlength="15"></label>
    <label class="span2">Company<input name="name" value="${esc(l.company)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Buyer name<input name="buyer_name" value="${esc(l.buyer_name)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Email<input name="email" type="email" value="${esc(l.email)}" autocomplete="off"></label>
    <label>Mobile<input name="mobile1" value="${esc(l.mobile1)}" inputmode="numeric" autocomplete="off" placeholder="10 digits"></label>
    <label>Mobile 2<input name="mobile2" value="${esc(l.mobile2)}" inputmode="numeric" autocomplete="off"></label>
    <label class="span2">Address<textarea name="address" rows="2">${esc(l.address)}</textarea></label>
    <label>Pincode <span class="hint">(fills city &amp; state)</span><input name="pincode" value="${esc(l.pincode)}" inputmode="numeric" autocomplete="off"></label>
    <label>City<input name="city" value="${esc(l.city)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>State<select name="state">${STATES().map(x => `<option ${x === (l.state || '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}${l.state && !STATES().includes(l.state) ? `<option selected>${esc(l.state)}</option>` : ''}</select></label>
    <label>Digipin<input name="digipin" value="${esc(l.digipin)}" ${MKT_UPPER} autocomplete="off"></label>
    <label class="span2">Note<input name="note" value="${esc(l.note)}" autocomplete="off"></label>
  </div><div class="hint" data-buyerhint style="margin-top:8px"></div>`;
}
// digits only, pincode → city & state, GST portal, "Also a buyer" (read-only look into billing buyers)
function mktWireLead(root) {
  const f = n => $(`[name=${n}]`, root);
  for (const n of ['mobile1', 'mobile2', 'pincode']) f(n).addEventListener('input', e => { const v = e.target.value.replace(/\D/g, ''); if (v !== e.target.value) e.target.value = v; });
  for (const n of ['mobile1', 'mobile2']) f(n).addEventListener('blur', e => { const v = e.target.value; if (v.length > 10 && v.startsWith('91')) e.target.value = v.slice(-10); });
  const pin = async () => {
    if (f('pincode').value.length !== 6) return;
    const r = await GET('/api/pincode/' + f('pincode').value).catch(() => null);
    if (!r || !r.found) return;
    if (!f('city').value) f('city').value = (r.city || r.district || '').toUpperCase();
    const st = f('state'), v = String(r.state || '').toUpperCase();
    if (v && ![...st.options].some(o => o.value === v)) st.add(new Option(v, v));
    if (v) st.value = v;
  };
  f('pincode').addEventListener('input', () => { f('city').value = ''; pin(); });
  gstFetchBox(f('gst'), root);
  const hint = $('[data-buyerhint]', root);
  const check = async () => {
    const m = f('mobile1').value, g = f('gst').value;
    if (m.length !== 10 && g.length !== 15) { hint.innerHTML = ''; return; }
    const r = await GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(m)}&gst=${encodeURIComponent(g)}`).catch(() => []);
    hint.innerHTML = r.length ? '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ') + ' <span class="muted">(billing data is not changed)</span>' : '';
  };
  f('mobile1').addEventListener('blur', check); f('gst').addEventListener('blur', check);
  check();
  return { check };
}
const mktLeadData = form => { const o = {}; for (const k of LEAD_KEYS) o[k] = form.elements[k] ? form.elements[k].value : ''; o.company = o.name; delete o.name; return o; };

// ---------- New Sample Dispatch (also: edit a saved dispatch) ----------
// arg: ''  new · 'L12' new dispatch for enquiry 12 · 'D5' edit dispatch 5
// the different samples sent to a customer before (newest first), each once
function mktOldSamples(disps) {
  const out = [], seen = new Set();
  for (const d of disps || []) for (const l of d.lines || []) {
    const k = ['item_name', 'grade', 'colour', 'mesh', 'form', 'sample_size'].map(x => String(l[x] || '').toUpperCase()).join('|');
    if (seen.has(k)) { const o = out.find(x => x.k === k); o.times++; continue; }
    seen.add(k); out.push({ k, line: l, date: d.date, times: 1 });
  }
  return out;
}
function mktPickOld(old, done) {
  modal('Send an earlier sample again', `<p class="hint" style="margin-top:0">Samples sent to this customer before — tick the ones to send again. Rate and packing are copied; change them in the sample after adding if needed.</p>
    <div class="tablewrap" style="max-height:55vh"><table class="t"><thead><tr><th style="width:34px"><input type="checkbox" id="moall" style="width:auto"></th><th>Grade</th><th>Item</th><th>Colour · Mesh · Form</th><th>Sample</th><th class="num">Rate</th><th>Last sent</th></tr></thead><tbody>
    ${old.map((o, i) => { const l = o.line; return `<tr class="click" data-oi="${i}"><td><input type="checkbox" data-ochk="${i}" style="width:auto"></td><td><b>${esc(l.grade || '')}</b></td><td>${esc(l.item_name || '')}</td>
      <td>${esc([l.colour, l.mesh, l.form].filter(Boolean).join(' · '))}</td><td>${esc(l.sample_size || '')}</td><td class="num">${l.rate != null && l.rate !== '' ? '₹' + esc(l.rate) + (l.unit ? ' / ' + esc(l.unit) : '') : ''}</td>
      <td>${dmy(o.date)}${o.times > 1 ? ` <span class="hint">(${o.times} times)</span>` : ''}</td></tr>`; }).join('')}</tbody></table></div>
    <div class="row" style="margin-top:10px"><button id="moadd" disabled>Add the ticked samples</button></div>`, root => {
    const upd = () => { const n = $$('[data-ochk]', root).filter(c => c.checked).length; const b = $('#moadd', root); if (!b) return; b.disabled = !n; b.textContent = n ? `Add ${n} sample${n === 1 ? '' : 's'}` : 'Add the ticked samples'; };
    root.addEventListener('click', e => { const tr = e.target.closest('tr[data-oi]'); if (tr && !e.target.matches('input')) { const c = $(`[data-ochk="${tr.dataset.oi}"]`, root); c.checked = !c.checked; } upd(); });
    $('#moall', root).onchange = e => { $$('[data-ochk]', root).forEach(c => { c.checked = e.target.checked; }); upd(); };
    $('#moadd', root).onclick = () => { const picked = $$('[data-ochk]', root).filter(c => c.checked).map(c => { const l = { ...old[Number(c.dataset.ochk)].line }; delete l.id; delete l.dispatch_id; return l; }); closeModal(); done(picked); };
  });
}
async function mktSampleForm(el, arg) {
  await loadLists(true);
  const [ml, ms] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/settings')]);
  const editId = /^D\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let leadId = /^L\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let lead = {}, disp = { date: today(), firm_code: ms.default_firm }, lines = [{}], lastDisp = null, allDisp = [];
  if (editId) { const r = await GET('/api/mkt/dispatches/' + editId); disp = r.dispatch; lines = r.lines; lead = r.lead; leadId = lead.id; }
  else if (leadId) { const r = await GET('/api/mkt/leads/' + leadId); lead = r.lead; lastDisp = r.dispatches[0] || null; allDisp = r.dispatches || []; }
  const nextRef = editId || leadId ? null : (await GET('/api/mkt/next-ref')).ref_no;
  $('#title').textContent = editId ? `Edit dispatch · Ref ${lead.ref_no}` : 'New Sample Dispatch';
  const defUnit = lv('unit').includes('KG') ? 'KG' : '';

  const sel = (name, label, vals, v, extra = '') => `<label ${extra}>${label}<select name="${name}">${[...new Set([...vals, ...(v != null && v !== '' ? [String(v)] : [])])]
    .map(x => `<option value="${esc(x)}" ${String(x) === String(v ?? '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>`;
  const ms1 = k => (ml[k] || []).map(x => x.value);
  const lineHtml = (ln, i) => `<div class="mline" data-line style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:10px">
    <div class="row" style="justify-content:space-between;margin-bottom:6px"><b data-lno>Sample ${i + 1}</b>
      <span><button type="button" class="small sec" data-ldup title="Copy this sample into a new one">⧉ Duplicate</button> <button type="button" class="small sec" data-ldel>✕ Remove</button></span></div>
    <div class="grid g6" style="gap:8px">
      ${sel('item_name', 'Item', mktOpts(lv('product')), ln.item_name, 'class="span2"')}
      ${sel('colour', 'Colour', mktOpts(lv('colour')), ln.colour)}${sel('mesh', 'Mesh', mktOpts(lv('mesh')), ln.mesh)}${sel('form', 'Form', mktOpts(lv('form')), ln.form)}
      <label>Grade <span class="hint">(fills itself)</span><input name="grade" value="${esc(ln.grade)}" ${MKT_UPPER} autocomplete="off" data-auto="${ln.grade ? 0 : 1}"></label>
      ${sel('sample_size', 'Sample size', mktOpts(ms1('sample_size')), ln.sample_size)}
      <label>Rate ₹<input name="rate" type="number" step="0.01" value="${esc(ln.rate)}"></label>
      ${sel('unit', 'Per', mktOpts(lv('unit')), ln.unit ?? defUnit)}
      ${sel('bag_type', 'Bag type', mktOpts(lv('bag_type')), ln.bag_type)}
      ${sel('packing_type', 'Packing type', mktOpts(lv('packing_type')), ln.packing_type)}
      <label>Liner<select name="liner"><option value=""></option><option value="1" ${ln.liner === 1 || ln.liner === '1' ? 'selected' : ''}>With liner</option><option value="0" ${ln.liner === 0 || ln.liner === '0' ? 'selected' : ''}>Without liner</option></select></label>
      ${sel('bag_weight', 'Bag weight (kg)', mktOpts(lv('bag_weight')), ln.bag_weight)}
      <label style="grid-column:span 5">Note on this sample<input name="note" value="${esc(ln.note)}" autocomplete="off"></label>
    </div></div>`;

  el.innerHTML = `
  ${editId ? '' : `<div class="card" style="position:relative">
    <div class="row" style="align-items:end">
      <label style="flex:1">Find enquiry <span class="hint">— Ref No., mobile, company or name</span><input id="mfind" autocomplete="off" placeholder="Type to search…"></label>
      <div id="mstate" style="padding-bottom:9px"></div></div>
    <div id="mres" class="card" style="position:absolute;left:16px;right:16px;z-index:5;max-height:320px;overflow:auto;padding:4px" hidden></div>
  </div>`}
  <form id="msf" autocomplete="off">
  <div class="grid" style="grid-template-columns:minmax(380px,1fr) minmax(380px,1fr);align-items:start">
    <div class="card" id="mlead"><h3>Customer <span id="mref" class="hint"></span></h3>${mktLeadFields(lead)}</div>
    <div><div class="card" id="mdisp"><h3>Dispatch</h3>
      <div class="grid g2" style="gap:10px">
        <label>Date<input name="d_date" type="date" value="${esc(disp.date)}"></label>
        <label>Sender<select name="d_firm_code">${(ms.firms.length ? ms.firms : [{ code: disp.firm_code || 'PM', name: disp.firm_code || 'PM' }])
          .map(x => `<option value="${esc(x.code)}" ${x.code === disp.firm_code ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
        ${sel('d_courier', 'Sent by', mktOpts(ms1('courier')), disp.courier)}
        <label>Tracking no.<input name="d_tracking_no" value="${esc(disp.tracking_no)}" ${MKT_UPPER} autocomplete="off"></label>
        <label>No. of parcels / bags <span class="hint">(a bag sticker each)</span><input name="d_parcels" type="number" step="1" min="0" value="${esc(disp.parcels)}"></label>
        <label>Total weight (kg)<input name="d_total_weight" type="number" step="0.001" min="0" value="${esc(disp.total_weight)}"></label>
        <label style="display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:9px"><input type="checkbox" name="d_freight_to_pay" style="width:auto" ${disp.freight_to_pay ? 'checked' : ''}> Freight to pay</label>
        <label>Delivered on<input name="d_delivered_on" type="date" value="${esc(disp.delivered_on)}"></label>
        <label class="span2">Note on dispatch<input name="d_note" value="${esc(disp.note)}" autocomplete="off"></label>
      </div>
      <p class="hint" style="margin:10px 0 0">After saving, the print window opens: one <b>sample sticker for each sample</b> and <b>one cover letter</b> for the whole dispatch are ticked.</p></div>
    <div class="card" id="mdrop"><h3>Fill from a file <span class="hint">— visiting card, letterhead, GST certificate, e-mail screenshot or PDF</span></h3>
      <div id="mdz" tabindex="0" style="border:2px dashed #9fc9d4;border-radius:12px;background:#f5fbfc;min-height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:14px;text-align:center;cursor:pointer;outline:none">
        <div style="font-size:30px">📋</div>
        <div><b>Paste</b> a picture here (Ctrl+V), <b>drop</b> a picture or PDF, or <button type="button" class="small sec" id="mdpick">Choose file…</button></div>
        <div class="hint">A GSTIN is looked up on the GST portal as before; otherwise the details are read from the file. Only empty boxes are filled.</div>
      </div>
      <input type="file" id="mdfile" accept="image/*,application/pdf" hidden>
      <div id="mdres" style="margin-top:10px" hidden></div></div></div>
  </div>
  <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px">
      <h3 style="margin:0">Samples in this dispatch <span class="badge grey" id="mcount"></span> <span class="hint">— item details from <a href="#/itemlists">Master → Item List</a></span></h3>
      <span id="mlast"></span></div>
    <div id="mlines">${lines.map(lineHtml).join('')}</div>
    <button type="button" class="sec" id="maddline">+ Add sample</button></div>
  <div class="card row" style="justify-content:space-between">
    <div class="row"><button type="submit">${editId ? 'Save changes' : 'Save dispatch'}</button>
      ${editId ? '' : '<button type="button" class="sec" id="monly">Save customer only</button>'}
      <button type="button" class="sec" id="mcancel">Cancel</button></div>
    <span class="hint">${editId ? '' : `Saving plans the first call “Did the sample arrive?” ${ms.followup_days} days after the dispatch date.`}</span>
  </div></form>`;

  const form = $('#msf', el), f = n => form.elements[n], linesBox = $('#mlines', el);
  markDirty(form); const lw = mktWireLead($('#mlead', el));

  // each sample line: grade fills itself from colour + mesh (same rule as Buyers → items), e.g. YELLOW + 300 → Y300 MESH
  const renumber = () => { const ls = $$('[data-line]', linesBox); ls.forEach((x, i) => { $('[data-lno]', x).textContent = `Sample ${i + 1}`; $('[data-ldel]', x).hidden = ls.length === 1; });
    $('#mcount', el).textContent = `${ls.length} sample${ls.length === 1 ? '' : 's'} · ${ls.length} sticker${ls.length === 1 ? '' : 's'}`; };
  linesBox.addEventListener('change', e => {
    const box = e.target.closest('[data-line]'); if (!box || !['colour', 'mesh', 'form'].includes(e.target.name)) return;
    const g = $('[name=grade]', box); if (g.dataset.auto !== '1') return;
    const form_ = $('[name=form]', box).value, mesh = $('[name=mesh]', box).value, col = $('[name=colour]', box).value;
    g.value = mesh && (!form_ || form_ === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form_ || '');
  });
  linesBox.addEventListener('input', e => { if (e.target.name === 'grade') e.target.dataset.auto = e.target.value ? '0' : '1'; });
  const lineVals = box => { const o = {}; for (const k of LINE_KEYS) o[k] = $(`[name=${k}]`, box).value; return o; };
  const addLine = (ln = {}) => { linesBox.insertAdjacentHTML('beforeend', lineHtml(ln, 0)); renumber(); S.dirty = true; return linesBox.lastElementChild; };
  linesBox.addEventListener('click', e => {
    const box = e.target.closest('[data-line]'); if (!box) return;
    if (e.target.closest('[data-ldel]') && $$('[data-line]', linesBox).length > 1) { box.remove(); renumber(); S.dirty = true; }
    if (e.target.closest('[data-ldup]')) { const v = lineVals(box); const nb = addLine(v); $('[name=grade]', nb).dataset.auto = '0'; $('[name=sample_size]', nb).focus(); }
  });
  $('#maddline', el).onclick = () => { const nb = addLine({ unit: defUnit }); $('[name=item_name]', nb).focus(); };
  renumber();

  const setLead = (l, last, alls) => {
    allDisp = alls || (last ? [last] : []);
    leadId = l ? l.id : null; lead = l || {};
    const box = $('#mlead', el);
    for (const k of LEAD_KEYS) { const e = box.querySelector(`[name=${k}]`); if (!e) continue; const v = (k === 'name' ? lead.company : lead[k]) ?? '';
      if (e.tagName === 'SELECT' && v && ![...e.options].some(o => o.value === v)) e.add(new Option(v, v)); e.value = v; }
    $('#mref', el).innerHTML = leadId ? `· <b>Ref ${lead.ref_no}</b> — existing enquiry` : `· new, will be <b>Ref ${nextRef}</b>`;
    const st = $('#mstate', el); if (st) st.innerHTML = leadId ? `<button type="button" class="small sec" id="mnewlead">Start a new customer instead</button>` : '';
    const nb = $('#mnewlead', el); if (nb) nb.onclick = () => setLead(null, null);
    lastDisp = last || null;
    $('#mlast', el).innerHTML = lastDisp ? `<span class="hint">Last dispatch ${dmy(lastDisp.date)}: ${esc(lastDisp.lines.map(x => [x.grade || x.item_name, x.sample_size].filter(Boolean).join(' ')).join(', '))}</span>
      <button type="button" class="small sec" id="mcopy">Copy last dispatch</button>` : '';
    // all samples sent to this customer before: tick the ones to send again (added to the samples below, new ones can be added too)
    const old = mktOldSamples(allDisp);
    if (old.length) $('#mlast', el).insertAdjacentHTML('beforeend', ` <button type="button" class="small" id="mold">📦 Send an earlier sample again (${old.length})</button>`);
    const ob = $('#mold', el); if (ob) ob.onclick = () => mktPickOld(old, picked => {
      const ls = $$('[data-line]', linesBox), empty = ls.length === 1 && !LINE_KEYS.some(k => k !== 'unit' && $(`[name=${k}]`, ls[0]).value);
      if (empty) ls[0].remove();
      for (const ln of picked) { const nb = addLine(ln); $('[name=grade]', nb).dataset.auto = '0'; }
      renumber(); toast(`${picked.length} earlier sample${picked.length === 1 ? '' : 's'} added — add new ones with “+ Add sample”`); });
    const cp = $('#mcopy', el); if (cp) cp.onclick = () => {
      linesBox.innerHTML = lastDisp.lines.map(lineHtml).join(''); $$('[name=grade]', linesBox).forEach(g => g.dataset.auto = '0'); renumber();
      f('d_courier').value = lastDisp.courier || ''; f('d_firm_code').value = lastDisp.firm_code || f('d_firm_code').value;
      S.dirty = true; toast(`Copied ${lastDisp.lines.length} sample${lastDisp.lines.length === 1 ? '' : 's'} — check the date and tracking no.`); };
    $('[data-buyerhint]', el).innerHTML = ''; lw.check();
  };
  if (!editId) setLead(leadId ? lead : null, lastDisp, allDisp); else $('#mref', el).innerHTML = `· <b>Ref ${lead.ref_no}</b>`;
  mktDropZone(el, lw);
  S.dirty = false;
  f('gst').focus();

  // find an enquiry
  const fi = $('#mfind', el), res = $('#mres', el); let ft;
  if (fi) {
    fi.oninput = () => { clearTimeout(ft); ft = setTimeout(async () => {
      const q = fi.value.trim(); if (!q) { res.hidden = true; return; }
      const rows = await GET('/api/mkt/find?q=' + encodeURIComponent(q)).catch(() => []);
      res.hidden = false;
      res.innerHTML = rows.length ? rows.map(r => `<a class="listhead" data-lid="${r.id}"><b>Ref ${r.ref_no}</b> · ${mktName(r)}${r.company && r.buyer_name ? ` <span class="hint">${esc(r.buyer_name)}</span>` : ''}
        <span class="hint" style="float:right">${esc([r.city, r.state].filter(Boolean).join(', '))} · ${esc(r.mobile1 || '')}</span></a>`).join('')
        : '<div class="muted" style="padding:8px">No enquiry found — fill in the customer below for a new one.</div>';
    }, 220); };
    fi.onkeydown = e => { if (e.key === 'Escape') res.hidden = true; };
    res.onclick = async e => { const a = e.target.closest('[data-lid]'); if (!a) return;
      const r = await guard(() => GET('/api/mkt/leads/' + a.dataset.lid)); res.hidden = true; fi.value = '';
      setLead(r.lead, r.dispatches[0], r.dispatches); S.dirty = false; };
    document.addEventListener('click', e => { if (!e.target.closest('#mres') && e.target !== fi) res.hidden = true; });
  }

  const dispData = () => { const o = {}; for (const k of ['date', 'firm_code', 'courier', 'tracking_no', 'parcels', 'total_weight', 'delivered_on', 'note']) o[k] = f('d_' + k).value;
    o.freight_to_pay = f('d_freight_to_pay').checked ? 1 : 0; return o; };
  const linesData = () => $$('[data-line]', linesBox).map(lineVals);
  // the server refuses a second customer with the same mobile; the user may still choose to keep both
  const send = async fn => { try { return await fn(false); } catch (e) {
    if (/is already Ref \d+/.test(e.message) && !leadId && confirm(e.message + '\n\nSave it as a separate customer anyway?')) return guard(() => fn(true));
    toast(e.message, true); return null; } };

  form.onsubmit = async e => {
    e.preventDefault();
    const body = dup => ({ lead_id: leadId, lead: mktLeadData($('#mlead', el).closest('form')), dispatch: dispData(), lines: linesData(), allow_duplicate: dup });
    if (editId) {
      const r = await send(dup => PUT('/api/mkt/dispatches/' + editId, body(dup))); if (!r) return;
      S.dirty = false; toast('Dispatch changed'); go('#/mkt/leads:' + r.lead_id); return;
    }
    const r = await send(dup => POST('/api/mkt/dispatches', body(dup))); if (!r) return;
    S.dirty = false; S.mktPrint = r.dispatch_id; toast(`Dispatch saved · Ref ${r.ref_no} · ${r.samples} sample${r.samples === 1 ? '' : 's'} · first call ${dmy(r.follow_up.due_date)}`); go('#/mkt/leads:' + r.lead_id);
  };
  const only = $('#monly', el); if (only) only.onclick = async () => {
    const ld = mktLeadData(form);
    const r = await send(dup => leadId ? PUT('/api/mkt/leads/' + leadId, { lead: ld, allow_duplicate: dup }) : POST('/api/mkt/leads', { lead: ld, allow_duplicate: dup })); if (!r) return;
    S.dirty = false; toast(leadId ? 'Customer saved' : `Customer saved · Ref ${r.ref_no}`); go('#/mkt/leads:' + r.id);
  };
  $('#mcancel', el).onclick = () => { if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return; S.dirty = false; history.length > 1 ? history.back() : go('#/mkt/leads'); };
}

// ---------- Enquiries list ----------
async function mktLeadsList(el) {
  el.innerHTML = `<div class="card"><div class="row" style="justify-content:space-between">
      <div class="row"><input id="lq" placeholder="Search: Ref No., company, name, mobile, city or state" style="width:420px" autocomplete="off"><span class="hint" id="lcount"></span></div>
      <div class="row"><button class="sec" id="lcsv">Export CSV</button><button id="lnew">+ New sample dispatch</button></div></div>
    <div class="tablewrap" style="margin-top:10px"><table class="t"><thead><tr><th>Ref</th><th>Company / buyer</th><th>City, state</th><th>Mobile</th><th class="num">Samples</th><th>Last dispatch</th><th>Next call</th></tr></thead>
    <tbody id="lbody"><tr><td colspan="7" class="muted">Loading…</td></tr></tbody></table></div></div>`;
  let rows = [], t;
  const load = async () => {
    const q = $('#lq', el).value.trim();
    rows = await GET('/api/mkt/leads?limit=1000&q=' + encodeURIComponent(q));
    $('#lcount', el).textContent = `${rows.length}${rows.length === 1000 ? '+' : ''} enquir${rows.length === 1 ? 'y' : 'ies'}`;
    $('#lbody', el).innerHTML = rows.map(r => `<tr class="click" data-lid="${r.id}"><td><b>${r.ref_no}</b></td>
      <td><b>${mktName(r)}</b>${r.company && r.buyer_name ? `<br><span class="hint">${esc(r.buyer_name)}</span>` : ''}${r.became_buyer_id ? ' <span class="badge PM">buyer</span>' : ''}</td>
      <td>${esc([r.city, r.state].filter(Boolean).join(', '))}</td><td>${esc(r.mobile1 || '')}</td><td class="num">${r.samples || ''}</td>
      <td>${r.last_sample ? esc(dmy(r.last_sample.slice(0, 10)) + r.last_sample.slice(10)) : '<span class="muted">—</span>'}</td><td>${mktDue(r.next_call)}</td></tr>`).join('')
      || `<tr><td colspan="7" class="muted">${q ? 'Nothing found.' : 'No enquiries yet. Press “+ New sample dispatch” to add the first one.'}</td></tr>`;
  };
  $('#lq', el).oninput = () => { clearTimeout(t); t = setTimeout(load, 250); };
  $('#lq', el).focus();
  $('#lnew', el).onclick = () => go('#/mkt/new');
  $('#lcsv', el).onclick = () => downloadCsv('enquiries.csv', rows.map(r => ({ ref_no: r.ref_no, company: r.company, buyer: r.buyer_name, city: r.city, state: r.state, mobile: r.mobile1,
    samples: r.samples, last_dispatch: r.last_sample, next_call: r.next_call })));
  $('#lbody', el).onclick = e => { const tr = e.target.closest('[data-lid]'); if (tr) go('#/mkt/leads:' + tr.dataset.lid); };
  await load();
}

// ---------- one enquiry: details, dispatches with their samples, calls ----------
async function mktLeadPage(el, id) {
  const [d, ms] = await Promise.all([GET('/api/mkt/leads/' + id), GET('/api/mkt/settings')]);
  const l = d.lead, nS = d.dispatches.reduce((a, x) => a + x.lines.length, 0);
  $('#title').textContent = `Ref ${l.ref_no} · ${l.company || l.buyer_name || ''}`;
  const line = (k, v) => v ? `<tr><td class="hint" style="width:110px">${k}</td><td>${v}</td></tr>` : '';
  const firm = c => (ms.firms.find(x => x.code === c) || {}).name || c || '';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(320px,1fr) 2fr;align-items:start">
    <div class="card" id="ldet"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Customer · Ref ${l.ref_no}</h3>
        <span>${l.became_buyer_id ? '' : '<button class="small" id="lbuyer" title="Copy this customer into Master → Buyer B2B">🤝 Make Buyer</button> '}<button class="small sec" id="ledit">Edit</button>${d.dispatches.length || d.communications.length ? '' : ' <button class="small sec" id="ldel">Delete</button>'}</span></div>
      <table class="t" style="margin-top:8px"><tbody>
        ${line('GSTIN', esc(l.gst))}${line('Company', `<b>${esc(l.company || '')}</b>`)}${line('Buyer', esc(l.buyer_name))}
        ${line('Mobile', [l.mobile1, l.mobile2].filter(Boolean).map(m => `<a href="tel:${esc(m)}">${esc(m)}</a>`).join(', '))}
        ${line('Email', l.email ? `<a href="mailto:${esc(l.email)}">${esc(l.email)}</a>` : '')}
        ${line('Address', esc([l.address, [l.city, l.pincode].filter(Boolean).join(' - '), l.state].filter(Boolean).join('\n')).replace(/\n/g, '<br>'))}
        ${line('Digipin', esc(l.digipin))}${line('Note', esc(l.note))}
        ${l.legacy ? '' : line('Since', dmy(String(l.created_at || '').slice(0, 10)))}
      </tbody></table><div class="hint" data-buyerhint></div>${l.became_buyer_id ? `<div class="firmbox" style="margin-top:8px" data-became>🤝 Became a buyer</div>` : ''}${l.legacy ? '<p class="hint" style="margin:8px 0 0">Brought from the Excel workbook.</p>' : ''}</div>
    <div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Dispatches · ${d.dispatches.length} <span class="hint">(${nS} sample${nS === 1 ? '' : 's'})</span></h3>
          <button id="lnewsample">+ New dispatch for this customer</button></div>
        ${d.dispatches.map(x => `<div style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-top:10px">
          <div class="row" style="justify-content:space-between"><div><b>${x.date ? dmy(x.date) : 'Date not known'}</b>${x.legacy ? ' <span class="badge grey">from Excel</span>' : ''} · ${esc(x.courier || '')} ${mktTrack(mktLinkTpl(ms, x.courier), x.tracking_no)}
            ${x.freight_to_pay ? '<span class="badge amber">to pay</span>' : ''} <span class="hint">${esc(firm(x.firm_code))}${x.parcels ? ` · ${x.parcels} parcel${x.parcels === 1 ? '' : 's'}` : ''}${x.total_weight ? ` · ${kg(x.total_weight)} kg` : ''}${x.delivered_on ? ` · delivered ${dmy(x.delivered_on)}` : ''}</span></div>
            <span style="white-space:nowrap"><span data-smst="${x.id}"></span> <button class="small" data-dprint="${x.id}">🖨 Print</button> <button class="small sec" data-dmail="${x.id}" title="Email the sample dispatch letter with the tracking number to the customer">✉ Email</button> <button class="small sec" data-dwa="${x.id}" title="Send on WhatsApp (linked template)">💬</button> <button class="small sec" data-ded="${x.id}">Edit</button> <button class="small sec" data-ddel="${x.id}">Delete</button></span></div>
          <table class="t" style="margin-top:6px"><thead><tr><th>#</th><th>Grade · item</th><th>Size</th><th class="num">Rate</th><th>Packing</th><th>Note</th></tr></thead><tbody>
          ${x.lines.map((s, i) => `<tr><td>${i + 1}</td><td><b>${esc(s.grade || '')}</b> <span class="hint">${esc(s.item_name || '')}</span></td><td>${esc(s.sample_size || '')}</td>
            <td class="num">${s.rate != null ? money(s.rate) + (s.unit ? ' / ' + esc(s.unit) : '') : ''}</td>
            <td>${esc([s.bag_type, s.packing_type, s.liner === 1 ? 'WITH LINER' : s.liner === 0 ? 'WITHOUT LINER' : '', s.bag_weight ? kg(s.bag_weight) + ' KG' : ''].filter(Boolean).join(' · '))}</td>
            <td>${esc(s.note || '')}</td></tr>`).join('')}</tbody></table>
          ${x.note ? `<p class="hint" style="margin:6px 0 0">${esc(x.note)}</p>` : ''}</div>`).join('') || '<p class="muted" style="margin-top:10px">No sample sent yet.</p>'}</div>
      <div class="card"><h3>Calls</h3>
        <table class="t"><thead><tr><th>Due</th><th>Reason</th><th>Status</th></tr></thead><tbody>
        ${d.follow_ups.map(x => `<tr><td>${x.status === 'PENDING' ? mktDue(x.due_date) : dmy(x.due_date)}</td><td>${esc(x.reason || '')}</td>
          <td>${x.status === 'PENDING' ? '<span class="badge amber">Pending</span>' : `<span class="badge grey">${esc(x.status)}</span>${x.done_on ? ' ' + dmy(x.done_on) : ''}`}</td></tr>`).join('')
          || '<tr><td colspan="3" class="muted">No calls planned.</td></tr>'}</tbody></table>
        ${d.communications.length ? `<h4 style="margin:14px 0 6px">History</h4><table class="t"><tbody>${d.communications.map(c => `<tr><td style="width:100px">${dmy(c.date)}</td>
          <td>${esc(c.channel || '')}</td><td>${esc([c.response, c.note].filter(Boolean).join(' — '))}</td></tr>`).join('')}</tbody></table>` : ''}
        <div class="row" style="margin-top:10px"><button class="small" onclick="go('#/mkt/comm:L${l.id}')">💬 Communication — log a call, WhatsApp, next call</button></div></div>
    </div></div>`;
  GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(l.mobile1 || '')}&gst=${encodeURIComponent(l.gst || '')}`).then(r => {
    if (r.length) $('[data-buyerhint]', el).innerHTML = '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ');
  }).catch(() => {});
  $('#lnewsample', el).onclick = () => go('#/mkt/new:L' + l.id);
  if ($('#lbuyer', el)) $('#lbuyer', el).onclick = () => mktMakeBuyer(l, () => mktLeadPage(el, id));
  if (l.became_buyer_id) GET('/api/m/parties/' + l.became_buyer_id).then(b => {
    const box = $('[data-became]', el); if (!box) return;
    box.innerHTML = b ? `🤝 Became a buyer: <b>${esc(b.name)}</b> <span class="badge ${esc(b.firm_code || 'grey')}">${esc(b.firm_code || '')}</span> — <a href="#/buyers">Master → Buyer B2B</a>
      <button class="small sec" id="lunbuyer" style="margin-left:6px">Unlink</button>` : '🤝 Became a buyer (removed from Buyer B2B since). <button class="small sec" id="lunbuyer">Unlink</button>';
    $('#lunbuyer', box).onclick = async () => { if (!confirm('Unlink this enquiry from the buyer? The buyer stays in Master → Buyer B2B.')) return; await guard(() => DEL(`/api/mkt/leads/${l.id}/buyer`)); mktLeadPage(el, id); };
  }).catch(() => {});
  if (S.mktPrint && d.dispatches.some(x => x.id === S.mktPrint)) { const pid = S.mktPrint; S.mktPrint = null; mktPrintBox(pid, l); }
  $('#ledit', el).onclick = () => {
    const box = $('#ldet', el);
    box.innerHTML = `<h3>Edit customer · Ref ${l.ref_no}</h3><form id="lef" autocomplete="off">${mktLeadFields(l)}
      <div class="row" style="margin-top:10px"><button type="submit">Save</button><button type="button" class="sec" id="lecancel">Cancel</button></div></form>`;
    const fm = $('#lef', box); mktWireLead(fm); markDirty(fm);
    $('#lecancel', box).onclick = () => { S.dirty = false; mktLeadPage(el, id); };
    fm.onsubmit = async e => { e.preventDefault(); const o = mktLeadData(fm);
      try { await PUT('/api/mkt/leads/' + id, { lead: o }); }
      catch (err) { if (!(/is already Ref \d+/.test(err.message) && confirm(err.message + '\n\nKeep this number on both customers?'))) { toast(err.message, true); return; }
        await guard(() => PUT('/api/mkt/leads/' + id, { lead: o, allow_duplicate: true })); }
      S.dirty = false; toast('Customer saved'); mktLeadPage(el, id); };
  };
  sampleMailBadges(el, d.dispatches.map(x => x.id));
  const del = $('#ldel', el); if (del) del.onclick = async () => { if (!confirm(`Delete enquiry Ref ${l.ref_no}?`)) return; await guard(() => DEL('/api/mkt/leads/' + id)); toast('Enquiry deleted'); go('#/mkt/leads'); };
  el.onclick = async e => {
    const ed = e.target.closest('[data-ded]'), dl = e.target.closest('[data-ddel]'), pr = e.target.closest('[data-dprint]');
    if (pr) mktPrintBox(Number(pr.dataset.dprint), d.lead);
    const ml = e.target.closest('[data-dmail]'); if (ml) sampleEmail(Number(ml.dataset.dmail), () => mktLeadPage(el, id));
    const wa = e.target.closest('[data-dwa]'); if (wa) waFor('SAMPLE', { id: Number(wa.dataset.dwa) });
    if (ed) go('#/mkt/new:D' + ed.dataset.ded);
    if (dl && confirm('Delete this dispatch and all its samples? Its planned call is removed too.')) { await guard(() => DEL('/api/mkt/dispatches/' + dl.dataset.ddel)); toast('Dispatch deleted'); mktLeadPage(el, id); }
  };
}

// ---------- sample dispatch email (template: Settings → Email templates → Sample dispatch) ----------
async function sampleMailBadges(el, ids) {
  if (!ids.length) return;
  const st = await GET('/api/sample-mail-status?ids=' + ids.join(',')).catch(() => ({}));
  for (const [id, m] of Object.entries(st)) {
    const sp = $(`[data-smst="${id}"]`, el); if (!sp) continue;
    const at = m.at ? dmy(String(m.at).slice(0, 10)) + ' ' + String(m.at).slice(11, 16) : '';
    sp.innerHTML = m.status === 'SENT' ? `<span class="badge" title="To ${esc(m.to || '')} · tracking ${esc(m.tracking_no || '')}">✉ emailed ${at}</span>`
      : m.status === 'WAIT' ? `<span class="badge amber" title="Goes by itself at ${at}">⚡ email at ${String(m.at).slice(11, 16)}</span>`
      : m.status === 'FAILED' ? `<span class="badge amber" title="${esc(m.error || '')}">✉ email failed — tried again every hour</span>`
      : m.status === 'NO EMAIL' ? '<span class="badge grey" title="Add the customer email to send it">no email address</span>' : '';
  }
}
async function sampleEmail(id, after) {
  const d = await guard(() => GET('/api/sample-mail/' + id));
  modal(`Email sample dispatch · ${d.company}`, `${d.ready ? '' : `<p class="badge amber">Email is not set up for ${esc(d.firm)}. Open Settings → Companies → Email sending first.</p>`}
    ${d.tracking_no ? '' : '<p class="badge amber" style="display:block;padding:8px 10px">This dispatch has no tracking number yet — add it with Edit, or send without it.</p>'}
    <form id="smf"><div class="grid g2">
      ${d.templates.length > 1 ? `<label class="span2">Email template<select id="smtpl">${d.templates.map(x => `<option value="${x.id}">${esc(x.name)}${x.is_default ? ' (default)' : ''}</option>`).join('')}</select></label>` : ''}
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      ${d.anreps && d.anreps.length ? `<div class="span2 firmbox" style="margin:0"><label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="smanrep" style="width:auto" ${d.with_anrep ? 'checked' : ''}> 🧪 Send the Analysis report with this email?</label>
          <div class="row" style="gap:8px;margin-top:6px;flex-wrap:wrap">${d.anreps.map(r => `<span>${esc(r.name)}</span><button type="button" class="small sec" data-anprev="${r.id}">👁 Preview</button>`).join('')}</div></div>`
        : '<p class="hint span2" style="margin:0">No analysis report fits these grades (Master → Analysis Reports).</p>'}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span> <span class="hint">— change anything before sending (tracking number, rates …)</span>${richArea('text', d.html || textToHtmlC(d.text), 320)}</div></div>
      <div class="row" style="margin-top:8px"><button type="submit" ${d.ready ? '' : 'disabled'}>Send email</button><span class="hint">Sent from ${esc(d.from || '')} (${esc(d.firm)}). Change the words in Settings → Email templates → Sample dispatch.</span></div></form>`, root => {
    richInit(root);
    const ts = $('#smtpl', root); if (ts) ts.onchange = async () => { const r = await guard(() => GET(`/api/sample-mail/${id}?tid=${ts.value}`)); richSet(root, 'text', r.html || textToHtmlC(r.text)); const c = $('#smanrep', root); if (c) c.checked = !!r.with_anrep; };
    $$('[data-anprev]', root).forEach(b => b.onclick = () => window.open(`/print/anreport/${b.dataset.anprev}?dispatch=${id}`, '_blank'));
    $('#smf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const f = e.target;
      try { await POST('/api/sample-mail/' + id, { anrep: $('#smanrep', root) && $('#smanrep', root).checked ? 1 : 0, to: f.to.value, cc: f.cc.value, subject: f.subject.value, text: f.text.value, html: f.html.value,
          template_name: ts ? ts.selectedOptions[0].text.replace(' (default)', '') : (d.templates[0] || {}).name || 'Standard message' });
        toast('Email sent'); closeModal(); after && after(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ---------- print the papers of a dispatch ----------
const MKT_KIND = { invoice: 'A4 printer', label: '4×6 label printer', envelope: 'Envelope printer' };
async function mktPrintBox(dispatchId, lead) {
  const [pd, last, drivers] = await Promise.all([GET('/api/mkt/print-docs'), GET(`/api/mkt/dispatches/${dispatchId}/freight`), GET('/api/m/local_drivers').catch(() => [])]);
  let ticked = JSON.parse(localStorage.getItem('mkt_print_ticks') || 'null') || pd.docs.filter(x => x.def).map(x => x.key);
  const kindLine = x => (x.printer ? esc(x.printer) : '<span class="badge amber">no printer chosen — opens the print window</span>') + `<br><span class="hint">${esc(x.paper)}</span>`;
  modal(`Print · Ref ${lead.ref_no} · ${lead.company || lead.buyer_name || ''}`, `
    <form id="mpf">
      <table class="t"><thead><tr><th style="width:30px"></th><th>Paper</th><th>Printer on this computer</th><th></th></tr></thead><tbody>
      ${pd.docs.map(x => `<tr><td><input type="checkbox" name="doc" value="${x.key}" style="width:auto" ${ticked.includes(x.key) ? 'checked' : ''}></td>
        <td><b>${esc(x.name)}</b>${x.note ? `<br><span class="hint">${esc(x.note)}</span>` : ''}</td>
        <td>${kindLine(x)}</td>
        <td><a href="/print/mkt/${x.key}/${dispatchId}" target="_blank" class="small">${x.key === 'note' ? 'Open &amp; edit' : 'Preview'}</a></td></tr>`).join('')}
      </tbody></table>
      <div id="mpfr" class="card" style="margin-top:10px;background:#fafcfc" hidden><h4 style="margin:0 0 8px">Local freight letter</h4>
        <div class="grid g3" style="gap:8px">
          <label>Driver<input name="driver" list="mpdrv" value="${esc(last.driver || '')}" style="text-transform:uppercase"></label>
          ${datalist('mpdrv', drivers.map(x => x.name))}
          <label>Vehicle no.<input name="tempo_no" value="${esc(last.tempo_no || '')}" style="text-transform:uppercase"></label>
          <label>Mobile<input name="mobile" value="${esc(last.mobile || '')}" inputmode="numeric"></label>
          <label>Amount ₹<input name="amount" type="number" step="1" value="${esc(last.amount || '')}"></label>
          <label class="span2">From our factory at<input name="from_place" value="${esc(last.from_place || '')}"></label>
        </div><p class="hint">Drivers come from Master → Logistics → Local Freight.</p></div>
      <div class="row" style="margin-top:12px"><button type="submit" id="mpgo">🖨 Print ticked papers</button><button type="button" class="sec" id="mpclose">Close</button>
        <span class="hint">${pd.direct && pd.local ? 'Prints straight to the printers above.' : pd.direct ? 'This computer is not the main PC: the print window opens here.' : 'The print window opens for each paper.'}
          Printer, paper and position of each paper: <a href="#/settings/pagesetup" onclick="closeModal()">Settings → Page Setup</a></span></div>
      <div id="mpres" style="margin-top:10px"></div>
    </form>`, root => {
    const fm = $('#mpf', root), fr = $('#mpfr', root);
    const showFr = () => { fr.hidden = !$$('[name=doc]', fm).some(c => c.value === 'freight' && c.checked); };
    showFr(); fm.addEventListener('change', showFr);
    const drv = fm.driver; drv.addEventListener('change', () => { const x = drivers.find(d => d.name === drv.value.toUpperCase()); if (x) { fm.tempo_no.value = x.tempo_no || ''; fm.mobile.value = x.mobile || ''; } });
    $('#mpclose', root).onclick = closeModal;
    fm.onsubmit = async e => {
      e.preventDefault();
      const docs = $$('[name=doc]', fm).filter(c => c.checked).map(c => c.value);
      if (!docs.length) return toast('Tick at least one paper.', true);
      try { localStorage.setItem('mkt_print_ticks', JSON.stringify(docs)); } catch { /* private */ }
      if (docs.includes('freight')) await guard(() => PUT(`/api/mkt/dispatches/${dispatchId}/freight`, { driver: fm.driver.value, tempo_no: fm.tempo_no.value, mobile: fm.mobile.value, amount: fm.amount.value, from_place: fm.from_place.value }));
      const b = $('#mpgo', root); b.disabled = true; b.textContent = 'Printing…';
      try {
        const r = await guard(() => POST('/api/mkt/print', { dispatch_id: dispatchId, docs }));
        $('#mpres', root).innerHTML = (r.printed.length ? `<p>✓ Sent to the printer: ${r.printed.map(x => `<b>${esc(x.name)}</b> (${x.pages} page${x.pages === 1 ? '' : 's'} · ${esc(x.printer)})`).join(', ')}</p>` : '')
          + (r.browser.length ? `<p class="hint">Open each paper and print it from its window:</p><div class="row" style="flex-wrap:wrap;gap:6px">${r.browser.map(x => `<a class="small" href="${esc(x.url)}" target="_blank"><button type="button" class="small sec">Open ${esc(x.name)}</button></a>`).join('')}</div>` : '');
        if (r.printed.length && !r.browser.length) toast('Printed');
      } catch { /* shown */ } finally { b.disabled = false; b.textContent = '🖨 Print ticked papers'; }
    };
  });
}

// ---------- "Fill from a file": paste / drop / choose a picture or PDF, read it, fill the customer ----------
function mktDropZone(el, lw) {
  const dz = $('#mdz', el), res = $('#mdres', el), inp = $('#mdfile', el), box = $('#mlead', el);
  if (!dz) return;
  const fieldOf = { gst: 'gst', company: 'name', buyer_name: 'buyer_name', mobile1: 'mobile1', mobile2: 'mobile2', email: 'email', address: 'address', pincode: 'pincode', city: 'city', state: 'state', digipin: 'digipin' };
  const label = { gst: 'GSTIN', company: 'Company', buyer_name: 'Buyer', mobile1: 'Mobile', mobile2: 'Mobile 2', email: 'Email', address: 'Address', pincode: 'Pincode', city: 'City', state: 'State', digipin: 'Digipin' };
  const busy = (msg, preview = '') => { res.hidden = false; res.innerHTML = `<div class="row" style="gap:10px;align-items:center">${preview}<span class="hint">⏳ ${esc(msg)}</span></div>`; };
  const fill = (found, text, preview) => {
    const filled = [], kept = [];
    for (const [k, n] of Object.entries(fieldOf)) {
      const v = found[k]; if (!v) continue;
      const e = box.querySelector(`[name=${n}]`); if (!e) continue;
      if (String(e.value || '').trim()) { if (String(e.value).toUpperCase() !== String(v).toUpperCase()) kept.push(k); continue; }
      if (e.tagName === 'SELECT' && ![...e.options].some(o => o.value === v)) e.add(new Option(v, v));
      e.value = v; filled.push(k);
      e.style.transition = 'background 1.5s'; e.style.background = '#fff6cc'; setTimeout(() => { e.style.background = ''; }, 1600);
    }
    if (filled.length) S.dirty = true;
    const any = Object.keys(found).length;
    res.hidden = false;
    res.innerHTML = `<div class="row" style="gap:10px;align-items:flex-start">${preview}<div style="flex:1">
      ${any ? `<table class="t"><tbody>${Object.keys(fieldOf).filter(k => found[k]).map(k => `<tr><td class="hint" style="width:80px">${label[k]}</td><td><b>${esc(found[k])}</b></td>
        <td>${filled.includes(k) ? '<span class="badge PM">filled</span>' : kept.includes(k) ? '<span class="badge grey">box already filled</span>' : ''}</td></tr>`).join('')}</tbody></table>`
        : '<span class="badge amber">No customer details were recognised in this file.</span>'}
      <details style="margin-top:6px"><summary class="hint" style="cursor:pointer">Text read from the file</summary><pre style="white-space:pre-wrap;font-size:11.5px;max-height:220px;overflow:auto;background:#f6f8f8;padding:8px;border-radius:6px">${esc(text)}</pre></details></div></div>`;
    lw.check();
    // a GSTIN: look it up on the GST portal as before (captcha), which fills the official name and address
    if (found.gst && filled.includes('gst')) {
      const btn = [...box.querySelectorAll('button')].find(b => /Get details from GST/.test(b.textContent));
      if (btn) { btn.click(); toast('GSTIN found — type the captcha to get the details from the GST portal'); }
    } else if (filled.length) toast(`Filled ${filled.length} box${filled.length === 1 ? '' : 'es'} from the file — check them`);
  };
  const send = async (payload, preview) => {
    try { const r = await POST('/api/mkt/read-file', payload); fill(r.found, r.text, preview); }
    catch (e) { res.hidden = false; res.innerHTML = `<div class="row" style="gap:10px">${preview}<span class="badge red">${esc(e.message)}</span></div>`; }
  };
  const thumb = src => `<img src="${src}" style="max-width:110px;max-height:110px;border:1px solid var(--line);border-radius:6px;background:#fff">`;
  // a picture: made smaller (at most 2400 px) and read on the main PC
  const fromImage = blob => new Promise(resolve => {
    const url = URL.createObjectURL(blob), im = new Image();
    im.onload = () => { const k = Math.min(1, 2400 / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); resolve(c.toDataURL('image/png')); };
    im.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
    im.src = url;
  });
  // a PDF: its text is read here; a scanned PDF (no text) is turned into a picture of page 1
  const fromPdf = async file => {
    const pdfjs = await import('/vendor/pdf.min.mjs'); pdfjs.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.mjs';
    const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    let text = '';
    for (let i = 1; i <= Math.min(2, doc.numPages); i++) {
      const tc = await (await doc.getPage(i)).getTextContent();
      let lastY = null; for (const it of tc.items) { const y = Math.round(it.transform[5]); text += (lastY !== null && Math.abs(y - lastY) > 3 ? '\n' : (text && !text.endsWith('\n') ? ' ' : '')) + it.str; lastY = y; }
      text += '\n';
    }
    const pg = await doc.getPage(1), vp0 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: Math.min(3, 2000 / vp0.width) });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
    await pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
    const png = c.toDataURL('image/png');
    return { text, image: text.replace(/\s/g, '').length < 40 ? png : null, thumb: png };
  };
  const handle = async file => {
    if (!file) return;
    if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '')) {
      busy('Reading the PDF…');
      try { const p = await fromPdf(file); busy(p.image ? 'Scanned PDF — reading the page on the main PC…' : 'Finding the details…', thumb(p.thumb)); await send(p.image ? { image: p.image } : { text: p.text }, thumb(p.thumb)); }
      catch (e) { res.hidden = false; res.innerHTML = `<span class="badge red">This PDF could not be read: ${esc(e.message)}</span>`; }
      return;
    }
    if (!/^image\//.test(file.type)) { toast('Use a picture (PNG, JPG) or a PDF.', true); return; }
    const img = await fromImage(file); if (!img) { toast('This picture could not be opened.', true); return; }
    busy('Reading the picture on the main PC…', thumb(img)); await send({ image: img }, thumb(img));
  };
  $('#mdpick', el).onclick = e => { e.stopPropagation(); inp.click(); };
  dz.onclick = () => dz.focus();
  inp.onchange = () => { handle(inp.files[0]); inp.value = ''; };
  dz.ondragover = e => { e.preventDefault(); dz.style.background = '#e3f3f7'; };
  dz.ondragleave = () => { dz.style.background = '#f5fbfc'; };
  dz.ondrop = e => { e.preventDefault(); dz.style.background = '#f5fbfc'; handle(e.dataTransfer.files[0]); };
  // Ctrl+V anywhere on this screen with a picture on the clipboard; text only when pasted into the box itself
  const onPaste = e => {
    if (!document.body.contains(dz)) { document.removeEventListener('paste', onPaste); return; }
    const items = [...(e.clipboardData && e.clipboardData.items || [])];
    const pic = items.find(i => i.kind === 'file' && /^image\/|application\/pdf/.test(i.type));
    if (pic) { e.preventDefault(); handle(pic.getAsFile()); return; }
    if (document.activeElement === dz) { const t = e.clipboardData.getData('text'); if (t && t.trim()) { e.preventDefault(); busy('Finding the details…'); send({ text: t }, ''); } }
  };
  document.addEventListener('paste', onPaste);
}

// =====================================================================
// Phase 4 — calls, communication, quick sticker, letters
// =====================================================================
const mktAddDays = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const mktWa = (m, t) => `https://wa.me/91${String(m || '').replace(/\D/g, '').slice(-10)}${t ? '?text=' + encodeURIComponent(t) : ''}`;
const mktCal = f => !f.calendar_status ? '' : f.calendar_status === 'SENT' ? '<span title="In Google Calendar">📅</span>'
  : `<span title="Google Calendar: ${esc(f.calendar_status === 'FAILED' ? 'not sent yet — ' + (f.calendar_error || '') : 'waiting to be sent')}" style="opacity:.55">📅…</span>`;
async function mktPrintOne(what, id) {
  const r = await guard(() => POST('/api/mkt/print-one', { what, id, where: typeof printWhere === 'function' ? printWhere() : '' }));
  if (r.browser) { const w = window.open(r.url, '_blank'); if (!w) toast('Allow pop-ups for Mineral Saathi to open the print window.', true); } else toast('Sent to ' + r.printer);
}

// ---------- Today's Calls ----------
async function mktCalls(el, day) {
  const d = await GET('/api/mkt/calls' + (day ? '?date=' + day : ''));
  const rows = (list, late) => list.map(f => `<tr class="click" data-open="${f.lead_id}" data-fu="${f.id}">
      <td>${f.status === 'PENDING' ? (late ? `<span class="badge red">${dmy(f.due_date)}</span>` : dmy(f.due_date)) : `<span class="badge grey">${esc(f.status)}</span>`}</td>
      <td><b>${f.ref_no}</b></td><td><b>${esc(f.company || f.buyer_name || '')}</b>${f.company && f.buyer_name ? `<br><span class="hint">${esc(f.buyer_name)}</span>` : ''}<br><span class="hint">${esc([f.city, f.state].filter(Boolean).join(', '))}</span></td>
      <td>${f.mobile1 ? `<a href="tel:${esc(f.mobile1)}" onclick="event.stopPropagation()">${esc(f.mobile1)}</a>` : ''}</td>
      <td>${esc(f.reason || '')} ${mktCal(f)}</td><td class="hint">${esc(f.last_talk || '')}${f.last_dispatch ? `<br>Sent ${esc(dmy(f.last_dispatch.slice(0, 10)) + f.last_dispatch.slice(10))}` : ''}</td>
      <td style="white-space:nowrap;text-align:right">${f.mobile1 ? `<a class="small" href="${esc(mktWa(f.mobile1))}" target="_blank" onclick="event.stopPropagation()"><button class="small sec" type="button">WhatsApp</button></a>` : ''}
        ${f.status === 'PENDING' ? `<button class="small sec" data-skip="${f.id}">Skip</button>` : ''} <button class="small">Open</button></td></tr>`).join('');
  const table = (list, late, empty) => `<div class="tablewrap"><table class="t"><thead><tr><th>Due</th><th>Ref</th><th>Customer</th><th>Mobile</th><th>Reason</th><th>Last</th><th></th></tr></thead>
    <tbody>${rows(list, late) || `<tr><td colspan="7" class="muted">${empty}</td></tr>`}</tbody></table></div>`;
  const pend = d.due.filter(f => f.status === 'PENDING').length;
  el.innerHTML = `<div class="card"><div class="row" style="justify-content:space-between">
      <div class="row" style="flex-wrap:nowrap;align-items:center"><button class="sec small" id="cprev">◀</button><input type="date" id="cday" value="${d.date}" style="width:auto"><button class="sec small" id="cnext">▶</button>
        ${d.date !== d.today ? '<button class="sec small" id="ctoday">Today</button>' : ''}</div>
      <span class="hint">${pend} call${pend === 1 ? '' : 's'} on ${dmy(d.date)}${d.overdue.length ? ` · <b style="color:var(--bad)">${d.overdue.length} late</b>` : ''} · ${d.upcoming} later</span></div></div>
    ${d.overdue.length ? `<div class="card"><h3 style="color:var(--bad)">Late — not called yet</h3>${table(d.overdue, true, '')}</div>` : ''}
    <div class="card"><h3>Calls on ${dmy(d.date)}</h3>${table(d.due, false, 'No calls on this day.')}</div>`;
  const goDay = v => go('#/mkt/calls:' + v);
  $('#cday', el).onchange = e => goDay(e.target.value);
  $('#cprev', el).onclick = () => goDay(mktAddDays(d.date, -1)); $('#cnext', el).onclick = () => goDay(mktAddDays(d.date, 1));
  const ct = $('#ctoday', el); if (ct) ct.onclick = () => go('#/mkt/calls');
  el.onclick = async e => {
    const sk = e.target.closest('[data-skip]');
    if (sk) { e.stopPropagation(); if (confirm('Skip this call? It leaves the list.')) { await guard(() => POST(`/api/mkt/follow-ups/${sk.dataset.skip}/skip`)); mktCalls(el, day); } return; }
    const tr = e.target.closest('[data-open]'); if (tr) go(`#/mkt/comm:L${tr.dataset.open}F${tr.dataset.fu}`);
  };
}

// ---------- Communication ----------
async function mktComm(el, arg) {
  const mm = String(arg).match(/^L(\d+)(?:F(\d+))?$/);
  if (!mm) {      // choose a customer first
    el.innerHTML = `<div class="card" style="position:relative"><label>Find enquiry <span class="hint">— Ref No., mobile, company or name</span><input id="cfind" autocomplete="off" placeholder="Type to search…"></label>
      <div id="cres" style="margin-top:8px"></div></div>`;
    const fi = $('#cfind', el); let t; fi.focus();
    fi.oninput = () => { clearTimeout(t); t = setTimeout(async () => {
      const rows = fi.value.trim() ? await GET('/api/mkt/find?q=' + encodeURIComponent(fi.value.trim())).catch(() => []) : [];
      $('#cres', el).innerHTML = rows.map(r => `<a class="listhead" onclick="go('#/mkt/comm:L${r.id}')"><b>Ref ${r.ref_no}</b> · ${mktName(r)} <span class="hint" style="float:right">${esc([r.city, r.state].filter(Boolean).join(', '))} · ${esc(r.mobile1 || '')}</span></a>`).join('')
        || (fi.value.trim() ? '<div class="muted">No enquiry found.</div>' : '');
    }, 220); };
    return;
  }
  const leadId = Number(mm[1]), fuWant = Number(mm[2]) || null;
  const [d, ml, tpls, ms] = await Promise.all([GET('/api/mkt/leads/' + leadId), GET('/api/mkt/lists'), GET('/api/mkt/templates'), GET('/api/mkt/settings')]);
  const l = d.lead, last = d.dispatches[0] || null, pend = d.follow_ups.filter(f => f.status === 'PENDING').sort((a, b) => a.due_date.localeCompare(b.due_date));
  $('#title').textContent = `Communication · Ref ${l.ref_no} · ${l.company || l.buyer_name || ''}`;
  const trackLink = last && last.tracking_no ? String(mktLinkTpl(ms, last.courier) || '').split('{tracking_no}').join(encodeURIComponent(last.tracking_no)) : '';
  const fillTpl = body => body.replace(/\{name\}/g, l.buyer_name || l.company || '').replace(/\{company\}/g, l.company || '').replace(/\{ref\}/g, l.ref_no)
    .replace(/\{courier\}/g, last ? last.courier || '' : '').replace(/\{tracking_no\}/g, last ? last.tracking_no || '' : '').replace(/\{tracking_link\}/g, trackLink);
  const opts = k => (ml[k] || []).map(x => `<option>${esc(x.value)}</option>`).join('');
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(320px,1fr) minmax(420px,1.3fr);align-items:start">
    <div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Ref ${l.ref_no} · ${esc(l.company || l.buyer_name || '')}</h3><button class="small sec" onclick="go('#/mkt/leads:${l.id}')">Open enquiry</button></div>
        <p style="margin:8px 0 0">${l.buyer_name ? `<b>${esc(l.buyer_name)}</b><br>` : ''}${[l.mobile1, l.mobile2].filter(Boolean).map(m => `📞 <a href="tel:${esc(m)}">${esc(m)}</a>`).join(' &nbsp; ')}
          <br><span class="hint">${esc([l.city, l.state].filter(Boolean).join(', '))}</span></p>
        ${last ? `<p class="hint" style="margin:8px 0 0">Last dispatch <b>${dmy(last.date)}</b> · ${esc(last.courier || '')} ${trackLink ? `<a href="${esc(trackLink)}" target="_blank">${esc(last.tracking_no)}</a>` : esc(last.tracking_no || '')}
          ${last.delivered_on ? ` · delivered ${dmy(last.delivered_on)}` : ''}</p>` : '<p class="hint">No sample sent yet.</p>'}
        ${d.dispatches.length ? `<h4 style="margin:12px 0 4px">Samples sent <span class="hint">— ${d.dispatches.reduce((n, x) => n + x.lines.length, 0)} in ${d.dispatches.length} dispatch${d.dispatches.length === 1 ? '' : 'es'}</span></h4>
          <div class="tablewrap" style="max-height:260px"><table class="t" style="font-size:12.5px"><thead><tr><th>Date</th><th>Grade / item</th><th>Colour · Mesh · Form</th><th>Sample</th><th class="num">Rate</th></tr></thead><tbody>
          ${d.dispatches.flatMap(x => x.lines.map((ln, i) => `<tr><td style="white-space:nowrap">${i ? '' : `<b>${dmy(x.date)}</b>${x.delivered_on ? '<br><span class="hint">delivered</span>' : ''}`}</td><td><b style="white-space:nowrap">${esc(ln.grade || '')}</b><br><span class="hint">${esc(ln.item_name || '')}</span></td>
            <td>${esc([ln.colour, ln.mesh, ln.form].filter(Boolean).join(' · '))}</td><td style="white-space:nowrap">${esc(ln.sample_size || '')}</td><td class="num" style="white-space:nowrap">${ln.rate != null && ln.rate !== '' ? '₹' + esc(ln.rate) + (ln.unit ? ' / ' + esc(ln.unit) : '') : ''}</td></tr>`)).join('')}</tbody></table></div>` : ''}</div>
      <div class="card"><h3>Calls planned</h3><table class="t"><tbody>
        ${pend.map(f => `<tr><td>${mktDue(f.due_date)}</td><td>${esc(f.reason || '')} ${mktCal(f)}</td><td style="text-align:right;white-space:nowrap">
          ${ms.calendar_url && f.calendar_status !== 'SENT' ? `<button class="small sec" data-cal="${f.id}">Send to calendar</button>` : ''} <button class="small sec" data-skip="${f.id}">Skip</button></td></tr>`).join('') || '<tr><td class="muted">No call planned.</td></tr>'}</tbody></table></div>
      <div class="card"><h3>History</h3><table class="t"><tbody>
        ${d.communications.map(c => `<tr><td style="width:84px">${dmy(c.date)}</td><td><span class="badge grey">${esc(c.channel || '')}</span></td><td>${c.response ? `<b>${esc(c.response)}</b>` : ''}${c.note ? `<div style="white-space:pre-line">${esc(c.note)}</div>` : ''}</td>
          <td><button class="small sec" data-cdel="${c.id}" title="Delete">✕</button></td></tr>`).join('') || '<tr><td class="muted">Nothing yet.</td></tr>'}</tbody></table></div>
    </div>
    <div>
      <div class="card"><h3>WhatsApp <span class="hint">— opens WhatsApp with the message ready; you press Send</span></h3>
        <div class="grid" style="grid-template-columns:1fr 170px;gap:12px;align-items:start">
          <div><label>Message<select id="wtpl"><option value="">— choose a ready message —</option>${tpls.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select></label>
            <textarea id="wtxt" rows="7" style="margin-top:8px">Hello${l.buyer_name ? ' ' + esc(l.buyer_name) : ''}, Ref No. ${l.ref_no}</textarea>
            <div class="row" style="margin-top:8px"><button type="button" id="wopen" ${l.mobile1 ? '' : 'disabled'}>Open WhatsApp</button><button type="button" class="sec" id="wcopy">Copy text</button>
              <label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" id="wlog" style="width:auto" checked> add to history</label></div></div>
          <div style="text-align:center"><div id="wqr" style="background:#fff;border:1px solid var(--line);border-radius:8px;padding:4px;min-height:160px"></div><span class="hint">Scan with your phone to send from it</span></div>
        </div></div>
      <form class="card" id="cf"><h3>Log this call and plan the next</h3>
        <div class="grid g3" style="gap:10px">
          <label>Date<input name="date" type="date" value="${today()}"></label>
          <label>By<select name="channel"><option value="CALL">Call</option><option value="WHATSAPP">WhatsApp</option><option value="EMAIL">E-mail</option><option value="VISIT">Visit</option><option value="OTHER">Other</option></select></label>
          <label>Response<select name="response"><option value=""></option>${opts('response')}</select></label>
          <label style="grid-column:span 3">Note<textarea name="note" rows="3" placeholder="What was said"></textarea></label>
          ${pend.length ? `<label style="grid-column:span 2">This call is done<select name="done"><option value="">— none —</option>${pend.map(f => `<option value="${f.id}" ${(fuWant ? f.id === fuWant : f === pend[0]) ? 'selected' : ''}>${dmy(f.due_date)} · ${esc(f.reason || '')}</option>`).join('')}</select></label>` : ''}
          ${last && !last.delivered_on ? `<label style="display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:9px;font-size:13px"><input type="checkbox" name="delivered" style="width:auto"> Sample received</label>` : ''}
        </div>
        <h4 style="margin:14px 0 6px">Next call</h4>
        <div class="grid g3" style="gap:10px;align-items:end">
          <label>Date<input name="next_date" type="date"></label>
          <label class="span2">Reason<select name="next_reason">${opts('followup_reason')}</select></label>
          <div style="grid-column:span 3" class="row">${[3, 7, 15, 30].map(n => `<button type="button" class="small sec" data-plus="${n}">+${n} days</button>`).join(' ')}
            <button type="button" class="small sec" data-plus="0">No next call</button>
            <span class="hint">${ms.calendar_url ? '📅 The next call goes to Google Calendar.' : 'Google Calendar link: Settings → Data Location.'}</span></div>
        </div>
        <div class="row" style="margin-top:12px"><button type="submit">Save</button></div></form>
    </div></div>`;
  // WhatsApp: ready message, link, QR for the phone
  const wt = $('#wtxt', el);
  const drawQr = async () => { if (!l.mobile1) { $('#wqr', el).innerHTML = '<span class="hint">No mobile number.</span>'; return; }
    const r = await POST('/api/mkt/qr', { data: mktWa(l.mobile1, wt.value), px: 160 }).catch(() => null); if (r) $('#wqr', el).innerHTML = r.svg; };
  let qt; wt.oninput = () => { clearTimeout(qt); qt = setTimeout(drawQr, 400); };
  $('#wtpl', el).onchange = e => { const t = tpls.find(x => String(x.id) === e.target.value); if (t) { wt.value = fillTpl(t.body); drawQr(); } };
  $('#wopen', el).onclick = async () => { window.open(mktWa(l.mobile1, wt.value), '_blank');
    if ($('#wlog', el).checked) { await POST('/api/mkt/whatsapp-log', { lead_id: l.id, text: wt.value }).catch(() => {}); toast('Added to history'); } };
  $('#wcopy', el).onclick = async () => { try { await navigator.clipboard.writeText(wt.value); toast('Copied'); } catch { wt.select(); document.execCommand('copy'); toast('Copied'); } };
  drawQr();
  refineButton($('#cf [name=note]', el), 'the note');
  // log + next call
  const f = $('#cf', el);
  $$('[data-plus]', f).forEach(b => b.onclick = () => { const n = Number(b.dataset.plus); f.next_date.value = n ? mktAddDays(today(), n) : ''; });
  f.next_date.value = mktAddDays(today(), 7);
  f.onsubmit = async e => {
    e.preventDefault();
    const r = await guard(() => POST('/api/mkt/comm/' + l.id, { date: f.date.value, channel: f.channel.value, response: f.response.value, note: f.note.value,
      done_follow_up_id: f.done ? f.done.value : null, delivered: f.delivered && f.delivered.checked, next: f.next_date.value ? { date: f.next_date.value, reason: f.next_reason.value } : null }));
    toast(r.next_id ? `Saved · next call ${dmy(f.next_date.value)}` : 'Saved'); mktComm(el, 'L' + l.id);
  };
  el.onclick = async e => {
    const sk = e.target.closest('[data-skip]'), cal = e.target.closest('[data-cal]'), cd = e.target.closest('[data-cdel]');
    if (sk && confirm('Skip this call?')) { await guard(() => POST(`/api/mkt/follow-ups/${sk.dataset.skip}/skip`)); mktComm(el, 'L' + l.id); }
    if (cal) { const r = await guard(() => POST(`/api/mkt/follow-ups/${cal.dataset.cal}/calendar`)); toast(r.calendar_status === 'SENT' ? 'Sent to Google Calendar' : 'Not sent: ' + (r.calendar_error || ''), r.calendar_status !== 'SENT'); mktComm(el, 'L' + l.id); }
    if (cd && confirm('Delete this line from the history?')) { await guard(() => DEL('/api/mkt/communications/' + cd.dataset.cdel)); mktComm(el, 'L' + l.id); }
  };
}

// ---------- Quick Sticker ----------
async function mktQuick(el) {
  await loadLists(true);
  const [rows, ms] = await Promise.all([GET('/api/mkt/quick'), GET('/api/mkt/settings')]);
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(380px,1fr) 1.2fr;align-items:start">
    <form class="card" id="qf" autocomplete="off"><h3>Quick sticker <span class="hint">— a 4×6 sticker with WhatsApp and call QR codes, no enquiry record</span></h3>
      <div class="grid g2" style="gap:10px">
        <label>Date<input name="date" type="date" value="${today()}"></label><label>Ref<input name="ref" style="text-transform:uppercase"></label>
        <label>Name<input name="name" style="text-transform:uppercase"></label><label>Company<input name="company" style="text-transform:uppercase"></label>
        <label>Mobile<input name="mobile" inputmode="numeric"></label><label>Pincode<input name="pincode" inputmode="numeric"></label>
        <label>City<input name="city" style="text-transform:uppercase"></label><label>State<input name="state" style="text-transform:uppercase"></label>
        <label class="span2">Item / grade<input name="item" list="qitems" style="text-transform:uppercase"></label>${datalist('qitems', lv('product'))}
        <label>Rate ₹<input name="rate" type="number" step="0.01"></label><label>Per<select name="unit"><option></option>${lv('unit').map(u => `<option ${u === 'KG' ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select></label>
        <label class="span2">Note<input name="remark"></label>
      </div>
      <div class="row" style="margin-top:12px"><button type="submit">Save and print</button><span class="hint">Printer and paper: Settings → Page Setup → Quick sticker.</span></div></form>
    <div class="card"><h3>Printed before</h3><table class="t"><thead><tr><th>Date</th><th>Ref</th><th>Name / company</th><th>Mobile</th><th>Item</th><th></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td>${dmy(r.date)}</td><td>${esc(r.ref || '')}</td><td><b>${esc(r.name || '')}</b><br><span class="hint">${esc(r.company || '')}</span></td><td>${esc(r.mobile || '')}</td><td>${esc(r.item || '')}</td>
        <td style="white-space:nowrap;text-align:right"><a href="/print/mkt/quick/${r.id}" target="_blank" class="small">Preview</a> <button class="small sec" data-qp="${r.id}">Print</button> <button class="small sec" data-qd="${r.id}">✕</button></td></tr>`).join('')
        || '<tr><td colspan="6" class="muted">None yet.</td></tr>'}</tbody></table></div></div>`;
  const f = $('#qf', el);
  f.mobile.oninput = () => { f.mobile.value = f.mobile.value.replace(/\D/g, ''); };
  f.pincode.oninput = async () => { f.pincode.value = f.pincode.value.replace(/\D/g, ''); if (f.pincode.value.length !== 6) return;
    const r = await GET('/api/pincode/' + f.pincode.value).catch(() => null); if (r && r.found) { f.city.value = String(r.city || '').toUpperCase(); f.state.value = String(r.state || '').toUpperCase(); } };
  f.onsubmit = async e => { e.preventDefault(); const r = await guard(() => POST('/api/mkt/quick', formData(f))); await mktPrintOne('quick', r.id); mktQuick(el); };
  el.onclick = async e => { const p = e.target.closest('[data-qp]'), dl = e.target.closest('[data-qd]');
    if (p) mktPrintOne('quick', Number(p.dataset.qp));
    if (dl && confirm('Delete this quick sticker from the list?')) { await guard(() => DEL('/api/mkt/quick/' + dl.dataset.qd)); mktQuick(el); } };
}

// ---------- Letters: letter pad, bus parcel label, blank envelope ----------
async function mktLetters(el, type) {
  type = ['PAD', 'BUS', 'ENVELOPE'].includes(type) ? type : 'PAD';
  const [rows, ms] = await Promise.all([GET('/api/mkt/letters'), GET('/api/mkt/settings')]);
  const T = { PAD: 'Letter pad', BUS: 'Bus parcel label', ENVELOPE: 'Envelope' };
  const firmSel = `<label>From (company)<select name="firm_code">${ms.firms.map(x => `<option value="${esc(x.code)}" ${x.code === ms.default_firm ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>`;
  const fields = {
    PAD: `<div class="grid g2" style="gap:10px"><label>Date<input name="date" type="date" value="${today()}"></label>${firmSel}
      <label class="span2">To<textarea name="to" rows="4" placeholder="Name, company, address"></textarea></label>
      <label class="span2">Subject<input name="subject"></label><label class="span2">Letter<textarea name="body" rows="10"></textarea></label>
      <label>Ref No.<input name="ref"></label><label>Signed by<input name="signer" value="${esc(ms.signer || '')}"></label></div>`,
    BUS: `<div class="grid g2" style="gap:10px"><label>Date<input name="date" type="date" value="${today()}"></label>${firmSel}
      <label class="span2">To<textarea name="to" rows="4" placeholder="Name, city"></textarea></label>
      <label>Phone<input name="phone" inputmode="numeric"></label><label>Contents<input name="contents" value="HOUSEHOLD GOODS" style="text-transform:uppercase"></label>
      <label class="span2">From (name)<input name="from" value="${esc(ms.signer || '')}"></label></div>`,
    ENVELOPE: `<div class="grid g2" style="gap:10px">${firmSel}<label style="display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:9px;font-size:13px"><input type="checkbox" name="show_from" style="width:auto" checked> Print our address on the left</label>
      <label class="span2">Heading <span class="hint">(e.g. TO, DELIVERY)</span><input name="heading" value="TO" style="text-transform:uppercase"></label>
      <label class="span2">Text<textarea name="to" rows="7" placeholder="Name and address, or any text"></textarea></label></div>`
  };
  el.innerHTML = `<div class="tabs" style="margin-bottom:12px">${Object.entries(T).map(([k, t]) => `<button class="${k === type ? 'on' : ''}" onclick="go('#/mkt/letters:${k}')">${t}</button>`).join('')}</div>
    <div class="grid" style="grid-template-columns:minmax(380px,1fr) 1fr;align-items:start">
      <form class="card" id="lf" autocomplete="off"><h3>${T[type]}</h3>
        <div style="position:relative;margin-bottom:10px"><label>Fill “To” from an enquiry<input id="lfind" placeholder="Ref No., mobile, company or name"></label><div id="lres"></div></div>
        ${fields[type]}
        <div class="row" style="margin-top:12px"><button type="submit">Save and print</button><button type="button" class="sec" id="lprev">Save and preview</button>
          <span class="hint">Printer and paper: Settings → Page Setup → ${T[type]}.</span></div></form>
      <div class="card"><h3>Made before</h3><table class="t"><tbody>
        ${rows.filter(r => r.type === type).map(r => { const x = JSON.parse(r.data || '{}'); return `<tr><td style="width:90px">${dmy(String(r.created_at).slice(0, 10))}</td>
          <td>${esc(String(x.subject || x.to || '').split('\n')[0].slice(0, 70))}</td><td style="white-space:nowrap;text-align:right"><a href="/print/mkt/letter/${r.id}" target="_blank" class="small">Preview</a>
          <button class="small sec" data-lp="${r.id}">Print</button> <button class="small sec" data-ld="${r.id}">✕</button></td></tr>`; }).join('') || '<tr><td class="muted">None yet.</td></tr>'}</tbody></table></div></div>`;
  const f = $('#lf', el); let leadId = null;
  const fi = $('#lfind', el); let t;
  fi.oninput = () => { clearTimeout(t); t = setTimeout(async () => {
    const rs = fi.value.trim() ? await GET('/api/mkt/find?q=' + encodeURIComponent(fi.value.trim())).catch(() => []) : [];
    $('#lres', el).innerHTML = rs.map(r => `<a class="listhead" data-lid="${r.id}"><b>Ref ${r.ref_no}</b> · ${mktName(r)} <span class="hint">${esc(r.city || '')}</span></a>`).join('');
  }, 220); };
  $('#lres', el).onclick = async e => { const a = e.target.closest('[data-lid]'); if (!a) return;
    const l = (await GET('/api/mkt/leads/' + a.dataset.lid)).lead; leadId = l.id;
    f.to.value = [l.buyer_name, l.company ? 'M/s. ' + l.company : '', l.address, [l.city, l.pincode].filter(Boolean).join(' - '), l.state, type === 'PAD' && l.mobile1 ? 'Ph. ' + l.mobile1 : ''].filter(Boolean).join('\n');
    if (type === 'BUS') { f.to.value = [l.buyer_name, l.company, [l.city, l.pincode].filter(Boolean).join(' - '), l.state].filter(Boolean).join('\n'); f.phone.value = l.mobile1 || ''; }
    if (f.ref) f.ref.value = l.ref_no;
    $('#lres', el).innerHTML = ''; fi.value = ''; };
  const save = async () => { const o = formData(f); const fc = o.firm_code; delete o.firm_code; o.show_from = type !== 'ENVELOPE' || !!o.show_from;
    return guard(() => POST('/api/mkt/letters', { type, lead_id: leadId, firm_code: fc, data: o })); };
  f.onsubmit = async e => { e.preventDefault(); const r = await save(); await mktPrintOne('letter', r.id); mktLetters(el, type); };
  $('#lprev', el).onclick = async () => { const w = window.open('', '_blank'); const r = await save().catch(() => null); if (!r) { if (w) w.close(); return; } if (w) w.location = '/print/mkt/letter/' + r.id; mktLetters(el, type); };
  el.onclick = async e => { const p = e.target.closest('[data-lp]'), dl = e.target.closest('[data-ld]');
    if (p) mktPrintOne('letter', Number(p.dataset.lp));
    if (dl && confirm('Delete this from the list?')) { await guard(() => DEL('/api/mkt/letters/' + dl.dataset.ld)); mktLetters(el, type); } };
}

// ---------- Make Buyer: copy the enquiry into Master → Buyer B2B once ----------
async function mktMakeBuyer(l, after) {
  const cands = await GET(`/api/mkt/leads/${l.id}/buyer-candidates`);
  modal('Make Buyer · Ref ' + l.ref_no, `
    ${cands.length ? `<div class="firmbox"><b>Already in Buyer B2B?</b> These buyers have the same GSTIN, mobile or name:
      <table class="t" style="margin-top:6px"><tbody>${cands.map(c => `<tr><td><b>${esc(c.name)}</b> <span class="hint">${esc(c.city || '')} ${esc(c.gstin || '')}</span></td>
        <td><span class="badge ${esc(c.firm_code || 'grey')}">${esc(c.firm_code || '—')}</span></td><td style="text-align:right"><button class="small sec" data-link="${c.id}">Link to this buyer</button></td></tr>`).join('')}</tbody></table></div>` : ''}
    <form id="mbf" class="grid" style="gap:10px;margin-top:10px">
      <p class="hint" style="margin:0">A new buyer is added to <b>Master → Buyer B2B</b> with these details (a one-time copy; later changes are made in Buyers).
        The enquiry stays in Marketing with its samples and calls.</p>
      ${field({ name: 'firm_code', label: 'Billing firm', type: 'select', options: [['', '— choose —'], ['PM', 'Parakh Marketing'], ['PF', 'Parakh Fertilizer']] }, '')}
      ${field({ name: 'name', label: 'Buyer name' }, l.company || l.buyer_name || '')}
      ${field({ name: 'gstin', label: 'GSTIN' }, l.gst || '')}
      ${field({ name: 'address', label: 'Address', type: 'textarea' }, l.address || '')}
      <div class="grid g3">${field({ name: 'city', label: 'City' }, l.city || '')}${field({ name: 'pincode', label: 'Pincode' }, l.pincode || '')}
        ${field({ name: 'state', label: 'State', type: 'select', options: STATES() }, l.state || '')}</div>
      <div class="grid g3">${field({ name: 'mobile', label: 'Mobile' }, l.mobile1 || '')}${field({ name: 'phone', label: 'Phone / 2nd mobile' }, l.mobile2 || '')}${field({ name: 'email', label: 'E-mail' }, l.email || '')}</div>
      <div class="row"><button type="submit">Add to Buyer B2B</button><button type="button" class="sec" onclick="closeModal()">Cancel</button></div>
    </form>`, box => {
    const done = async pid => { await guard(() => POST(`/api/mkt/leads/${l.id}/buyer`, { party_id: pid })); S.parties = null; closeModal(); toast('Linked to Buyer B2B'); after && after(); };
    box.querySelectorAll('[data-link]').forEach(b => b.onclick = () => done(Number(b.dataset.link)));
    $('#mbf', box).onsubmit = async e => {
      e.preventDefault(); const f = e.target;
      if (!f.firm_code.value) return toast('Choose the billing firm.', true);
      const o = { firm_code: f.firm_code.value, name: f.name.value.trim().toUpperCase(), gstin: f.gstin.value.trim(), address: f.address.value.trim(), city: f.city.value.trim().toUpperCase(),
        pincode: f.pincode.value.trim(), state: f.state.value, mobile: f.mobile.value.trim(), phone: f.phone.value.trim(), email: f.email.value.trim(),
        is_b2c: f.gstin.value.trim() ? 0 : 1, notes: `From Marketing Ref ${l.ref_no}` };
      const r = await guard(() => POST('/api/m/parties', o));
      await done(r.id);
    };
  });
}

// ---------- Marketing Reports ----------
async function mktReports(el, from = '', to = '') {
  const d = await GET(`/api/mkt/reports?from=${from}&to=${to}`);
  const s = d.summary, num = v => v == null ? '' : Number(v).toLocaleString('en-IN');
  const tile = (n, t, cls = '') => `<div class="card" style="margin:0;padding:12px 14px"><div class="hint">${t}</div><div style="font-size:24px;font-weight:700" class="${cls}">${num(n)}</div></div>`;
  const ym = m => m ? new Date(m + '-01T00:00:00').toLocaleString('en-IN', { month: 'short', year: 'numeric' }) : 'Date not known (Excel)';
  const max = Math.max(1, ...d.by_month.map(r => r.samples));
  const tbl = (id, title, head, rows, empty = 'Nothing yet.') => `<div class="card"><div class="toolbar"><h3 style="margin:0">${title}</h3><span class="spacer"></span><button class="sec small" data-csv="${id}">Export</button></div>
    <div class="tablewrap"><table class="t"><thead><tr>${head.map(h => `<th${/^#|^Samples|^Dispatch|^Enquir|^Deliver|^Avg|^Became|^Calls/.test(h) ? ' class="num"' : ''}>${h}</th>`).join('')}</tr></thead>
    <tbody>${rows || `<tr><td colspan="${head.length}" class="muted">${empty}</td></tr>`}</tbody></table></div></div>`;
  el.innerHTML = `<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:8px">
      <label>From <input type="date" id="rfrom" value="${esc(from)}"></label><label>To <input type="date" id="rto" value="${esc(to)}"></label>
      <button id="rgo">Show</button><button class="sec" id="rall">All time</button>
      <span class="hint">${from || to ? 'Samples, dispatches and calls in this period. Samples from Excel without a date are left out.' : 'All time, including the samples brought from Excel.'}</span></div></div>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px">
      ${tile(s.enquiries, 'Enquiries (all)')}${s.new_enquiries != null ? tile(s.new_enquiries, 'New enquiries in period') : ''}${tile(s.samples, 'Samples sent')}${tile(s.dispatches, 'Dispatches')}
      ${tile(s.calls_done, 'Calls & messages logged')}${tile(s.pending, 'Calls planned')}${tile(s.overdue, 'Calls overdue', s.overdue ? 'neg' : '')}${tile(s.buyers, 'Became buyers')}</div>
    <div class="grid g2" style="align-items:start">
      ${tbl('month', 'Samples by month', ['Month', 'Samples', 'Dispatches', 'Enquiries', ''], d.by_month.map(r => `<tr><td>${ym(r.month)}</td><td class="num">${r.samples}</td><td class="num">${r.dispatches}</td><td class="num">${r.enquiries}</td>
        <td style="width:35%"><div style="height:10px;border-radius:5px;background:var(--accent,#2F4F5A);width:${Math.round(r.samples / max * 100)}%"></div></td></tr>`).join(''))}
      ${tbl('grade', 'Samples by grade', ['Grade', 'Samples', 'Enquiries', 'Became buyers'], d.by_grade.map(r => `<tr><td><b>${esc(r.grade)}</b></td><td class="num">${r.samples}</td><td class="num">${r.enquiries}</td><td class="num">${r.to_buyers || ''}</td></tr>`).join(''))}
      ${tbl('courier', 'Dispatches by courier', ['Courier', 'Dispatches', 'Delivered', 'Avg days'], d.by_courier.map(r => `<tr><td>${esc(r.courier)}</td><td class="num">${r.dispatches}</td><td class="num">${r.delivered || ''}</td><td class="num">${r.avg_days ?? ''}</td></tr>`).join(''))}
      ${tbl('state', 'Enquiries by state', ['State', 'Enquiries', 'Samples', 'Became buyers'], d.by_state.map(r => `<tr><td>${esc(r.state)}</td><td class="num">${r.enquiries}</td><td class="num">${r.samples || ''}</td><td class="num">${r.to_buyers || ''}</td></tr>`).join(''))}
    </div>
    ${tbl('calls', `Pending calls · ${d.calls.length}`, ['Due', 'Ref', 'Customer', 'City', 'Mobile', 'Reason'], d.calls.map(c => `<tr style="cursor:pointer" onclick="go('#/mkt/comm:L${c.lead_id}')"><td>${mktDue(c.due_date)}</td><td>${c.ref_no}</td>
      <td><b>${esc(c.company || c.buyer_name || '')}</b></td><td>${esc(c.city || '')}</td><td>${esc(c.mobile1 || '')}</td><td>${esc(c.reason || '')}</td></tr>`).join(''), 'No calls pending.')}
    ${tbl('buyers', `Enquiries that became buyers · ${d.buyers.length}`, ['Ref', 'Enquiry', 'Buyer B2B', 'City', 'Grades sampled', 'First sample'], d.buyers.map(b => `<tr style="cursor:pointer" onclick="go('#/mkt/leads:${b.id}')"><td>${b.ref_no}</td>
      <td><b>${esc(b.company || b.buyer_name || '')}</b></td><td>${esc(b.buyer)}</td><td>${esc(b.city || '')}</td><td>${esc(b.grades || '')}</td><td>${dmy(b.first_sample)}</td></tr>`).join(''), 'None yet — use 🤝 Make Buyer on an enquiry.')}`;
  const sets = { month: d.by_month, grade: d.by_grade, courier: d.by_courier, state: d.by_state, buyers: d.buyers,
    calls: d.calls.map(c => ({ due: c.due_date, ref: c.ref_no, company: c.company, name: c.buyer_name, city: c.city, mobile: c.mobile1, reason: c.reason })) };
  el.querySelectorAll('[data-csv]').forEach(b => b.onclick = () => downloadCsv(`marketing_${b.dataset.csv}${from || to ? `_${from}_${to}` : ''}.csv`, sets[b.dataset.csv]));
  $('#rgo', el).onclick = () => mktReports(el, $('#rfrom', el).value, $('#rto', el).value);
  $('#rall', el).onclick = () => mktReports(el);
}

// ---------- Settings → Import: the old Sample Dispatch Excel ----------
{
  const importPage = SETTINGS.import;
  SETTINGS.import = async box => {
    await importPage(box);
    const card = document.createElement('div'); card.className = 'card';
    card.innerHTML = `<h3>📣 Marketing — Sample Dispatch Excel</h3>
      <p class="hint">Choose <b>Sample_Dispatch.xlsm</b> (everything: enquiries, samples, the numbered sheets with the call history, CALL UPDATE)
        or a file with only the DATA sheet such as <b>Sample_data.xlsx</b> (enquiries and samples; history already imported is kept).
        It can be run again while Excel and Mineral Saathi run side by side: enquiries are updated by Ref No. and the samples, history and calls from Excel are replaced.
        Enquiries, samples and calls entered in Mineral Saathi are never touched. A safety copy of the Marketing data is made first.</p>
      <div class="row"><input type="file" id="mkimpf" accept=".xlsx,.xlsm" style="max-width:420px"><button id="mkimpread">Read the file</button></div>
      <div id="mkimp" style="margin-top:12px"></div>`;
    box.appendChild(card);
    const out = $('#mkimp', card);
    $('#mkimpread', card).onclick = async () => {
      const file = $('#mkimpf', card).files[0]; if (!file) return toast('Choose the Excel file first.', true);
      const b = $('#mkimpread', card); b.disabled = true; b.textContent = 'Reading…'; out.innerHTML = '<p class="hint">Reading the workbook — a big .xlsm takes a few seconds…</p>';
      try {
        const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('The file could not be read.')); r.readAsDataURL(file); });
        mktImportPreview(out, await POST('/api/mkt/import/preview', { name: file.name, data }));
      } catch (e) { out.innerHTML = ''; toast(e.message, true); }
      b.disabled = false; b.textContent = 'Read the file';
    };
  };
}

function mktExceptions(list) {
  if (!list.length) return '<p class="hint">Nothing to check by hand.</p>';
  const groups = {};
  for (const e of list) (groups[e.kind] = groups[e.kind] || []).push(e.text);
  return Object.entries(groups).map(([k, arr]) => `<details style="margin:4px 0"><summary><b>${esc(k)}</b> · ${arr.length}</summary>
    <div class="hint" style="margin:4px 0 8px 16px;line-height:1.6">${arr.map(esc).join('<br>')}</div></details>`).join('');
}

function mktImportPreview(out, p) {
  const c = p.counts;
  const opt = (g) => `<option value="">— choose —</option>${p.items.map(i => `<option value="${i.id}" ${String(g.suggest) === String(i.id) ? 'selected' : ''}>${esc(i.name)}${i.grade ? ' — ' + esc(i.grade) : ''}</option>`).join('')}
    <option value="KEEP" ${g.suggest === 'KEEP' ? 'selected' : ''}>Keep as written in Excel (no item)</option>`;
  out.innerHTML = `<div class="firmbox"><b>${esc(p.file)}</b> · sheet ${esc(p.sheet)}<br>
      ${c.leads} enquiries · ${c.samples} with a sample${c.comms != null ? ` · ${c.comms} calls and messages · ${c.calls} planned calls (${c.calls_pending} pending)` : ' · no history sheets in this file'}${c.old ? ` · ${c.old} old dispatches (2020–21)` : ''}
      ${c.already ? `<br>${c.already} enquiries were imported before — they are updated, their Excel samples, history and calls are replaced.` : ''}
      ${c.taken.length ? `<br><span class="neg">Ref No. ${c.taken.join(', ')} already belong to enquiries made in Mineral Saathi — those Excel rows are not imported.</span>` : ''}</div>
    <h4 style="margin:14px 0 6px">1 · Match each Excel grade to the Item List</h4>
    <p class="hint" style="margin:0 0 6px">Guessed where possible — please check. Mesh, colour and form are read from the Excel grade. Choose “Keep as written” for mixed entries such as “Y300 &amp; 150M”.</p>
    <div class="tablewrap"><table class="t"><thead><tr><th>Excel grade</th><th class="num">Samples</th><th>Read as</th><th>Item List</th></tr></thead><tbody>
      ${p.grades.map(g => `<tr><td><b>${esc(g.key)}</b></td><td class="num">${g.count}</td><td class="hint">${esc([g.parts.colour, g.parts.mesh ? g.parts.mesh + ' mesh' : '', g.parts.form].filter(Boolean).join(' · '))}</td>
        <td><select data-grade="${esc(g.key)}" style="min-width:260px">${opt(g)}</select></td></tr>`).join('') || '<tr><td colspan="4" class="muted">No grades in this file.</td></tr>'}</tbody></table></div>
    <h4 style="margin:14px 0 6px">2 · To check by hand (${p.exceptions.length})</h4>${mktExceptions(p.exceptions)}
    <div class="row" style="margin-top:14px"><button id="mkimpgo">Import now</button><span class="hint" id="mkimpleft"></span></div>`;
  const left = () => { const n = [...out.querySelectorAll('[data-grade]')].filter(s => !s.value).length; $('#mkimpleft', out).textContent = n ? `${n} grade${n === 1 ? '' : 's'} still to match` : ''; return n; };
  out.querySelectorAll('[data-grade]').forEach(s => s.onchange = left); left();
  $('#mkimpgo', out).onclick = async () => {
    if (left()) return toast('Match every grade first.', true);
    if (!confirm(`Import ${c.leads} enquiries from ${p.file}?`)) return;
    const b = $('#mkimpgo', out); b.disabled = true; b.textContent = 'Importing…';
    try {
      const grades = Object.fromEntries([...out.querySelectorAll('[data-grade]')].map(s => [s.dataset.grade, s.value]));
      mktImportDone(out, await POST('/api/mkt/import/run', { token: p.token, grades }));
      toast('Import finished'); mktMenu();
    } catch (e) { toast(e.message, true); b.disabled = false; b.textContent = 'Import now'; }
  };
}

function mktImportDone(out, r) {
  out.innerHTML = `<div class="firmbox"><b>Done.</b> ${r.leads_added} enquiries added, ${r.leads_updated} updated · ${r.samples} samples${r.history ? ` · ${r.comms} calls and messages · ${r.calls_pending} calls pending` : ' · history and calls already in Mineral Saathi kept'}.
      A safety copy was made in the backup folder (Marketing_before-import_….db).</div>
    <h4 style="margin:14px 0 6px">Check report</h4>
    <table class="t"><tbody>${r.checks.map(x => `<tr><td style="width:28px">${x.ok ? '<span class="badge PM">✓</span>' : '<span class="badge red">✕</span>'}</td><td><b>${esc(x.what)}</b><br><span class="hint">${esc(x.text)}</span></td></tr>`).join('')}</tbody></table>
    <h4 style="margin:14px 0 6px">10 enquiries to compare with Excel</h4>
    <div class="tablewrap"><table class="t"><thead><tr><th>Ref</th><th>Customer</th><th>City</th><th>Mobile</th><th>Sample</th><th class="num">Calls</th><th>Next call</th></tr></thead><tbody>
      ${r.sample.map(x => `<tr style="cursor:pointer" onclick="go('#/mkt/leads:${x.id}')"><td>${x.ref_no}</td><td><b>${esc(x.company || '')}</b></td><td>${esc(x.city || '')}</td><td>${esc(x.mobile1 || '')}</td>
        <td>${esc(x.sample)}</td><td class="num">${x.calls}</td><td>${dmy(x.next_call)}</td></tr>`).join('')}</tbody></table></div>
    <h4 style="margin:14px 0 6px">To check by hand (${r.exceptions.length})</h4>${mktExceptions(r.exceptions)}
    <div class="row" style="margin-top:12px"><button class="sec" onclick="go('#/mkt/leads')">Open Enquiries</button><button class="sec" onclick="go('#/mkt/calls')">Open Today's Calls</button></div>`;
}
