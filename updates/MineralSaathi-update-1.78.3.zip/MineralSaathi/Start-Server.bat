@echo off
title Mineral Saathi Server - keep this window open
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed on this PC.
  echo  Install "Node.js LTS" from https://nodejs.org and run this file again.
  echo.
  pause
  exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)"
if errorlevel 1 (
  echo  Your Node.js is too old. Install the latest "Node.js LTS" from https://nodejs.org
  pause
  exit /b 1
)
:run
node --no-warnings server\server.js
if %errorlevel%==2 (
  timeout /t 8
  exit /b 0
)
if %errorlevel%==3 (
  pause
  exit /b 1
)
echo.
echo  Server stopped. Restarting in 5 seconds... (close this window to stop it)
timeout /t 5 /nobreak >nul
goto run
