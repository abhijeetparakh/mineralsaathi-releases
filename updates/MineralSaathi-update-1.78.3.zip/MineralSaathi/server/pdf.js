'use strict';
// Makes a PDF of a print page using Microsoft Edge (already on every Windows PC), in the background.
const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');

const CANDIDATES = [
  process.env.MS_BROWSER,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  '/usr/bin/chromium', '/usr/bin/google-chrome'
].filter(Boolean);

function browser() {
  const b = CANDIDATES.find(p => { try { return fs.existsSync(p); } catch { return false; } });
  if (!b) throw new Error('Microsoft Edge was not found on the main PC, so the PDF could not be made.');
  return b;
}

function makePdf(url, outFile) {
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  const args = ['--headless=new', '--disable-gpu', '--no-first-run', '--no-pdf-header-footer',
    `--print-to-pdf=${outFile}`, url];
  if (process.platform !== 'win32') args.unshift('--no-sandbox');
  return new Promise((resolve, reject) => {
    execFile(browser(), args, { timeout: 60000, windowsHide: true }, err => {
      if (fs.existsSync(outFile) && fs.statSync(outFile).size > 500) resolve(outFile);
      else reject(new Error('PDF could not be made' + (err ? ': ' + err.message : '.')));
    });
  });
}

module.exports = { makePdf };
