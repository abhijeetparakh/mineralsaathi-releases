'use strict';
// Small message board between parts of the program (e.g. Marketing tells the email part that a tracking number changed).
const { EventEmitter } = require('node:events');
module.exports = new EventEmitter();
