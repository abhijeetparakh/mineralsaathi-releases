'use strict';
// Orders Expected → gentle reminder emails to buyers (two templates):
//   EXP_LATE — the order was expected (from past orders) and has not come: sent by itself N days after the expected date
//   EXP_SOON — the order is expected soon: sent by itself N days before the expected date
// Each is sent once for each expected date. A buyer with an order in the Orders Book, or who has stopped buying, is not emailed by itself.
const { all, get, run, setting, setSetting } = require('./db');
const mailer = require('./mailer');
const analysis = require('./analysis');

run(`CREATE TABLE IF NOT EXISTS exp_mails (id INTEGER PRIMARY KEY, party_id INTEGER, kind TEXT, expected TEXT, status TEXT, error TEXT, to_addr TEXT, auto INTEGER,
  at TEXT DEFAULT (datetime('now','localtime')))`);
class E extends Error { constructor(m) { super(m); this.status = 400; } }
const MON = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
const mi = ym => (Number(ym.slice(5, 7)) + 8) % 12;
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + Math.round(n)); return d.toISOString().slice(0, 10); };
const days = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 864e5);
const dmy = iso => iso ? iso.split('-').reverse().join('.') : '';
const mt = n => { const v = Math.round((Number(n) || 0) * 1000) / 1000; return Number.isInteger(v) ? String(v) : v.toFixed(3); };

// the same study as Reports → Expected Orders (public/analysis.js anPredict)
function predict() {
  const d = analysis.data(), med = a => { const s = [...a].sort((x, y) => x - y), n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : 0; };
  const by = new Map();
  for (const o of d.orders) { const p = d.parties[o[0]]; if (!p || p.own || /ONLINE SALE/i.test(p.name)) continue; (by.get(o[0]) || by.set(o[0], []).get(o[0])).push(o); }
  const today = d.today, from4 = addDays(today, -4 * 365), out = [];
  for (const [pk, os] of by) {
    os.sort((a, b) => a[1].localeCompare(b[1]));
    const ord = []; for (const o of os) { const l = ord[ord.length - 1]; if (l && days(l.date, o[1]) <= 3) { l.qty += o[3]; o[5].split(', ').forEach(x => l.items.add(x)); } else ord.push({ date: o[1], qty: o[3], items: new Set(o[5].split(', ')) }); }
    if (ord.length < 3) continue;
    const recent = ord.filter(o => o.date >= from4), use = recent.length >= 3 ? recent : ord.slice(-6);
    const gaps = []; for (let i = 1; i < use.length; i++) gaps.push(days(use[i - 1].date, use[i].date));
    const g = gaps.slice(-8), gap = Math.max(7, med(g));
    const last = ord[ord.length - 1]; let next = addDays(last.date, gap), late = days(next, today);
    const q = med(ord.slice(-5).map(o => o.qty)), since = days(last.date, today);
    const cnt = new Map(); ord.slice(-5).forEach(o => o.items.forEach(i => cnt.set(i, (cnt.get(i) || 0) + 1)));
    const items = [...cnt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]).join(', ');
    const months = new Map(); ord.slice(-12).forEach(o => months.set(mi(o.date.slice(0, 7)), 1));
    let status = late > Math.max(gap, 180) || since > 730 ? 'lost' : late > Math.max(10, gap * 0.25) ? 'overdue' : late > -31 ? 'due' : 'later';
    const seasonal = months.size && ord.length >= 6 && months.size <= 4 ? [...months.keys()].sort((a, b) => a - b) : null;
    if (seasonal && status !== 'due' && status !== 'later' && since <= 730) {
      const cm = mi(today.slice(0, 7)); let k = 1; while (k <= 12 && !seasonal.includes((cm + k) % 12)) k++;
      const t = Number(today.slice(0, 4)) * 12 + Number(today.slice(5, 7)) - 1 + k; next = `${Math.floor(t / 12)}-${String(t % 12 + 1).padStart(2, '0')}-01`; late = days(next, today); status = late > -31 ? 'due' : 'later';
    }
    out.push({ pk, party_id: pk[0] === 'p' ? Number(pk.slice(1)) : null, name: d.parties[pk].name, last: last.date, lastQty: last.qty, gap: Math.round(gap), next, late, qty: q, items, status,
      season: seasonal ? seasonal.map(i => MON[i]).join(', ') : '' });
  }
  return { today, list: out };
}

const EXP_VARS = ['Buyer name', 'Usual items', 'Usual qty', 'Last order date', 'Last order qty', 'Expected date', 'Days late', 'Days to go', 'Seller name', 'Today'];
const STD = {
  EXP_LATE: 'Dear Sir / Madam,\n\nGreetings from {Seller name}.\n\nYour last order of {Usual items} was on {Last order date}, and as per your usual buying we were expecting your next order around {Expected date}.\n\nThis is just a gentle reminder — if you need {Usual items} (about {Usual qty} MT), we will be happy to dispatch at the earliest. Please share your requirement, or let us know if there is anything we can do better for you.\n\nThank you for your continued business.\n\nRegards,\n{Seller name}',
  EXP_SOON: 'Dear Sir / Madam,\n\nGreetings from {Seller name}.\n\nAs per your usual buying, your next requirement of {Usual items} (about {Usual qty} MT) may be due around {Expected date}.\n\nTo plan production and dispatch on time, kindly share your order and the dispatch date at your convenience. We will be happy to serve you.\n\nThank you for your continued business.\n\nRegards,\n{Seller name}'
};
const NAMES = { EXP_LATE: 'Gentle reminder — order expected (late)', EXP_SOON: 'Gentle reminder — order coming soon' };
for (const k of Object.keys(STD)) if (!get('SELECT 1 FROM email_templates WHERE purpose = ?', k))
  run('INSERT INTO email_templates(name, purpose, body, html, is_default, auto_send) VALUES(?,?,?,?,1,0)', NAMES[k], k, STD[k], mailer.textToHtml(STD[k]));

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function fill(tpl, x, firm, html) {
  const v = { 'buyer name': x.name, 'usual items': x.items, 'usual qty': mt(x.qty), 'last order date': dmy(x.last), 'last order qty': mt(x.lastQty), 'expected date': dmy(x.next),
    'days late': String(Math.max(0, x.late)), 'days to go': String(Math.max(0, -x.late)), 'seller name': firm.name || '', today: dmy(new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10)) };
  return String(tpl || '').replace(/\{([^{}<>]+)\}/g, (m, k) => { const r = v[k.trim().toLowerCase()]; return r == null ? m : html ? esc(r) : r; });
}
function draft(pk, kind, tid) {
  const p = predict(), x = p.list.find(r => r.pk === pk); if (!x || !x.party_id) throw new E('This buyer has not enough past orders to expect the next one.');
  const party = get('SELECT * FROM parties WHERE id = ?', x.party_id); if (!party) throw new E('Buyer not found.');
  kind = kind === 'EXP_SOON' || kind === 'EXP_LATE' ? kind : (x.next < p.today ? 'EXP_LATE' : 'EXP_SOON');
  const firm = get('SELECT * FROM firms WHERE code = ?', party.firm_code || 'PM') || {};
  const tpl = tid ? get('SELECT name, body, html FROM email_templates WHERE id = ?', tid) : get('SELECT name, body, html FROM email_templates WHERE purpose = ? AND active = 1 ORDER BY is_default DESC, id LIMIT 1', kind);
  const to = mailer.splitAddr(party.email);
  return { kind, x, party_id: party.id, to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), firm_code: firm.code, firm: firm.name, from: firm.smtp_user || firm.email || '', ready: !!(firm.smtp_user && firm.smtp_pass),
    subject: kind === 'EXP_LATE' ? `Gentle reminder — your next order of ${x.items.split(', ')[0] || 'our material'} — ${firm.name || ''}` : `Your next requirement of ${x.items.split(', ')[0] || 'our material'} — ${firm.name || ''}`,
    template_name: tpl ? tpl.name : 'Standard message', text: fill(tpl ? tpl.body : STD[kind], x, firm), html: fill(tpl && tpl.html ? tpl.html : mailer.textToHtml(tpl ? tpl.body : STD[kind]), x, firm, true),
    templates: all('SELECT id, name, is_default FROM email_templates WHERE purpose = ? AND active = 1 ORDER BY is_default DESC, name', kind),
    sent: all('SELECT kind, expected, status, at, auto FROM exp_mails WHERE party_id = ? ORDER BY id DESC LIMIT 5', party.id) };
}

module.exports = function register(route, { smtpSend, brandLogo }) {
  async function send(pk, body, auto) {
    const dr = draft(pk, body.kind), party = get('SELECT * FROM parties WHERE id = ?', dr.party_id), firm = get('SELECT * FROM firms WHERE code = ?', dr.firm_code) || {};
    const to = mailer.splitAddr(body.to != null ? body.to : dr.to), cc = mailer.splitAddr(body.cc != null ? body.cc : dr.cc);
    const log = (status, error) => {
      run('INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)', firm.code, firm.name, party.name, to.join('; '),
        body.template_name || dr.template_name, 'Expected ' + dmy(dr.x.next), (dr.kind === 'EXP_LATE' ? 'Order reminder (late)' : 'Order reminder (coming)') + (auto ? ' — automatic' : ''), status, error || null, null);
      run('INSERT INTO exp_mails(party_id, kind, expected, status, error, to_addr, auto) VALUES(?,?,?,?,?,?,?)', party.id, dr.kind, dr.x.next, status, error || null, to.join('; '), auto ? 1 : 0);
    };
    try {
      if (!firm.smtp_user || !firm.smtp_pass) throw new E(`Email is not set up for ${firm.name || 'the firm'}. Open Settings → Companies → Email.`);
      if (!to.length) throw new E(`${party.name} has no email address in Buyers.`);
      await smtpSend({ host: firm.smtp_host || 'smtp.gmail.com', port: firm.smtp_port || 465, user: firm.smtp_user, pass: firm.smtp_pass },
        { from: firm.smtp_user, fromName: firm.name, logo: brandLogo(firm), to, cc, subject: body.subject || dr.subject, text: body.text || dr.text, html: body.html || dr.html });
      log('SENT'); return { sent: true, to: to.join(', ') };
    } catch (e) { log('FAILED', e.message); throw e; }
  }
  // automatic: once an hour between 10 am and 7 pm
  let busy = false;
  async function autoRun() {
    const lateOn = setting('exp_late_auto', '0') === '1', soonOn = setting('exp_soon_auto', '0') === '1';
    if ((!lateOn && !soonOn) || busy) return;
    const h = new Date().getHours(); if (h < 10 || h >= 19) return;
    busy = true;
    try {
      const p = predict(), nLate = Number(setting('exp_late_days', '7')) || 7, nSoon = Number(setting('exp_soon_days', '5')) || 5;
      const inBook = new Set(all('SELECT party_id FROM orders').map(r => r.party_id));
      let n = 0;
      for (const x of p.list) {
        if (n >= 20 || !x.party_id || x.status === 'lost' || inBook.has(x.party_id)) continue;
        // late: from N days after the expected date, for 30 days (older ones only by hand, so switching on does not email buyers months late)
        const kind = x.late >= nLate && x.late <= nLate + 30 && lateOn ? 'EXP_LATE' : x.late <= 0 && -x.late <= nSoon && soonOn ? 'EXP_SOON' : null;
        if (!kind) continue;
        if (get("SELECT 1 FROM exp_mails WHERE party_id = ? AND kind = ? AND expected = ? AND (status = 'SENT' OR (status = 'FAILED' AND at > datetime('now','localtime','-1 day')))", x.party_id, kind, x.next)) continue;
        const party = get('SELECT email FROM parties WHERE id = ?', x.party_id); if (!party || !String(party.email || '').trim()) continue;
        n++;
        try { await send(x.pk, { kind }, true); console.log(`  Order reminder (${kind}) sent to ${x.name} (automatic).`); } catch (e) { console.error(`  Order reminder to ${x.name}: ${e.message}`); }
      }
    } finally { busy = false; }
  }
  setTimeout(() => autoRun().catch(e => console.error('Order reminder:', e.message)), 3 * 60e3).unref();
  setInterval(() => autoRun().catch(e => console.error('Order reminder:', e.message)), 60 * 60e3).unref();

  route('GET', '/api/exp-mail/:pk', ({ p, q }) => draft(decodeURIComponent(p.pk), q.kind, q.tid ? Number(q.tid) : null));
  route('POST', '/api/exp-mail/:pk', ({ p, body }) => send(decodeURIComponent(p.pk), body || {}, false));
  route('GET', '/api/exp-mail-status', () => Object.fromEntries(all(`SELECT party_id, kind, expected, status, at FROM exp_mails WHERE id IN (SELECT MAX(id) FROM exp_mails GROUP BY party_id)`).map(r => ['p' + r.party_id, r])));
  route('GET', '/api/exp-mail-settings', () => ({ late_auto: setting('exp_late_auto', '0') === '1', late_days: Number(setting('exp_late_days', '7')) || 7, soon_auto: setting('exp_soon_auto', '0') === '1', soon_days: Number(setting('exp_soon_days', '5')) || 5 }));
  route('PUT', '/api/exp-mail-settings', ({ body }) => {
    for (const k of ['late', 'soon']) {
      if (body[k + '_auto'] !== undefined) setSetting(`exp_${k}_auto`, Number(body[k + '_auto']) ? '1' : '0');
      if (body[k + '_days'] !== undefined) { const n = Math.round(Number(body[k + '_days'])); if (!(n >= 0 && n <= 60)) throw new E('Days: 0 to 60.'); setSetting(`exp_${k}_days`, String(n)); }
    }
    return { ok: true };
  });
};
module.exports.EXP_VARS = EXP_VARS;
