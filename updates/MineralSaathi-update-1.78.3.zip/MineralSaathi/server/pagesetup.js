'use strict';
// Page setup of each paper on THIS computer (saved in config.json, like the printers): which printer, which paper,
// where on the paper and how big. The PM / PPE / PF sales invoices (and proformas) keep their own setup.
const { pageSetup, pageShell, paperSize, sheetSize, sheetCount, mediaFor, placeDoc, printable, isMulti, PAGE_PAPERS, LABEL_PRESETS, setupFor } = require('./print');

// every paper with a page setup: key, name, group, design (the size it is drawn at) and the old printer kind it starts from
const PAPERS = [
  { key: 'mkt_stickers', name: 'Sample stickers', group: 'Marketing', design: 'label' },
  { key: 'mkt_cover', name: 'Cover letter', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_address', name: 'Address label', group: 'Marketing', design: 'label' },
  { key: 'mkt_bags', name: 'Bag stickers (samples)', group: 'Marketing', design: 'label' },
  { key: 'mkt_envelope', name: 'Envelope (samples)', group: 'Marketing', design: 'envelope' },
  { key: 'mkt_annexure', name: 'Annexure-A', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_cdf', name: 'CDF-I (India Post)', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_cn23', name: 'CN 23 customs declaration', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_towhom', name: 'To Whom It May Concern', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_note', name: 'Sample note', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_freight', name: 'Local freight letter (samples)', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_quick', name: 'Quick sticker', group: 'Marketing', design: 'label' },
  { key: 'mkt_letter', name: 'Letter pad', group: 'Marketing', design: 'invoice' },
  { key: 'mkt_bus', name: 'Bus parcel label', group: 'Marketing', design: 'label' },
  { key: 'mkt_blankenv', name: 'Blank envelope', group: 'Marketing', design: 'envelope' },
  { key: 'label', name: 'Bag / parcel stickers', group: 'Billing', design: 'label' },
  { key: 'envelope', name: 'Envelope', group: 'Billing', design: 'envelope' },
  { key: 'voucher', name: 'Inward & freight voucher', group: 'Billing', design: 'invoice' },
  { key: 'localfreight', name: 'Local freight letter', group: 'Billing', design: 'invoice', margin: 12 },
  { key: 'trinvoice', name: 'Transporter invoice', group: 'Billing', design: 'invoice', margin: 8 },
  { key: 'wages', name: 'Factory wages voucher', group: 'Billing', design: 'invoice', margin: 12 }
];
const byKey = k => PAPERS.find(x => x.key === k);

// the size each paper is drawn at (its own paper, before the page setup places it)
function design(key) { const x = byKey(key); const s = setupFor(x.design, x.margin != null ? { margin: x.margin } : {}); return { w: s.w, h: s.h, pad: s.margin }; }

module.exports = function create({ pcSettings, savePcSettings }) {
  // first use: start from the printer and paper already chosen for that kind on this computer (Printer Settings)
  function defaults(key) {
    const x = byKey(key), old = (pcSettings() || {})['print_' + x.design] || {};
    const d = { printer: old.printer || '', margin: 0, fit: true, area: 'full' };
    if (x.design === 'label') Object.assign(d, { paper: 'LABEL4X6' });
    else if (x.design === 'envelope') Object.assign(d, { paper: 'ENV_DL', landscape: true });
    else Object.assign(d, { paper: 'A4' });
    // billing bag stickers and envelopes keep the paper, nudge and size they were set to before
    if (['label', 'envelope'].includes(key) && (old.paper || old.w)) {
      if (old.paper && PAGE_PAPERS[old.paper]) d.paper = old.paper; else if (old.w && old.h) Object.assign(d, { paper: 'CUSTOM', cw: old.w, ch: old.h });
      if (old.landscape !== undefined) d.landscape = !!old.landscape;
      d.ox = Number(old.ox) || 0; d.oy = Number(old.oy) || 0;
      if (old.scale && Number(old.scale) !== 100) { d.fit = false; d.scale = Number(old.scale); }
    }
    return d;
  }
  function get(key) {
    if (!byKey(key)) throw new Error('Unknown paper ' + key);
    const saved = (pcSettings() || {})['page_' + key];
    return pageSetup(saved, defaults(key));
  }
  function save(key, raw) {
    if (!byKey(key)) throw Object.assign(new Error('Unknown paper.'), { status: 400 });
    const p = pageSetup(raw, defaults(key));
    savePcSettings({ ['page_' + key]: p });
    return p;
  }
  // the sheets to send for n documents of a paper, in batches of at most 10 documents
  function jobs(key, n, url, port) {
    const p = get(key), m = mediaFor(p), out = [];
    for (let a = 1; a <= n; a += 10) {
      const b = Math.min(n, a + 9);
      out.push({ url: `http://127.0.0.1:${port}${url}${url.includes('?') ? '&' : '?'}shot=1&from=${a}&to=${b}`, w: m.w, h: m.h, count: sheetCount(p, b - a + 1), paperName: m.paperName, noTurn: m.noTurn });
    }
    return { printer: p.printer, pages: out };
  }

  // test / preview page: the design box with a ruler, so the place on the paper can be checked
  function testHtml(key, p, opts = {}) {
    const d = design(key), x = byKey(key);
    const n = isMulti(p) ? p.across * p.down : 1;
    const doc = i => `<div style="position:relative;width:100%;height:100%;border:1.5px solid #9A4A2A;font-family:Arial;color:#2F4F5A;
      background: repeating-linear-gradient(90deg, transparent 0, transparent 9.8mm, #e6c9bd 9.8mm, #e6c9bd 10mm), repeating-linear-gradient(0deg, transparent 0, transparent 9.8mm, #e6c9bd 9.8mm, #e6c9bd 10mm)">
      <div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);text-align:center;background:#fff;padding:2mm 3mm;border:1px solid #9A4A2A">
        <b style="font-size:${Math.max(9, Math.min(20, d.w / 9))}px">${x.name}${n > 1 ? ' · ' + (i + 1) : ''}</b><br><span style="font-size:10px">${d.w} × ${d.h} mm · 10 mm squares</span></div>
      <div style="position:absolute;left:1mm;top:1mm;font-size:10px;font-weight:700">▲ TOP · LEFT</div>
      <div style="position:absolute;right:1mm;bottom:1mm;font-size:10px;font-weight:700">BOTTOM · RIGHT ▼</div></div>`;
    return pageShell(`Page setup test · ${x.name}`, Array.from({ length: n }, (_, i) => doc(i)), { w: d.w, h: d.h, pad: 0 }, { ...p, copies: 1 }, opts);
  }

  function register(route, { isLocal, port, winprint }) {
    route('GET', '/api/page-setup', ({ req }) => ({
      local: isLocal(req), direct: winprint.supported(), presets: LABEL_PRESETS, papers_std: PAGE_PAPERS,
      papers: PAPERS.map(x => ({ key: x.key, name: x.name, group: x.group, design: design(x.key), setup: get(x.key) }))
    }));
    route('PUT', '/api/page-setup/:key', ({ p, body }) => save(p.key, body));
    // what the setup gives: paper size, printed page size, sheets for one document, where it lands
    route('POST', '/api/page-setup/:key/check', ({ p, body }) => {
      const s = pageSetup(body, {}), d = design(p.key), q = placeDoc(s, d.w, d.h), a = printable(s), [pw, ph] = paperSize(s), [sw, sh] = sheetSize(s);
      return { paper: [pw, ph], sheet: [sw, sh], area: a, place: q, scale: Math.round(q.k * 1000) / 10, design: d };
    });
    route('POST', '/api/page-setup/:key/test', async ({ p, body, req }) => {
      const s = get(p.key);
      if (!(winprint.supported() && s.printer && (isLocal(req) || body.where === 'main'))) return { browser: true, url: `/print/pagetest/${p.key}?print=1` };
      const m = mediaFor(s);
      await winprint.printPages(s.printer, [{ url: `http://127.0.0.1:${port()}/print/pagetest/${p.key}?shot=1`, w: m.w, h: m.h, count: 1, paperName: m.paperName, noTurn: m.noTurn }], 'Mineral Saathi page setup test');
      return { printed: true, printer: s.printer };
    });
  }
  // GET /print/pagetest/<key>  (?s=<setup as JSON> previews a setup that is not saved yet)
  function serveTest(url, q, res, send) {
    const m = url.pathname.match(/^\/print\/pagetest\/([a-z_]+)$/);
    if (!m || !byKey(m[1])) return send(res, 404, 'Not found', 'text/plain');
    let s = get(m[1]);
    if (q.s) { try { s = pageSetup(JSON.parse(q.s), {}); } catch { /* keep saved */ } }
    return send(res, 200, testHtml(m[1], s, { shot: q.shot === '1', autoPrint: q.print === '1' }), 'text/html; charset=utf-8');
  }
  return { PAPERS, get, save, jobs, design, register, serveTest };
};
module.exports.PAPERS = PAPERS;
