'use strict';
// Silent printing on the computer that runs Mineral Saathi (main office PC, home PC, laptop).
// Each page is drawn by Microsoft Edge as a sharp picture at the exact paper size, then sent by
// Windows straight to the chosen printer — no print window, nothing extra to install.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile } = require('node:child_process');

const PS = (args, timeout = 60000) => new Promise((resolve, reject) => {
  execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args], { windowsHide: true, timeout, maxBuffer: 4e6 }, (err, out, errOut) => {
    if (err && !out) return reject(new Error((errOut || err.message || '').toString().trim().split('\n').pop()));
    resolve(String(out || '').trim());
  });
});

const supported = () => process.platform === 'win32';

async function printers() {
  if (!supported()) return { printers: [], default: null };
  const out = await PS(['-Command', `Add-Type -AssemblyName System.Drawing; $d=(New-Object System.Drawing.Printing.PrinterSettings).PrinterName; [System.Drawing.Printing.PrinterSettings]::InstalledPrinters | ForEach-Object { if ($_ -eq $d) { "*" + $_ } else { $_ } }`]);
  const lines = out.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  return { printers: lines.map(s => s.replace(/^\*/, '')), default: (lines.find(s => s.startsWith('*')) || '').slice(1) || null };
}

async function papers(name) {
  if (!supported() || !name) return [];
  const n = name.replace(/'/g, "''");
  const out = await PS(['-Command', `Add-Type -AssemblyName System.Drawing; $p=New-Object System.Drawing.Printing.PrinterSettings; $p.PrinterName='${n}'; if(-not $p.IsValid){exit}; $c=$p.DefaultPageSettings.PaperSize.PaperName; foreach($s in $p.PaperSizes){ if($s.Width -gt 0){ "{0}|{1}|{2}|{3}" -f $s.PaperName,([Math]::Round($s.Width*0.254,1)),([Math]::Round($s.Height*0.254,1)),($s.PaperName -eq $c) } }`]);
  return out.split(/\r?\n/).filter(Boolean).map(l => { const [n2, w, h, cur] = l.split('|'); return { name: n2.trim(), w: Number(w), h: Number(h), current: cur === 'True' }; });
}

function browser() {
  const c = [process.env.MS_BROWSER, 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', '/opt/google/chrome/chrome', '/usr/bin/chromium'].filter(Boolean);
  const b = c.find(p => { try { return fs.existsSync(p); } catch { return false; } });
  if (!b) throw new Error('Microsoft Edge was not found, so the page could not be drawn for printing.');
  return b;
}

// draw one page (url must render exactly one sheet in "shot" mode) as a PNG
function snapshot(url, wMm, hMm, out, wait = false) {
  const px = mm => Math.round(mm / 25.4 * 96);
  const args = ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--force-device-scale-factor=3',
    `--window-size=${px(wMm)},${px(hMm)}`, `--screenshot=${out}`, ...(wait ? ['--virtual-time-budget=15000', '--run-all-compositor-stages-before-draw'] : []), url];
  if (process.platform !== 'win32') args.unshift('--no-sandbox');
  return new Promise((resolve, reject) => {
    execFile(browser(), args, { timeout: 60000, windowsHide: true }, err => {
      if (fs.existsSync(out) && fs.statSync(out).size > 1000) resolve(out);
      else reject(new Error('The page could not be drawn for printing' + (err ? ': ' + err.message : '.')));
    });
  });
}

// draw a page that finishes drawing by itself (window.__ewbDone): the browser is driven over DevTools so the
// picture is taken only when the page says it is ready (e.g. the e-way bill PDF drawn on the back of the invoice)
async function snapshotReady(url, wMm, hMm, out) {
  const { spawn } = require('node:child_process');
  const px = mm => Math.round(mm / 25.4 * 96);
  const port = 9300 + Math.floor(Math.random() * 600);
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'ms-cdp-'));
  const args = ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, 'about:blank'];
  if (process.platform !== 'win32') args.unshift('--no-sandbox');
  const br = spawn(browser(), args, { windowsHide: true, stdio: 'ignore' });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  try {
    let target = null;
    for (let i = 0; i < 60 && !target; i++) { await sleep(250); try { const l = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); target = l.find(x => x.type === 'page'); } catch { /* starting */ } }
    if (!target) throw new Error('the browser did not start');
    const ws = new WebSocket(target.webSocketDebuggerUrl); let id = 0; const wait = {};
    await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('no DevTools connection')); });
    ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && wait[m.id]) { wait[m.id](m); delete wait[m.id]; } };
    const call = (method, params = {}) => new Promise((res, rej) => { const n = ++id; wait[n] = m => m.error ? rej(new Error(m.error.message)) : res(m.result); ws.send(JSON.stringify({ id: n, method, params })); });
    await call('Emulation.setDeviceMetricsOverride', { width: px(wMm), height: px(hMm), deviceScaleFactor: 3, mobile: false });
    await call('Page.enable'); await call('Page.navigate', { url });
    let ready = false;
    for (let i = 0; i < 120 && !ready; i++) { await sleep(250); try { const r = await call('Runtime.evaluate', { expression: 'document.readyState === "complete" && window.__ewbDone !== false', returnByValue: true }); ready = r.result.value === true; } catch { /* navigating */ } }
    await sleep(300);
    const shot = await call('Page.captureScreenshot', { format: 'png', clip: { x: 0, y: 0, width: px(wMm), height: px(hMm), scale: 1 }, captureBeyondViewport: true });
    fs.writeFileSync(out, Buffer.from(shot.data, 'base64')); ws.close();
    return out;
  } finally { try { br.kill(); } catch { /* gone */ } setTimeout(() => { try { fs.rmSync(prof, { recursive: true, force: true }); } catch { /* in use */ } }, 3000); }
}

// pages: [{ url, w, h, count }] → each url shows `count` sheets one under the other; printed in order on `printer`
async function printPages(printer, pages, job) {
  if (!supported()) throw new Error('Direct printing works only on Windows.');
  if (!printer) throw new Error('No printer is chosen for this. Choose one in Settings → This computer → Printers.');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ms-print-'));
  try {
    for (let i = 0; i < pages.length; i++) {
      const pg = pages[i];
      const png = path.join(dir, `p${i}.png`);
      const count = Math.max(1, pg.count || 1);
      if (pg.wait) await snapshotReady(pg.url, pg.w, pg.h * count, png); else await snapshot(pg.url, pg.w, pg.h * count, png);
      const res = await PS(['-File', path.join(__dirname, 'print-image.ps1'), '-Printer', printer, '-Image', png, '-WidthMm', String(pg.w), '-HeightMm', String(pg.h),
        '-Copies', String(pg.copies || 1), '-Pages', String(count), '-Job', job, ...(pg.duplex ? ['-Duplex'] : []),
        ...(pg.paperName ? ['-PaperName', pg.paperName] : []), ...(pg.noTurn ? ['-NoTurn'] : [])], 180000);
      if (/NOPRINTER/.test(res)) throw new Error(`The printer "${printer}" isn't available on this computer. Check that it is on, or choose another in Settings → This computer.`);
    }
  } finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ } }
}

module.exports = { supported, printers, papers, printPages, snapshot, snapshotReady };
