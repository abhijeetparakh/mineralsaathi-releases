# Prints a picture of a page to a named Windows printer, at the given paper size, with no print window.
param([string]$Printer, [string]$Image, [double]$WidthMm, [double]$HeightMm, [int]$Copies = 1, [int]$Pages = 1, [string]$Job = "Mineral Saathi", [switch]$Duplex, [string]$PaperName = "", [switch]$NoTurn)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile($Image)
try {
  $pd = New-Object System.Drawing.Printing.PrintDocument
  $pd.PrinterSettings.PrinterName = $Printer
  if (-not $pd.PrinterSettings.IsValid) { Write-Output "NOPRINTER"; exit 2 }
  $pd.DocumentName = $Job
  $pd.PrinterSettings.Copies = [Math]::Max(1, $Copies)
  # both sides (invoice in front, e-way bill on the back), when the printer can
  if ($Duplex -and $pd.PrinterSettings.CanDuplex) { $pd.PrinterSettings.Duplex = [System.Drawing.Printing.Duplex]::Vertical }
  # label rolls are sent exactly as they lie (width across the roll, height along it), never turned
  $landscape = (-not $NoTurn) -and ($WidthMm -gt $HeightMm)
  if ($NoTurn) { $sw = $WidthMm; $lg = $HeightMm } else { $sw = [Math]::Min($WidthMm, $HeightMm); $lg = [Math]::Max($WidthMm, $HeightMm) }
  $w = [int][Math]::Round($sw / 25.4 * 100); $h = [int][Math]::Round($lg / 25.4 * 100)
  # use the printer's own paper of that size when its driver has one (label printers name theirs, e.g. "USER")
  $paper = $null
  # the paper chosen from the printer's own list (Page setup), when it is there
  if ($PaperName) { foreach ($p in $pd.PrinterSettings.PaperSizes) { if ($p.PaperName -eq $PaperName) { $paper = $p; break } } }
  if (-not $paper) { foreach ($p in $pd.PrinterSettings.PaperSizes) {
    if (([Math]::Abs($p.Width - $w) -le 4 -and [Math]::Abs($p.Height - $h) -le 4)) { $paper = $p; break }
    if (-not $NoTurn -and ([Math]::Abs($p.Width - $h) -le 4 -and [Math]::Abs($p.Height - $w) -le 4)) { $paper = $p; break }
  } }
  if (-not $paper) { $paper = New-Object System.Drawing.Printing.PaperSize("Custom", $w, $h) }
  $pd.DefaultPageSettings.PaperSize = $paper
  $pd.DefaultPageSettings.Landscape = $landscape
  $pd.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(0, 0, 0, 0)
  $pd.OriginAtMargins = $false
  $pd.PrintController = New-Object System.Drawing.Printing.StandardPrintController
  # the picture holds $Pages pages one under the other; each is printed on its own sheet
  $script:page = 0
  $sliceH = $img.Height / [Math]::Max(1, $Pages)
  $pd.add_PrintPage({
    param($s, $e)
    $e.Graphics.TranslateTransform(-$e.PageSettings.HardMarginX, -$e.PageSettings.HardMarginY)
    $e.Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $src = New-Object System.Drawing.RectangleF(0, ($script:page * $sliceH), $img.Width, $sliceH)
    $dst = New-Object System.Drawing.RectangleF(0, 0, $e.PageBounds.Width, $e.PageBounds.Height)
    $e.Graphics.DrawImage($img, $dst, $src, [System.Drawing.GraphicsUnit]::Pixel)
    $script:page++
    $e.HasMorePages = $script:page -lt $Pages
  })
  $pd.Print()
  Write-Output "OK"
} finally { $img.Dispose() }
