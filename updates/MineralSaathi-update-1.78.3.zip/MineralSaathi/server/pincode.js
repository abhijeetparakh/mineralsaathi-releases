'use strict';
// City and state from an Indian pincode (offline list).
const fs = require('node:fs');
const path = require('node:path');
let PINS = null;
function lookup(pin) {
  if (!PINS) PINS = JSON.parse(fs.readFileSync(path.join(__dirname, 'pincodes.json'), 'utf8'));
  const v = PINS[String(pin || '').replace(/\D/g, '')];
  if (!v) return null;
  const [city, state] = v.split('|');
  return { city, state };
}
module.exports = { lookup };
