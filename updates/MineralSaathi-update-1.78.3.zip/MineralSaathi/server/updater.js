'use strict';
// Automatic updates.
// The main PC checks the release page every 30 minutes. When a newer version is there it
// downloads it, takes a backup, copies the new program files in (never the data folder),
// and restarts the server. Every PC then reloads the new screens by itself.
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { setting, setSetting, ROOT, DATA_DIR } = require('./db');
const backup = require('./backup');

// latest.json in the update repository: { "version": "1.4.3", "url": "<zip link>", "notes": "..." }
const DEFAULT_SOURCE = 'https://raw.githubusercontent.com/abhijeetparakh/mineralsaathi-releases/main/latest.json';
const ASSET = /^MineralSaathi-update.*\.zip$/i;
// what an update may replace; data, import files and the running Start-Server.bat are never touched
const ALLOWED = ['server', 'public', 'windows', 'tools', 'version.json', 'README.txt',
  'Open-Mineral-Saathi.bat', 'Setup-Main-PC.bat', 'Setup-Other-PC.bat'];

let lastWrite = 0;               // time of the last save from any PC
let busy = false;
const markWrite = () => { lastWrite = Date.now(); };

const currentVersion = () => JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;
const parse = v => String(v || '').replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
function newer(a, b) { const x = parse(a), y = parse(b); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }

function status() {
  return {
    current: currentVersion(), auto: setting('auto_update', '1') === '1', source: setting('update_source') || DEFAULT_SOURCE,
    last_check: setting('update_last_check'), latest: setting('update_latest'), message: setting('update_message'), busy
  };
}

async function latestRelease() {
  const src = setting('update_source') || DEFAULT_SOURCE;
  const r = await fetch(src + (src.includes('?') ? '&' : '?') + 't=' + Date.now(), { headers: { 'User-Agent': 'MineralSaathi', Accept: 'application/json', 'Cache-Control': 'no-cache' } });
  if (r.status === 404) throw new Error('No update page found yet.');
  if (!r.ok) throw new Error('Update check failed (' + r.status + ').');
  const j = await r.json();
  if (j.version) return { version: String(j.version).replace(/^v/i, ''), notes: j.notes || '', url: j.url, name: j.url && j.url.split('/').pop() };
  const asset = (j.assets || []).find(a => ASSET.test(a.name));   // GitHub release page format
  return { version: (j.tag_name || '').replace(/^v/i, ''), notes: j.body || '', url: asset && asset.browser_download_url, name: asset && asset.name };
}

function extract(zip, dest) {
  fs.mkdirSync(dest, { recursive: true });
  try { execFileSync('tar', ['-xf', zip, '-C', dest], { windowsHide: true, stdio: 'ignore' }); return; } catch { /* try next */ }
  try {
    execFileSync('powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dest}' -Force`], { windowsHide: true, stdio: 'ignore' });
    return;
  } catch { /* try next */ }
  execFileSync('unzip', ['-o', '-q', zip, '-d', dest], { stdio: 'ignore' });
}

function copyInto(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const f of fs.readdirSync(src)) copyInto(path.join(src, f), path.join(dst, f));
  } else fs.copyFileSync(src, dst);
}

// check = look for a new version; install = also put it in (when quiet, unless forced)
async function check({ install = true, force = false } = {}) {
  if (busy) return status();
  busy = true;
  try {
    setSetting('update_last_check', new Date().toISOString());
    const rel = await latestRelease();
    setSetting('update_latest', rel.version);
    const cur = currentVersion();
    if (!newer(rel.version, cur)) { setSetting('update_message', `Up to date (version ${cur}).`); return status(); }
    if (!rel.url) { setSetting('update_message', `Version ${rel.version} is out, but its package is missing.`); return status(); }
    if (!install) { setSetting('update_message', `Version ${rel.version} is ready to install.`); return status(); }
    if (!force && Date.now() - lastWrite < 5 * 60 * 1000) { setSetting('update_message', `Version ${rel.version} will install when nobody has saved anything for 5 minutes.`); return status(); }

    const dir = path.join(DATA_DIR, 'updates');
    fs.mkdirSync(dir, { recursive: true });
    const zip = path.join(dir, `update-${rel.version}.zip`);
    const r = await fetch(rel.url, { headers: { 'User-Agent': 'MineralSaathi' } });
    if (!r.ok) throw new Error('Download failed (' + r.status + ').');
    fs.writeFileSync(zip, Buffer.from(await r.arrayBuffer()));
    const out = path.join(dir, `update-${rel.version}`);
    fs.rmSync(out, { recursive: true, force: true });
    extract(zip, out);
    const root = fs.existsSync(path.join(out, 'MineralSaathi', 'version.json')) ? path.join(out, 'MineralSaathi') : out;
    const newVer = JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8')).version;
    if (!fs.existsSync(path.join(root, 'server', 'server.js'))) throw new Error('The update package looks damaged — not installed.');

    try { backup.backupNow('before-update'); } catch (e) { console.error('Backup before update failed:', e.message); }
    for (const name of ALLOWED) {
      const s = path.join(root, name);
      if (fs.existsSync(s)) copyInto(s, path.join(ROOT, name));
    }
    setSetting('update_message', `Updated to version ${newVer} on ${new Date().toLocaleString('en-IN')}.`);
    console.log(`\n  Updated to version ${newVer}. Restarting...\n`);
    setTimeout(() => process.exit(0), 1500);     // Start-Server.bat starts the new version again
    return { ...status(), installing: newVer };
  } catch (e) {
    setSetting('update_message', 'Update: ' + e.message);
    return status();
  } finally { busy = false; }
}

function start() {
  // automatic updates off: still look for a new version (not installed), so the version line can turn red
  const run = () => check({ install: setting('auto_update', '1') === '1' }).catch(() => { });
  setTimeout(run, 60 * 1000);
  setInterval(run, 30 * 60 * 1000);
}

module.exports = { start, check, status, markWrite, newer };
