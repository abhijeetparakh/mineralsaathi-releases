'use strict';
// E-way bill PDFs: read the text of a PDF downloaded from the e-way bill portal, check that it belongs to an
// invoice (seller GSTIN, buyer GSTIN, invoice no., amount) and take the 12-digit e-way bill number from it.
// Also joins PDFs (invoice + e-way bill on the next page). Uses pdf.js and pdf-lib, kept in server/vendor.
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

let pdfjs = null;
async function lib() {
  if (pdfjs) return pdfjs;
  // pdf.js expects a few browser things; text reading does not need real ones
  globalThis.DOMMatrix = globalThis.DOMMatrix || class { constructor() { Object.assign(this, { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 }); }
    multiplySelf() { return this; } preMultiplySelf() { return this; } translateSelf() { return this; } scaleSelf() { return this; } invertSelf() { return this; } };
  globalThis.Path2D = globalThis.Path2D || class {};
  const warn = console.warn, log = console.log; console.warn = () => {}; console.log = () => {};
  try { pdfjs = await import(pathToFileURL(path.join(__dirname, 'vendor', 'pdf.min.mjs')).href); }
  finally { console.warn = warn; console.log = log; }
  pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(path.join(__dirname, 'vendor', 'pdf.worker.min.mjs')).href;
  return pdfjs;
}

async function pdfText(bytes) {
  const p = await lib();
  const task = p.getDocument({ data: new Uint8Array(bytes), isEvalSupported: false, useSystemFonts: false, verbosity: 0 });
  const doc = await task.promise;
  let out = '';
  for (let i = 1; i <= Math.min(doc.numPages, 4); i++) {
    const tc = await (await doc.getPage(i)).getTextContent();
    out += tc.items.map(x => x.str).join(' ') + '\n';
  }
  try { await task.destroy(); } catch { /* ignore */ }
  return out;
}

const digits = s => String(s || '').replace(/\D/g, '');
// the e-way bill number printed on the PDF ("E-Way Bill No: 3412 3456 7890")
function ewbNumber(text) {
  const t = text.replace(/\s+/g, ' ');
  const m = t.match(/(?:e\s*-?\s*way\s*bill|ewb)\s*(?:no|number)?\.?\s*[:\-]?\s*((?:\d[\s]?){12})/i);
  if (m) return digits(m[1]).slice(0, 12);
  const any = t.match(/\b(\d{4}\s\d{4}\s\d{4}|\d{12})\b/);
  return any ? digits(any[1]) : null;
}
const amountForms = n => {
  const v = Number(n) || 0, i = Math.round(v);
  return [v.toFixed(2), String(i), i.toLocaleString('en-IN'), v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
    i.toLocaleString('en-US'), v.toLocaleString('en-US', { minimumFractionDigits: 2 })];
};

// does this e-way bill belong to the invoice? info = { firm_gstin, party_gstin, inv_no, total }
function check(text, info) {
  const T = text.toUpperCase().replace(/\s+/g, ' '), squeezed = T.replace(/\s/g, '');
  const reasons = [];
  const seller = info.firm_gstin && squeezed.includes(info.firm_gstin.toUpperCase());
  if (!seller) reasons.push("seller's GSTIN " + info.firm_gstin + ' is not on it');
  const buyer = !info.party_gstin || squeezed.includes(info.party_gstin.toUpperCase());
  if (!buyer) reasons.push("buyer's GSTIN " + info.party_gstin + ' is not on it');
  // invoice no.: the value after "Document No." / "Doc. No." / "Invoice No." (a bare number could be part of a date)
  const want = String(info.inv_no).replace(/[^0-9A-Z]/gi, '');
  const docNos = [...T.matchAll(/(?:DOCUMENT|DOC|INVOICE|INV)\.?\s*(?:NO|NUMBER)\.?\s*[:\-]?\s*([A-Z0-9\/\-]+)/g)].map(m => m[1]);
  const inv = docNos.length ? docNos.some(v => v === want || v.split(/[\/\-]/).includes(want) || v.replace(/^0+/, '') === want)
    : new RegExp('(^|[^0-9/])' + want + '([^0-9/]|$)').test(T);
  if (!inv) reasons.push('invoice no. ' + info.inv_no + ' is not on it');
  const amount = amountForms(info.total).some(a => T.includes(a.toUpperCase()));
  const ewb = ewbNumber(text);
  if (!ewb) reasons.push('no 12-digit e-way bill number found');
  return { ok: seller && buyer && inv && !!ewb, amount, ewb_no: ewb, reasons };
}

// look in the e-way bill folder for the PDF of this invoice
async function find(folder, info) {
  let files = [];
  try { files = fs.readdirSync(folder).filter(n => /\.pdf$/i.test(n)).map(n => path.join(folder, n)); } catch { return null; }
  files.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);      // newest first
  let best = null;
  for (const f of files.slice(0, 40)) {
    try {
      const r = check(await pdfText(fs.readFileSync(f)), info);
      if (r.ok && (!best || (r.amount && !best.amount))) best = { ...r, file: f };
      if (best && best.amount) break;
    } catch { /* not a readable PDF */ }
  }
  return best;
}

// invoice PDF + other PDFs (e-way bill) on the following pages
async function join(mainFile, extraFiles, outFile) {
  const { PDFDocument } = require('./vendor/pdf-lib.min.js');
  const out = await PDFDocument.load(fs.readFileSync(mainFile));
  for (const f of extraFiles) {
    try {
      const d = await PDFDocument.load(fs.readFileSync(f), { ignoreEncryption: true });
      for (const pg of await out.copyPages(d, d.getPageIndices())) out.addPage(pg);
    } catch (e) { console.error('Could not add', path.basename(f), e.message); }
  }
  fs.writeFileSync(outFile, await out.save());
  return outFile;
}

module.exports = { pdfText, check, find, join, ewbNumber };
