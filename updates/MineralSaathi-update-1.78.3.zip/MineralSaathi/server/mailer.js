'use strict';
// Sends email straight from the app (no Outlook needed), over SMTP with SSL.
// Gmail: host smtp.gmail.com, port 465, user = full address, password = Google "App password".
const tls = require('node:tls');
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function b64(s) { return Buffer.from(s).toString('base64'); }
function wrap(s) { return s.replace(/.{1,76}/g, '$&\r\n'); }
function encWord(s) { return /^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`; }

const MIME = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', json: 'application/json' };
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
// plain text → paragraphs (a blank line starts a new paragraph, a single line break stays)
function textToHtml(text) {
  return String(text || '').replace(/\r/g, '').split(/\n\s*\n/).map(p => p.trim() ? `<p style="margin:0 0 14px">${esc(p).replace(/\n/g, '<br>')}</p>` : '').join('');
}
// HTML → plain text (the text part of the email)
function htmlToText(html) {
  return String(html || '').replace(/<(br)\s*\/?>/gi, '\n').replace(/<\/(p|div|h\d|li|tr|table)>/gi, '\n').replace(/<li[^>]*>/gi, '• ').replace(/<\/t[dh]>/gi, '\t')
    .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
// width × height of a PNG / JPEG (Outlook needs the logo size written in the email)
function imgSize(buf) {
  try {
    if (buf[0] === 0x89 && buf[1] === 0x50) return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
    if (buf[0] === 0xff && buf[1] === 0xd8) {
      let i = 2;
      while (i < buf.length) { if (buf[i] !== 0xff) { i++; continue; } const m = buf[i + 1], len = buf.readUInt16BE(i + 2);
        if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) }; i += 2 + len; }
    }
  } catch { /* unknown */ }
  return null;
}
// the whole email: white card, logo (fixed size), message in the chosen font, firm details at the bottom
function layout(inner, { logoCid, logoW, logoH, style = {}, fromName }) {
  const font = style.font || 'Arial, Helvetica, sans-serif', size = Number(style.size) || 14, color = style.color || '#222222', align = style.align === 'center' ? 'center' : 'left';
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#f2f4f5"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f2f4f5"><tr><td align="center" style="padding:22px 10px">
<table role="presentation" width="640" cellpadding="0" cellspacing="0" border="0" style="width:640px;max-width:100%;background:#ffffff;border:1px solid #e1e6e8">
${logoCid ? `<tr><td align="${align}" style="padding:20px 28px 4px"><img src="cid:${logoCid}" width="${logoW}" height="${logoH}" alt="${esc(fromName || '')}" style="display:block;width:${logoW}px;height:${logoH}px;border:0;outline:none"></td></tr>` : ''}
<tr><td style="padding:16px 28px 22px;font-family:${esc(font)};font-size:${size}px;line-height:1.6;color:${esc(color)}">${inner}</td></tr>
${style.footer ? `<tr><td style="padding:12px 28px 16px;border-top:1px solid #e1e6e8;font-family:Arial, Helvetica, sans-serif;font-size:12px;line-height:1.5;color:#7b878b">${style.footer}</td></tr>` : ''}
</table></td></tr></table></body></html>`;
}

function buildMessage({ from, fromName, to, cc, subject, text, html, logo, style, attachments = [] }) {
  const boundary = 'ms_' + crypto.randomBytes(12).toString('hex'), alt = 'msa_' + crypto.randomBytes(12).toString('hex'), rel = 'msr_' + crypto.randomBytes(12).toString('hex');
  // every email goes as a proper HTML email (and plain text for old mail programs); the logo is an inline picture of a fixed size
  const lg = logo && String(logo).match(/^data:(image\/(?:png|jpeg|webp));base64,(.+)$/);
  let logoW = 0, logoH = 0;
  if (lg) {
    const sz = imgSize(Buffer.from(lg[2], 'base64')) || { w: 300, h: 100 };
    logoH = Math.max(24, Math.min(160, Number((style || {}).logoH) || 60)); logoW = Math.round(sz.w * logoH / sz.h);
    if (logoW > 300) { logoW = 300; logoH = Math.round(sz.h * 300 / sz.w); }
  }
  if (!text && html) text = htmlToText(html);
  html = layout(html || textToHtml(text), { logoCid: lg ? 'companylogo' : null, logoW, logoH, style, fromName });
  const lines = [
    `From: ${fromName ? `"${encWord(fromName)}" ` : ''}<${from}>`,
    `To: ${to.join(', ')}`,
    cc.length ? `Cc: ${cc.join(', ')}` : null,
    `Subject: ${encWord(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomBytes(10).toString('hex')}@mineralsaathi>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    ...(lg ? [`Content-Type: multipart/related; boundary="${rel}"`, '', `--${rel}`] : []),
    ...(html ? [`Content-Type: multipart/alternative; boundary="${alt}"`, '', `--${alt}`] : []),
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap(b64(text)),
    ...(html ? [`--${alt}`, 'Content-Type: text/html; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', wrap(b64(html)), `--${alt}--`] : []),
    ...(lg ? [`--${rel}`, `Content-Type: ${lg[1]}; name="logo.${lg[1].split('/')[1]}"`, 'Content-Transfer-Encoding: base64', 'Content-ID: <companylogo>',
      `Content-Disposition: inline; filename="logo.${lg[1].split('/')[1]}"`, '', wrap(lg[2]), `--${rel}--`] : []),
  ].filter(l => l !== null);
  for (const a of attachments) {
    const name = a.filename || path.basename(a.path);
    const ext = (name.match(/\.([a-z0-9]+)$/i) || [])[1] || '';
    lines.push(`--${boundary}`, `Content-Type: ${MIME[ext.toLowerCase()] || 'application/octet-stream'}; name="${name}"`, 'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${name}"`, '', wrap(fs.readFileSync(a.path).toString('base64')));
  }
  lines.push(`--${boundary}--`, '');
  // dot-stuffing
  return lines.join('\r\n').replace(/\r\n\./g, '\r\n..');
}

function smtpSend(cfg, msg) {
  const { host, port = 465, user, pass } = cfg;
  // every email also goes to the sender (self CC), unless the sender is already on it
  const me = String(msg.from || user || '').trim();
  if (me && ![...(msg.to || []), ...(msg.cc || [])].some(a => String(a).trim().toLowerCase() === me.toLowerCase())) msg = { ...msg, cc: [...(msg.cc || []), me] };
  const recipients = [...msg.to, ...msg.cc];
  return new Promise((resolve, reject) => {
    let sock;
    let buf = '';
    let step = 0;
    const secureNow = cfg.secure ?? Number(port) === 465;
    const timer = setTimeout(() => { fail(new Error('Email server did not answer (timeout).')); }, 30000);
    const fail = e => { clearTimeout(timer); try { sock.destroy(); } catch { } reject(e); };
    const send = l => sock.write(l + '\r\n');
    const queue = [];
    let waiting = null;
    const expect = (code) => new Promise((res, rej) => { waiting = { code, res, rej }; flush(); });

    function flush() {
      if (!waiting) return;
      const m = buf.match(/^(\d{3})[ ](.*)\r?\n/m);
      if (!m) return;
      const end = buf.indexOf(m[0]) + m[0].length;
      const reply = buf.slice(0, end);
      buf = buf.slice(end);
      const w = waiting; waiting = null;
      if (String(m[1]).startsWith(String(w.code))) w.res(reply);
      else w.rej(new Error('Email server said: ' + reply.trim().split('\n').pop()));
    }
    function attach(s) {
      sock = s;
      sock.setEncoding('utf8');
      sock.on('data', d => { buf += d; flush(); });
      sock.on('error', fail);
    }

    async function dialog(startTls) {
      try {
        if (!startTls) await expect(2);
        send('EHLO mineralsaathi'); await expect(2);
        if (!secureNow && !startTls) {
          send('STARTTLS'); await expect(2);
          const plain = sock; plain.removeAllListeners('data');
          const t = tls.connect({ socket: plain, servername: host }, () => { attach(t); dialog(true); });
          t.on('error', fail);
          return;
        }
        if (user) {
          send('AUTH LOGIN'); await expect(3);
          send(b64(user)); await expect(3);
          send(b64(pass || '')); await expect(2);
        }
        send(`MAIL FROM:<${msg.from}>`); await expect(2);
        for (const r of recipients) { send(`RCPT TO:<${r}>`); await expect(2); }
        send('DATA'); await expect(3);
        sock.write(buildMessage(msg) + '\r\n.\r\n'); await expect(2);
        send('QUIT');
        clearTimeout(timer);
        setTimeout(() => sock.end(), 200);
        resolve(true);
      } catch (e) { fail(e); }
    }

    if (secureNow) {
      const s = tls.connect({ host, port: Number(port), servername: host }, () => { attach(s); dialog(false); });
      s.on('error', fail);
    } else {
      const s = net.connect({ host, port: Number(port) }, () => { attach(s); dialog(false); });
      s.on('error', fail);
    }
  });
}

const splitAddr = s => String(s || '').split(/[;,\s]+/).map(x => x.trim()).filter(x => /.+@.+\..+/.test(x));

module.exports = { smtpSend, splitAddr, buildMessage, textToHtml, htmlToText };
