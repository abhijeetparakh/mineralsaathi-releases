'use strict';
// A small reader for Excel files (.xlsx / .xlsm): sheet names and cell values, nothing else.
// Enough to import the old Sample Dispatch workbook; nothing to install.
const zlib = require('node:zlib');

function unzip(buf) {
  // end of central directory: last 22+ bytes, signature 0x06054b50
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('not an Excel file');
  const count = buf.readUInt16LE(e + 10);
  let p = buf.readUInt32LE(e + 16);
  const files = new Map();
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('damaged Excel file');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20);
    const nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen);
    files.set(name, { method, csize, local });
    p += 46 + nlen + xlen + clen;
  }
  return name => {
    const f = files.get(name);
    if (!f) return null;
    const start = f.local + 30 + buf.readUInt16LE(f.local + 26) + buf.readUInt16LE(f.local + 28);
    const data = buf.subarray(start, start + f.csize);
    return (f.method === 8 ? zlib.inflateRawSync(data) : data).toString('utf8');
  };
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const unxml = s => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, k) => k[0] === '#' ? String.fromCodePoint(k[1] === 'x' || k[1] === 'X' ? parseInt(k.slice(2), 16) : Number(k.slice(1))) : (ENT[k] ?? m));
const attr = (tag, a) => { const m = tag.match(new RegExp('\\s' + a + '="([^"]*)"')); return m ? unxml(m[1]) : null; };
const texts = xml => { let o = ''; for (const m of xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)) o += m[1]; return unxml(o); };
const colNo = ref => { let n = 0; for (const ch of ref.replace(/\d+$/, '')) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };

// Excel day number → yyyy-mm-dd
function serialDate(n) {
  const d = new Date(Date.UTC(1899, 11, 30) + Math.round(Number(n) * 86400000));
  return d.toISOString().slice(0, 10);
}

function open(buf) {
  const read = unzip(buf);
  const wb = read('xl/workbook.xml');
  if (!wb) throw new Error('not an Excel workbook');
  const rels = new Map();
  for (const m of (read('xl/_rels/workbook.xml.rels') || '').matchAll(/<Relationship\b[^>]*>/g)) rels.set(attr(m[0], 'Id'), attr(m[0], 'Target'));
  const sheets = [];
  for (const m of wb.matchAll(/<sheet\b[^>]*>/g)) {
    let t = rels.get(attr(m[0], 'r:id')) || '';
    t = t.startsWith('/') ? t.slice(1) : 'xl/' + t.replace(/^\.\//, '');
    sheets.push({ name: attr(m[0], 'name'), path: t });
  }
  const shared = [];
  const ss = read('xl/sharedStrings.xml');
  if (ss) for (const m of ss.matchAll(/<si>([\s\S]*?)<\/si>/g)) shared.push(texts(m[1]));
  // which cell styles show a date
  const dateStyle = [];
  const st = read('xl/styles.xml');
  if (st) {
    const custom = new Map();
    for (const m of st.matchAll(/<numFmt\b[^>]*>/g)) custom.set(Number(attr(m[0], 'numFmtId')), attr(m[0], 'formatCode') || '');
    const xfs = (st.match(/<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/) || [])[1] || '';
    for (const m of xfs.matchAll(/<xf\b[^>]*>/g)) {
      const id = Number(attr(m[0], 'numFmtId') || 0), code = custom.get(id) || '';
      dateStyle.push((id >= 14 && id <= 22) || (id >= 45 && id <= 47) || (custom.has(id) && /[dmy]/i.test(code.replace(/\[[^\]]*\]|"[^"]*"/g, '')) && !/^[#0.,%]+$/.test(code)));
    }
  }

  // rows of a sheet: array (row 1 = index 0) of arrays (column A = index 0); dates come as { date: 'yyyy-mm-dd' }
  function rows(name) {
    const s = sheets.find(x => x.name === name);
    if (!s) return null;
    const xml = read(s.path) || '';
    const out = [];
    for (const rm of xml.matchAll(/<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g)) {
      const r = Number(attr(rm[0], 'r')) - 1, cells = [];
      for (const cm of (rm[2] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const tag = '<c' + cm[1] + '>', ref = attr(tag, 'r'), t = attr(tag, 't'), sIdx = Number(attr(tag, 's') || 0), inner = cm[2] || '';
        const v = (inner.match(/<v>([\s\S]*?)<\/v>/) || [])[1];
        let val = null;
        if (t === 's') val = v != null ? shared[Number(v)] ?? null : null;
        else if (t === 'inlineStr') val = texts(inner);
        else if (t === 'str') val = v != null ? unxml(v) : null;
        else if (t === 'b') val = v === '1';
        else if (t === 'e') val = null;
        else if (v != null) { const n = Number(v); val = dateStyle[sIdx] && n > 0 && n < 2958466 ? { date: serialDate(n) } : n; }
        if (ref) cells[colNo(ref)] = val;
      }
      out[r] = cells;
    }
    for (let i = 0; i < out.length; i++) if (!out[i]) out[i] = [];
    return out;
  }
  return { sheets: sheets.map(s => s.name), rows };
}

module.exports = { open, serialDate };
