'use strict';
// Marketing phase 5: bring the old Sample Dispatch Excel data into marketing.db.
// Reads the workbook itself (Sample_Dispatch.xlsm, or a file with only the DATA sheet such as Sample_data.xlsx):
//   DATA sheet          → enquiries (same Ref No.) + one "old" dispatch with its sample
//   numbered sheets     → communication history (rows 20 on) and next calls (columns O–Q)
//   CALL UPDATE         → calls with Done / Pending, merged with the numbered sheets on Ref No. + date
//   DISPATCH DETAILS    → 2020–21 dispatches, when the name matches an enquiry
// It can be run again (Excel and Mineral Saathi side by side during the trial): enquiries are updated by Ref No.,
// the old samples, history and calls from Excel are replaced; what was entered in Mineral Saathi is kept.
const path = require('node:path');
const crypto = require('node:crypto');
const M = require('./db');
const X = require('./xlsx');
const { all: mAll, setting, setSetting } = require('../db');

const DIGIPIN = /^[2-9CFJKLMPT]{3}-[2-9CFJKLMPT]{3}-[2-9CFJKLMPT]{4}$/;
const RESPONSES = ['NO RESPONSE', 'CALLED', 'WHATSAPP MESSAGE SENT', 'PHONE NOT REACHABLE'];

const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
// a cell as text: Excel line ends (_x000D_), non-breaking spaces and dates cleaned
function str(v) {
  if (v == null || v === false) return '';
  if (typeof v === 'object' && v.date) return v.date;
  return String(v).replace(/_x000D_/g, '').replace(/\r/g, '').replace(/ /g, ' ').trim();
}
const one = v => str(v).replace(/\s+/g, ' ').trim();
const up = v => one(v).toUpperCase() || null;
const note = v => str(v).split('\n').map(l => l.replace(/[ \t]+/g, ' ').trim()).join('\n').replace(/\n{3,}/g, '\n\n').trim() || null;
const squash = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

// dd.mm.yy, dd.mm.yyyy, dd/mm/yyyy, dd-mm-yyyy, Excel dates → yyyy-mm-dd
function date(v) {
  if (v && typeof v === 'object' && v.date) return v.date;
  if (typeof v === 'number' && v > 20000 && v < 80000) return X.serialDate(v);
  const m = one(v).match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2}|\d{4})$/);
  if (!m) return null;
  const d = Number(m[1]), mo = Number(m[2]), y = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
  const t = new Date(Date.UTC(y, mo - 1, d));
  if (t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== d || y < 2000 || y > 2100) return null;
  return t.toISOString().slice(0, 10);
}

// phone cells: "9167022303", 9167022303, "+91 98…", "022/28200426", "210027,210888"
function phones(v) {
  const s = one(v);
  if (!s) return { mobiles: [], other: [] };
  const mobiles = [], other = [];
  for (const part of s.split(/[,/|;]| or |&/i).map(x => x.trim()).filter(Boolean)) {
    let d = part.replace(/\D/g, '');
    if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
    if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
    if (/^[6-9]\d{9}$/.test(d) && (!part.startsWith('+') || part.startsWith('+91'))) mobiles.push(d); else other.push(part);
  }
  return { mobiles, other: other.length ? [s] : [] };
}

// "abc@gmailcom" → "abc@gmail.com"
function emails(v) {
  const good = [], bad = [], fixed = [];
  for (let e of one(v).toLowerCase().split(/[,;\s]+/).filter(Boolean)) {
    const was = e;
    if (e.includes('@') && !/@[^@]+\.[^@]+$/.test(e)) e = e.replace(/(yahoo)coin$/, '$1.co.in').replace(/(\w)(com|in|net|org)$/, '$1.$2');
    if (/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/.test(e)) { good.push(e); if (e !== was) fixed.push(`${was} → ${e}`); } else bad.push(was);
  }
  return { good, bad, fixed };
}

function gst(v) {
  let g = one(v).toUpperCase().replace(/[\s-]/g, '');
  if (!g) return { gst: null };
  if (/^\d[A-Z]{5}\d{4}[A-Z][0-9A-Z]Z[0-9A-Z]$/.test(g)) g = '0' + g;          // 7AADCA1816E1Z5 → 07…
  if (/^[0-9A-Z]{15}$/.test(g)) return { gst: g };
  if (/^[A-Z]{5}\d{4}[A-Z]$/.test(g)) return { gst: null, pan: g };
  return { gst: null, bad: one(v) };
}

const COURIER = { 'VK EXPRESS': 'V K EXPRESS', 'VRL': 'VRL LOGISTICS LIMITED', 'POST': 'INDIAN POSTAL SERVICE', 'INDIA POST': 'INDIAN POSTAL SERVICE' };
function courier(v) {
  const c = up(v);
  if (!c) return { courier: null };
  if (/^\d+$/.test(c)) return { courier: null, bad: c };
  return { courier: COURIER[c] || c };
}
function unit(v) { const u = squash(v).replace(/^PER/, ''); return u === 'KG' || u === 'MT' ? u : (u ? u : null); }
function sampleSize(v) {
  const s = one(v).toUpperCase();
  if (!s) return null;
  const m = s.match(/^([\d.]+)\s*(KG|GM|G|GMS|GRAM|GRAMS)?$/);
  if (!m) return s;
  return m[2] ? `${m[1]} ${m[2].startsWith('G') ? 'GM' : 'KG'}` : m[1];
}
// Excel grade text → the key used on the matching screen ("500 +" = "500+", "Y 300" = "Y300")
function gradeKey(v) { return one(v).toUpperCase().replace(/\s*\+/g, '+').replace(/^([A-Z])\s+(\d)/, '$1$2') || null; }
// mesh / colour / form read from the Excel grade code (Y300 = light yellow 300 mesh powder)
function gradeParts(k) {
  if (!k) return {};
  const o = {};
  if (/GRANUL/.test(k)) o.form = 'GRANULES'; else if (/CHIP/.test(k)) o.form = 'CHIPS'; else o.form = 'POWDER';
  if (/^Y\d/.test(k)) o.colour = 'LIGHT YELLOW'; else if (/^W\d|WHITE/.test(k)) o.colour = 'OFF WHITE';
  const ms = k.match(/\d+(?:\+(?!\d))?/g);
  if (ms && o.form === 'POWDER') o.mesh = ms.join(' + ');
  return o;
}

// ------------- read the workbook -------------
function readWorkbook(buf, fileName) {
  let wb;
  try { wb = X.open(buf); } catch (e) { throw new M.MktError('This file could not be read as an Excel file (' + e.message + '). Save it as .xlsx or .xlsm and try again.'); }
  // the DATA sheet: by name, or the first sheet whose first row has SL / NAME / COMPANY
  let dataName = wb.sheets.find(n => n.trim().toUpperCase() === 'DATA');
  let rows = dataName && wb.rows(dataName);
  if (!rows) for (const n of wb.sheets) {
    const r = wb.rows(n), h = (r[0] || []).map(x => squash(str(x)));
    if (h[0] === 'SL' && h.some(x => x.startsWith('COMPANY'))) { dataName = n; rows = r; break; }
  }
  if (!rows) throw new M.MktError('No DATA sheet found. The first row must have the headings SL, NAME, COMPANY NAME, ADDRESS… like the Sample Dispatch workbook.');
  // columns by heading (the old workbook order is the fallback)
  const head = (rows[0] || []).map(x => squash(str(x)));
  const col = (re, def) => { const i = head.findIndex(h => re.test(h)); return i >= 0 ? i : def; };
  const C = {
    sl: 0, name: col(/^NAME\d*$/, 1), company: col(/^COMPANY/, 2), address: col(/^ADDRESS/, 3), city: col(/^CITY/, 4), pin: col(/^PIN/, 5),
    state: col(/^STATE/, 6), mob1: col(/^MOBILE1/, 7), mob2: col(/^MOBILE2/, 8), date: 9, gst: col(/^GST/, 10), email: col(/^EMAIL/, 11),
    track: col(/^REFNO/, 12), digipin: col(/^DIGIPIN/, 13), quality: col(/^QUALITY/, 14), rate: col(/^RATE/, 15), size: col(/^SAMPLESIZE/, 16),
    note: col(/^NOTE/, 17), sent: col(/^SENTBY/, 18), unit: col(/^WEGUNIT|^UNIT/, 19), extra: 20
  };
  const ex = [];                 // exceptions shown in the check report
  const leads = [], seen = new Map();
  const numRefs = new Set(rows.slice(1).map(r => one(r[C.sl])).filter(s => /^\d+$/.test(s)).map(Number));
  const maxRef = Math.max(0, ...numRefs);
  let free = 1;
  const nextFree = () => { while (numRefs.has(free)) free++; numRefs.add(free); return free; };

  rows.slice(1).forEach((r, i) => {
    const row = i + 2, sl = one(r[C.sl]);
    if (!r.some(v => str(v))) return;
    if (!sl) { ex.push({ kind: 'Row without SL', text: `Row ${row}: ${one(r[C.company]) || one(r[C.name])} — not imported` }); return; }
    const extraNote = [];
    let ref;
    if (/^\d+$/.test(sl)) ref = Number(sl);
    else { ref = nextFree(); extraNote.push(`Excel SL ${sl}`); ex.push({ kind: 'SL changed', text: `SL "${sl}" (${one(r[C.company])}) is not a number — given the free Ref No. ${ref}` }); }
    if (seen.has(ref)) { ex.push({ kind: 'SL twice', text: `SL ${ref} is in DATA twice (rows ${seen.get(ref)} and ${row}) — the second is not imported` }); return; }
    seen.set(ref, row);
    const co = up(r[C.company]), nm = up(r[C.name]);
    if (!co && !nm) { ex.push({ kind: 'Row without name', text: `SL ${sl}: no company and no name — not imported` }); return; }
    const who = `SL ${sl} ${co || nm}`;

    const p1 = phones(r[C.mob1]), p2 = phones(r[C.mob2]);
    const mobs = [...p1.mobiles, ...p2.mobiles].filter((x, k, a) => a.indexOf(x) === k);
    const otherPhones = [...p1.other, ...p2.other, ...mobs.slice(2)];
    if (!mobs.length) ex.push({ kind: 'No 10-digit mobile', text: `${who}: ${one(r[C.mob1]) ? `"${one(r[C.mob1])}"` : 'no number'} — add a mobile when you next open it` });
    if (otherPhones.length) extraNote.push('Phone: ' + otherPhones.join(', '));

    const em = emails(r[C.email]);
    if (em.fixed.length) ex.push({ kind: 'E-mail corrected', text: `${who}: ${em.fixed.join('; ')}` });
    if (em.bad.length) { ex.push({ kind: 'E-mail not valid', text: `${who}: "${em.bad.join(', ')}" — kept in the note` }); extraNote.push('E-mail: ' + em.bad.join(', ')); }
    if (em.good.length > 1) extraNote.push('E-mail: ' + em.good.slice(1).join(', '));

    const g = gst(r[C.gst]);
    if (g.pan) { extraNote.push('PAN: ' + g.pan); ex.push({ kind: 'GST not valid', text: `${who}: "${g.pan}" is a PAN — kept in the note` }); }
    if (g.bad) { extraNote.push('GST: ' + g.bad); ex.push({ kind: 'GST not valid', text: `${who}: "${g.bad}" — kept in the note` }); }

    let pin = one(r[C.pin]).replace(/\D/g, '');
    if (pin && pin.length !== 6) { ex.push({ kind: 'Pincode not valid', text: `${who}: "${one(r[C.pin])}" — left blank` }); pin = ''; }
    let dp = r[C.digipin];
    let digipin = null;
    if (dp && typeof dp === 'object') ex.push({ kind: 'Digipin lost in Excel', text: `${who}: Excel turned the Digipin into a date — enter it again` });
    else if (one(dp)) { const d = one(dp).toUpperCase(); if (DIGIPIN.test(d)) digipin = d; else { ex.push({ kind: 'Digipin not valid', text: `${who}: "${one(dp)}"` }); extraNote.push('Digipin: ' + one(dp)); } }

    const rateTxt = one(r[C.rate]);
    const rate = rateTxt && /^\d+(\.\d+)?$/.test(rateTxt) ? Number(rateTxt) : null;
    if (rateTxt && rate == null) extraNote.push('Rate: ' + rateTxt);
    const extra = one(r[C.extra]);
    if (extra) extraNote.push(extra);
    const cr = courier(r[C.sent]);
    if (cr.bad) { extraNote.push('Sent by: ' + cr.bad); ex.push({ kind: 'Sent by not valid', text: `${who}: "${cr.bad}" — kept in the note` }); }

    const lead = {
      ref_no: ref, row, buyer_name: nm, company: co, address: one(r[C.address]).replace(/,\s*$/, '') || null,
      city: up(r[C.city]), state: up(r[C.state]), pincode: pin || null, digipin,
      mobile1: mobs[0] || null, mobile2: mobs[1] || null, gst: g.gst, email: em.good[0] || null,
      note: null, _dn: note(r[C.note]), _extra: extraNote
    };
    const quality = gradeKey(r[C.quality]), size = sampleSize(r[C.size]), track = up(r[C.track]);
    if (quality || size || cr.courier || track || rate != null) {
      lead.sample = {
        date: date(r[C.date]), courier: cr.courier, tracking_no: track ? track.replace(/\s/g, '') : null,
        quality, sample_size: size, rate, unit: unit(r[C.unit])
      };
      if (rate != null && !lead.sample.unit) lead.sample.unit = rate >= 500 ? 'MT' : 'KG';
    }
    leads.push(lead);
  });
  if (!leads.length) throw new M.MktError('The DATA sheet has no enquiries.');
  const byRef = new Map(leads.map(l => [l.ref_no, l]));

  // ---- the numbered sheets (one per enquiry) ----
  const numbered = wb.sheets.filter(n => /^\d+$/.test(n.trim()));
  let history = null;
  if (numbered.length || wb.sheets.some(n => n.trim().toUpperCase() === 'CALL UPDATE')) {
    history = { comms: [], calls: new Map(), conflicts: new Set() };
    const addCall = (ref, due, reason, done, from) => {
      const k = ref + '|' + due, old = history.calls.get(k);
      if (old) {
        if (old.done && !done && from === 'call update') { history.conflicts.add(ref); ex.push({ kind: 'Pending in CALL UPDATE, Done on the sheet', text: `Ref ${ref} call of ${due.split('-').reverse().join('.')}: kept as Done` }); }
        old.done = old.done || done; if (!old.reason && reason) old.reason = reason; return;
      }
      history.calls.set(k, { ref, due, reason, done, from });
    };
    for (const n of numbered) {
      const ref = Number(n.trim()), lead = byRef.get(ref);
      if (!lead) { ex.push({ kind: 'Sheet without DATA row', text: `Sheet ${n.trim()} has no row in DATA — its history is not imported` }); continue; }
      const rs = wb.rows(n) || [];
      // the NOTE on the sheet, when it says more than the DATA note
      const sn = note((rs[9] || [])[1]), a = squash(lead._dn), b = squash(sn);
      if (b && !a.includes(b)) lead._dn = !a || b.includes(a) ? sn : lead._dn + '\n' + sn;
      // communication: rows 20 on, B = date, C = note
      let last = null;
      for (let i = 19; i < rs.length; i++) {
        const r = rs[i] || [], d = date(r[1]), t = note([r[2], r[3]].map(str).filter(Boolean).join(' '));
        if (!d && !t) continue;
        const when = d || last;
        if (!when) { ex.push({ kind: 'Call note without date', text: `Sheet ${ref} row ${i + 1}: "${(t || '').slice(0, 60)}" — not imported` }); continue; }
        if (!d && one(r[1])) ex.push({ kind: 'Date not readable', text: `Sheet ${ref} row ${i + 1}: "${one(r[1])}" — the date before it was used` });
        last = when;
        const T = (t || '').toUpperCase();
        const channel = /WHATS?\s?APP|\bMSG\b|MESSAGE|\bWA\b/.test(T) ? 'WHATSAPP' : /\bVISIT/.test(T) ? 'VISIT' : /E-?MAIL|\bMAIL\b/.test(T) ? 'EMAIL' : 'CALL';
        const resp = RESPONSES.find(x => T.replace(/[^A-Z ]/g, '').replace(/\s+/g, ' ').trim().startsWith(x)) ||
          (/NO RESPON/.test(T) ? 'NO RESPONSE' : /NOT REACHABLE/.test(T) ? 'PHONE NOT REACHABLE' : null);
        history.comms.push({ ref, date: when, channel, response: resp, note: t });
      }
      // next calls: from row 2, O = date, P = note, Q = status
      for (let i = 1; i < rs.length && i < 200; i++) {
        const r = rs[i] || [], d = date(r[14]);
        if (!d) { if (one(r[14]) && i > 1 && /\d/.test(one(r[14]))) ex.push({ kind: 'Date not readable', text: `Sheet ${ref} next call row ${i + 1}: "${one(r[14])}" — not imported` }); continue; }
        let reason = one(r[15]).replace(/^[\s,]+|[\s,]+$/g, '').replace(/\s*,\s*/g, ', ');
        let done = /^DONE$/i.test(one(r[16]));
        if (/^DONE$/i.test(reason)) { done = true; reason = ''; }
        addCall(ref, d, reason ? reason.toUpperCase() : null, done, 'sheet');
      }
    }
    // CALL UPDATE: SL, DATE, REF, NAME, COMPANY, STATUS, MOBILE1, MOBILE2, CONTENT
    const cuName = wb.sheets.find(n => n.trim().toUpperCase() === 'CALL UPDATE');
    const cu = cuName ? wb.rows(cuName) : [];
    let undated = 0;
    for (let i = 1; i < cu.length; i++) {
      const r = cu[i] || [];
      if (!r.some(v => str(v))) continue;
      const ref = Number(one(r[2]));
      if (!byRef.has(ref)) { ex.push({ kind: 'Call without enquiry', text: `CALL UPDATE row ${i + 1}: Ref "${one(r[2])}" is not in DATA — not imported` }); continue; }
      const done = /^DONE$/i.test(one(r[5])), reason = one(r[8]).toUpperCase() || null;
      let d = date(r[1]);
      if (!d) {
        if (done) continue;
        // a pending call without a date: due today, unless the enquiry already has a pending call
        const hasPending = [...history.calls.values()].some(c => c.ref === ref && !c.done);
        if (hasPending) continue;
        d = today(); undated++;
      }
      addCall(ref, d, reason, done, 'call update');
    }
    if (undated) ex.push({ kind: 'Pending call without date', text: `${undated} pending calls in CALL UPDATE have no date — they are put on the import day, so they show in Today's Calls` });
    history.cuPending = cu.slice(1).filter(r => r && one(r[2]) && /^PENDING$/i.test(one(r[5]))).length;
    history.cuPendingRefs = [...new Set(cu.slice(1).filter(r => r && one(r[2]) && /^PENDING$/i.test(one(r[5]))).map(r => Number(one(r[2]))))];
    history.calls = [...history.calls.values()];
    // an enquiry keeps one pending call: the latest; older pending ones were overtaken by it (marked Skipped)
    const lastPending = new Map();
    for (const c of history.calls) if (!c.done && (!lastPending.has(c.ref) || lastPending.get(c.ref).due < c.due)) lastPending.set(c.ref, c);
    let overtaken = 0;
    for (const c of history.calls) if (!c.done && lastPending.get(c.ref) !== c) { c.skipped = true; overtaken++; }
    if (overtaken) ex.push({ kind: 'Older pending calls', text: `${overtaken} older pending calls have a later call planned for the same enquiry — kept as Skipped; only the latest stays pending` });
  }

  // ---- DISPATCH DETAILS (2020–21): only when the name matches one enquiry ----
  const old = [];
  const ddName = wb.sheets.find(n => n.trim().toUpperCase() === 'DISPATCH DETAILS');
  if (ddName) {
    const dd = wb.rows(ddName);
    for (let i = 1; i < dd.length; i++) {
      const r = dd[i] || [];
      if (!r.some(v => str(v))) continue;
      const name = up(r[1]);
      const hit = leads.filter(l => (l.company && squash(l.company) === squash(name)) || (l.buyer_name && squash(l.buyer_name) === squash(name)));
      if (hit.length !== 1) { ex.push({ kind: 'Old dispatch (2020–21) not matched', text: `${one(r[0])} ${name} ${one(r[2])} ${one(r[4])} — no single enquiry with this name, not imported` }); continue; }
      old.push({ ref: hit[0].ref_no, date: date(r[0]), item: up(r[3]), tracking_no: up(r[4]), courier: courier(r[5]).courier, delivered_on: date(r[6]) });
    }
  }

  for (const l of leads) { l.note = [l._dn, ...l._extra].filter(Boolean).join('\n') || null; delete l._dn; delete l._extra; }

  // grades to match
  const grades = {};
  for (const l of leads) if (l.sample && l.sample.quality) grades[l.sample.quality] = (grades[l.sample.quality] || 0) + 1;
  return { file: fileName, sheet: dataName, maxRef, leads, history, old, hasOld: !!ddName, grades, exceptions: ex };
}

// ------------- grade suggestions from Master → Item List -------------
const PLAN = { 'ORGASIL': '150', '150M': '150', '150': '150', '500+': '500', 'DEE-E': 'W325', 'DEE-E RUBBER': 'W325' };
function suggest(key, items) {
  const k = squash(key);
  const sq = items.map(it => ({ it, g: squash(it.grade), n: squash(it.name) }));
  let hit = sq.find(x => x.g === k) || sq.find(x => x.g.startsWith(k) && /^[A-Z]\d/.test(k)) || sq.find(x => k.length > 3 && x.g.includes(k));
  if (!hit && /ZEO/.test(k)) hit = sq.find(x => /ZEO/.test(x.g + x.n) && (!/GRANUL/.test(k) || /GRANUL/.test(x.g))) || sq.find(x => /ZEO/.test(x.g + x.n));
  if (!hit && /ZEO/.test(k)) return null;
  if (!hit && /GRANUL/.test(k)) hit = sq.find(x => /GRANUL/.test(x.g + x.n));
  if (!hit && /CHIP/.test(k)) hit = sq.find(x => /CHIP/.test(x.g + x.n));
  if (!hit && PLAN[key]) hit = sq.find(x => x.g.startsWith(PLAN[key]) || x.g.includes(PLAN[key] + 'MESH'));
  return hit ? hit.it.id : null;
}

// ------------- write into marketing.db -------------
function apply(parsed, gradeMap, firm) {
  const items = new Map(mAll('SELECT id, name, grade FROM items').map(i => [i.id, i]));
  const rep = { leads_added: 0, leads_updated: 0, samples: 0, comms: 0, calls_pending: 0, calls_done: 0, old_dispatches: 0, skipped: [] };
  const existing = new Map(M.all('SELECT id, ref_no, legacy FROM leads').map(l => [l.ref_no, l]));
  const idByRef = new Map();
  M.tx(() => {
    // old samples brought from Excel are replaced (with what was printed or written for them)
    // (legacy 1 = DATA sheet, legacy 2 = DISPATCH DETAILS 2020–21, replaced only when the file has that sheet)
    const kinds = parsed.hasOld ? '1, 2' : '1';
    const oldD = M.all(`SELECT id FROM dispatches WHERE legacy IN (${kinds})`).map(d => d.id);
    for (const id of oldD) { M.run('DELETE FROM samples WHERE dispatch_id = ?', id); M.run('DELETE FROM dispatch_freight WHERE dispatch_id = ?', id); M.run('DELETE FROM dispatches WHERE id = ?', id); }
    if (parsed.history) { M.run('DELETE FROM communications WHERE legacy = 1'); M.run('DELETE FROM follow_ups WHERE legacy = 1'); }

    const F = ['buyer_name', 'company', 'address', 'city', 'state', 'pincode', 'digipin', 'mobile1', 'mobile2', 'gst', 'email', 'note'];
    for (const l of parsed.leads) {
      const ex = existing.get(l.ref_no);
      if (ex && !ex.legacy) { rep.skipped.push(`Ref ${l.ref_no} ${l.company || l.buyer_name}: this Ref No. is already a new enquiry in Mineral Saathi — not imported`); continue; }
      if (ex) {
        M.run(`UPDATE leads SET ${F.map(f => f + ' = ?').join(', ')}, updated_at = datetime('now','localtime') WHERE id = ?`, ...F.map(f => l[f]), ex.id);
        idByRef.set(l.ref_no, ex.id); rep.leads_updated++;
      } else {
        const id = Number(M.run(`INSERT INTO leads(ref_no, legacy, ${F.join(',')}) VALUES(?, 1, ${F.map(() => '?').join(',')})`, l.ref_no, ...F.map(f => l[f])).lastInsertRowid);
        idByRef.set(l.ref_no, id); rep.leads_added++;
      }
      const s = l.sample;
      if (s) {
        const did = Number(M.run('INSERT INTO dispatches(lead_id, date, firm_code, courier, tracking_no, legacy) VALUES(?, ?, ?, ?, ?, 1)',
          idByRef.get(l.ref_no), s.date, firm, s.courier, s.tracking_no).lastInsertRowid);
        const m = s.quality ? gradeMap[s.quality] : null, it = m && m !== 'KEEP' ? items.get(Number(m)) : null;
        const parts = gradeParts(s.quality);
        M.run(`INSERT INTO samples(dispatch_id, lead_id, date, firm_code, item_name, grade, mesh, colour, form, sample_size, courier, tracking_no, rate, unit, legacy)
          VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`, did, idByRef.get(l.ref_no), s.date, firm,
          it ? String(it.name).toUpperCase() : null, it ? (String(it.grade || '').toUpperCase() || s.quality) : s.quality,
          parts.mesh || null, parts.colour || null, s.quality ? parts.form : null, s.sample_size, s.courier, s.tracking_no, s.rate, s.unit);
        rep.samples++;
      }
    }
    for (const o of parsed.old) {
      const lid = idByRef.get(o.ref); if (!lid) continue;
      const did = Number(M.run('INSERT INTO dispatches(lead_id, date, firm_code, courier, tracking_no, delivered_on, legacy) VALUES(?, ?, ?, ?, ?, ?, 2)', lid, o.date, firm, o.courier, o.tracking_no, o.delivered_on).lastInsertRowid);
      M.run('INSERT INTO samples(dispatch_id, lead_id, date, firm_code, grade, courier, tracking_no, delivered_on, legacy) VALUES(?, ?, ?, ?, ?, ?, ?, ?, 2)', did, lid, o.date, firm, o.item, o.courier, o.tracking_no, o.delivered_on);
      rep.old_dispatches++;
    }
    if (parsed.history) {
      for (const c of parsed.history.comms) {
        const lid = idByRef.get(c.ref); if (!lid) continue;
        M.run('INSERT INTO communications(lead_id, date, channel, response, note, legacy) VALUES(?, ?, ?, ?, ?, 1)', lid, c.date, c.channel, c.response, c.note);
        rep.comms++;
      }
      for (const c of parsed.history.calls) {
        const lid = idByRef.get(c.ref); if (!lid) continue;
        M.run('INSERT INTO follow_ups(lead_id, due_date, reason, status, done_on, legacy) VALUES(?, ?, ?, ?, ?, 1)', lid, c.due, c.reason, c.done ? 'DONE' : c.skipped ? 'SKIPPED' : 'PENDING', c.done ? c.due : null);
        if (c.done) rep.calls_done++; else if (c.skipped) rep.calls_skipped = (rep.calls_skipped || 0) + 1; else rep.calls_pending++;
      }
    }
  });
  return rep;
}

// ------------- the check report -------------
function check(parsed, rep) {
  const idOk = ref => !!M.get('SELECT 1 FROM leads WHERE ref_no = ? AND legacy = 1', ref);
  const n = (sql, ...a) => M.get(sql, ...a).n;
  const refs = parsed.leads.map(l => l.ref_no);
  const pick = [];
  const pool = refs.slice();
  for (let i = 0; i < 10 && pool.length; i++) pick.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
  const sample = pick.sort((a, b) => a - b).map(ref => {
    const l = M.get('SELECT * FROM leads WHERE ref_no = ?', ref);
    if (!l) return null;
    return {
      id: l.id, ref_no: ref, company: l.company || l.buyer_name, city: l.city, mobile1: l.mobile1,
      sample: (M.get("SELECT group_concat(COALESCE(grade, item_name) || COALESCE(' · ' || sample_size, ''), ', ') g FROM samples WHERE lead_id = ?", l.id) || {}).g || '',
      calls: n('SELECT COUNT(*) n FROM communications WHERE lead_id = ?', l.id),
      next_call: (M.get("SELECT MIN(due_date) d FROM follow_ups WHERE lead_id = ? AND status = 'PENDING'", l.id) || {}).d || ''
    };
  }).filter(Boolean);
  const checks = [
    { what: 'Enquiries: rows in DATA = enquiries imported', ok: parsed.leads.length === rep.leads_added + rep.leads_updated, text: `${parsed.leads.length} rows · ${rep.leads_added} added, ${rep.leads_updated} updated${rep.skipped.length ? ` · ${rep.skipped.length} not imported` : ''}` },
    { what: 'Samples imported', ok: true, text: `${rep.samples} samples${rep.old_dispatches ? ` + ${rep.old_dispatches} old dispatches (2020–21)` : ''}` }
  ];
  if (parsed.history) {
    const withSheet = new Set(parsed.history.comms.map(c => c.ref)).size;
    checks.push({ what: 'Communication history', ok: true, text: `${rep.comms} calls and messages for ${withSheet} enquiries` });
    checks.push({ what: 'Calls: pending in CALL UPDATE are pending in Mineral Saathi', ok: (parsed.history.cuPendingRefs || []).every(ref => !idOk(ref) || parsed.history.conflicts.has(ref) || M.get("SELECT 1 FROM follow_ups f JOIN leads l ON l.id = f.lead_id WHERE l.ref_no = ? AND f.status = 'PENDING'", ref)),
      text: `CALL UPDATE has ${parsed.history.cuPending || 0} pending · Mineral Saathi now has ${rep.calls_pending} pending (one per enquiry, numbered sheets included), ${rep.calls_done} done${rep.calls_skipped ? `, ${rep.calls_skipped} older ones skipped` : ''}` });
  } else checks.push({ what: 'Communication history and calls', ok: true, text: 'This file has only the DATA sheet — history and calls already imported are kept. Import Sample_Dispatch.xlsm to bring them.' });
  checks.push({ what: 'Next Ref No. for new enquiries', ok: true, text: String(Math.max((M.get('SELECT MAX(ref_no) m FROM leads').m || 0) + 1, Number(require('./routes').settings().next_ref) || 1)) });
  return { checks, sample, exceptions: [...parsed.exceptions, ...rep.skipped.map(t => ({ kind: 'Not imported', text: t }))] };
}

module.exports = function register(route, { settings, backupFolder }) {
  const cache = new Map();          // token → parsed workbook (until the import is run, or the app restarts)

  route('POST', '/api/mkt/import/preview', ({ body }) => {
    const m = String(body.data || '').match(/^data:([^;]*);base64,(.+)$/);
    if (!m) throw new M.MktError('Choose the Excel file first.');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 30e6) throw new M.MktError('The file is too big (30 MB at most).');
    const parsed = readWorkbook(buf, String(body.name || 'Excel file'));
    const token = crypto.randomBytes(8).toString('hex');
    cache.clear(); cache.set(token, parsed);
    const items = mAll('SELECT id, name, grade FROM items WHERE active = 1 ORDER BY name, grade');
    let saved = {}; try { saved = JSON.parse(setting('mkt.import_grades') || '{}') || {}; } catch { /* none */ }
    const known = M.all('SELECT ref_no, legacy FROM leads');
    const taken = known.filter(k => !k.legacy && parsed.leads.some(l => l.ref_no === k.ref_no)).map(k => k.ref_no);
    return {
      token, file: parsed.file, sheet: parsed.sheet,
      counts: { leads: parsed.leads.length, samples: parsed.leads.filter(l => l.sample).length,
        comms: parsed.history ? parsed.history.comms.length : null, calls: parsed.history ? parsed.history.calls.length : null,
        calls_pending: parsed.history ? parsed.history.calls.filter(c => !c.done && !c.skipped).length : null, old: parsed.old.length,
        already: known.filter(k => k.legacy).length, taken },
      grades: Object.entries(parsed.grades).sort((a, b) => b[1] - a[1]).map(([key, count]) => {
        // the choice made at the last import comes first, then a guess from the Item List
        const was = saved[key], ok = was === 'KEEP' || items.some(i => i.id === Number(was));
        return { key, count, suggest: ok ? was : suggest(key, items), parts: gradeParts(key) };
      }),
      items, exceptions: parsed.exceptions
    };
  });

  route('POST', '/api/mkt/import/run', ({ body }) => {
    const parsed = cache.get(String(body.token || ''));
    if (!parsed) throw new M.MktError('Choose the Excel file again (the app was restarted or another file was chosen).');
    const map = body.grades || {};
    const missing = Object.keys(parsed.grades).filter(k => !map[k]);
    if (missing.length) throw new M.MktError('Match every grade first: ' + missing.join(', '));
    // a safety copy of marketing.db before the import
    const stamp = new Date().toISOString().slice(0, 19).replace(/[-:T]/g, '').replace(/^(\d{8})(\d{4}).*/, '$1-$2');
    try { M.backupInto(path.join(backupFolder(), `Marketing_before-import_${stamp}.db`)); } catch (e) { throw new M.MktError('Could not make the safety copy before the import: ' + e.message); }
    const rep = apply(parsed, map, settings().default_firm);
    setSetting('mkt.import_grades', JSON.stringify(map));
    cache.clear();
    return { ...rep, history: !!parsed.history, ...check(parsed, rep) };
  });
};
module.exports.readWorkbook = readWorkbook;
module.exports.gradeKey = gradeKey;
