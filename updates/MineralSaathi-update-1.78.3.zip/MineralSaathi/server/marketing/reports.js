'use strict';
// Marketing Reports: samples by month, grade and courier; enquiries per state; pending and overdue calls;
// enquiries that became buyers. Read-only.
const M = require('./db');
const { get: mGet } = require('../db');

const isoDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null;
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };

module.exports = function register(route) {
  route('GET', '/api/mkt/reports', ({ q }) => {
    const from = isoDate(q.from), to = isoDate(q.to), t = today();
    // samples in the period (samples without a date — old Excel ones — only when no period is chosen)
    const sw = from || to ? `s.date BETWEEN ? AND ?` : '1 = 1';
    const sa = from || to ? [from || '0000-00-00', to || '9999-12-31'] : [];
    const lw = from || to ? `substr(l.created_at, 1, 10) BETWEEN ? AND ?` : '1 = 1';
    const n = (sql, ...a) => M.get(sql, ...a).n;
    return {
      from, to, today: t,
      summary: {
        enquiries: n('SELECT COUNT(*) n FROM leads'),
        new_enquiries: from || to ? n(`SELECT COUNT(*) n FROM leads l WHERE legacy = 0 AND ${lw}`, ...sa) : null,
        samples: n(`SELECT COUNT(*) n FROM samples s WHERE ${sw}`, ...sa),
        dispatches: n(`SELECT COUNT(*) n FROM dispatches s WHERE ${sw}`, ...sa),
        calls_done: n(`SELECT COUNT(*) n FROM communications s WHERE ${sw}`, ...sa),
        pending: n("SELECT COUNT(*) n FROM follow_ups WHERE status = 'PENDING' AND due_date >= ?", t),
        overdue: n("SELECT COUNT(*) n FROM follow_ups WHERE status = 'PENDING' AND due_date < ?", t),
        buyers: n('SELECT COUNT(*) n FROM leads WHERE became_buyer_id IS NOT NULL')
      },
      by_month: M.all(`SELECT COALESCE(substr(s.date, 1, 7), '') AS month, COUNT(*) AS samples, COUNT(DISTINCT s.dispatch_id) AS dispatches, COUNT(DISTINCT s.lead_id) AS enquiries
        FROM samples s WHERE ${sw} GROUP BY 1 ORDER BY 1 DESC`, ...sa),
      by_grade: M.all(`SELECT COALESCE(NULLIF(s.grade, ''), s.item_name, '(not written)') AS grade, COUNT(*) AS samples, COUNT(DISTINCT s.lead_id) AS enquiries,
        SUM(CASE WHEN l.became_buyer_id IS NOT NULL THEN 1 ELSE 0 END) AS to_buyers
        FROM samples s JOIN leads l ON l.id = s.lead_id WHERE ${sw} GROUP BY 1 ORDER BY 2 DESC`, ...sa),
      by_courier: M.all(`SELECT COALESCE(NULLIF(d.courier, ''), '(not written)') AS courier, COUNT(*) AS dispatches,
        SUM(CASE WHEN d.delivered_on IS NOT NULL THEN 1 ELSE 0 END) AS delivered,
        ROUND(AVG(CASE WHEN d.delivered_on IS NOT NULL AND d.date IS NOT NULL THEN julianday(d.delivered_on) - julianday(d.date) END), 1) AS avg_days
        FROM dispatches d WHERE ${sw.replace(/s\.date/g, 'd.date')} GROUP BY 1 ORDER BY 2 DESC`, ...sa),
      by_state: M.all(`SELECT COALESCE(NULLIF(l.state, ''), '(not written)') AS state, COUNT(*) AS enquiries,
        SUM((SELECT COUNT(*) FROM samples s WHERE s.lead_id = l.id)) AS samples,
        SUM(CASE WHEN l.became_buyer_id IS NOT NULL THEN 1 ELSE 0 END) AS to_buyers
        FROM leads l GROUP BY 1 ORDER BY 2 DESC`),
      calls: M.all(`SELECT f.id, f.due_date, f.reason, l.id AS lead_id, l.ref_no, l.company, l.buyer_name, l.mobile1, l.city
        FROM follow_ups f JOIN leads l ON l.id = f.lead_id WHERE f.status = 'PENDING' ORDER BY f.due_date, l.ref_no LIMIT 500`),
      buyers: M.all(`SELECT l.id, l.ref_no, l.company, l.buyer_name, l.city, l.state, l.became_buyer_id,
        (SELECT MIN(s.date) FROM samples s WHERE s.lead_id = l.id) AS first_sample,
        (SELECT group_concat(DISTINCT COALESCE(s.grade, s.item_name)) FROM samples s WHERE s.lead_id = l.id) AS grades
        FROM leads l WHERE l.became_buyer_id IS NOT NULL ORDER BY l.ref_no DESC`)
        .map(b => ({ ...b, buyer: (mGet('SELECT name FROM parties WHERE id = ?', b.became_buyer_id) || {}).name || '(removed from Buyers)' }))
    };
  });
};
