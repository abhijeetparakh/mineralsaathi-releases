'use strict';
// "Paste or drop a file" on New Sample Dispatch: reads a visiting card, letterhead, GST certificate,
// e-mail screenshot or PDF and finds the customer's GSTIN, company, name, mobiles, e-mail, address,
// pincode and Digipin. Text PDFs are read on the screen (pdf.js); pictures and scanned PDFs are read
// here with the text recognition built into Windows — offline, nothing to install.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile } = require('node:child_process');
const M = require('./db');
const pincode = require('../pincode');

function ocr(file) {
  if (process.platform !== 'win32') return Promise.reject(new M.MktError('Reading pictures works on the Windows main PC only.'));
  return new Promise((resolve, reject) => {
    execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'ocr.ps1'), '-Image', file],
      { windowsHide: true, timeout: 60000, maxBuffer: 4e6, encoding: 'utf8' }, (err, out, errOut) => {
        const t = String(out || '').trim();
        if (/^NOOCR/.test(t)) return reject(new M.MktError('Windows text recognition is not installed on the main PC. Windows Settings → Time & language → Language → English (India) → Options → add "Optical character recognition".'));
        if (err && !t) return reject(new M.MktError('The picture could not be read: ' + String(errOut || err.message).trim().split('\n').pop()));
        resolve(t);
      });
  });
}

const GSTIN = /\b(\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]Z[0-9A-Z])\b/;
const MOBILE = /(?:\+?\s*91[\s-]*|\b0)?\b([6-9]\d(?:[\s-]?\d){8})\b/g;
const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const DIGIPIN = /\b([2-9CFJKLMPT]{3}-[2-9CFJKLMPT]{3}-[2-9CFJKLMPT]{4})\b/i;
const COMPANY = /\b(PVT\.?|PRIVATE|LTD\.?|LIMITED|LLP|INDUSTRIES|ENTERPRISES?|TRADERS?|TRADING|CORPORATION|CORP\.?|COMPANY|& ?CO\.?|AGRO|CHEMICALS?|MINERALS?|CERAMICS?|FERTILI[SZ]ERS?|PAINTS?|EXPORTS?|IMPORTS?|SOLUTIONS|INTERNATIONAL|GROUP|MILLS?|WORKS|FIRM|AGENC(Y|IES)|SUPPLIERS?|M\/S\.?)\b/i;
const LABEL = /^(name|contact( person)?|attn\.?|attention|mr\.?|mrs\.?|ms\.?|shri|smt\.?|dr\.?|proprietor|director|partner|owner)\b[\s.:,-]*/i;
const NOISE = /(tax invoice|invoice|gstin|gst no|pan|state code|phone|mobile|mob|tel|email|e-mail|website|www\.|http|fax|ph\.|whatsapp|bank|ifsc|a\/c|account)/i;

// find the fields in plain text
function parse(text) {
  const raw = String(text || '').replace(/\r/g, '');
  const lines = raw.split('\n').map(l => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const up = raw.toUpperCase().replace(/[O](?=\d{4}[A-Z])/g, '0');
  const out = {};
  const g = up.replace(/\s+/g, ' ').match(GSTIN) || up.replace(/\s/g, '').match(GSTIN);
  if (g) out.gst = g[1];
  const mobiles = [...new Set([...raw.matchAll(MOBILE)].map(m => m[1].replace(/\D/g, '')).filter(m => m.length === 10))];
  if (mobiles[0]) out.mobile1 = mobiles[0];
  if (mobiles[1]) out.mobile2 = mobiles[1];
  const em = raw.match(EMAIL); if (em) out.email = em[0].toLowerCase();
  const dp = raw.match(DIGIPIN); if (dp) out.digipin = dp[1].toUpperCase();
  // pincode: a 6-digit number that is a real Indian pincode, last one wins (address usually ends with it)
  let pinLine = -1;
  lines.forEach((l, i) => { for (const m of l.matchAll(/\b([1-9]\d{2})\s?(\d{3})\b/g)) {
    const pin = m[1] + m[2]; if (out.mobile1 && out.mobile1.includes(pin)) continue;
    const r = pincode.lookup(pin); if (r) { out.pincode = pin; out.city = String(r.city || r.district || '').toUpperCase(); out.state = String(r.state || '').toUpperCase(); pinLine = i; } } });
  // labelled lines (GST certificate, forms): "Trade Name : …", "Legal Name : …", "Address … : …"
  const after = re => { const l = lines.find(x => re.test(x)); const v = l && l.split(':').slice(1).join(':').trim(); return v || null; };
  const trade = after(/^trade name/i), legal = after(/^legal name/i);
  // company: a labelled trade / legal name, or a line that looks like a firm name
  let ci = lines.findIndex(l => COMPANY.test(l) && !NOISE.test(l) && !/:/.test(l) && l.length <= 80 && !/\d{5,}/.test(l));
  if (trade || legal) out.company = String(trade || legal).toUpperCase();
  else if (ci >= 0) out.company = lines[ci].replace(/^(M\/S\.?|MESSRS\.?)\s*/i, '').replace(/[,.:;]+$/, '').toUpperCase();
  const labelled = l => /^(legal name|trade name|registration|form gst|type of|constitution|date of)/i.test(l);
  // person: "Name: …", "Mr. …", or a short line of words just before / after the company
  const pi = lines.findIndex((l, i) => i !== ci && LABEL.test(l) && l.replace(LABEL, '').trim().length > 2 && !/\d{3,}/.test(l.replace(LABEL, '')));
  if (pi >= 0) out.buyer_name = lines[pi].replace(LABEL, '').replace(/^[:\-.\s]+/, '').replace(/[,.:;]+$/, '').toUpperCase();
  // a visiting card: the person's name is a short line of 2–4 words near the top, not a job title
  const JOB = /\b(manager|director|proprietor|partner|owner|ceo|head|executive|officer|purchase|sales|marketing|engineer|incharge|in-charge|founder|chairman)\b/i;
  if (!out.buyer_name && !legal) {
    const k = lines.slice(0, 4).findIndex((l, i) => i !== ci && /^[A-Za-z.]+( [A-Za-z.]+){1,3}$/.test(l) && !COMPANY.test(l) && !JOB.test(l) && !NOISE.test(l) && !/regards|thanks|dear/i.test(l));
    if (k >= 0) out.buyer_name = lines[k].replace(LABEL, '').toUpperCase();
  }
  // address: the lines between the company (or the top) and the pincode line, without phone / e-mail / GST lines
  if (pinLine >= 0) {
    const from = Math.max(ci >= 0 ? ci + 1 : pinLine - 3, pinLine - 4);
    const addrLine = lines.findIndex(l => /^address\b/i.test(l) && l.includes(':'));
    const start = addrLine >= 0 && addrLine <= pinLine ? addrLine : from;
    const addr = lines.slice(start, pinLine + 1).filter((l, k) => start + k !== pi && !labelled(l) && !NOISE.test(l) && !/@/.test(l) && !GSTIN.test(l.toUpperCase()))
      .map(l => l.replace(/^address[^:]*:\s*/i, '').replace(/\b[1-9]\d{2}\s?\d{3}\b/, ' ').trim())
      .filter(l => l && l.toUpperCase() !== out.company && l.toUpperCase() !== out.buyer_name);
    // drop the city, state and pincode left at the end (they have their own boxes)
    let a = addr.join(', ').replace(/\s*[-–]\s*(?=,|$)/g, '').replace(/\s+,/g, ',').replace(/,\s*,/g, ',');
    const tail = new RegExp('(,\\s*(' + [out.city, out.state].filter(Boolean).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + '|india))+\\s*[,.]?\\s*$', 'i');
    if (out.city || out.state) a = a.replace(tail, '');
    a = a.replace(/[\s,.-]+$/, '').trim();
    if (a) out.address = a;
  }
  return out;
}

module.exports = function register(route) {
  // text from the screen (PDF text or pasted text), or a picture as a data URL (image/png, image/jpeg)
  route('POST', '/api/mkt/read-file', async ({ body }) => {
    let text = String(body.text || '');
    if (body.image) {
      const m = String(body.image).match(/^data:image\/(png|jpe?g|webp|bmp|gif);base64,(.+)$/);
      if (!m) throw new M.MktError('This file type cannot be read. Use a picture (PNG, JPG) or a PDF.');
      const buf = Buffer.from(m[2], 'base64');
      if (buf.length > 15e6) throw new M.MktError('The picture is too large (over 15 MB).');
      const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'ms-read-')), 'page.' + (m[1] === 'jpeg' ? 'jpg' : m[1]));
      fs.writeFileSync(file, buf);
      try { text = (text ? text + '\n' : '') + await ocr(file); } finally { try { fs.rmSync(path.dirname(file), { recursive: true, force: true }); } catch { /* ignore */ } }
    }
    if (!text.trim()) throw new M.MktError('No text was found in this file.');
    return { text: text.slice(0, 20000), found: parse(text) };
  });
};
module.exports.parse = parse;
