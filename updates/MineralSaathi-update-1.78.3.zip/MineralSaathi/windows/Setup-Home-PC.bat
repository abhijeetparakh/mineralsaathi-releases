@echo off
rem Run once on your HOME PC or LAPTOP. The data stays in Google Drive; one computer at a time.
cd /d "%~dp0.."
echo.
echo  Mineral Saathi - setup for home PC / laptop
echo  -------------------------------------------
where node >nul 2>nul
if errorlevel 1 (
  echo  First install "Node.js LTS" from https://nodejs.org , then run this again.
  pause
  exit /b 1
)
echo  Google Drive for desktop must be installed and signed in with the same Google account.
echo.
set /p F= Paste the Google Drive data folder (example  G:\My Drive\Mineral Saathi Data): 
if "%F%"=="" exit /b 1
set F=%F:"=%
if not exist "%F%\mineral.db" (
  echo.
  echo  No Mineral Saathi data found in "%F%".
  echo  Check the path, and in Google Drive set that folder to "Available offline".
  pause
  exit /b 1
)
powershell -NoProfile -Command "[IO.File]::WriteAllText('%CD%\config.json', (ConvertTo-Json @{data_folder='%F%'}))"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Mineral Saathi.lnk');$s.TargetPath='%CD%\Open-Mineral-Saathi.bat';$s.WorkingDirectory='%CD%';$s.IconLocation='%CD%\windows\mineral-saathi.ico';$s.WindowStyle=7;$s.Save()"
echo.
echo  Done. Open "Mineral Saathi" from the desktop.
echo  Remember: before using it here, press "Close for today" on the office PC.
pause
