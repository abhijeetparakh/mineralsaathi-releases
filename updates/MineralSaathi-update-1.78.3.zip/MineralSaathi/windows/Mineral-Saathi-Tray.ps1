# Mineral Saathi server in the system tray (near the clock) instead of a window on the taskbar,
# so it is not closed by mistake. Right-click the icon: Open, Close for today, Server messages, Stop.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$root = Split-Path -Parent $PSScriptRoot
$port = 8765
$log = Join-Path $root 'server-log.txt'

# only one tray icon: a second start just wakes the first one
$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'MineralSaathiTray', [ref]$created)
if (-not $created) {
  try { ([System.Threading.EventWaitHandle]::OpenExisting('MineralSaathiTrayWake')).Set() | Out-Null } catch {}
  exit
}
$wake = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, 'MineralSaathiTrayWake')

$icon = New-Object System.Windows.Forms.NotifyIcon
try { $icon.Icon = New-Object System.Drawing.Icon (Join-Path $PSScriptRoot 'mineral-saathi.ico') } catch { $icon.Icon = [System.Drawing.SystemIcons]::Application }
$icon.Text = 'Mineral Saathi - starting'
$icon.Visible = $true

$script:proc = $null
$script:state = 'stopped'      # running, closed, error, stopped
$script:restartAt = $null

function Start-MS {
  if ($script:proc -and -not $script:proc.HasExited) { return }
  $script:proc = Start-Process -FilePath 'cmd.exe' -ArgumentList "/c node --no-warnings server\server.js > `"$log`" 2>&1" -WorkingDirectory $root -WindowStyle Hidden -PassThru
  $script:state = 'running'; $script:restartAt = $null
  $icon.Text = 'Mineral Saathi - running'
}
function Open-App {
  Start-MS
  Start-Process -FilePath 'cmd.exe' -ArgumentList '/c "Open-Mineral-Saathi.bat"' -WorkingDirectory $root -WindowStyle Hidden
}
function Close-Today {
  try { Invoke-RestMethod -Method Post -Uri "http://localhost:$port/api/close" -TimeoutSec 5 | Out-Null } catch {}
}

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miOpen = $menu.Items.Add('Open Mineral Saathi'); $miOpen.Font = New-Object System.Drawing.Font($miOpen.Font, [System.Drawing.FontStyle]::Bold)
$miOpen.add_Click({ Open-App })
$miClose = $menu.Items.Add('Close for today (free the data for another computer)')
$miClose.add_Click({ Close-Today })
$miLog = $menu.Items.Add('Server messages')
$miLog.add_Click({ if (Test-Path $log) { Start-Process notepad.exe $log } })
$menu.Items.Add('-') | Out-Null
$miExit = $menu.Items.Add('Stop the server and remove this icon')
$miExit.add_Click({
  if ($script:proc -and -not $script:proc.HasExited) { Close-Today; Start-Sleep -Seconds 3 }
  $icon.Visible = $false; $icon.Dispose(); [System.Windows.Forms.Application]::Exit()
})
$icon.ContextMenuStrip = $menu
$icon.add_MouseDoubleClick({ Open-App })
$icon.add_BalloonTipClicked({ if ($script:state -eq 'error' -and (Test-Path $log)) { Start-Process notepad.exe $log } else { Open-App } })

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.add_Tick({
  if ($wake.WaitOne(0)) { Start-MS }                     # the desktop icon was opened again
  if ($script:proc -and $script:proc.HasExited -and $script:state -eq 'running') {
    $code = $script:proc.ExitCode
    if ($code -eq 2) {                                   # closed for today (or already running)
      $script:state = 'closed'; $icon.Text = 'Mineral Saathi - closed for today'
      $icon.ShowBalloonTip(4000, 'Mineral Saathi', 'Closed for today. The data is free for another computer. Double-click this icon to open again.', 'Info')
    } elseif ($code -eq 3) {                             # needs attention: the message is in the log
      $script:state = 'error'; $icon.Text = 'Mineral Saathi - needs attention'
      $msg = ''; try { $msg = ((Get-Content $log -Tail 8) -join ' ').Trim() } catch {}
      if ($msg.Length -gt 220) { $msg = $msg.Substring(0, 220) + '...' }
      $icon.ShowBalloonTip(10000, 'Mineral Saathi could not start', $msg + ' (click to read)', 'Warning')
    } else {                                             # stopped for an update or a problem: start again
      $script:state = 'restart'; $script:restartAt = (Get-Date).AddSeconds(3); $icon.Text = 'Mineral Saathi - restarting'
    }
  }
  if ($script:state -eq 'restart' -and $script:restartAt -and (Get-Date) -ge $script:restartAt) { Start-MS }
})
$timer.Start()

if ($args -notcontains '-nostart') { Start-MS }
[System.Windows.Forms.Application]::Run()
$mutex.ReleaseMutex()
