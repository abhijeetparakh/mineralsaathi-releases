@echo off
rem Opens the Mineral Saathi data on THIS computer when another computer did not close it properly.
cd /d "%~dp0.."
echo.
echo  Use this only if Mineral Saathi is CLOSED or the other computer is SWITCHED OFF.
echo  If it is still running there, entries made there could be lost.
echo.
choice /c YN /m " Is Mineral Saathi closed on the other computer"
if errorlevel 2 exit /b 0
set MS_TAKEOVER=1
start "Mineral Saathi Server" /min "%~dp0..\Start-Server.bat"
timeout /t 6 /nobreak >nul
call "%~dp0..\Open-Mineral-Saathi.bat"
