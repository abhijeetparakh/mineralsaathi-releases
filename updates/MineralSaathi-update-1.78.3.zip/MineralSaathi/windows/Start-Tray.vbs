' Starts the Mineral Saathi server hidden, with its icon near the clock (system tray).
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
CreateObject("WScript.Shell").Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & here & "\Mineral-Saathi-Tray.ps1""", 0, False
