@echo off
rem Opens Mineral Saathi full screen. On the main PC it also starts the server if it is not running.
set ADDR=localhost:8765
if exist "%~dp0server-address.txt" set /p ADDR=<"%~dp0server-address.txt"
set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
if not exist "%EDGE%" set EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe

curl.exe -s -o nul http://%ADDR%/api/version
if not errorlevel 1 goto open

if /i "%ADDR:~0,9%"=="localhost" (
  echo  Starting the Mineral Saathi server...
  rem the server runs hidden, with its icon near the clock (system tray)
  wscript.exe "%~dp0windows\Start-Tray.vbs"
)
echo  Waiting for the server at %ADDR% ...
for /l %%i in (1,1,30) do (
  timeout /t 1 /nobreak >nul
  curl.exe -s -o nul http://%ADDR%/api/version && goto open
)
echo.
echo  The server at %ADDR% is not answering.
echo  Right-click the Mineral Saathi icon near the clock and choose "Server messages".
echo  If it says the data is open on another computer, press "Close for today" there first.
pause
exit /b 1

:open
set SECURE=--unsafely-treat-insecure-origin-as-secure=http://%ADDR%
if /i "%ADDR:~0,9%"=="localhost" set SECURE=
start "" "%EDGE%" --app=http://%ADDR%/ --start-fullscreen %SECURE% --no-first-run --user-data-dir="%LOCALAPPDATA%\MineralSaathiApp"
