@echo off
rem Run on every OTHER office PC. Nothing else needs to be installed there.
set /p ADDR=Type the main PC address shown during main PC setup (example 192.168.1.10):
if "%ADDR%"=="" exit /b 1
echo %ADDR%| findstr ":" >nul || set ADDR=%ADDR%:8765
set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
if not exist "%EDGE%" set EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe
if not exist "%LOCALAPPDATA%\MineralSaathiApp" mkdir "%LOCALAPPDATA%\MineralSaathiApp"
copy /y "%~dp0windows\mineral-saathi.ico" "%LOCALAPPDATA%\MineralSaathiApp\mineral-saathi.ico" >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Mineral Saathi.lnk');$s.TargetPath='%EDGE%';$s.Arguments='--app=http://%ADDR%/ --start-fullscreen --unsafely-treat-insecure-origin-as-secure=http://%ADDR% --no-first-run --user-data-dir=\"%LOCALAPPDATA%\MineralSaathiApp\"';$s.IconLocation='%LOCALAPPDATA%\MineralSaathiApp\mineral-saathi.ico';$s.Save()"
echo.
echo  Done. Open "Mineral Saathi" from the desktop.
pause
