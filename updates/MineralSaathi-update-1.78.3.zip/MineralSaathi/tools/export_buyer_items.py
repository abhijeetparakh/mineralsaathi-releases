"""Collects each buyer's items, rates and packing from the old Excel buyer lists
(MAIN DATA / PF DATA sheets) into a data file for Settings -> Import.

Usage: python export_buyer_items.py <out.json> <workbook.xlsm> [<workbook.xlsm> ...]
"""
import sys, re, json, datetime, warnings
import openpyxl

warnings.filterwarnings("ignore")
OUT, SOURCES = sys.argv[1], sys.argv[2:]

# (item, grade, rate, bag type, kg per bag) column names for the 5 item slots in MAIN DATA
SLOTS = [("PARTICULERS", "GRADE1", "RATE1", "PACKING TYPE 1", "PACKING SIZE"),
         ("PARTICULAS 2", "GRADE2", "RATE2", "PACKING TYPE 2", "PACKING SIZE 2"),
         ("PARTICULAS 3", "GRADE 3", "RATE 3", "PACKING TYPE 3", "PACKING GRADE 3"),
         ("PARTICULERS 4", "GRADE 4", "RATE 4", "PACKING 4", "PACKING SIZE 4"),
         ("PARTICULERS 5", "GRADE 5", "RATE 5", "PACKING 5", "PACKING SIZE 5")]


def s(v):
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    t = str(v).replace("_x000D_", " ").strip()
    return t or None


def num(v):
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"[^0-9.]", "", str(v))
    try:
        return float(t) if t else None
    except ValueError:
        return None


def liner(text):
    t = (text or "").upper()
    if re.search(r"WITHOUT\s+LIN", t):
        return 0
    if re.search(r"LINN?ER", t):
        return 1
    return None


buyers = {}
for src in SOURCES:
    wb = openpyxl.load_workbook(src, read_only=True, data_only=True)
    for sh in ("MAIN DATA", "PF DATA"):
        if sh not in wb.sheetnames:
            continue
        it = wb[sh].iter_rows(values_only=True, max_col=70)
        head = [str(c).strip().upper() if c is not None else "" for c in next(it)]
        for r in it:
            rec = {}
            for i, h in enumerate(head):
                if h and h not in rec and i < len(r):
                    rec[h] = r[i]
            name = s(rec.get("ORGANIZATIONNAME"))
            if not name:
                continue
            gst = (s(rec.get("GST NO")) or "").upper()
            gst = gst if re.match(r"^\d\d[A-Z0-9]{13}$", gst) else None
            key = gst or (name.upper(), (s(rec.get("CITY")) or "").upper())
            b = buyers.setdefault(key, {"name": name, "gstin": gst, "city": s(rec.get("CITY")), "items": []})
            supply = s(rec.get("WITH (YES) AND WIITHOUT PACKING (NO)"))
            for slot in SLOTS:
                item = (s(rec.get(slot[0])) or "").upper()
                grade = (s(rec.get(slot[1])) or "").upper()
                rate = num(rec.get(slot[2]))
                if not item or not (grade or rate):
                    continue
                bag = s(rec.get(slot[3]))
                entry = {"item_name": item, "grade": grade or None, "rate": rate, "pack_size": num(rec.get(slot[4])),
                         "bag_type": bag.upper() if bag else None, "liner": liner(bag),
                         "bag_supply": "OUR" if (supply or "").upper() == "YES" else None}
                if not any(x["item_name"] == item and (x["grade"] or "") == grade for x in b["items"]):
                    b["items"].append(entry)

data = {"kind": "mineral-saathi-buyer-items", "made": datetime.datetime.now().isoformat(timespec="seconds"),
        "buyers": [b for b in buyers.values() if b["items"]]}
json.dump(data, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("buyers with items:", len(data["buyers"]), "items:", sum(len(b["items"]) for b in data["buyers"]))
