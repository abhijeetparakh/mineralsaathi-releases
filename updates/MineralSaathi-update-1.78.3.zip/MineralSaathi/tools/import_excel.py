"""One-time import of the old Excel workbooks into the Mineral Saathi database.

Usage:  python import_excel.py <billing.xlsm> <inward.xlsm> <schema.sql> <out.db>
"""
import sys, re, sqlite3, datetime, warnings
import openpyxl

warnings.filterwarnings("ignore")
BILL, INWARD, SCHEMA, OUT = sys.argv[1:5]

db = sqlite3.connect(OUT)
db.executescript(open(SCHEMA, encoding="utf-8").read())
cur = db.cursor()

wb = openpyxl.load_workbook(BILL, read_only=True, data_only=True)
wi = openpyxl.load_workbook(INWARD, read_only=True, data_only=True)


# ---------- helpers ----------
def s(v):
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    t = str(v).replace("_x000D_", "").strip()
    return t or None


def num(v):
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"[^0-9.\-]", "", str(v))
    try:
        return float(t) if t not in ("", ".", "-") else None
    except ValueError:
        return None


def dt(v):
    """Excel dates come as datetime or 'dd.mm.yyyy' / 'dd.mm.yy' text."""
    if v is None:
        return None
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    if isinstance(v, datetime.date):
        return v.isoformat()
    m = re.match(r"\s*(\d{1,2})[./\-](\d{1,2})[./\-](\d{2,5})", str(v))
    if not m:
        return None
    d, mo, y = int(m.group(1)), int(m.group(2)), m.group(3)
    y = int(y[:4]) if len(y) >= 4 else 2000 + int(y)
    try:
        return datetime.date(y, mo, d).isoformat()
    except ValueError:
        return None


def rows(ws, maxcol=70):
    it = ws.iter_rows(values_only=True, max_col=maxcol)
    head = [str(c).strip().upper() if c is not None else "" for c in next(it)]
    for r in it:
        if r is None or all(c in (None, "") for c in r):
            continue
        rec = {}
        for i, h in enumerate(head):
            if h and h not in rec and i < len(r):
                rec[h] = r[i]
        rec["_raw"] = r
        yield rec


def fy_from_name(name):
    m = re.search(r"(20\d\d)-(\d\d)", name)
    return f"{m.group(1)}-{m.group(2)}" if m else None


# ---------- firms ----------
firm_rows = {r["NAME"]: r for r in rows(wb["COMPANY DATA"]) if r.get("NAME")}
TERMS = ("Seller is not responsible for any loss or damage of goods in transit.\n"
         "Disputes if any, will be subject to Jodhpur court jurisdiction.")
for code, key in (("PPE", "P.P.ENTERPRISE"), ("PM", "PARAKH MARKETING"), ("PF", "PARAKH FERTILIZER")):
    r = firm_rows[key]
    cur.execute("""INSERT INTO firms(code,name,gstin,pan,address,city,state,state_code,pincode,phone,email,upi_id,terms,smtp_host,smtp_port)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (code, s(r["NAME"]).title().replace("P.P.Enterprise", "P.P. Enterprise"), s(r["GST NO"]), s(r["PAN"]),
                 re.sub(r",\s*,", ",", s(r["REG ADDRES"])).strip(" ,"), s(r["CITY"]), s(r["STATE"]), "08", s(r["PINCODE"]),
                 s(r["MOBILE NO"]), s(r["EMAIL"]),
                 "parakhmarketing@kotak" if code == "PM" else None, TERMS, "smtp.gmail.com", 465))
cur.execute("UPDATE firms SET name='P.P. Enterprise' WHERE code='PPE'")
cur.execute("UPDATE firms SET name='Parakh Marketing' WHERE code='PM'")
cur.execute("UPDATE firms SET name='Parakh Fertilizer' WHERE code='PF'")

# ---------- plants ----------
cur.execute("INSERT INTO plants(name,full_name,address) VALUES('PPI PLANT','P.P. Industries','F-106, Mandore Industrial Area RIICO, Jodhpur')")
cur.execute("INSERT INTO plants(name,full_name,address) VALUES('KI PLANT','Karni Industries','F-100, Mandore Industrial Area RIICO, Jodhpur')")

# ---------- parties ----------
seen = set()


def add_party(r, firm, b2c=0):
    name = s(r.get("ORGANIZATIONNAME"))
    if not name:
        return
    key = (name.upper(), (s(r.get("CITY")) or "").upper())
    if key in seen:
        return
    seen.add(key)
    gst = s(r.get("GST NO"))
    if gst and not re.match(r"^\d\d[A-Z0-9]{13}$", gst.upper()):
        gst = None
    sc = s(r.get("STATE CODE"))
    if gst:
        sc = gst[:2]
    if sc and sc.isdigit():
        sc = sc.zfill(2)
    cur.execute("""INSERT INTO parties(name,firm_code,gstin,pan,address,city,state,state_code,pincode,ship_address,
                   email,mobile,phone,transporter,km,group_name,payment_terms,notes,is_b2c)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (name, firm, gst.upper() if gst else None, (s(r.get("BUYER PAN")) or "").upper() or None,
                 s(r.get("DELIVERY ADDRESS")), s(r.get("CITY")), (s(r.get("STATE")) or "").upper() or None, sc,
                 s(r.get("PINCODE2")), s(r.get("SHIPPING ADDRESS")) or s(r.get("PLANT 1")),
                 s(r.get("EMAIL")), s(r.get("MOBILE NO.")), s(r.get("TEL NO.")),
                 s(r.get("TRANSPORT")), int(num(r.get("KM")) or 0) or None,
                 s(r.get("GROUP OF COMPANY")), s(r.get("PAYMENT TERMS")), s(r.get("NOTE")), b2c))


for r in rows(wb["PF DATA"]):
    add_party(r, "PF")
pf_keys = set(seen)
both = set()
for r in rows(wb["MAIN DATA"]):
    k = ((s(r.get("ORGANIZATIONNAME")) or "").upper(), (s(r.get("CITY")) or "").upper())
    if k in pf_keys and s(r.get("BILLING FIRM")) != "PARAKH FERTILIZER":
        both.add(k)
    add_party(r, "PF" if s(r.get("BILLING FIRM")) == "PARAKH FERTILIZER" else "PM")
# Buyers found in both the Parakh Marketing and Parakh Fertilizer lists: billing firm left blank,
# to be chosen in the Buyers screen.
for name, city in both:
    cur.execute("UPDATE parties SET firm_code = NULL WHERE upper(name) = ? AND upper(COALESCE(city,'')) = ?", (name, city))
print("buyers left without billing firm:", len(both))
for r in rows(wb["ONLINE DATA"]):
    add_party(r, "PM", 1)
# Parakh Fertilizer is also a buyer of Parakh Marketing
pf = firm_rows["PARAKH FERTILIZER"]
cur.execute("""INSERT INTO parties(name,firm_code,gstin,pan,address,city,state,state_code,pincode,email,mobile)
               VALUES('PARAKH FERTILIZER','PM',?,?,?,?,?,'08',?,?,?)""",
            (s(pf["GST NO"]), s(pf["PAN"]), s(pf["REG ADDRES"]), s(pf["CITY"]), s(pf["STATE"]),
             s(pf["PINCODE"]), s(pf["EMAIL"]), s(pf["MOBILE NO"])))

# ---------- items ----------
item_seen = set()


def add_item(name, grade, hsn, gst, bag=None, pack=None, rate=None):
    name = (s(name) or "").upper()
    if not name:
        return
    grade = (s(grade) or "").upper() or None
    key = (name, grade)
    if key in item_seen:
        return
    item_seen.add(key)
    cur.execute("INSERT INTO items(name,grade,hsn,gst_rate,bag_type,pack_size,rate) VALUES(?,?,?,?,?,?,?)",
                (name, grade, s(hsn) or "2512", gst or 5, s(bag), num(pack), num(rate)))


add_item("DIATOMACEOUS EARTH (RAW)", "YELLOW", "2512", 5)
add_item("DIATOMACEOUS EARTH (RAW)", "WHITE", "2512", 5)
for r in rows(wb["item master"]):
    add_item(r.get("ITEM"), r.get("QUALITY"), r.get("HSN CODE"), num(r.get("TAX RATE")), r.get("BAG TYPE"), r.get("PACKING"), r.get("RATE"))
for sh in ("INVOICE DATA 2026-27", "INVOICE DATA 2025-26"):
    for r in rows(wb[sh]):
        amt, tax = num(r.get("AMOUNT")), num(r.get("TAX"))
        g = round(tax / amt * 100, 1) if amt and tax else 5
        if g not in (0, 5, 12, 18):
            g = 5
        hsn = s(r.get("HSN CODE"))
        if hsn and len(hsn) > 8:
            hsn = None
        add_item(r.get("ITMENAME"), r.get("GRADE"), hsn, g, r.get("PACKINGTYPE"), r.get("PACKING"), r.get("RATE"))

# ---------- transporters ----------
for r in rows(wb["TRANSPORT DETAILES"]):
    n = s(r.get("TRANSPORTER"))
    if not n:
        continue
    cur.execute("""INSERT INTO transporters(name,phone,mobile,address,district,state,gstin,pan,email,contact,bank_name,bank_account,bank_ifsc)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (n, s(r.get("PHONE NO.")), s(r.get("MOBILE NO.")), s(r.get("ADDRESS")), s(r.get("DISTRICT")), s(r.get("STATE")),
                 s(r.get("GST NUMBER")), s(r.get("PAN")), s(r.get("EMAIL")), s(r.get("CONTACT PERSON")),
                 s(r.get("BANK NAME")), s(r.get("ACCOUNT NO.")), s(r.get("IFSC"))))

# ---------- lorries ----------
for r in rows(wi["PAN CARD"]):
    ln = (s(r.get("LORRY NO")) or "").upper().replace(" ", "")
    if not ln:
        continue
    cur.execute("""INSERT OR IGNORE INTO lorries(lorry_no,owner,pan,mobile,address,driver_name,driver_phone,bank_name,holder,bank_ifsc,bank_account,upi,tds_declaration)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (ln, s(r.get("OWNER")), s(r.get("PAN")), s(r.get("MOBILE NO.")), s(r.get("ADDRESS")),
                 s(r.get("DRIVER NAME")), s(r.get("DRIVER NUMBER")), s(r.get("BANK NAME")), s(r.get("HOLDER NAME")),
                 s(r.get("IFCS")), s(r.get("ACCOUNT NO")), s(r.get("UPI")), s(r.get("DECLARATION STATUS"))))

# ---------- suppliers ----------
for r in rows(wi["Suppliers"]):
    n = s(r.get("SUPPLIERS"))
    if n:
        cur.execute("INSERT OR IGNORE INTO suppliers(name,grade,rate,freight_rate,type) VALUES(?,?,?,?,?)",
                    (n, s(r.get("GRADE")), num(r.get("RATE")), num(r.get("FREIGHT")), s(r.get("TYPE")) or "REG"))

# ---------- inwards ----------
n_in = 0
for sh in wi.sheetnames:
    if not re.match(r"^INWARD 20\d\d-\d\d$", sh):
        continue
    fy = fy_from_name(sh)
    used = set()
    for k, r in enumerate(rows(wi[sh], 50)):
        actual = num(r.get("QTY"))
        lorry = (s(r.get("LORRY NO,")) or "").upper().replace(" ", "")
        if not lorry or actual is None:
            continue
        vno = (s(r.get("VOUCHER")) or "").replace(" ", "")
        if not vno or not re.search(r"V\d", vno.upper()):
            vno = f"OLD-{k+1}"
        base, i = vno, 2
        while vno in used:
            vno = f"{base}/{i}"; i += 1
        used.add(vno)
        upi = s(r.get("INVOCE DONE"))
        if upi and "@" not in upi:
            upi = None
        rate = num(r.get("FPM"))
        frt = num(r.get("TOTAL  FRG")) or (round(actual * rate, 2) if rate else None)
        mode = " / ".join(x for x in (s(r.get("MODE")), s(r.get("CHQ NO."))) if x)
        cur.execute("""INSERT INTO inwards(fy,voucher_no,date,voucher_date,supplier,mines,lorry_no,grade,condition,plant,
                       rawana_no,challan_no,rawana_wt,actual_wt,freight_rate,freight_amt,pay_mode,cash_amt,bank_amt,
                       owner_name,pan,driver_name,driver_phone,upi,transporter,lr_no,royalty,dmft,nmet,legacy)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",
                    (fy, vno, dt(r.get("DATE")), dt(r.get("V.DATE")), s(r.get("FROM")), s(r.get("MINES")), lorry,
                     s(r.get("GRADE")), s(r.get("CONDITION")), s(r.get("PLANT")), s(r.get("RAVANA NO.")),
                     s(r.get("CHALLEN NO")), num(r.get("RAWANA WEG")), actual, rate, frt, mode or None,
                     num(r.get("CASH")) or 0, num(r.get("BANK")) or 0, s(r.get("OWNER NAME")), s(r.get("PAN")),
                     s(r.get("DRIVER NAME")), s(r.get("DRIVER PH")), upi, s(r.get("TRANSORTOR")), s(r.get("L.R.NO")),
                     num(r.get("ROYALTY")), num(r.get("DMFT")), num(r.get("NMET"))))
        n_in += 1

# ---------- Parakh Marketing sales invoices ----------
party_ids = {}
for pid, name in cur.execute("SELECT id, upper(name) FROM parties").fetchall():
    party_ids.setdefault(name, pid)

n_pm = 0
for sh in wb.sheetnames:
    if not re.match(r"^INVOICE DATA 20\d\d-\d\d$", sh):
        continue
    fy = fy_from_name(sh)
    for r in rows(wb[sh]):
        if s(r.get("FIRM")) != "PARAKH MARKETING":
            continue
        no = num(r.get("INVOICENO"))
        if not no:
            continue
        no = int(no)
        party = s(r.get("PARTY")) or ""
        amt = num(r.get("AMOUNT")) or 0
        sg, cg, ig = num(r.get("SGST")) or 0, num(r.get("CGST")) or 0, num(r.get("IGST")) or 0
        tax = num(r.get("TAX")) or 0
        if not (sg or cg or ig) and tax:
            if (s(r.get("STATE")) or "RAJASTHAN").upper() == "RAJASTHAN":
                sg = cg = round(tax / 2, 2)
            else:
                ig = tax
        gst = s(r.get("GST NO"))
        amt = round(amt - (sg + cg + ig), 2)   # AMOUNT column in Excel is the grand total incl. tax
        row = cur.execute("SELECT id FROM invoices WHERE firm_code='PM' AND fy=? AND inv_no=?", (fy, no)).fetchone()
        if row:
            inv_id = row[0]
            cur.execute("""UPDATE invoices SET taxable=taxable+?, cgst=cgst+?, sgst=sgst+?, igst=igst+?, total=total+? WHERE id=?""",
                        (amt, cg, sg, ig, amt + cg + sg + ig, inv_id))
        else:
            cur.execute("""INSERT INTO invoices(firm_code,fy,inv_no,date,kind,party_id,party_name,party_gstin,party_address,party_city,
                           party_state,party_state_code,ship_address,supply_type,lorry_no,transporter,lr_no,driver_phone,plant,ewb_no,
                           freight_note,taxable,cgst,sgst,igst,round_off,total,email_sent_at,notes,legacy)
                           VALUES('PM',?,?,?,'SALE',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?,1)""",
                        (fy, no, dt(r.get("DATE")), party_ids.get(party.upper()), party, gst, s(r.get("ADDRESS")),
                         s(r.get("CITY")) or s(r.get("PARTYPLANT")), s(r.get("STATE")), s(r.get("STATE CODE")),
                         s(r.get("DELIVERY ADDRESS")), "B2B" if gst else "B2C", s(r.get("LORRYNO.")), s(r.get("TRANSPOTOR")),
                         s(r.get("LRNO")), s(r.get("DRIVERNO")), s(r.get("PLANT")), s(r.get("WAY BILL NO")),
                         s(r.get("FREIGHTPMT")), amt, cg, sg, ig, amt + cg + sg + ig,
                         s(r.get("EMAILSENTDATETIME")), s(r.get("NOTE"))))
            inv_id = cur.lastrowid
            n_pm += 1
        sl = cur.execute("SELECT count(*)+1 FROM invoice_items WHERE invoice_id=?", (inv_id,)).fetchone()[0]
        qty, rate = num(r.get("WEG")), num(r.get("RATE"))
        cur.execute("""INSERT INTO invoice_items(invoice_id,sl,item_name,grade,hsn,qty,unit,rate,amount,gst_rate,bags,pack_size,bag_type,lorry_no)
                       VALUES(?,?,?,?,?,?,'MT',?,?,?,?,?,?,?)""",
                    (inv_id, sl, s(r.get("ITMENAME")) or s(r.get("PARTICULERS")), s(r.get("GRADE")),
                     (s(r.get("HSN CODE")) or "2512")[:8], qty, rate, amt,
                     round((cg + sg + ig) / amt * 100) if amt else 5,
                     int(num(r.get("NOOFBAGS")) or 0) or None, num(r.get("PACKING")), s(r.get("PACKINGTYPE")),
                     s(r.get("LORRYNO."))))

# ---------- P.P. Enterprise -> Parakh Marketing bills ----------
pm_party = party_ids.get("PARAKH MARKETING")
pmf = firm_rows["PARAKH MARKETING"]
n_ppe = 0
for sh in wb.sheetnames:
    if not sh.startswith("PPENTER DATA 20"):
        continue
    fy = fy_from_name(sh)
    for r in rows(wb[sh]):
        no = num(r.get("INVOICE NO"))
        if not no:
            continue
        no = int(no)
        taxable, tax = num(r.get("TOTAL")) or 0, num(r.get("TAX")) or 0
        if cur.execute("SELECT 1 FROM invoices WHERE firm_code='PPE' AND fy=? AND inv_no=?", (fy, no)).fetchone():
            continue
        cur.execute("""INSERT INTO invoices(firm_code,fy,inv_no,date,kind,party_id,party_name,party_gstin,party_pan,party_address,party_city,
                       party_state,party_state_code,party_pincode,supply_type,lorry_no,taxable,cgst,sgst,igst,round_off,total,legacy)
                       VALUES('PPE',?,?,?,'PPE_BILL',?,'PARAKH MARKETING',?,?,?,?,?,'08',?,'B2B',?,?,?,?,0,0,?,1)""",
                    (fy, no, dt(r.get("DATE")), pm_party, s(pmf["GST NO"]), s(pmf["PAN"]), s(pmf["REG ADDRES"]),
                     s(pmf["CITY"]), s(pmf["STATE"]), s(pmf["PINCODE"]), s(r.get("LORRYNO 1")),
                     taxable, round(tax / 2, 2), round(tax / 2, 2), taxable + tax))
        inv_id = cur.lastrowid
        n_ppe += 1
        rate = num(r.get("RATE"))
        for j in ("1", "2"):
            lorry = s(r.get("LORRYNO " + j))
            q = num(r.get("QTY" + j))
            if not lorry or not q:
                continue
            rno = s(r.get("R NO" + j))
            chn = s(r.get("CHN0" + j))
            inw = cur.execute("SELECT id FROM inwards WHERE rawana_no=? AND rawana_no IS NOT NULL", (rno,)).fetchone() if rno else None
            cur.execute("""INSERT INTO invoice_items(invoice_id,sl,item_name,grade,hsn,qty,unit,rate,amount,gst_rate,inward_id,lorry_no,rawana_no,challan_no)
                           VALUES(?,?,'DIATOMACEOUS EARTH (RAW)',NULL,'2512',?,'MT',?,?,5,?,?,?,?)""",
                        (inv_id, int(j), q, rate, round(q * (rate or 0), 2), inw[0] if inw else None, lorry, rno, chn))
            if inw:
                cur.execute("UPDATE inwards SET ppe_invoice_id=? WHERE id=?", (inv_id, inw[0]))

cur.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('imported_at',?)", (datetime.datetime.now().isoformat(timespec="seconds"),))
cur.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('current_fy','2026-27')")
db.commit()

for t in ("firms", "plants", "parties", "items", "transporters", "lorries", "suppliers", "inwards", "invoices", "invoice_items"):
    print(t, cur.execute(f"SELECT count(*) FROM {t}").fetchone()[0])
print("PM invoices", n_pm, "PPE bills", n_ppe, "inwards", n_in)
