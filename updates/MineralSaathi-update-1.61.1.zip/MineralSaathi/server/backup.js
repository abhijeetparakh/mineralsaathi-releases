'use strict';
// Backups: a full copy of the database goes to the chosen backup folder after every new / changed
// invoice and every hour — always into that day's one file; the last 10 days are kept.
const fs = require('node:fs');
const path = require('node:path');
const { db, setting, setSetting, DATA_DIR } = require('./db');

const KEEP_DAYS = 10;         // one backup file per day, the last 10 days
let pending = null;

function folder() {
  return setting('backup_folder') || path.join(DATA_DIR, 'backups');
}

const p2 = n => String(n).padStart(2, '0');
function today() { const d = new Date(); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; }

// every backup of a day replaces that day's file: MineralSaathi_2026-11-19.db
function backupNow(reason = 'manual') {
  const dir = folder();
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `MineralSaathi_${today()}.db`), tmp = file + '.part';
  try { fs.unlinkSync(tmp); } catch { /* none */ }
  db.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
  fs.renameSync(tmp, file);
  // Marketing data (marketing.db) is backed up at the same moment: Marketing_2026-11-19.db
  try { require('./marketing/db').backupInto(path.join(dir, `Marketing_${today()}.db`)); }
  catch (e) { console.error('Marketing backup failed:', e.message); setSetting('last_backup_error', 'Marketing: ' + e.message); }
  setSetting('last_backup', new Date().toISOString());
  setSetting('last_backup_file', file);
  setSetting('last_backup_reason', reason);
  prune(dir);
  return file;
}

// keep the newest backup of each of the last 10 days (older names "…_2026-11-19_101530_hourly.db" too); delete the rest
function prune(dir) {
  // Marketing copies: keep the last 10 days too
  const mk = fs.readdirSync(dir).filter(f => /^Marketing_\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort().reverse();
  for (const f of mk.slice(KEEP_DAYS)) { try { fs.unlinkSync(path.join(dir, f)); } catch { /* in use */ } }
  const files = fs.readdirSync(dir).filter(f => /^MineralSaathi_\d{4}-\d{2}-\d{2}.*\.db$/.test(f));
  const byDay = new Map();
  for (const f of files) {
    const day = f.slice(14, 24), mt = fs.statSync(path.join(dir, f)).mtimeMs;
    const cur = byDay.get(day); if (!cur || mt > cur.mt) byDay.set(day, { f, mt });
  }
  const keepDays = [...byDay.keys()].sort().reverse().slice(0, KEEP_DAYS);
  for (const f of files) {
    const day = f.slice(14, 24), best = byDay.get(day);
    if (!keepDays.includes(day) || best.f !== f) { try { fs.unlinkSync(path.join(dir, f)); } catch { /* in use */ } }
  }
  // the kept file of an older day gets the plain daily name
  for (const day of keepDays) {
    const { f } = byDay.get(day), want = `MineralSaathi_${day}.db`;
    if (f !== want) { try { fs.renameSync(path.join(dir, f), path.join(dir, want)); } catch { /* in use */ } }
  }
}

// Called after every invoice save. Waits a few seconds so a burst of saves makes one backup.
function backupSoon(reason = 'invoice') {
  clearTimeout(pending);
  pending = setTimeout(() => {
    try { backupNow(reason); } catch (e) { console.error('Backup failed:', e.message); setSetting('last_backup_error', e.message); }
  }, 3000);
}

function list() {
  const dir = folder();
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(f => /^(MineralSaathi|Marketing)_.*\.db$/.test(f)).sort().reverse().slice(0, 50)
    .map(f => ({ name: f, size: fs.statSync(path.join(dir, f)).size }));
}

function startHourly() {
  setInterval(() => {
    try { backupNow('hourly'); } catch (e) { console.error('Hourly backup failed:', e.message); setSetting('last_backup_error', e.message); }
  }, 60 * 60 * 1000);
}

module.exports = { backupNow, backupSoon, list, folder, startHourly };
