'use strict';
// one computer at a time: check the lock note before the data is opened
// a new installation (or data that could not be opened): first ask where the data is
if (require.main === module && require('./firstrun').needed()) { require('./firstrun').run(); return; }
if (require.main === module && require('./lock').acquireOrExit() === 'page') return;   // "take over?" page is showing
// Mineral Saathi server — runs on the main office PC. Every PC opens http://<main-pc>:7070 full screen.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { all, get, run, columns, setting, setSetting, ROOT, DATA_DIR } = require('./db');
const L = require('./logic');
const backup = require('./backup');
const { wagesHtml, localFreightHtml, trInvoiceHtml, invoiceHtml, voucherHtml, labelHtml, envelopeHtml, setupFor, invoiceCopies, PAPERS, DEFAULT_SETUP, mediaFor, sheetCount } = require('./print');
const winprint = require('./winprint');
const mailer = require('./mailer'), { splitAddr } = mailer;
// HTML written in the email boxes: no scripts, no event handlers, no javascript: links
function cleanHtml(h) {
  return String(h || '').replace(/<\s*(script|style|iframe|object|embed|form|input|button|meta|link)[\s\S]*?(<\/\s*\1\s*>|$)/gi, '')
    .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '').replace(/(href|src)\s*=\s*("|')\s*javascript:[^"']*\2/gi, '$1="#"');
}
// the look of every email (Settings → Email templates → Email look)
function emailStyle(firm) {
  const s = { font: setting('email_font', 'Arial, Helvetica, sans-serif'), size: Number(setting('email_size', '14')) || 14, color: setting('email_color', '#222222'),
    logoH: Number(setting('email_logo_h', '60')) || 60, align: setting('email_logo_align', 'left'), footer: '' };
  if (firm && setting('email_footer', '1') === '1') {
    const e = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    s.footer = `<b style="color:#4a5659">${e(firm.name)}</b><br>${e([firm.address, [firm.city, firm.pincode].filter(Boolean).join(' - '), firm.state].filter(Boolean).join(', '))}`
      + `<br>${[firm.phone ? 'Ph: ' + e(firm.phone) : '', firm.email ? e(firm.email) : '', firm.gstin ? 'GSTIN: ' + e(firm.gstin) : ''].filter(Boolean).join(' &nbsp;·&nbsp; ')}`;
  }
  return s;
}
const smtpSend = (cfg, msg) => {
  const firm = get('SELECT * FROM firms WHERE lower(smtp_user) = lower(?) OR lower(email) = lower(?) LIMIT 1', msg.from || '', msg.from || '');
  return mailer.smtpSend(cfg, { ...msg, html: msg.html ? cleanHtml(msg.html) : undefined, text: msg.html && !msg.text ? undefined : msg.text, style: emailStyle(firm) });
};
const { makePdf } = require('./pdf');
const updater = require('./updater');
const lock = require('./lock');
const { db } = require('./db');
const { readConfig, writeConfig, DB_FILE: DBF, ROOT: APP_ROOT } = require('./paths');

function shutdown(code, releaseLock = true) {
  try { db.close(); } catch { /* already closed */ }
  try { require('./marketing/db').close(); } catch { /* not open */ }
  if (releaseLock) lock.release();
  process.exit(code);
}

const PORT = Number(process.env.MS_PORT || 8765);
const PUBLIC = path.join(ROOT, 'public');
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;

const MASTER_TABLES = ['parties', 'items', 'transporters', 'lorries', 'suppliers', 'plants', 'firms', 'local_drivers', 'b2c_customers'];
const SEARCH_COLS = {
  parties: ['name', 'city', 'gstin', 'group_name'], items: ['name', 'grade', 'hsn'], transporters: ['name', 'district', 'gstin'],
  lorries: ['lorry_no', 'owner', 'pan', 'driver_name'], suppliers: ['name', 'grade'], plants: ['name', 'full_name'], firms: ['name', 'code'], local_drivers: ['name', 'tempo_no', 'mobile'], b2c_customers: ['name', 'mobile', 'city', 'email']
};
const ORDER = { parties: 'name', items: 'name, grade', transporters: 'name', lorries: 'lorry_no', suppliers: 'name', plants: 'name', firms: 'id', local_drivers: 'name', b2c_customers: 'name' };

// ---------- helpers ----------
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', c => { d += c; if (d.length > 50e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { reject(new L.UserError('Bad data sent.')); } });
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

function serveStatic(res, urlPath) {
  const p = path.normalize(path.join(PUBLIC, urlPath === '/' ? 'index.html' : urlPath));
  if (!p.startsWith(PUBLIC) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) return send(res, 404, 'Not found', 'text/plain');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(p).pipe(res);
}

function cleanRow(table, body) {
  const cols = columns(table).filter(c => c !== 'id');
  const o = {};
  for (const c of cols) if (body[c] !== undefined) o[c] = body[c] === '' ? null : body[c];
  L.normalize(o);
  return o;
}

function checkParty(o, id) {
  if (o.name !== undefined && !String(o.name || '').trim()) throw new L.UserError('Enter the buyer name.');
  for (const k of ['group_name', 'payment_terms', 'test_report', 'print_loc']) if (o[k]) o[k] = String(o[k]).trim().toUpperCase();
  checkPayFields(o, id ? get('SELECT pay_days, email FROM parties WHERE id = ?', id) || {} : {});
  if (o.location_url !== undefined) o.location_url = cleanLocation(o.location_url);
  if (!id) { if (!o.payment_terms) o.payment_terms = '100% ADVANCE'; if (!o.test_report) o.test_report = 'NO'; }
  if (o.auto_email !== undefined) {
    o.auto_email = Number(o.auto_email) ? 1 : 0;
    const cur = id ? get('SELECT auto_email FROM parties WHERE id = ?', id) : null;
    if (o.auto_email && !(cur && cur.auto_email)) o.auto_email_since = new Date().toISOString().slice(0, 19).replace('T', ' ');
  }
  if (!id && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Choose the billing firm for this buyer (Parakh Marketing or Parakh Fertilizer).');
  if (o.firm_code !== undefined && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Billing firm must be Parakh Marketing or Parakh Fertilizer.');
  if (id && o.firm_code !== undefined) {
    const cur = get('SELECT firm_code FROM parties WHERE id = ?', id);
    const used = get('SELECT COUNT(*) AS n FROM invoices WHERE party_id = ? AND legacy = 0', id).n;
    if (cur && cur.firm_code && cur.firm_code !== o.firm_code && used)
      throw new L.UserError('This buyer already has invoices, so its billing firm is fixed.');
  }
  if (o.gstin) {
    o.gstin = String(o.gstin).toUpperCase().trim();
    if (!/^\d{2}[A-Z0-9]{13}$/.test(o.gstin)) throw new L.UserError('GSTIN should be 15 characters, like 08AIVPP2793C1ZQ.');
    o.state_code = o.gstin.slice(0, 2);
    if (!o.pan) o.pan = o.gstin.slice(2, 12);
  } else if (o.state) {
    o.state_code = L.stateCode(o.state) || o.state_code;
  }
  if (o.state) o.state = String(o.state).toUpperCase();
  o.is_b2c = o.gstin ? 0 : (o.is_b2c ?? 1);
}

function emailDraft(inv) {
  const f = inv.firm;
  const it = inv.items.map(i => `${i.item_name}${i.grade ? ' ' + i.grade : ''} — ${i.qty} ${i.unit}${i.bags ? ' (' + i.bags + ' bags)' : ''}`).join('\n');
  const d = inv.date ? inv.date.split('-').reverse().join('.') : '';
  const text = `Dear Sir / Madam,

Please find attached our invoice. Details of the dispatch are below${inv.ewb_no ? ', and the E-Way Bill No. is ' + inv.ewb_no : ''}.

Invoice No.: ${inv.inv_no}   Date: ${d}
${it}
${inv.send_by === 'COURIER' ? `Sent by courier: ${inv.courier || '-'}   Docket No.: ${inv.docket_no || '-'}
` : `Lorry No.: ${inv.lorry_no || '-'}
Transporter: ${inv.transporter || '-'}   L.R. No.: ${inv.lr_no || '-'}
Driver Ph.: ${inv.driver_phone || '-'}
`}${inv.freight_note || inv.freight_mode ? 'Freight: ' + [L.freightRate(inv.freight_note) > 0 ? 'Rs.' + L.freightRate(inv.freight_note) + ' per MT' : inv.freight_note, inv.freight_total ? 'total approx Rs.' + Number(inv.freight_total).toLocaleString('en-IN') : '', inv.freight_mode].filter(Boolean).join(', ') + '\n' : ''}Invoice amount: Rs. ${Number(inv.total).toLocaleString('en-IN')}

Kindly acknowledge receipt.

Regards,
${f.name}
${f.phone || ''}  ${f.email || ''}`;
  const to = inv.party ? splitAddr(inv.party.email) : [];
  const tpl = get(`SELECT name, body, html FROM email_templates WHERE purpose = 'SALE' AND active = 1 ORDER BY is_default DESC, id LIMIT 1`);
  const m = tpl ? fillBoth(tpl, inv) : { text, html: mailer.textToHtml(text) };
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: `Invoice ${inv.inv_no} dt ${d} — ${f.name}`, text: m.text, html: m.html, template_name: tpl ? tpl.name : 'Standard message' };
}

// ---------- email templates ----------
const TEMPLATE_VARS = [
  ['Buyer name', inv => inv.party_name],
  ['Invoice No.', inv => inv.pi_no || inv.inv_no],
  ['Invoice date', inv => inv.date ? inv.date.split('-').reverse().join('.') : ''],
  ['Delivery plant', inv => inv.plant || ''],
  ['Item name', inv => [...new Set(inv.items.map(i => [i.item_name, i.grade].filter(Boolean).join(' ')))].join(', ')],
  ['Item qty', inv => L.mt(inv.items.reduce((s, i) => s + (Number(i.qty) || 0), 0)) + ' MT'],
  ['Lorry no.', inv => inv.lorry_no || ''],
  ['Courier', inv => inv.courier || ''],
  ['Docket no.', inv => inv.docket_no || ''],
  ['Total freight', inv => inv.freight_total ? 'Rs.' + Number(inv.freight_total).toLocaleString('en-IN') : ''],
  ['Freight mode', inv => inv.freight_mode || ''],
  ['Driver number', inv => inv.driver_phone || ''],
  ['Transporter name', inv => inv.transporter || ''],
  ['Transporter phone', inv => { const t = trOf(inv); return t ? [t.mobile, t.phone].filter(Boolean).join(', ') : ''; }],
  ['Transporter bank details', inv => { const t = trOf(inv); return t ? [t.bank_name, t.bank_account, t.bank_ifsc].filter(Boolean).join(' – ') : ''; }],
  ['Seller bank details', inv => [inv.firm.bank_name, inv.firm.bank_account, inv.firm.bank_ifsc].filter(Boolean).join(' – ')],
  ['L.R. no.', inv => inv.lr_no || ''],
  ['E-way bill no.', inv => inv.ewb_no || ''],
  ['Invoice amount', inv => 'Rs.' + Number(inv.total).toLocaleString('en-IN')],
  ['Seller name', inv => inv.firm.name]
];
function trOf(inv) { return inv.transporter ? get('SELECT * FROM transporters WHERE upper(trim(name)) = upper(trim(?))', inv.transporter) : null; }
function fillTemplate(body, inv, html = false) {
  const map = Object.fromEntries(TEMPLATE_VARS.map(([k, fn]) => [k.toLowerCase(), fn]));
  const e = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  return String(body || '').replace(/\{([^{}]+)\}/g, (m, k) => { const fn = map[k.trim().replace(/&nbsp;/g, ' ').toLowerCase()]; return fn ? (html ? e(fn(inv) ?? '') : String(fn(inv) ?? '')) : m; });
}
// the message of a template ready for the email box: formatted (html) and plain (text)
function fillBoth(tpl, inv) { return { text: fillTemplate(tpl.body, inv), html: tpl.html ? fillTemplate(tpl.html, inv, true) : mailer.textToHtml(fillTemplate(tpl.body, inv)) }; }


// Parakh Marketing and Parakh Fertilizer print and email their logo instead of the name
const brandLogo = f => f && ['PM', 'PF'].includes(f.code) && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo || '') ? f.logo : null;
function pdfFolder() { return setting('pdf_folder') || path.join(DATA_DIR, 'pdf'); }
function safeName(s) { return String(s).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80); }

// ---------- routes ----------
const routes = [];
const route = (method, pattern, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

route('GET', '/api/version', () => ({ version: VERSION }));

route('GET', '/api/meta', () => ({
  version: VERSION,
  firms: all('SELECT id, code, name, gstin, state_code, pincode FROM firms ORDER BY id'),
  plants: all('SELECT name, full_name FROM plants ORDER BY name'),
  current_fy: L.fyOf(),
  fys: all(`SELECT fy FROM (SELECT fy FROM invoices UNION SELECT fy FROM inwards) ORDER BY fy DESC`).map(r => r.fy),
  states: Object.keys(L.STATE_CODES),
  host: os.hostname(),
  shared: lock.status().shared,
  rules: L.rules()
}));
// Settings → Universal rules
route('GET', '/api/rules', () => L.rules());
// the one switch for automatic invoice email (Settings → Email templates)
route('GET', '/api/auto-email', () => ({ on: setting('auto_invoice_email', '0') === '1', since: setting('auto_invoice_email_since', null),
  transporter: setting('auto_transporter_email', '0') === '1', transporter_since: setting('auto_transporter_email_since', null) }));
route('PUT', '/api/auto-email/transporter', ({ body }) => {
  const on = Number(body.on) ? '1' : '0';
  if (on === '1' && setting('auto_transporter_email', '0') !== '1') { const d = new Date(); setSetting('auto_transporter_email_since', new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19).replace('T', ' ')); }
  setSetting('auto_transporter_email', on); return { transporter: on === '1' };
});
route('PUT', '/api/auto-email', ({ body }) => {
  const on = Number(body.on) ? '1' : '0';
  if (on === '1' && setting('auto_invoice_email', '0') !== '1') {        // only invoices made from now on are emailed by themselves
    const d = new Date(); setSetting('auto_invoice_email_since', new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19).replace('T', ' '));
  }
  setSetting('auto_invoice_email', on);
  return { on: on === '1', since: setting('auto_invoice_email_since', null) };
});
route('PUT', '/api/rules', ({ body }) => {
  const num = (k, min, max, label) => {
    if (body[k] === undefined) return;
    const n = Number(String(body[k]).replace(/[^0-9]/g, ''));
    if (!(n >= min && n <= max)) throw new L.UserError(`${label} must be between ${min} and ${max}.`);
    setSetting(k === 'ewb_intra' ? 'ewb_limit_intra' : k === 'ewb_inter' ? 'ewb_limit_inter' : k, String(n));
  };
  num('ewb_intra', 0, 10000000, 'E-way bill limit within the state'); num('ewb_inter', 0, 10000000, 'E-way bill limit outside the state');
  num('mobile_digits', 6, 15, 'Mobile number digits');
  return L.rules();
});

route('GET', '/api/dashboard', ({ q }) => {
  const fy = q.fy || L.fyOf();
  const month = new Date().toISOString().slice(0, 7);
  return {
    fy,
    sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total, ROUND(SUM(taxable)) taxable FROM invoices WHERE fy = ? AND cancelled = 0 GROUP BY firm_code`, fy),
    month_sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total FROM invoices WHERE date LIKE ? AND cancelled = 0 GROUP BY firm_code`, month + '%'),
    inward: get(`SELECT COUNT(*) n, ROUND(SUM(actual_wt), 2) actual, ROUND(SUM(rawana_wt), 2) rawana, ROUND(SUM(freight_amt)) freight FROM inwards WHERE fy = ?`, fy),
    unbilled: get(`SELECT COUNT(*) n, ROUND(SUM(rawana_wt), 2) qty FROM inwards WHERE fy = ? AND ppe_invoice_id IS NULL AND supplier LIKE '%ENTERPRISE%'`, fy),
    recent: all(`SELECT id, firm_code, inv_no, date, party_name, total, kind FROM invoices WHERE cancelled = 0 ORDER BY date DESC, id DESC LIMIT 8`),
    last_backup: setting('last_backup'), backup_error: setting('last_backup_error')
  };
});

// masters
route('GET', '/api/m/:table', ({ p, q }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const where = []; const args = [];
  if (q.q) { where.push('(' + SEARCH_COLS[p.table].map(c => `${c} LIKE ?`).join(' OR ') + ')'); SEARCH_COLS[p.table].forEach(() => args.push('%' + q.q + '%')); }
  if (q.firm === 'NONE' && p.table === 'parties') where.push('firm_code IS NULL');
  else if (q.firm && p.table === 'parties') { where.push('firm_code = ?'); args.push(q.firm); }
  const limit = Math.min(Number(q.limit) || 500, 2000);
  const extra = p.table === 'parties' ? ', (SELECT COUNT(*) FROM party_items pi WHERE pi.party_id = parties.id AND pi.active = 1 AND pi.b2c_id IS NULL) AS item_count' : '';
  const rows = all(`SELECT *${extra} FROM ${p.table} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${ORDER[p.table]} LIMIT ${limit}`, ...args);
  if (p.table === 'firms') rows.forEach(r => delete r.smtp_pass);      // never send passwords to the screen
  if (p.table === 'transporters') rows.forEach(r => { r.has_pan_card = r.pan_card ? 1 : 0; r.has_bank_proof = r.bank_proof ? 1 : 0; delete r.pan_card; delete r.bank_proof; delete r.signature; });
  return rows;
});
route('GET', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const r = get(`SELECT * FROM ${p.table} WHERE id = ?`, p.id);
  if (r && p.table === 'firms') delete r.smtp_pass;
  if (r && p.table === 'transporters') { r.has_pan_card = r.pan_card ? 1 : 0; r.has_bank_proof = r.bank_proof ? 1 : 0; delete r.pan_card; delete r.bank_proof; delete r.signature; }
  return r;
});
route('POST', '/api/m/:table', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table) || p.table === 'firms') throw new L.UserError('Cannot add here.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') { checkParty(o); if (o.old_names !== undefined) o.old_names = cleanOldNames(o.old_names); }
  if (p.table === 'lorries') L.lorryUpi(o);
  const keys = Object.keys(o);
  if (!keys.length) throw new L.UserError('Nothing to save.');
  const r = run(`INSERT INTO ${p.table}(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
  if (p.table === 'parties') linkOldInvoices(Number(r.lastInsertRowid));
  return { id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/m/:table/:id', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') checkParty(o, p.id);
  if (p.table === 'lorries') L.lorryUpi(o, get('SELECT * FROM lorries WHERE id = ?', p.id) || {});
  if (p.table === 'firms') {
    delete o.code; delete o.smtp_pass;
    if (o.state) { o.state = String(o.state).toUpperCase(); o.state_code = L.stateCode(o.state, o.gstin) || o.state_code; }
    if (o.gstin) o.gstin = String(o.gstin).toUpperCase().trim();
    if (o.pan) o.pan = String(o.pan).toUpperCase().trim();
    for (const k of ['logo', 'signature', 'bank_proof']) if (o[k] && !/^data:image\/(png|jpeg|webp);base64,/.test(o[k])) throw new L.UserError('The picture must be a PNG or JPG.');
  }
  if (p.table === 'parties' && o.old_names !== undefined) o.old_names = cleanOldNames(o.old_names);
  const keys = Object.keys(o);
  run(`UPDATE ${p.table} SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  if (p.table === 'parties') linkOldInvoices(Number(p.id));
  return { id: Number(p.id) };
});
// old Excel invoices written under another name of the buyer ("VEDANT AGRO TECH") are linked to the buyer
function cleanOldNames(v) {
  const names = [...new Set(String(v || '').split(/[\n;]+/).map(s => s.trim().toUpperCase()).filter(Boolean))];
  return names.length ? names.join('\n') : null;
}
function linkOldInvoices(pid) {
  const b = get('SELECT id, old_names FROM parties WHERE id = ?', pid);
  const names = String((b && b.old_names) || '').split('\n').filter(Boolean);
  let n = 0;
  for (const nm of names) n += Number(run(`UPDATE invoices SET party_id = ? WHERE party_id IS NULL AND kind = 'SALE' AND upper(trim(party_name)) = ?`, pid, nm).changes || 0);
  return n;
}
route('GET', '/api/old-buyer-names', () => all(`SELECT upper(trim(party_name)) name, count(*) n, min(date) first, max(date) last FROM invoices
  WHERE party_id IS NULL AND kind = 'SALE' AND COALESCE(party_name,'') <> '' GROUP BY upper(trim(party_name)) ORDER BY name`));
route('DELETE', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table) || ['firms'].includes(p.table)) throw new L.UserError('Cannot delete here.');
  if (p.table === 'parties' && get('SELECT 1 FROM invoices WHERE party_id = ?', p.id)) {
    run('UPDATE parties SET active = 0 WHERE id = ?', p.id);
    return { hidden: true };
  }
  run(`DELETE FROM ${p.table} WHERE id = ?`, p.id);
  return { deleted: true };
});

// items, rates and packing for one buyer
const PI_COLS = ['plant', 'item_name', 'grade', 'colour', 'mesh', 'form', 'hsn', 'gst_rate', 'rate', 'pack_size', 'bag_type', 'packing_type', 'bag_supply', 'liner', 'notes', 'active', 'commission', 'agent', 'lot_needed'];
function cleanPartyItem(b) {
  const o = {};
  for (const c of PI_COLS) if (b[c] !== undefined) o[c] = b[c] === '' ? null : b[c];
  if (o.item_name !== undefined) { o.item_name = String(o.item_name || '').trim().toUpperCase(); if (!o.item_name) throw new L.UserError('Enter the item name.'); }
  if (o.grade) o.grade = String(o.grade).trim().toUpperCase();
  for (const c of ['bag_type', 'colour', 'mesh', 'form', 'packing_type', 'agent', 'lot_needed']) if (o[c]) o[c] = String(o[c]).trim().toUpperCase();
  for (const c of ['gst_rate', 'rate', 'pack_size', 'commission']) if (o[c] != null) o[c] = Number(o[c]) || (c === 'commission' ? null : 0);
  if (o.liner != null) o.liner = Number(o.liner) ? 1 : 0;
  L.normalize(o);
  if (o.bag_supply && !['OUR', 'BUYER'].includes(o.bag_supply)) o.bag_supply = null;
  return o;
}
// ?b2c=<customer>: that B2C customer's own items (Buyers B2C); &all=1 adds the ONLINE SALE ledger's items (invoice form). Without b2c: the buyer's own items only.
route('GET', '/api/parties/:id/items', ({ p, q }) => {
  const b = Number(q.b2c) || null;
  if (!b) return all('SELECT * FROM party_items WHERE party_id = ? AND active = 1 AND b2c_id IS NULL ORDER BY item_name, grade', p.id);
  return all(`SELECT * FROM party_items WHERE party_id = ? AND active = 1 AND (b2c_id = ? ${q.all ? 'OR b2c_id IS NULL' : ''}) ORDER BY b2c_id IS NULL, item_name, grade`, p.id, b);
});
route('POST', '/api/parties/:id/items', ({ p, body, q }) => {
  if (!get('SELECT 1 FROM parties WHERE id = ?', p.id)) throw new L.UserError('Buyer not found.');
  const o = cleanPartyItem(body), b2c = Number(q.b2c) || null;
  if (b2c && !get('SELECT 1 FROM b2c_customers WHERE id = ?', b2c)) throw new L.UserError('B2C customer not found.');
  if (!o.item_name) throw new L.UserError('Enter the item name.');
  // the same item and grade may be there with other packing; an exact copy is refused
  if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND COALESCE(b2c_id, 0) = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'') AND active = 1
           AND COALESCE(bag_type,'') = COALESCE(?,'') AND COALESCE(pack_size,0) = COALESCE(?,0) AND COALESCE(packing_type,'') = COALESCE(?,'')
           AND COALESCE(bag_supply,'') = COALESCE(?,'') AND COALESCE(liner,-1) = COALESCE(?,-1) AND COALESCE(plant,'') = COALESCE(?,'')`,
      p.id, b2c || 0, o.item_name, o.grade, o.bag_type, o.pack_size, o.packing_type, o.bag_supply, o.liner, o.plant))
    throw new L.UserError('This buyer already has exactly this item, grade and packing. Change something, or use Edit.');
  const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
  if (!o.hsn) o.hsn = m?.hsn || '2512';
  if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
  o.party_id = Number(p.id); if (b2c) o.b2c_id = b2c;
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/party-items/:id', ({ p, body }) => {
  const o = cleanPartyItem(body); const keys = Object.keys(o);
  run(`UPDATE party_items SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/party-items/:id', ({ p }) => { run('DELETE FROM party_items WHERE id = ?', p.id); return { deleted: true }; });

// pick-lists
const LIST_KEYS = ['product', 'colour', 'mesh', 'form', 'bag_type', 'hsn', 'bag_weight', 'packing_type', 'unit', 'gst_rate', 'condition', 'mines', 'freight_mode', 'agent', 'payment_terms', 'group_company', 'raw_material', 'sale_medium'];
route('GET', '/api/lists', () => {
  const out = Object.fromEntries(LIST_KEYS.map(k => [k, []]));
  for (const r of all('SELECT * FROM lists WHERE active = 1 ORDER BY list_key, sort, value')) if (out[r.list_key]) out[r.list_key].push(r);
  return out;
});
function cleanList(b) {
  const o = {};
  if (b.list_key !== undefined) { if (!LIST_KEYS.includes(b.list_key)) throw new L.UserError('Unknown list.'); o.list_key = b.list_key; }
  if (b.value !== undefined) {
    o.value = String(b.value || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (!o.value) throw new L.UserError('Enter a value.');
  }
  if (b.note !== undefined) o.note = String(b.note || '').trim() || null;
  if (b.num !== undefined) o.num = b.num === '' || b.num == null ? null : Number(b.num);
  if (b.sort !== undefined) o.sort = Number(b.sort) || 0;
  if (b.flag !== undefined) o.flag = Number(b.flag) ? 1 : 0;
  return o;
}
route('POST', '/api/lists', ({ body }) => {
  const o = cleanList(body);
  if (!o.list_key || !o.value) throw new L.UserError('Enter a value.');
  if (['hsn', 'bag_weight', 'gst_rate'].includes(o.list_key) && !/^\d+(\.\d+)?$/.test(o.value)) throw new L.UserError('This list takes numbers only.');
  if (o.list_key === 'bag_weight' && o.num == null) o.num = Number(o.value);
  if (o.list_key === 'gst_rate') o.num = Number(o.value);
  if (get('SELECT 1 FROM lists WHERE list_key = ? AND value = ? AND active = 1', o.list_key, o.value)) throw new L.UserError(`"${o.value}" is already in the list.`);
  const old = get('SELECT id FROM lists WHERE list_key = ? AND value = ?', o.list_key, o.value);
  if (old) { run('UPDATE lists SET active = 1, note = ?, num = ?, flag = ? WHERE id = ?', o.note ?? null, o.num ?? null, o.flag || 0, old.id); return { id: old.id }; }
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO lists(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/lists/:id', ({ p, body }) => {
  const o = cleanList(body); delete o.list_key;
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE lists SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/lists/:id', ({ p }) => { run('UPDATE lists SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

// city & state from pincode (offline list of Indian pincodes)
const pincode = require('./pincode');
route('GET', '/api/pincode/:pin', ({ p }) => {
  const r = pincode.lookup(p.pin);
  return r ? { found: true, ...r, state_code: L.stateCode(r.state) } : { found: false };
});

// delivery addresses (godowns) of a buyer
const PA_COLS = ['godown_name', 'address', 'city', 'state', 'pincode', 'contact', 'phone', 'km', 'is_default', 'active', 'location_url'];
// delivery location link (Google Maps link, or "latitude, longitude")
function cleanLocation(v) {
  v = String(v ?? '').trim(); if (!v) return null;
  const ll = v.match(/^(-?\d{1,2}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)$/);
  if (ll) return `https://www.google.com/maps?q=${ll[1]},${ll[2]}`;
  if (!/^https?:\/\/\S+$/i.test(v)) {
    if (/^(maps\.app\.goo\.gl|goo\.gl|www\.google\.|google\.|maps\.google\.)\S*$/i.test(v)) return 'https://' + v;
    throw new L.UserError('Location link: paste the Google Maps link (Share → Copy link), or type "latitude, longitude".');
  }
  if (v.length > 600) throw new L.UserError('The location link is too long — use Share → Copy link in Google Maps (a short maps.app.goo.gl link).');
  return v;
}
// payment reminder fields of a buyer (B2B and B2C): Payment by 1–45 days, Send payment reminder YES / NO
function checkPayFields(o, cur) {
  if (o.pay_reminder) o.pay_reminder = String(o.pay_reminder).trim().toUpperCase();
  if (o.pay_days !== undefined && o.pay_days !== null) { const n = Math.round(Number(o.pay_days)); if (!(n >= 1 && n <= 45)) throw new L.UserError('Payment by: choose 1 to 45 days.'); o.pay_days = n; }
  if (o.pay_reminder === 'YES') {
    if (!(o.pay_days !== undefined ? o.pay_days : cur.pay_days)) throw new L.UserError('Choose "Payment by" (days) to send payment reminders.');
    if (!String(o.email !== undefined ? o.email || '' : cur.email || '').trim()) throw new L.UserError('Enter the email to send payment reminders.');
  }
}
function cleanAddress(b) {
  const o = {};
  for (const c of PA_COLS) if (b[c] !== undefined) o[c] = b[c] === '' ? null : b[c];
  L.normalize(o);
  if (o.godown_name) o.godown_name = String(o.godown_name).trim().toUpperCase();
  if (o.city) o.city = String(o.city).trim().toUpperCase();
  if (o.state) o.state = String(o.state).trim().toUpperCase();
  if (o.pincode && !/^\d{6}$/.test(o.pincode)) throw new L.UserError('Pincode must be 6 digits.');
  if (o.pincode && (!o.state || !o.city)) { const r = pincode.lookup(o.pincode); if (r) { o.city = o.city || r.city; o.state = o.state || r.state; } }
  if (o.state || o.pincode) o.state_code = L.stateCode(o.state) || null;
  if (o.km != null) o.km = Number(o.km) || null;
  if (o.location_url !== undefined) o.location_url = cleanLocation(o.location_url);
  if (o.is_default != null) o.is_default = Number(o.is_default) ? 1 : 0;
  return o;
}
// ?b2c=<customer>: the delivery addresses of that B2C customer (under the ONLINE SALE ledger)
route('GET', '/api/parties/:id/addresses', ({ p, q }) => all(`SELECT * FROM party_addresses WHERE party_id = ? AND active = 1 AND ${Number(q.b2c) ? 'b2c_id = ?' : 'b2c_id IS NULL'} ORDER BY is_default DESC, godown_name`, p.id, ...(Number(q.b2c) ? [Number(q.b2c)] : [])));
route('POST', '/api/parties/:id/addresses', ({ p, body, q }) => {
  if (!get('SELECT 1 FROM parties WHERE id = ?', p.id)) throw new L.UserError('Buyer not found.');
  const o = cleanAddress(body);
  if (!o.address) throw new L.UserError('Enter the delivery address.');
  if (!o.pincode) throw new L.UserError('Enter the pincode of the delivery address.');
  o.party_id = Number(p.id);
  const b2c = Number(q.b2c) || null; if (b2c) o.b2c_id = b2c;
  if (o.is_default) run('UPDATE party_addresses SET is_default = 0 WHERE party_id = ? AND COALESCE(b2c_id, 0) = ?', p.id, b2c || 0);
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO party_addresses(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/party-addresses/:id', ({ p, body }) => {
  const cur = get('SELECT * FROM party_addresses WHERE id = ?', p.id);
  if (!cur) throw new L.UserError('Address not found.');
  const o = cleanAddress(body);
  if (o.is_default) run('UPDATE party_addresses SET is_default = 0 WHERE party_id = ? AND COALESCE(b2c_id, 0) = ?', cur.party_id, cur.b2c_id || 0);
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE party_addresses SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/party-addresses/:id', ({ p }) => { run('UPDATE party_addresses SET active = 0, is_default = 0 WHERE id = ?', p.id); return { deleted: true }; });

// driver phone numbers used before with this lorry, latest first
route('GET', '/api/lorry-phones/:no', ({ p }) => {
  const no = decodeURIComponent(p.no).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const rows = all(`SELECT driver_phone ph, d FROM (
      SELECT driver_phone, date d, id FROM invoices WHERE replace(upper(lorry_no),' ','') = ? AND COALESCE(driver_phone,'') <> ''
      UNION ALL SELECT driver_phone, date d, id FROM inwards WHERE lorry_no = ? AND COALESCE(driver_phone,'') <> ''
      UNION ALL SELECT driver_phone, '0000' d, id FROM lorries WHERE lorry_no = ? AND COALESCE(driver_phone,'') <> '')
    ORDER BY d DESC, id DESC`, no, no, no);
  const seen = []; for (const r of rows) for (const ph of String(r.ph).split(/[,;]\s*/)) if (ph && !seen.includes(ph)) seen.push(ph);
  return seen.slice(0, 10);
});
route('GET', '/api/lorry/:no', ({ p }) => {
  const no = decodeURIComponent(p.no).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const l = get('SELECT * FROM lorries WHERE lorry_no = ?', no);
  const last = get('SELECT supplier, mines, grade, plant, freight_rate, owner_name, pan, driver_name, driver_phone, upi FROM inwards WHERE lorry_no = ? ORDER BY id DESC LIMIT 1', no);
  return { lorry: l, last };
});

// inwards
route('GET', '/api/inwards', ({ q }) => {
  const where = ['w.fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.q) { where.push('(w.lorry_no LIKE ? OR w.voucher_no LIKE ? OR w.rawana_no LIKE ? OR w.supplier LIKE ? OR w.owner_name LIKE ?)'); for (let i = 0; i < 5; i++) args.push('%' + q.q + '%'); }
  if (q.status === 'unbilled') where.push('w.ppe_invoice_id IS NULL');
  if (q.status === 'billed') where.push('w.ppe_invoice_id IS NOT NULL');
  if (q.supplier) { where.push('w.supplier LIKE ?'); args.push('%' + q.supplier + '%'); }
  return all(`SELECT w.*, i.inv_no AS ppe_inv_no FROM inwards w LEFT JOIN invoices i ON i.id = w.ppe_invoice_id
              WHERE ${where.join(' AND ')} ORDER BY w.date DESC, w.id DESC LIMIT 2000`, ...args);
});
route('GET', '/api/inwards/next', ({ q }) => ({ voucher_no: L.nextVoucherNo(q.fy || L.fyOf(q.date), q.firm) }));
route('GET', '/api/inwards/:id', ({ p }) => get('SELECT * FROM inwards WHERE id = ?', p.id));
route('POST', '/api/inwards', ({ body }) => ({ id: L.saveInward(body) }));
route('PUT', '/api/inwards/:id', ({ p, body }) => { checkEditPassword(body.edit_password); return { id: L.saveInward(body, Number(p.id)) }; });
route('DELETE', '/api/inwards/:id', ({ p, q }) => {
  checkEditPassword(q.pw);
  const w = get('SELECT * FROM inwards WHERE id = ?', p.id);
  if (!w) throw new L.UserError('Not found.');
  if (w.ppe_invoice_id) throw new L.UserError('This lorry is billed. Cancel the P.P. Enterprise bill first.');
  run('DELETE FROM inwards WHERE id = ?', p.id);
  return { deleted: true };
});

// invoices
route('GET', '/api/invoices', ({ q }) => {
  const where = ['fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.firm) { where.push('firm_code = ?'); args.push(q.firm); }
  if (q.kind) { where.push('kind = ?'); args.push(q.kind); }
  if (q.q) { where.push('(party_name LIKE ? OR lorry_no LIKE ? OR CAST(inv_no AS TEXT) = ? OR ewb_no LIKE ?)'); args.push('%' + q.q + '%', '%' + q.q + '%', q.q, '%' + q.q + '%'); }
  return all(`SELECT id, firm_code, fy, inv_no, date, kind, party_name, party_gstin, supply_type, lorry_no, ewb_no, taxable, cgst, sgst, igst, total,
              email_sent_at, legacy, cancelled, (SELECT ROUND(SUM(qty), 3) FROM invoice_items WHERE invoice_id = invoices.id) AS qty,
              (SELECT COUNT(*) FROM invoice_items WHERE invoice_id = invoices.id) AS lines
              FROM invoices WHERE ${where.join(' AND ')} ORDER BY date DESC, inv_no DESC LIMIT 3000`, ...args);
});
route('GET', '/api/invoices/next', ({ q }) => ({ inv_no: L.nextInvoiceNo(q.firm, q.fy || L.fyOf(q.date)) }));
route('GET', '/api/invoices/:id', ({ p }) => L.invoiceFull(p.id));
// Parakh Fertilizer sells to a buyer → Parakh Marketing's invoice to Parakh Fertilizer is made by itself:
// PF's own items (as a buyer of PM), bags rounded up so the quantity is never less than PF's dispatch.
function pfBuyer() {
  const pf = get(`SELECT gstin, name FROM firms WHERE code = 'PF'`);
  return get(`SELECT * FROM parties WHERE firm_code = 'PM' AND COALESCE(active, 1) = 1 AND ((? <> '' AND upper(gstin) = upper(?)) OR upper(name) LIKE 'PARAKH FERTILI%') ORDER BY (upper(gstin) = upper(?)) DESC LIMIT 1`,
    (pf && pf.gstin) || '', (pf && pf.gstin) || '', (pf && pf.gstin) || '');
}
function makePmToPf(pfInvId) {
  const src = L.invoiceFull(pfInvId);
  if (!src || src.firm_code !== 'PF' || src.kind !== 'SALE' || src.cancelled) return null;
  const buyer = pfBuyer();
  if (!buyer) return { error: 'Parakh Fertilizer is not in Buyers under Parakh Marketing, so the PM → PF invoice was not made.' };
  const own = all('SELECT * FROM party_items WHERE party_id = ? AND active = 1', buyer.id);
  const K = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const G = s => { const k = K(s); return /^\d+(\+)?MESH$/.test(k) ? 'Y' + k : k; };
  const one = arr => arr.length === 1 ? arr[0] : null;
  const items = [];
  for (const it of src.items) {
    const pi = own.find(x => K(x.item_name) === K(it.item_name) && G(x.grade) === G(it.grade)) || one(own.filter(x => G(x.grade) === G(it.grade))) || one(own.filter(x => K(x.item_name) === K(it.item_name)));
    if (!pi) return { error: `"${it.item_name} ${it.grade || ''}" is not in Parakh Fertilizer's items (Buyers → Parakh Fertilizer), so the PM → PF invoice was not made.` };
    const kg = Number(it.qty) * 1000, pack = Number(pi.pack_size) || 0;
    const bags = pack > 0 ? Math.ceil(Math.round(kg * 1000) / 1000 / pack) : null;          // never less than PF's quantity
    items.push({ party_item_id: pi.id, bags, qty: bags ? Math.round(bags * pack) / 1000 : it.qty, plant: it.plant || src.plant, lot_no: it.lot_no });
  }
  const body = { party_id: buyer.id, date: src.date, lorry_no: src.lorry_no, transporter: src.transporter, lr_no: src.lr_no, driver_phone: src.driver_phone,
    freight_mode: src.freight_mode, freight_note: src.freight_note, notes: `Against Parakh Fertilizer invoice ${src.inv_no}`, items };
  const linked = get('SELECT id FROM invoices WHERE pf_source_id = ? AND COALESCE(cancelled, 0) = 0', src.id);
  const id = L.saveSale(body, linked ? linked.id : undefined, false, { internal: true, pf_source_id: src.id });
  pdfSoon(id);
  return { id };
}
route('GET', '/api/invoices/:id/linked', ({ p }) => { const r = get('SELECT id, inv_no FROM invoices WHERE pf_source_id = ? AND COALESCE(cancelled, 0) = 0', p.id); return r || {}; });
route('POST', '/api/invoices', ({ body }) => {
  const id = L.saveSale(body); backup.backupSoon('invoice'); pdfSoon(id);
  let linked = null; try { linked = makePmToPf(id); } catch (e) { linked = { error: 'PM → PF invoice: ' + e.message }; }
  return { id, linked };   // the TDS declaration and bank proof are never sent on their own: they go with the invoice email
});

// ---------- transporter TDS declarations ----------
const tds = require('./tds');
// pictures of a transporter: PAN card, bank proof, signature
const TR_IMAGES = { 'pan-card': 'pan_card', 'bank-proof': 'bank_proof', signature: 'signature' };
route('GET', '/api/transporters/:id/images', ({ p }) => get('SELECT pan_card, bank_proof, signature FROM transporters WHERE id = ?', p.id) || {});
route('PUT', '/api/transporters/:id/image/:kind', ({ p, body }) => {
  const col = TR_IMAGES[p.kind]; if (!col) throw new L.UserError('Unknown picture.');
  const img = body.image || null;
  if (img && !/^data:image\/(png|jpeg|webp);base64,/.test(img)) throw new L.UserError('The file must be a picture (JPG or PNG).');
  if (img && img.length > 3e6) throw new L.UserError('The picture is too big.');
  run(`UPDATE transporters SET ${col} = ? WHERE id = ?`, img, p.id);
  return { ok: true };
});
route('GET', '/api/transporters/:id/pan-card', ({ p }) => { const r = get('SELECT pan_card FROM transporters WHERE id = ?', p.id); return { image: r ? r.pan_card : null }; });
route('PUT', '/api/transporters/:id/pan-card', ({ p, body }) => {
  const img = body.image || null;
  if (img && !/^data:image\/(png|jpeg|webp);base64,/.test(img)) throw new L.UserError('The PAN card must be a picture (JPG or PNG).');
  if (img && img.length > 3e6) throw new L.UserError('The picture is too big.');
  run('UPDATE transporters SET pan_card = ? WHERE id = ?', img, p.id);
  return { ok: true };
});
route('GET', '/api/tds', ({ q }) => tds.list(q.fy || L.fyOf()));
route('GET', '/api/tds/templates', () => ({ ...tds.templates(), defaults: tds.DEFAULTS }));
route('PUT', '/api/tds/templates', ({ body }) => {
  for (const k of Object.keys(tds.DEFAULTS)) if (body[k] !== undefined) setSetting(k, String(body[k]).trim() || null);
  return tds.templates();
});
function tdsCert(fy, trId, partyId) {
  const c = tds.ensure(fy, Number(trId), Number(partyId));
  if (!c) throw new L.UserError('No invoice in this financial year for this buyer with this transporter.');
  return tds.data(c.id);
}
route('GET', '/api/tds/draft', ({ q }) => {
  const d = tdsCert(q.fy, q.t, q.p);
  const who = q.who === 'buyer' ? 'buyer' : 'transporter';
  return { to: who === 'buyer' ? d.party.email || '' : d.tr.email || '', subject: tds.fill(tds.template('tds_subject_' + who), d),
    text: tds.fill(tds.template('tds_body_' + who), d), problems: tds.problems(d, who), from: d.firm.smtp_user || '', firm: d.firm.name };
});
// the transporter's bank proof as a file to attach (sent to the buyer together with the TDS declaration)
function trBankProofFile(tr) {
  const m = String((tr && tr.bank_proof) || '').match(/^data:image\/(png|jpeg|webp);base64,(.+)$/);
  if (!m) return [];
  const file = path.join(DATA_DIR, 'tmp', safeName(`${tr.name} bank proof`) + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]));
  fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, Buffer.from(m[2], 'base64'));
  return [{ path: file, filename: path.basename(file) }];
}
async function tdsSend(d, who, over = {}) {
  const logIt = (status, error) => { try { run(`INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    d.firm.code, d.firm.name, who === 'buyer' ? d.party.name : d.tr.name, String(over.to || (who === 'buyer' ? d.party.email : d.tr.email) || ''), 'TDS declaration template',
    `${d.tr.name} ${d.c.fy}`, 'TDS declaration to the ' + who, status, error || null, who === 'buyer' && d.tr.bank_proof ? 'TDS declaration, transporter bank proof' : 'TDS declaration'); } catch { /* ignore */ } };
  try { const r = await tdsSendInner(d, who, over); logIt('SENT'); return r; } catch (e) { logIt('FAILED', e.message); throw e; }
}
async function tdsSendInner(d, who, over = {}) {
  const f = d.firm;
  const miss = tds.problems(d, who).filter(x => !(over.to && /email/.test(x)));
  if (miss.length) throw new L.UserError('Missing: ' + miss.join(', ') + '.');
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError(`Email is not set up for ${f.name}. Open Settings → Companies → Email.`);
  const to = splitAddr(over.to || (who === 'buyer' ? d.party.email : d.tr.email)), cc = splitAddr(over.cc || '');
  if (!to.length) throw new L.UserError('Enter the email address.');
  const file = path.join(pdfFolder(), 'TDS', d.c.fy, safeName(`${d.tr.name} to ${d.party.name} TDS ${d.c.fy}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/tds/${d.c.id}?shot=1`, file);
  await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: over.subject || tds.fill(tds.template('tds_subject_' + who), d),
      text: over.text || tds.fill(tds.template('tds_body_' + who), d), html: over.html || null, attachments: [{ path: file, filename: path.basename(file) }, ...(who === 'buyer' ? trBankProofFile(d.tr) : [])] });
  const at = new Date().toLocaleString('en-IN');
  run(`UPDATE tds_certs SET ${who === 'buyer' ? 'sent_buyer_at' : 'sent_transporter_at'} = ?, last_error = NULL WHERE id = ?`, at, d.c.id);
  if (who === 'buyer' && d.tr.bank_proof) run(`INSERT OR IGNORE INTO sent_docs(party_id, transporter_id, kind, at) VALUES(?,?,'BANK_PROOF',?)`, d.party.id, d.tr.id, at);
  return { sent: true, at, pdf: file };
}
route('POST', '/api/tds/send', async ({ body }) => tdsSend(tdsCert(body.fy, body.t, body.p), body.who === 'buyer' ? 'buyer' : 'transporter', body));
// a new invoice: if its transporter has a PAN card, the year's declaration for this buyer goes to the transporter and to the buyer (once)
const tdsBusy = new Set();              // a declaration being sent right now is not sent a second time
async function tdsAuto(invId) {
  let key = null;
  try {
    const inv = get('SELECT id, fy, party_id, transporter, kind, cancelled FROM invoices WHERE id = ?', invId);
    if (!inv || inv.kind !== 'SALE' || inv.cancelled || !inv.party_id) return;
    const tr = tds.findTransporter(inv.transporter);
    if (!tr || !tr.pan_card) return;
    const c = tds.ensure(inv.fy, tr.id, inv.party_id); if (!c) return;
    if (tdsBusy.has(c.id)) return;
    key = c.id; tdsBusy.add(key);
    const errs = [];
    for (const who of ['transporter', 'buyer']) {
      const cur = get('SELECT * FROM tds_certs WHERE id = ?', c.id);
      if (cur[who === 'buyer' ? 'sent_buyer_at' : 'sent_transporter_at']) continue;
      try { await tdsSend(tds.data(c.id), who); console.log(`  TDS declaration ${tr.name} / ${inv.fy} sent to the ${who}.`); }
      catch (e) { errs.push(`${who}: ${e.message}`); }
    }
    if (errs.length) run('UPDATE tds_certs SET last_error = ? WHERE id = ?', errs.join(' | ').slice(0, 500), c.id);
  } catch (e) { console.error('TDS declaration:', e.message); }
  finally { if (key) tdsBusy.delete(key); }
}
// a saved invoice can be changed or cancelled only with the edit password (Settings → Security)
const crypto = require('node:crypto');
const pwHash = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
function checkEditPassword(pw) {
  const h = setting('edit_password_hash'), salt = setting('edit_password_salt');
  if (!h) throw new L.UserError('Set the invoice edit password first: Settings → Security.');
  if (!pw || !crypto.timingSafeEqual(Buffer.from(pwHash(pw, salt), 'hex'), Buffer.from(h, 'hex'))) throw new L.UserError('Wrong edit password.');
}
route('POST', '/api/edit-password/check', ({ body }) => { checkEditPassword(body.password); return { ok: true }; });
route('PUT', '/api/edit-password', ({ body }) => {
  if (setting('edit_password_hash')) {
    try { checkEditPassword(body.old); } catch { throw new L.UserError('The current password is wrong.'); }
  }
  const pw = String(body.password || '');
  if (pw.length < 4) throw new L.UserError('The password must have at least 4 characters.');
  const salt = crypto.randomBytes(16).toString('hex');
  setSetting('edit_password_salt', salt); setSetting('edit_password_hash', pwHash(pw, salt));
  return { ok: true };
});
// ---------- Proforma invoices (PM_2026-27_001) ----------
route('GET', '/api/proformas', ({ q }) => all(`SELECT p.id, p.firm_code, p.fy, p.inv_no, p.date, p.party_name, p.party_city, p.total, p.email_sent_at, p.pdf_file,
    (SELECT ROUND(SUM(qty), 3) FROM proforma_items WHERE invoice_id = p.id) AS qty
  FROM proformas p WHERE (? = '' OR p.fy = ?) AND (? = '' OR p.firm_code = ?) ORDER BY p.date DESC, p.id DESC LIMIT 2000`, q.fy || '', q.fy || '', q.firm || '', q.firm || '')
  .map(r => ({ ...r, pi_no: L.proformaNo(r.firm_code, r.fy, r.inv_no) })));
route('GET', '/api/proformas/next', ({ q }) => { const fy = L.fyOf(q.date); const n = L.nextProformaNo(q.firm, fy); return { inv_no: L.proformaNo(q.firm, fy, n) }; });
route('GET', '/api/proformas/:id', ({ p }) => { const r = L.proformaFull(p.id); if (!r) throw new L.UserError('Proforma invoice not found.'); return r; });
route('POST', '/api/proformas', ({ body }) => {
  const id = L.saveProforma(body);
  // every proforma also goes into the Orders book, to be dispatched within 7 days
  const pf = L.proformaFull(id), d = new Date(); d.setDate(d.getDate() + 7);
  const items = pf.items.map(it => { const pi = get(`SELECT id FROM party_items WHERE party_id = ? AND active = 1 AND upper(item_name) = upper(?) AND upper(COALESCE(grade,'')) = upper(COALESCE(?,''))
      ORDER BY (COALESCE(pack_size,0) = COALESCE(?,0)) DESC, (COALESCE(bag_type,'') = COALESCE(?,'')) DESC LIMIT 1`, pf.party_id, it.item_name, it.grade, it.pack_size, it.bag_type);
    return pi ? { party_item_id: pi.id, qty: it.qty } : null; }).filter(Boolean);
  try { if (items.length) saveOrder({ firm_code: pf.firm_code, party_id: pf.party_id, dispatch_by: d.toISOString().slice(0, 10), notes: 'Proforma ' + pf.pi_no, proforma_id: id, items }); }
  catch (e) { console.error('Order from proforma:', e.message); }
  backup.backupSoon('proforma'); proformaPdfSoon(id);
  return { id };
});
route('PUT', '/api/proformas/:id', ({ p, body }) => { const id = L.saveProforma(body, Number(p.id)); backup.backupSoon('proforma'); proformaPdfSoon(id); return { id }; });
route('DELETE', '/api/proformas/:id', ({ p, body }) => {
  checkEditPassword(body && body.edit_password);
  run('DELETE FROM proforma_items WHERE invoice_id = ?', p.id); run('DELETE FROM proformas WHERE id = ?', p.id); return { deleted: true };
});
async function makeProformaPdf(id) {
  const inv = L.proformaFull(id); if (!inv) throw new L.UserError('Proforma invoice not found.');
  const clean = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
  const file = path.join(pdfFolder(), inv.fy, 'Proforma', clean(`${inv.pi_no}_${inv.party_name}_${inv.firm.name}_ProformaInvoice`).slice(0, 180) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/proforma/${inv.id}?shot=1`, file);
  if (inv.pdf_file && inv.pdf_file !== file) { try { fs.unlinkSync(inv.pdf_file); } catch { /* old name */ } }
  run('UPDATE proformas SET pdf_file = ? WHERE id = ?', file, id);
  return file;
}
function proformaPdfSoon(id) { setTimeout(() => makeProformaPdf(id).catch(e => console.error('Proforma PDF:', e.message)), 800); }
// email: proforma PDF, our bank proof, the transporter's bank proof
function firmBankProofFile(f) {
  const m = String((f && f.bank_proof) || '').match(/^data:image\/(png|jpeg|webp);base64,(.+)$/);
  if (!m) return [];
  const file = path.join(DATA_DIR, 'tmp', safeName(`${f.name} bank details`) + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]));
  fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, Buffer.from(m[2], 'base64'));
  return [{ path: file, filename: path.basename(file) }];
}
route('GET', '/api/proformas/:id/email', ({ p }) => {
  const inv = L.proformaFull(p.id); if (!inv) throw new L.UserError('Proforma invoice not found.');
  const f = inv.firm, tr = trOf(inv), to = inv.party ? splitAddr(inv.party.email) : [];
  const tpl = get(`SELECT name, body, html FROM email_templates WHERE purpose = 'PROFORMA' AND active = 1 ORDER BY is_default DESC, id LIMIT 1`);
  const d = inv.date ? inv.date.split('-').reverse().join('.') : '';
  const bankSent = tr && inv.party_id ? get(`SELECT 1 FROM sent_docs WHERE party_id = ? AND transporter_id = ? AND kind = 'BANK_PROOF'`, inv.party_id, tr.id) : null;
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: `Proforma invoice ${inv.pi_no} dt ${d} — ${f.name}`,
    text: tpl ? fillTemplate(tpl.body, inv) : `Dear Sir / Madam,\n\nPlease find attached our proforma invoice ${inv.pi_no} dated ${d} for Rs.${Number(inv.total).toLocaleString('en-IN')}.\nKindly arrange the payment so that we can dispatch the goods.\n\nRegards,\n${f.name}`,
    html: tpl && tpl.html ? fillTemplate(tpl.html, inv, true) : null,
    template_name: tpl ? tpl.name : 'Standard message', templates: all(`SELECT id, name, is_default FROM email_templates WHERE purpose = 'PROFORMA' AND active = 1 ORDER BY is_default DESC, name`),
    from: f.smtp_user || f.email, ready: !!(f.smtp_user && f.smtp_pass),
    options: { seller_bank: !!f.bank_proof, tr_bank: !!(tr && tr.bank_proof), tr_bank_sent: !!bankSent, transporter: inv.transporter || '' } };
});
route('GET', '/api/proformas/:id/template/:tid', ({ p }) => {
  const inv = L.proformaFull(p.id), tp = get('SELECT body, html FROM email_templates WHERE id = ?', p.tid);
  if (!inv || !tp) throw new L.UserError('Not found.');
  return fillBoth(tp, inv);
});
route('POST', '/api/proformas/:id/email', async ({ p, body }) => {
  const inv = L.proformaFull(p.id); if (!inv) throw new L.UserError('Proforma invoice not found.');
  const f = inv.firm, tr = trOf(inv), a = body.attach || { proforma: 1, seller_bank: 1 };
  const log = (status, error, att) => run(`INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    inv.firm_code, f.name, inv.party_name, String(body.to || ''), body.template_name || 'Standard message', inv.pi_no, 'Proforma invoice', status, error || null, att || null);
  try {
    if (!f.smtp_user || !f.smtp_pass) throw new L.UserError(`Email is not set up for ${f.name}. Open Settings → Email.`);
    const to = splitAddr(body.to), cc = splitAddr(body.cc);
    if (!to.length) throw new L.UserError('Enter the buyer email address.');
    const attachments = [], done = [];
    if (a.proforma) { const file = await makeProformaPdf(inv.id); attachments.push({ path: file, filename: path.basename(file) }); done.push('Proforma invoice'); }
    if (a.seller_bank) { const x = firmBankProofFile(f); attachments.push(...x); if (x.length) done.push('Our bank proof'); }
    if (a.tr_bank && tr) { const x = trBankProofFile(tr); attachments.push(...x); if (x.length) done.push('Transporter bank proof'); }
    if (!attachments.length) throw new L.UserError('Tick at least one thing to attach.');
    await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
      { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || 'Proforma invoice', text: body.text || '', html: body.html || null, attachments });
    const at = new Date().toLocaleString('en-IN');
    run('UPDATE proformas SET email_sent_at = ? WHERE id = ?', at, inv.id);
    if (a.tr_bank && tr && inv.party_id) run(`INSERT OR IGNORE INTO sent_docs(party_id, transporter_id, kind, at) VALUES(?,?,'BANK_PROOF',?)`, inv.party_id, tr.id, at);
    log('SENT', null, done.join(', '));
    return { sent: true, at };
  } catch (e) { log('FAILED', e.message); throw e; }
});

// ---------- Reports → Payment reminder: PM and PF invoices, Due / Received, reminder email ----------
const REMINDER_VARS = ['Buyer name', 'Seller name', 'Invoice table', 'Total due', 'Invoice count', 'Seller bank details', 'Today'];
const inr = n => 'Rs.' + Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dmyOf = d => d ? d.split('-').reverse().join('.') : '';
function paymentRows(fy, ids) {
  const where = [`i.firm_code IN ('PM', 'PF')`, `COALESCE(i.cancelled, 0) = 0`, `COALESCE(i.kind, 'SALE') = 'SALE'`, `i.pf_source_id IS NULL`], args = [];
  if (fy) { where.push('i.fy = ?'); args.push(fy); }
  if (ids) { where.push(`i.id IN (${ids.map(() => '?').join(',') || 'NULL'})`); args.push(...ids); }
  return all(`SELECT i.id, i.firm_code, i.fy, i.inv_no, i.date, i.party_id, i.party_name, i.total, COALESCE(i.paid, 0) AS paid, i.paid_at, i.reminder_at, i.reminder_on, i.b2c_id, i.b2c_name,
      (SELECT ROUND(SUM(qty), 3) FROM invoice_items WHERE invoice_id = i.id) AS qty
    FROM invoices i WHERE ${where.join(' AND ')} ORDER BY i.date, i.firm_code, i.inv_no`, ...args)
    .map(r => ({ ...r, buyer_key: r.party_id ? 'p' + r.party_id : 'n' + String(r.party_name || '').trim().toUpperCase() }));
}
// The invoice list as a text table (lines up in a fixed-width font) and as an HTML table for the email.
// payDays (buyer master "Payment by"): adds the due date and the days overdue
function reminderTable(rows, payDays) {
  const pd = Number(payDays) || 0;
  const head = ['Sl', 'Inv. date', 'Invoice no.', 'Qty (MT)', 'Amount (Rs.)', ...(pd ? ['Due on', 'Days overdue'] : ['Days'])];
  const loc = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10), today = new Date(loc);
  const due = r => { const d = new Date(r.date); d.setUTCDate(d.getUTCDate() + pd); return d; };
  const body = rows.map((r, i) => [String(i + 1), dmyOf(r.date), String(r.inv_no), r.qty == null ? '' : L.mt(r.qty),
    Number(r.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
    ...(pd ? [r.date ? dmyOf(due(r).toISOString().slice(0, 10)) : '', r.date ? String(Math.max(0, Math.round((today - due(r)) / 864e5))) : '']
      : [r.date ? String(Math.max(0, Math.round((today - new Date(r.date)) / 864e5))) : ''])]);
  const total = rows.reduce((s, r) => s + (Number(r.total) || 0), 0);
  const foot = ['', '', 'Total', L.mt(rows.reduce((s, r) => s + (Number(r.qty) || 0), 0)), Number(total).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), ...(pd ? ['', ''] : [''])];
  const w = head.map((h, c) => Math.max(h.length, ...body.map(b => b[c].length), foot[c].length));
  const right = [true, false, false, true, true, ...(pd ? [false, true] : [true])];
  const line = cells => cells.map((x, c) => right[c] ? x.padStart(w[c]) : x.padEnd(w[c])).join(' | ').replace(/\s+$/, '');
  const rule = w.map(n => '-'.repeat(n)).join('-+-');
  const text = [line(head), rule, ...body.map(line), rule, line(foot)].join('\n');
  const e = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const td = (x, c, tag = 'td') => `<${tag} style="border:1px solid #c9d3d6;padding:5px 9px;white-space:nowrap;${right[c] ? 'text-align:right;' : 'text-align:left;'}">${e(x)}</${tag}>`;
  const html = `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;margin:0 0 14px"><thead><tr style="background:#eef3f4">${head.map((h, c) => td(h, c, 'th')).join('')}</tr></thead><tbody>`
    + body.map(b => `<tr>${b.map((x, c) => td(x, c)).join('')}</tr>`).join('')
    + `<tr style="font-weight:bold;background:#f7f7f7">${foot.map((x, c) => td(x, c)).join('')}</tr></tbody></table>`;
  return { text, html, total };
}
function reminderFill(body, d, html = false) {
  const e = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  if (html) return String(body || '').replace(/<p[^>]*>\s*\{\s*invoice table\s*\}\s*<\/p>/gi, () => d.table.html).replace(/\{([^{}]+)\}/g, (m, k) => { k = k.trim().replace(/&nbsp;/g, ' ').toLowerCase();
    if (k === 'invoice table') return d.table.html; const v = reminderFill('{' + k + '}', d); return v === '{' + k + '}' ? m : e(v); });
  const map = { 'buyer name': d.buyer, 'seller name': d.firm.name, 'invoice table': d.table.text, 'total due': inr(d.table.total), 'invoice count': String(d.rows.length),
    'seller bank details': [d.firm.bank_name, d.firm.bank_account, d.firm.bank_ifsc].filter(Boolean).join(' – '), 'today': dmyOf(new Date().toISOString().slice(0, 10)) };
  return String(body || '').replace(/\{([^{}]+)\}/g, (m, k) => { const v = map[k.trim().toLowerCase()]; return v != null ? v : m; })
    .replace(/ ?Our bank details: *\n/, '\n');      // firm without bank details
}
const REMINDER_STD = 'Dear Sir / Madam,\n\nThis is a gentle reminder that the payment for the following invoice(s) is still due:\n\n{Invoice table}\n\nTotal due: {Total due}\n\nKindly arrange the payment at the earliest. Our bank details: {Seller bank details}\nIf you have already paid, please share the payment details and ignore this reminder.\n\nRegards,\n{Seller name}';
// the buyer of an invoice for reminders: the B2C customer (ONLINE SALE invoices) or the B2B buyer
function reminderBuyer(r) {
  if (r.b2c_id) return get('SELECT * FROM b2c_customers WHERE id = ?', r.b2c_id);
  return r.party_id ? get('SELECT * FROM parties WHERE id = ?', r.party_id) : null;
}
function reminderDraft(ids, tid) {
  const rows = paymentRows(null, ids.map(Number));
  if (!rows.length) throw new L.UserError('Select the invoices to remind about.');
  if (new Set(rows.map(r => r.buyer_key + '|' + (r.b2c_id || ''))).size > 1) throw new L.UserError('Select invoices of one buyer.');
  const tpl = tid ? get(`SELECT name, body, html FROM email_templates WHERE id = ?`, tid)
    : get(`SELECT name, body, html FROM email_templates WHERE purpose = 'REMINDER' AND active = 1 ORDER BY is_default DESC, id LIMIT 1`);
  const party = reminderBuyer(rows[0]), buyerName = rows[0].b2c_id ? rows[0].b2c_name || (party || {}).name || rows[0].party_name : rows[0].party_name;
  const to = party ? splitAddr(party.email) : [];
  // one email per seller (a buyer is normally billed by one firm)
  const mails = [...new Set(rows.map(r => r.firm_code))].map(code => {
    const firm = get('SELECT * FROM firms WHERE code = ?', code), list = rows.filter(r => r.firm_code === code), table = reminderTable(list, party && party.pay_days);
    const d = { buyer: buyerName, firm, rows: list, table };
    return { firm_code: code, firm: firm.name, from: firm.smtp_user || firm.email || '', ready: !!(firm.smtp_user && firm.smtp_pass), ids: list.map(r => r.id),
      subject: `Payment reminder — ${list.length} invoice${list.length > 1 ? 's' : ''}, ${inr(table.total)} due — ${firm.name}`,
      text: reminderFill(tpl ? tpl.body : REMINDER_STD, d), table: table.text,
      html: reminderFill(tpl && tpl.html ? tpl.html : mailer.textToHtml(tpl ? tpl.body : REMINDER_STD), d, true) };
  });
  return { buyer: buyerName, to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), template_name: tpl ? tpl.name : 'Standard message',
    templates: all(`SELECT id, name, is_default FROM email_templates WHERE purpose = 'REMINDER' AND active = 1 ORDER BY is_default DESC, name`), mails };
}
route('GET', '/api/payments', ({ q }) => {
  const rows = paymentRows(q.fy || L.fyOf());
  return { rows, fys: all(`SELECT DISTINCT fy FROM invoices WHERE firm_code IN ('PM', 'PF') ORDER BY fy DESC`).map(r => r.fy) };
});
route('PUT', '/api/invoices/:id/paid', ({ p, body }) => {
  const paid = Number(body.paid) ? 1 : 0;
  run('UPDATE invoices SET paid = ?, paid_at = ? WHERE id = ?', paid, paid ? new Date().toISOString().slice(0, 10) : null, p.id);
  backup.backupSoon('payment');
  return get('SELECT id, paid, paid_at FROM invoices WHERE id = ?', p.id);
});
route('POST', '/api/payment-reminder/draft', ({ body }) => reminderDraft(body.ids || [], body.template_id));
route('POST', '/api/payment-reminder', ({ body }) => sendReminder(body, false));
// one payment reminder email (by hand, or automatic). Attachments: our bank proof and the invoice copies (attach.bank / attach.invoice).
async function sendReminder(body, auto) {
  const rows = paymentRows(null, (body.ids || []).map(Number));
  if (!rows.length) throw new L.UserError('Select the invoices to remind about.');
  const firm = get('SELECT * FROM firms WHERE code = ?', rows[0].firm_code);
  if (rows.some(r => r.firm_code !== firm.code)) throw new L.UserError('One reminder is sent for one seller at a time.');
  const docs = rows.map(r => r.inv_no).join(', ');
  const log = (status, error) => run(`INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    firm.code, firm.name, rows[0].b2c_name || rows[0].party_name, String(body.to || ''), body.template_name || 'Standard message', docs, auto ? 'Payment reminder (automatic)' : 'Payment reminder', status, error || null, done.join(', ') || null);
  const att = body.attach || {}, attachments = [], done = [];
  try {
    if (!firm.smtp_user || !firm.smtp_pass) throw new L.UserError(`Email is not set up for ${firm.name}. Open Settings → Companies → Email.`);
    const to = splitAddr(body.to), cc = splitAddr(body.cc);
    if (!to.length) throw new L.UserError('Enter the buyer email address.');
    const text = String(body.text || ''), table = reminderTable(rows, (reminderBuyer(rows[0]) || {}).pay_days), given = body.html ? String(body.html) : null;
    // HTML copy: the text as it is, with the invoice table shown as a real table where it sits in the message
    const e = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const para = s => `<div style="font-family:Arial,sans-serif;font-size:14px;white-space:pre-wrap">${e(s)}</div>`;
    const at = text.indexOf(table.text);
    const html = given || (at >= 0 ? para(text.slice(0, at)) + table.html + para(text.slice(at + table.text.length)) : para(text));
    if (att.bank) { const x = firmBankProofFile(firm); attachments.push(...x); if (x.length) done.push('Our bank proof'); }
    if (att.invoice) for (const r of rows) {          // only the invoice PDFs already saved; the table still lists every due invoice
      const fp = savedInvoicePdf(r.id); if (fp) { attachments.push({ path: fp, filename: path.basename(fp) }); done.push('Invoice ' + r.inv_no); }
    }
    await smtpSend({ host: firm.smtp_host || 'smtp.gmail.com', port: firm.smtp_port || 465, user: firm.smtp_user, pass: firm.smtp_pass },
      { from: firm.smtp_user, fromName: firm.name, logo: brandLogo(firm), to, cc, subject: body.subject || 'Payment reminder', text, html, attachments });
    const now = new Date().toLocaleString('en-IN'), today = todayIso();
    rows.forEach(r => run('UPDATE invoices SET reminder_at = ?, reminder_on = ? WHERE id = ?', now, today, r.id));
    log('SENT');
    return { sent: true, at: now, attached: done };
  } catch (err) { log('FAILED', err.message); throw err; }
}

// the invoice PDF already saved for this invoice (invoice folder), or null
function savedInvoicePdf(id) {
  const inv = L.invoiceFull(id); if (!inv) return null;
  for (const f of [inv.pdf_file, path.join(pdfFolder(), inv.fy || '', invoicePdfName(inv))]) if (f && fs.existsSync(f)) return f;
  return null;
}
// ---------- Automatic payment reminder (switch inside the Payment reminder template, off to start with) ----------
// Buyer master: "Payment by" (1–45 days from the invoice date) and "Send payment reminder" YES / NO.
// When an unpaid invoice passes its payment date, one email goes to the buyer with all its overdue unpaid invoices
// (date, number, qty, amount), our bank proof and the invoice copies. While still unpaid it is sent again every 5 days.
// Only invoices dated on or after the "from" date of the switch; marking the invoice received (Reports → Payment reminder) stops it.
const REMIND_EVERY = 5;
const todayIso = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 10); };
const addDaysIso = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
function reminderPlan() {
  const today = todayIso(), since = setting('auto_reminder_since', '9999-12-31');
  const yes = t => new Map(all(`SELECT id, name, email, pay_days, pay_reminder FROM ${t} WHERE upper(COALESCE(pay_reminder, 'NO')) = 'YES' AND COALESCE(pay_days, 0) > 0`).map(p => [p.id, p]));
  const parties = yes('parties'), b2c = yes('b2c_customers');
  const groups = new Map();
  for (const r of paymentRows(null)) {
    const p = r.b2c_id ? b2c.get(r.b2c_id) : parties.get(r.party_id); if (!p || r.paid || !r.date || r.date < since) continue;
    const dueOn = addDaysIso(r.date, Number(p.pay_days)); if (dueOn > today) continue;
    const key = (r.b2c_id ? 'c' + r.b2c_id : 'p' + r.party_id) + '|' + r.firm_code;
    const g = groups.get(key) || { party: p, firm_code: r.firm_code, rows: [], send: false, next: null };
    const last = r.reminder_on || null, nextOn = last ? addDaysIso(last, REMIND_EVERY) : dueOn;
    g.rows.push({ ...r, due_on: dueOn, last_reminder: last });
    if (nextOn <= today) g.send = true; else if (!g.next || nextOn < g.next) g.next = nextOn;
    groups.set(key, g);
  }
  return [...groups.values()];
}
const remindTried = new Map();          // a failed reminder is tried again after an hour
let remindBusy = false;
async function autoReminder() {
  if (setting('auto_reminder_email', '0') !== '1' || remindBusy) return;
  remindBusy = true;
  try {
    for (const g of reminderPlan().filter(x => x.send)) {
      const key = (g.rows[0].b2c_id ? 'c' : 'p') + g.party.id + '|' + g.firm_code;
      if (Date.now() - (remindTried.get(key) || 0) < 3600e3) continue;
      remindTried.set(key, Date.now());
      if (!splitAddr(g.party.email).length) continue;
      try {
        const d = reminderDraft(g.rows.map(r => r.id)), m = d.mails[0];
        await sendReminder({ ids: m.ids, to: d.to, cc: d.cc, subject: m.subject, text: m.text, html: m.html, template_name: d.template_name, attach: { bank: 1, invoice: 1 } }, true);
        remindTried.delete(key);
        console.log(`  Payment reminder to ${g.party.name} (${g.firm_code}, ${m.ids.length} invoice${m.ids.length > 1 ? 's' : ''}) sent (automatic).`);
      } catch (e) { console.error(`  Payment reminder to ${g.party.name}: ${e.message}`); }
    }
  } finally { remindBusy = false; }
}
route('GET', '/api/auto-email/reminder', () => {
  const on = setting('auto_reminder_email', '0') === '1', plan = on ? reminderPlan() : [];
  return { on, since: setting('auto_reminder_since', null), every: REMIND_EVERY,
    buyers: ['parties', 'b2c_customers'].reduce((n, t) => n + all(`SELECT COUNT(*) n FROM ${t} WHERE upper(COALESCE(pay_reminder, 'NO')) = 'YES' AND COALESCE(pay_days, 0) > 0`)[0].n, 0),
    plan: plan.map(g => ({ buyer: g.party.name, firm: g.firm_code, email: g.party.email || '', invoices: g.rows.map(r => r.inv_no).join(', '), total: g.rows.reduce((s, r) => s + (Number(r.total) || 0), 0),
      next: g.send ? 'now' : g.next })) };
});
route('PUT', '/api/auto-email/reminder', ({ body }) => {
  const on = Number(body.on) ? '1' : '0';
  if (body.since !== undefined) { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(body.since))) throw new L.UserError('Choose the date from which invoices are reminded.'); setSetting('auto_reminder_since', String(body.since)); }
  else if (on === '1' && setting('auto_reminder_email', '0') !== '1') setSetting('auto_reminder_since', todayIso());
  setSetting('auto_reminder_email', on);
  return { on: on === '1', since: setting('auto_reminder_since', null) };
});

// ---------- Local freight letter: tempo to the transporter's godown, for invoices under 200 bags ----------
const bagsOf = inv => inv.items.reduce((s, i) => s + (Number(i.bags) || 0), 0);
route('GET', '/api/invoices/:id/local-freight', ({ p }) => {
  const inv = L.invoiceFull(p.id); if (!inv) throw new L.UserError('Invoice not found.');
  return { bags: bagsOf(inv), last: get('SELECT * FROM local_freight WHERE invoice_id = ? ORDER BY id DESC LIMIT 1', inv.id) || null,
    drivers: all('SELECT * FROM local_drivers ORDER BY name'), from_place: setting('lf_from_place') || 'Mandore Industrial Area', signer: setting('lf_signer') || 'Abhijeet Parakh',
    transporter: inv.transporter || '' };
});
route('POST', '/api/invoices/:id/local-freight', ({ p, body }) => {
  const inv = L.invoiceFull(p.id); if (!inv) throw new L.UserError('Invoice not found.');
  if (bagsOf(inv) >= 200) throw new L.UserError('The local freight letter is for invoices under 200 bags.');
  if (!inv.transporter) throw new L.UserError('Put the transporter on the invoice first.');
  const o = { driver: String(body.driver || '').trim().toUpperCase(), tempo_no: String(body.tempo_no || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), mobile: String(body.mobile || '').replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''),
    amount: Number(body.amount), from_place: String(body.from_place || '').trim() || 'Mandore Industrial Area', signer: String(body.signer || '').trim() };
  if (!o.driver) throw new L.UserError('Enter the driver name.');
  if (!o.tempo_no) throw new L.UserError('Enter the tempo number.');
  const n = L.rules().mobile_digits; if (o.mobile && n && o.mobile.length !== n) throw new L.UserError(`The mobile number must have ${n} digits.`);
  if (!(o.amount > 0)) throw new L.UserError('Enter the amount.');
  // a new driver / tempo goes into Item lists → Local freight
  const ex = get('SELECT * FROM local_drivers WHERE upper(trim(name)) = ? AND COALESCE(tempo_no, \'\') = ?', o.driver, o.tempo_no);
  if (ex) { if (o.mobile && o.mobile !== ex.mobile) run('UPDATE local_drivers SET mobile = ? WHERE id = ?', o.mobile, ex.id); }
  else run('INSERT INTO local_drivers(name, tempo_no, mobile) VALUES(?,?,?)', o.driver, o.tempo_no, o.mobile || null);
  setSetting('lf_from_place', o.from_place); if (o.signer) setSetting('lf_signer', o.signer);
  const id = Number(run('INSERT INTO local_freight(invoice_id, driver, tempo_no, mobile, amount, from_place, signer) VALUES(?,?,?,?,?,?,?)', inv.id, o.driver, o.tempo_no, o.mobile || null, o.amount, o.from_place, o.signer || null).lastInsertRowid);
  backup.backupSoon('local freight');
  return { id };
});

// ---------- Buyers B2C: customers of the ledger ONLINE SALE, kept apart from the B2B buyers ----------
route('GET', '/api/b2c', ({ q }) => all(`SELECT c.*, (SELECT COUNT(*) FROM invoices i WHERE i.b2c_id = c.id AND COALESCE(i.cancelled, 0) = 0) AS invoices,
    (SELECT ROUND(SUM(total), 2) FROM invoices i WHERE i.b2c_id = c.id AND COALESCE(i.cancelled, 0) = 0) AS amount,
    (SELECT MAX(date) FROM invoices i WHERE i.b2c_id = c.id AND COALESCE(i.cancelled, 0) = 0) AS last_date
  FROM b2c_customers c WHERE c.active = 1 ${q.q ? 'AND (c.name LIKE ? OR c.mobile LIKE ? OR c.city LIKE ?)' : ''} ORDER BY c.name`, ...(q.q ? ['%' + q.q + '%', '%' + q.q + '%', '%' + q.q + '%'] : [])));
route('GET', '/api/b2c/:id/invoices', ({ p }) => all(`SELECT id, fy, inv_no, date, sale_medium, total, cancelled, (SELECT ROUND(SUM(qty), 3) FROM invoice_items WHERE invoice_id = invoices.id) AS qty
  FROM invoices WHERE b2c_id = ? ORDER BY date DESC, id DESC`, p.id));
function cleanB2c(b, id) {
  const o = {};
  for (const k of ['name', 'mobile', 'email', 'address', 'city', 'state', 'pincode', 'notes', 'location_url', 'pay_days', 'pay_reminder', 'print_loc']) if (b[k] !== undefined) o[k] = String(b[k] ?? '').trim() || null;
  if (o.location_url !== undefined) o.location_url = cleanLocation(o.location_url);
  if (o.print_loc) o.print_loc = o.print_loc.toUpperCase() === 'NO' ? 'NO' : 'YES';
  checkPayFields(o, id ? get('SELECT pay_days, email FROM b2c_customers WHERE id = ?', id) || {} : {});
  for (const k of ['name', 'city', 'state']) if (o[k]) o[k] = o[k].toUpperCase();
  if (o.mobile) { o.mobile = o.mobile.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''); const n = L.rules().mobile_digits; if (n && o.mobile.length !== n) throw new L.UserError(`The mobile number must have ${n} digits.`); }
  if (o.pincode && !/^\d{6}$/.test(o.pincode)) throw new L.UserError('The pincode must have 6 digits.');
  if (o.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(o.email)) throw new L.UserError('The email address is not right.');
  return o;
}
route('POST', '/api/b2c', ({ body }) => {
  const o = cleanB2c(body);
  if (!o.name) throw new L.UserError('Enter the customer name.');
  if (!o.state) throw new L.UserError('Enter the state (GST depends on it).');
  if (o.mobile && get('SELECT 1 FROM b2c_customers WHERE mobile = ? AND active = 1', o.mobile)) throw new L.UserError(`A customer with mobile ${o.mobile} is already in Buyers B2C.`);
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO b2c_customers(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/b2c/:id', ({ p, body }) => {
  const o = cleanB2c(body, p.id);
  if (o.name === null) throw new L.UserError('Enter the customer name.');
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE b2c_customers SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
// the ONLINE SALE ledger (Buyers B2B) that B2C invoices, items and delivery addresses hang under
route('GET', '/api/b2c-ledger', () => get(`SELECT id, name, pincode, firm_code FROM parties WHERE COALESCE(is_online, 0) = 1 AND COALESCE(active, 1) = 1 ORDER BY id LIMIT 1`) || {});
route('DELETE', '/api/b2c/:id', ({ p }) => { run('UPDATE b2c_customers SET active = 0 WHERE id = ?', p.id); return { hidden: true }; });

// ---------- GSTIN → name and address from the GST portal (captcha typed by the user) ----------
route('GET', '/api/gst-captcha', async ({ q }) => { try { return await require('./gstlookup').captcha(q.id); } catch (e) { throw new L.UserError(e.message); } });
route('POST', '/api/gst-lookup', async ({ body }) => {
  try { return await require('./gstlookup').lookup(body.id, body.gstin, body.captcha); }
  catch (e) { const err = new L.UserError(e.message); if (e.captcha) err.message += ''; throw err; }
});

// ---------- Rawana QR: the scanner types the link on the rawana; the page is read for rawana no., lorry, net weight, driver ----------
route('GET', '/api/rawana', async ({ q }) => {
  const R = require('./rawana');
  if (!R.parseCode(q.code)) throw new L.UserError('Scan the QR code on the rawana (or type the rawana no.).');
  const { r, html } = await R.lookup(q.code).catch(e => { throw new L.UserError(e.message); });
  try { fs.writeFileSync(path.join(DATA_DIR, 'rawana-last.html'), html); } catch {}       // kept to check the reading if the page changes
  r.used = { inward: get('SELECT voucher_no FROM inwards WHERE rawana_no = ?', r.rawana_no)?.voucher_no || null, stock: get('SELECT st_no FROM stock_in WHERE rawana_no = ?', r.rawana_no)?.st_no || null };
  if (r.driver_phone) { const n = L.rules().mobile_digits; if (n && r.driver_phone.length !== n) delete r.driver_phone; }
  // supplier: by GSTIN, else by the lessee name
  const up = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const sups = all('SELECT * FROM suppliers');
  const s = (r.gstin && sups.find(x => up(x.gstin) === up(r.gstin))) || (r.lessee && sups.find(x => [x.lessee_name, x.name].some(n => n && up(n) === up(r.lessee))));
  if (s) { r.supplier = s.name; if (s.item) r.item = s.item; }
  // raw material from the mineral name (Siliceous Earth is Diatomaceous Earth)
  if (r.mineral) {
    const SAME = [['SILICEOUS EARTH', 'DIATOMACEOUS EARTH'], ['KIESELGUHR', 'DIATOMACEOUS EARTH'], ['SELENITE', 'GYPSUM']];
    const raws = all(`SELECT value FROM lists WHERE list_key = 'raw_material' AND active = 1`).map(x => x.value);
    let m = r.mineral; for (const [a, b] of SAME) if (m.includes(a)) m = b;
    const hit = raws.find(v => up(v) === up(m)) || raws.find(v => up(v).startsWith(up(m))) || raws.find(v => up(m).includes(up(v.replace(/\(.*\)/, ''))));
    if (hit) r.item = hit;
  }
  return r;
});

// ---------- Stock IN: everything received — P.P. Enterprise and Parakh Marketing inward vouchers + Parakh Marketing stock-in entries ----------
function stockRows(q) {
  const w = [], a = [];
  if (q.fy) { w.push('fy = ?'); a.push(q.fy); }
  if (q.month) { w.push('substr(date, 6, 2) = ?'); a.push(String(q.month).padStart(2, '0')); }
  if (q.supplier) { w.push('upper(trim(supplier)) = upper(trim(?))'); a.push(q.supplier); }
  if (q.item) { w.push('item = ?'); a.push(q.item); }
  return all(`SELECT * FROM (
      SELECT 'inward' AS src_table, i.id, i.fy, i.voucher_no AS no, i.date, i.supplier, COALESCE(NULLIF(i.item, ''),
          CASE WHEN upper(trim(i.grade)) IN ('YELLOW', 'WHITE') THEN 'DIATOMACEOUS EARTH (RAW)' WHEN upper(trim(i.grade)) = 'GYPSUM' THEN 'GYPSUM' END,   -- yellow and white are both diatomaceous earth (HSN 251200)
          NULLIF(s.item, ''), i.grade, '—') AS item,
        i.rawana_no, i.rawana_wt, i.actual_wt, i.freight_rate, i.freight_amt AS freight_total, i.lorry_no,
        CASE WHEN i.voucher_no LIKE 'PPE%' THEN 'PPE' ELSE 'PM' END AS src
      FROM inwards i LEFT JOIN suppliers s ON upper(trim(s.name)) = upper(trim(i.supplier))
      UNION ALL
      SELECT 'stock_in', id, fy, st_no, date, supplier, COALESCE(item, '—'), rawana_no, rawana_wt, actual_wt, freight_rate, freight_total, NULL, 'ST' FROM stock_in
    ) ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY date, no`, ...a);
}
route('GET', '/api/stock', ({ q }) => {
  const fy = q.fy || L.fyOf(), rows = stockRows({ ...q, fy });
  const sum = (list, key) => {
    const m = new Map();
    for (const r of list) {
      const k = key(r), x = m.get(k) || { key: k, lorries: 0, rawana: 0, actual: 0, PPE: { rawana: 0, actual: 0 }, PM: { rawana: 0, actual: 0 }, ST: { rawana: 0, actual: 0 } };
      x.lorries++; x.rawana += Number(r.rawana_wt) || 0; x.actual += Number(r.actual_wt) || 0;
      x[r.src].rawana += Number(r.rawana_wt) || 0; x[r.src].actual += Number(r.actual_wt) || 0; m.set(k, x);
    }
    return [...m.values()].sort((p, q2) => q2.actual - p.actual);
  };
  const base = stockRows({ fy });          // dropdowns show what exists in the year
  return { fy, items: sum(rows, r => r.item), suppliers: sum(rows, r => String(r.supplier || '—').trim().toUpperCase() + '\u0000' + r.item).map(x => { const [s, it] = x.key.split('\u0000'); return { ...x, supplier: s, item: it }; }),
    entries: all(`SELECT * FROM stock_in WHERE fy = ? ORDER BY date DESC, st_no DESC`, fy),
    supplier_list: [...new Set([...all('SELECT name FROM suppliers ORDER BY name').map(r => r.name), ...base.map(r => String(r.supplier || '').trim().toUpperCase()).filter(Boolean)])].sort(),
    item_list: [...new Set(base.map(r => r.item))].sort(),
    next_no: nextStockNo(fy) };
});
function nextStockNo(fy) {
  const n = all('SELECT st_no FROM stock_in WHERE fy = ?', fy).map(r => Number(String(r.st_no).replace(/\D/g, '')) || 0);
  return 'PMST' + String((n.length ? Math.max(...n) : 0) + 1).padStart(2, '0');
}
function saveStockIn(b, id) {
  const o = { date: b.date || null, supplier: String(b.supplier || '').trim().toUpperCase() || null, item: String(b.item || '').trim().toUpperCase() || null,
    rawana_no: String(b.rawana_no || '').trim() || null, rawana_wt: b.rawana_wt === '' || b.rawana_wt == null ? null : Number(b.rawana_wt),
    actual_wt: b.actual_wt === '' || b.actual_wt == null ? null : Number(b.actual_wt), freight_rate: b.freight_rate === '' || b.freight_rate == null ? null : Number(b.freight_rate),
    remarks: String(b.remarks || '').trim() || null };
  if (!o.date) throw new L.UserError('Enter the date.');
  if (!o.supplier) throw new L.UserError('Select the supplier.');
  if (!o.item) throw new L.UserError('Select the raw material.');
  if (!(o.rawana_wt > 0) && !(o.actual_wt > 0)) throw new L.UserError('Enter the rawana qty or the actual qty.');
  o.freight_total = o.freight_rate ? L.r2(o.freight_rate * (o.actual_wt || o.rawana_wt || 0)) : null;
  const fy = L.fyOf(o.date);
  let no = String(b.st_no || '').trim().toUpperCase() || nextStockNo(fy);
  if (!/^PMST\d+$/.test(no)) throw new L.UserError('Stock-in no. is PMST and a number, e.g. PMST02.');
  if (get('SELECT 1 FROM stock_in WHERE fy = ? AND st_no = ? AND id IS NOT ?', fy, no, id || null)) throw new L.UserError(`${no} is already used in ${fy}.`);
  if (o.rawana_no && get('SELECT 1 FROM stock_in WHERE rawana_no = ? AND id IS NOT ?', o.rawana_no, id || null)) throw new L.UserError(`Rawana ${o.rawana_no} is already in Stock IN.`);
  if (o.rawana_no && get('SELECT 1 FROM inwards WHERE rawana_no = ?', o.rawana_no)) throw new L.UserError(`Rawana ${o.rawana_no} is already on an inward voucher.`);
  const row = { ...o, fy, st_no: no }, keys = Object.keys(row);
  if (id) run(`UPDATE stock_in SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => row[k]), id);
  else id = Number(run(`INSERT INTO stock_in(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => row[k])).lastInsertRowid);
  backup.backupSoon('stock in');
  return { id, st_no: no };
}
route('GET', '/api/stock-in/next', ({ q }) => ({ st_no: nextStockNo(L.fyOf(q.date)) }));
route('POST', '/api/stock-in', ({ body }) => saveStockIn(body));
route('PUT', '/api/stock-in/:id', ({ p, body }) => { checkEditPassword(body.edit_password); return saveStockIn(body, Number(p.id)); });
route('DELETE', '/api/stock-in/:id', ({ p, q }) => { checkEditPassword(q.pw); run('DELETE FROM stock_in WHERE id = ?', p.id); backup.backupSoon('stock in'); return { deleted: true }; });

// ---------- Orders book (B2B buyers and B2C customers) ----------
function orderFull(o) {
  o.party = get('SELECT id, name, city, firm_code FROM parties WHERE id = ?', o.party_id) || {};
  if (o.b2c_id) { o.customer = get('SELECT id, name, mobile, city, state FROM b2c_customers WHERE id = ?', o.b2c_id) || {}; o.buyer = o.customer.name || o.party.name; o.city = o.customer.city || ''; }
  else { o.buyer = o.party.name; o.city = o.party.city || ''; }
  o.items = all(`SELECT oi.*, pi.pack_size, pi.bag_type, pi.packing_type FROM order_items oi LEFT JOIN party_items pi ON pi.id = oi.party_item_id WHERE oi.order_id = ? ORDER BY oi.id`, o.id);
  return o;
}
route('GET', '/api/orders', () => all(`SELECT o.* FROM orders o ORDER BY COALESCE(o.dispatch_by, '9999'), o.id`).map(orderFull));
route('GET', '/api/orders/:id', ({ p }) => { const o = get('SELECT * FROM orders WHERE id = ?', p.id); if (!o) throw new L.UserError('This order is not in the book any more.'); return orderFull(o); });
function saveOrder(body, id) {
  const b2c = Number(body.b2c_id) || null;
  const party = b2c ? get('SELECT * FROM parties WHERE COALESCE(is_online, 0) = 1 ORDER BY id LIMIT 1') : get('SELECT * FROM parties WHERE id = ?', body.party_id);
  if (!party) throw new L.UserError(b2c ? 'The ledger ONLINE SALE is not in Buyers B2B.' : 'Choose the buyer.');
  if (b2c && !get('SELECT 1 FROM b2c_customers WHERE id = ?', b2c)) throw new L.UserError('Choose the customer from Buyers B2C.');
  const firm = b2c ? party.firm_code || 'PM' : body.firm_code || party.firm_code;
  if (party.firm_code && party.firm_code !== firm) throw new L.UserError('This buyer is billed by the other firm.');
  const items = (body.items || []).filter(x => Number(x.party_item_id));
  if (!items.length) throw new L.UserError('Tick at least one item.');
  const old = id ? get('SELECT dispatch_by FROM orders WHERE id = ?', id) : null;
  const res = require('./db').tx(() => {
    let oid = id;
    if (id) run('UPDATE orders SET firm_code = ?, party_id = ?, b2c_id = ?, dispatch_by = ?, notes = ? WHERE id = ?', firm, party.id, b2c, body.dispatch_by || null, body.notes || null, id);
    else oid = Number(run('INSERT INTO orders(firm_code, party_id, b2c_id, dispatch_by, notes, proforma_id) VALUES(?,?,?,?,?,?)', firm, party.id, b2c, body.dispatch_by || null, body.notes || null, body.proforma_id || null).lastInsertRowid);
    run('DELETE FROM order_items WHERE order_id = ?', oid);
    for (const it of items) {
      const pi = get('SELECT * FROM party_items WHERE id = ? AND party_id = ? AND (b2c_id IS NULL OR b2c_id = ?)', it.party_item_id, party.id, b2c || -1);
      if (!pi) throw new L.UserError('An item does not belong to this buyer.');
      const bags = Number(it.bags) || null;
      const qty = bags && pi.pack_size > 0 ? Math.round(bags * pi.pack_size) / 1000 : Number(it.qty) || null;
      run('INSERT INTO order_items(order_id, party_item_id, item_name, grade, qty, bags) VALUES(?,?,?,?,?,?)', oid, pi.id, pi.item_name, pi.grade, qty, bags);
    }
    return { id: oid };
  });
  // Google Calendar: a new order, or a new dispatch date → the entries are made (again)
  if (body.dispatch_by && (!old || old.dispatch_by !== body.dispatch_by)) { run("UPDATE orders SET calendar_status = 'QUEUED', calendar_error = NULL WHERE id = ?", res.id); setImmediate(() => orderCalendar(res.id).catch(() => {})); }
  return res;
}
// ---- Google Calendar (the Apps Script link in Settings → Data Location): an order shows from 3 days before its dispatch date
// until the dispatch date — one entry on each of those days (the link takes one event at a time).
const ORDER_CAL_DAYS = 3;
async function orderCalendar(id) {
  const url = setting('mkt.calendar_url'); if (!url) return;
  const o = get('SELECT * FROM orders WHERE id = ?', id); if (!o || !o.dispatch_by || o.calendar_status !== 'QUEUED' && o.calendar_status !== 'FAILED') return;
  const full = orderFull(o), today = todayIso();
  const items = full.items.map(i => `${i.item_name} ${i.grade || ''}${i.bags ? ` — ${i.bags} bags` : i.qty ? ` — ${L.mt(i.qty)} MT` : ''}`.trim());
  const days = [];
  for (let k = ORDER_CAL_DAYS; k >= 0; k--) { const d = addDaysIso(o.dispatch_by, -k); if (d >= today) days.push({ d, k }); }
  try {
    for (const { d, k } of days) {
      const payload = { title: `${k ? `Dispatch in ${k} day${k > 1 ? 's' : ''}` : 'DISPATCH TODAY'}: ${full.buyer}${full.city ? ' (' + full.city + ')' : ''} [${o.firm_code}${o.b2c_id ? ' B2C' : ''}]`,
        startTime: `${d}T09:30:00`, endTime: `${d}T10:00:00`, allDay: true, date: d, dispatch_by: o.dispatch_by,
        description: [`Order to dispatch by ${dmyOf(o.dispatch_by)}`, ...items, o.notes ? 'Note: ' + o.notes : '', 'Mineral Saathi → Orders Book'].filter(Boolean).join('\n') };
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), redirect: 'follow', signal: AbortSignal.timeout(25000) });
      const t = (await r.text()).trim();
      if (!r.ok || /^<!doctype html|^<html/i.test(t)) throw new Error(`Google answered ${r.status}`);
    }
    run("UPDATE orders SET calendar_status = 'SENT', calendar_sent_for = ?, calendar_error = NULL WHERE id = ?", o.dispatch_by, id);
  } catch (e) { run("UPDATE orders SET calendar_status = 'FAILED', calendar_error = ? WHERE id = ?", String(e.message || e).slice(0, 200), id); }
}
// waiting entries (no internet …) are tried again every 10 minutes
setInterval(async () => { for (const o of all("SELECT id FROM orders WHERE calendar_status IN ('QUEUED', 'FAILED') AND dispatch_by >= ? LIMIT 20", todayIso())) await orderCalendar(o.id).catch(() => {}); }, 10 * 60e3).unref();
route('POST', '/api/orders/:id/calendar', async ({ p }) => {
  if (!setting('mkt.calendar_url')) throw new L.UserError('Set the Google Calendar link first: Settings → Data Location.');
  run("UPDATE orders SET calendar_status = 'QUEUED' WHERE id = ?", p.id); await orderCalendar(Number(p.id));
  return get('SELECT calendar_status, calendar_error FROM orders WHERE id = ?', p.id);
});
route('POST', '/api/orders', ({ body }) => saveOrder(body));
route('PUT', '/api/orders/:id', ({ p, body }) => saveOrder(body, Number(p.id)));
route('DELETE', '/api/orders/:id', ({ p }) => { run('DELETE FROM order_items WHERE order_id = ?', p.id); run('DELETE FROM orders WHERE id = ?', p.id); return { deleted: true }; });

// ---------- Factory wages (Parakh Marketing invoices only) ----------
const wages = require('./wages');
route('GET', '/api/wages', ({ q }) => wages.month(q.month));
route('GET', '/api/wages/saved', () => wages.savedMonths());
// ---------- Fuel: barrels used at the factory; cost per MT of the items whose form uses fuel (from Oct 2026) ----------
const FUEL_FROM = '2026-10-01';
route('GET', '/api/fuel', ({ q }) => {
  const fy = q.fy || L.fyOf(), y0 = Number(fy.slice(0, 4));
  let from = `${y0}-04-01`, to = `${y0 + 1}-03-31`;
  if (q.month) { from = q.month + '-01'; to = q.month + '-31'; }
  const calcFrom = from < FUEL_FROM ? FUEL_FROM : from;
  const entries = all('SELECT * FROM fuel_entries WHERE date BETWEEN ? AND ? ORDER BY date DESC, id DESC', from, to);
  const used = all('SELECT * FROM fuel_entries WHERE date BETWEEN ? AND ?', calcFrom, to);
  const disp = calcFrom <= to ? wages.fuelDispatch(calcFrom, to) : { months: [], items: [], forms: [] };
  const months = new Map();
  for (const e of used) { const m = e.date.slice(0, 7), x = months.get(m) || { month: m, amount: 0, litres: 0, mt: 0 }; x.amount += Number(e.amount) || 0; x.litres += Number(e.litres) || 0; months.set(m, x); }
  for (const d of disp.months) { const x = months.get(d.month) || { month: d.month, amount: 0, litres: 0, mt: 0 }; x.mt = d.mt; months.set(d.month, x); }
  const list = [...months.values()].sort((a, b) => b.month.localeCompare(a.month)).map(x => ({ ...x, amount: L.r2(x.amount), per_mt: x.mt > 0 ? L.r2(x.amount / x.mt) : null }));
  const amt = L.r2(used.reduce((s, e) => s + (Number(e.amount) || 0), 0)), litres = used.reduce((s, e) => s + (Number(e.litres) || 0), 0);
  const mt = Math.round(disp.items.reduce((s, i) => s + i.mt, 0) * 1000) / 1000, per = mt > 0 ? L.r2(amt / mt) : null;
  return { fy, from, to, calc_from: calcFrom, fuel_from: FUEL_FROM, entries, months: list, amount: amt, litres: L.r2(litres), mt, per_mt: per,
    per_litre_mt: mt > 0 ? L.r2(litres / mt) : null, items: disp.items.map(i => ({ ...i, cost: per != null ? L.r2(i.mt * per) : null })), fuel_forms: disp.forms };
});
function saveFuel(b, id) {
  const o = { date: b.date || null, barrels: Number(b.barrels) || 0, ltr_per_barrel: Number(b.ltr_per_barrel) || 0, rate: Number(b.rate) || 0, notes: String(b.notes || '').trim() || null };
  if (!o.date) throw new L.UserError('Enter the date.');
  if (!(o.barrels > 0)) throw new L.UserError('Enter the number of barrels.');
  if (!(o.ltr_per_barrel > 0)) throw new L.UserError('Enter the litres in a barrel.');
  if (!(o.rate > 0)) throw new L.UserError('Enter the rate per litre.');
  o.litres = Math.round(o.barrels * o.ltr_per_barrel * 1000) / 1000; o.amount = L.r2(o.litres * o.rate);
  const keys = Object.keys(o);
  if (id) run(`UPDATE fuel_entries SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), id);
  else id = Number(run(`INSERT INTO fuel_entries(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid);
  setSetting('fuel_ltr_per_barrel', String(o.ltr_per_barrel)); setSetting('fuel_rate', String(o.rate));
  backup.backupSoon('fuel');
  return { id };
}
route('GET', '/api/fuel/defaults', () => ({ ltr_per_barrel: Number(setting('fuel_ltr_per_barrel')) || 200, rate: Number(setting('fuel_rate')) || '' }));
route('POST', '/api/fuel', ({ body }) => saveFuel(body));
route('PUT', '/api/fuel/:id', ({ p, body }) => { checkEditPassword(body.edit_password); return saveFuel(body, Number(p.id)); });
route('DELETE', '/api/fuel/:id', ({ p, q }) => { checkEditPassword(q.pw); run('DELETE FROM fuel_entries WHERE id = ?', p.id); return { deleted: true }; });
route('PUT', '/api/wages', ({ body }) => { const r = wages.save(body.month, body.rows); backup.backupSoon('wages'); return r; });
route('GET', '/api/factory-fixed', () => all('SELECT * FROM factory_fixed WHERE active = 1 ORDER BY plant DESC, name'));
function cleanFixed(b) {
  const o = { plant: String(b.plant || '').trim(), name: String(b.name || '').trim().toUpperCase(), amount: b.amount === '' || b.amount == null ? null : Number(b.amount) };
  if (!get('SELECT 1 FROM plants WHERE name = ?', o.plant)) throw new L.UserError('Choose the plant.');
  if (!o.name) throw new L.UserError('Enter the expense name.');
  return o;
}
route('POST', '/api/factory-fixed', ({ body }) => { const o = cleanFixed(body); return { id: Number(run('INSERT INTO factory_fixed(plant, name, amount) VALUES(?,?,?)', o.plant, o.name, o.amount).lastInsertRowid) }; });
route('PUT', '/api/factory-fixed/:id', ({ p, body }) => { const o = cleanFixed(body); run('UPDATE factory_fixed SET plant = ?, name = ?, amount = ? WHERE id = ?', o.plant, o.name, o.amount, p.id); return { id: Number(p.id) }; });
route('DELETE', '/api/factory-fixed/:id', ({ p }) => { run('UPDATE factory_fixed SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

// ---------- Commission (private): own password, never in prints, emails or reports ----------
function checkCommPassword(req) {
  const h = setting('comm_password_hash'), salt = setting('comm_password_salt');
  if (!h) throw new L.UserError('Set the Commission password first: Settings → Security.');
  const pw = req.headers['x-comm-pw'] ? decodeURIComponent(String(req.headers['x-comm-pw'])) : '';
  if (!pw || !crypto.timingSafeEqual(Buffer.from(pwHash(pw, salt), 'hex'), Buffer.from(h, 'hex'))) { const e = new L.UserError('Wrong Commission password.'); e.status = 403; throw e; }
}
route('PUT', '/api/comm-password', ({ body }) => {
  if (setting('comm_password_hash')) {
    const salt = setting('comm_password_salt');
    if (!body.old || pwHash(body.old, salt) !== setting('comm_password_hash')) throw new L.UserError('The current Commission password is wrong.');
  }
  const pw = String(body.password || '');
  if (pw.length < 4) throw new L.UserError('The password must have at least 4 characters.');
  const salt = crypto.randomBytes(16).toString('hex');
  setSetting('comm_password_salt', salt); setSetting('comm_password_hash', pwHash(pw, salt));
  return { ok: true };
});
route('POST', '/api/commission/check', ({ req }) => { checkCommPassword(req); return { ok: true }; });
// every invoice line of buyers whose items carry a commission rate (all years, from the very first invoice)
function commissionLines() {
  // all active items of the buyers that have at least one item with a commission rate
  const rates = all(`SELECT pi.party_id, upper(pi.item_name) item, upper(COALESCE(pi.grade,'')) grade, COALESCE(pi.commission, 0) commission, pi.agent, p.name
                     FROM party_items pi JOIN parties p ON p.id = pi.party_id
                     WHERE pi.active = 1 AND pi.party_id IN (SELECT party_id FROM party_items WHERE active = 1 AND commission > 0)`);
  if (!rates.length) return { lines: [], buyers: [], agents: [] };
  const byParty = {};
  for (const r of rates) (byParty[r.party_id] = byParty[r.party_id] || { name: r.name, items: [] }).items.push(r);
  const ids = Object.keys(byParty).map(Number);
  const names = Object.fromEntries(ids.map(id => [byParty[id].name.toUpperCase().trim(), id]));
  const rows = all(`SELECT i.id inv_id, i.date, i.inv_no, i.fy, i.firm_code, i.party_id, i.party_name, it.item_name, it.grade, it.qty, it.comm_rate
                    FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
                    WHERE i.kind = 'SALE' AND COALESCE(i.cancelled, 0) = 0 ORDER BY i.date, i.inv_no, it.sl`);
  const lines = [];
  for (const r of rows) {
    const pid = r.party_id && byParty[r.party_id] ? r.party_id : (!r.party_id ? names[String(r.party_name || '').toUpperCase().trim()] : null);
    if (!pid) continue;
    // match the invoice line to the buyer's item. Old invoices used other item names (e.g. DIATOMITE AMORPHOUS SILICA,
    // DIATOMACEOUS EARTH POWDER), so: same name + grade → same name → same grade → the buyer's only item
    const K = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    // a mesh grade without a colour letter is the yellow one: 150 MESH = Y150 MESH, 300 MESH = Y300 MESH (W300 stays white)
    const G = s => { const k = K(s); return /^\d+(\+)?MESH$/.test(k) || /^\d+$/.test(k) ? 'Y' + k.replace(/MESH$/, '') + 'MESH' : k; };
    const its = byParty[pid].items.map(x => ({ ...x, gk: G(x.grade) })), item = K(r.item_name), grade = G(r.grade);
    const one = arr => arr.length === 1 ? arr[0] : null;
    const pi = its.find(x => K(x.item) === item && x.gk === grade) || one(its.filter(x => K(x.item) === item))
      || (grade ? one(its.filter(x => x.gk === grade)) : null) || one(its);
    const rate = Number(r.comm_rate) || (pi ? pi.commission : 0);
    if (!(rate > 0)) continue;
    const qty = Number(r.qty) || 0;
    lines.push({ inv_id: r.inv_id, date: r.date, inv_no: r.inv_no, fy: r.fy, firm_code: r.firm_code, party_id: pid, buyer: byParty[pid].name,
      item: [r.item_name, r.grade].filter(Boolean).join(' '), agent: (pi && pi.agent) || '', qty, rate, commission: L.r2(qty * rate) });
  }
  const agents = [...new Set(rates.filter(r => r.commission > 0 && r.agent).map(r => r.agent))].sort();
  const buyers = ids.map(id => ({ id, name: byParty[id].name, agents: [...new Set(byParty[id].items.filter(x => x.commission > 0 && x.agent).map(x => x.agent))] }))
    .sort((a, b) => a.name.localeCompare(b.name));
  return { lines, buyers, agents };
}
route('GET', '/api/commission', ({ q, req }) => {
  checkCommPassword(req);
  const { lines, buyers, agents } = commissionLines();
  const fys = [...new Set([...lines.map(l => l.fy), ...all('SELECT DISTINCT fy FROM commission_pay').map(r => r.fy)].filter(Boolean))].sort().reverse();
  const pid = Number(q.party) || null, fy = q.fy || '', agent = String(q.agent || '').toUpperCase();
  const sel = lines.filter(l => (!pid || l.party_id === pid) && (!fy || l.fy === fy) && (!agent || l.agent === agent));
  const pays = all(`SELECT cp.*, p.name buyer FROM commission_pay cp LEFT JOIN parties p ON p.id = cp.party_id
                    WHERE (? IS NULL OR cp.party_id = ?) AND (? = '' OR cp.fy = ?) AND (? = '' OR cp.agent = ?) ORDER BY cp.date, cp.id`, pid, pid, fy, fy, agent, agent);
  const extras = all(`SELECT ce.*, p.name buyer FROM commission_extra ce LEFT JOIN parties p ON p.id = ce.party_id
                      WHERE (? IS NULL OR ce.party_id = ?) AND (? = '' OR ce.fy = ?) AND (? = '' OR ce.agent = ?) ORDER BY ce.date, ce.id`, pid, pid, fy, fy, agent, agent);
  const commission = L.r2(sel.reduce((s, l) => s + l.commission, 0)), extra = L.r2(extras.reduce((s, x) => s + (Number(x.amount) || 0), 0));
  const total = L.r2(commission + extra), paid = L.r2(pays.reduce((s, x) => s + (Number(x.amount) || 0), 0));
  return { buyers, agents, fys, lines: sel, extras, payments: pays, commission, extra, total, paid, balance: L.r2(total - paid), qty: L.r2(sel.reduce((s, l) => s + l.qty, 0)) };
});
route('POST', '/api/commission/payments', ({ body, req }) => {
  checkCommPassword(req);
  const pid = Number(body.party_id) || null, agent = String(body.agent || '').trim().toUpperCase() || null;
  if (!pid && !agent) throw new L.UserError('Choose the agent or the buyer first.');
  if (pid && !get('SELECT 1 FROM parties WHERE id = ?', pid)) throw new L.UserError('Buyer not found.');
  const amount = Number(String(body.amount || '').replace(/[^0-9.]/g, ''));
  if (!(amount > 0)) throw new L.UserError('Enter the amount paid.');
  if (!body.date) throw new L.UserError('Enter the date.');
  const o = { party_id: pid, agent, date: body.date, fy: L.fyOf(body.date), amount,
    sent_to: String(body.sent_to || '').trim().toUpperCase() || null, sent_via: String(body.sent_via || '').trim().toUpperCase() || null,
    ref: String(body.ref || '').trim() || null, notes: String(body.notes || '').trim() || null };
  const keys = Object.keys(o);
  const id = Number(run(`INSERT INTO commission_pay(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid);
  backup.backupSoon('commission');
  return { id };
});
// expenses owed to the agent / for the buyer
route('POST', '/api/commission/extras', ({ body, req }) => {
  checkCommPassword(req);
  const pid = Number(body.party_id) || null, agent = String(body.agent || '').trim().toUpperCase() || null;
  if (!pid && !agent) throw new L.UserError('Choose the agent or the buyer first.');
  const amount = Number(String(body.amount || '').replace(/[^0-9.\-]/g, ''));
  if (!amount) throw new L.UserError('Enter the amount.');
  if (!body.date) throw new L.UserError('Enter the date.');
  if (!String(body.description || '').trim()) throw new L.UserError('Enter what the expense is for.');
  const id = Number(run('INSERT INTO commission_extra(party_id, agent, date, fy, description, amount) VALUES(?,?,?,?,?,?)',
    pid, agent, body.date, L.fyOf(body.date), String(body.description).trim(), amount).lastInsertRowid);
  backup.backupSoon('commission');
  return { id };
});
route('DELETE', '/api/commission/extras/:id', ({ p, req }) => { checkCommPassword(req); run('DELETE FROM commission_extra WHERE id = ?', p.id); return { deleted: true }; });
// many old payments at once (from an Excel / CSV file read on the screen). Rows already saved are skipped.
route('POST', '/api/commission/payments/bulk', ({ body, req }) => {
  checkCommPassword(req);
  const dfltPid = Number(body.party_id) || null, dfltAgent = String(body.agent || '').trim().toUpperCase() || null;
  const rep = { added: 0, skipped: 0, errors: [] };
  require('./db').tx(() => {
    (body.rows || []).forEach((r, i) => {
      const agent = String(r.agent || '').trim().toUpperCase() || dfltAgent;
      let pid = dfltPid;
      if (r.buyer) { const b = get('SELECT id FROM parties WHERE upper(trim(name)) = upper(trim(?))', r.buyer); if (b) pid = b.id; }
      const amount = Number(String(r.amount ?? '').replace(/[^0-9.]/g, ''));
      if (!/^\d{4}-\d{2}-\d{2}$/.test(r.date || '') || !(amount > 0)) { rep.errors.push(`Row ${i + 1}: date or amount missing`); return; }
      if (!pid && !agent) { rep.errors.push(`Row ${i + 1}: no agent or buyer`); return; }
      if (get(`SELECT 1 FROM commission_pay WHERE date = ? AND amount = ? AND COALESCE(agent,'') = COALESCE(?,'') AND COALESCE(party_id,0) = COALESCE(?,0)`, r.date, amount, agent, pid)) { rep.skipped++; return; }
      run(`INSERT INTO commission_pay(party_id, agent, date, fy, amount, sent_to, sent_via, ref, notes) VALUES(?,?,?,?,?,?,?,?,?)`,
        pid, agent, r.date, L.fyOf(r.date), amount, String(r.sent_to || '').trim().toUpperCase() || null, String(r.sent_via || '').trim().toUpperCase() || null,
        String(r.ref || '').trim() || null, String(r.notes || '').trim() || null);
      rep.added++;
    });
  });
  backup.backupSoon('commission');
  return rep;
});
route('DELETE', '/api/commission/payments/:id', ({ p, req }) => { checkCommPassword(req); run('DELETE FROM commission_pay WHERE id = ?', p.id); return { deleted: true }; });

route('PUT', '/api/invoices/:id', ({ p, body }) => {
  checkEditPassword(body.edit_password); const id = L.saveSale(body, Number(p.id)); backup.backupSoon('invoice'); pdfSoon(id);
  // a changed PF invoice changes its PM → PF invoice too
  let linked = null; if (get('SELECT 1 FROM invoices WHERE pf_source_id = ?', id)) { try { linked = makePmToPf(id); } catch (e) { linked = { error: 'PM → PF invoice: ' + e.message }; } }
  return { id, linked };
});
route('POST', '/api/invoices/:id/cancel', ({ p, body }) => {
  checkEditPassword(body.edit_password); L.cancelInvoice(p.id);
  // cancelling a PF invoice cancels its PM → PF invoice too
  for (const l of all('SELECT id FROM invoices WHERE pf_source_id = ? AND COALESCE(cancelled, 0) = 0', p.id)) L.cancelInvoice(l.id);
  backup.backupSoon('cancel'); return { ok: true };
});
route('POST', '/api/ppe-bills', ({ body }) => { const id = L.savePpeBill(body); backup.backupSoon('invoice'); return { id }; });
route('PUT', '/api/ppe-bills/:id', ({ p, body }) => { checkEditPassword(body.edit_password); const id = L.savePpeBill(body, Number(p.id)); backup.backupSoon('invoice'); return { id }; });
route('POST', '/api/ewaybill-json', ({ body, req }) => {
  const json = L.ewayBillJson(body);
  // on the computer that runs Mineral Saathi the file goes straight into the e-way bill folder (Settings → Backup & files)
  if (isLocal(req)) {
    try {
      const dir = ewbFolder(); fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, 'ewaybill.json');
      fs.writeFileSync(file, JSON.stringify(json, null, 1));
      const b = json.billLists[0];
      const copy = path.join(dir, 'old', safeName(`${b.docDate.split('/').reverse().join('-')} ${b.fromTrdName} ${b.docNo} ${b.toTrdName}`) + '.json');
      fs.mkdirSync(path.dirname(copy), { recursive: true }); fs.writeFileSync(copy, JSON.stringify(json, null, 1));
      return { ...json, saved: file };
    } catch (e) { console.error('E-way bill folder:', e.message); return { ...json, save_error: `Could not save in ${ewbFolder()}: ${e.message}` }; }
  }
  return json;
});
// the Desktop the user really sees: on Windows it is often moved into OneDrive (C:\Users\<name>\OneDrive\Desktop)
let desktopCache = null;
function desktopDir() {
  if (desktopCache) return desktopCache;
  const home = os.homedir(), cands = [];
  if (process.platform === 'win32') {
    try {
      const out = require('child_process').execFileSync('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders', '/v', 'Desktop'], { encoding: 'utf8', windowsHide: true, timeout: 5000 });
      const m = out.match(/Desktop\s+REG_(?:EXPAND_)?SZ\s+(.+)/i);
      if (m) cands.push(m[1].trim().replace(/%([^%]+)%/g, (x, k) => process.env[k] || process.env[k.toUpperCase()] || x));
    } catch { /* no registry answer */ }
    for (const k of ['OneDrive', 'OneDriveConsumer', 'OneDriveCommercial']) if (process.env[k]) cands.push(path.join(process.env[k], 'Desktop'));
  }
  cands.push(path.join(home, 'Desktop'));
  desktopCache = cands.find(d => { try { return fs.statSync(d).isDirectory(); } catch { return false; } }) || path.join(home, 'Desktop');
  return desktopCache;
}
function ewbFolder() {
  const set = pcSettings().ewb_folder;
  // a folder saved as the old default (C:\Users\<name>\Desktop) follows the real Desktop
  if (!set || path.resolve(set).toLowerCase() === path.join(os.homedir(), 'Desktop').toLowerCase()) return desktopDir();
  return set;
}
route('POST', '/api/totals', ({ body }) => {
  // live preview of totals while typing an invoice
  const firmCode = body.firm_code || (body.party_id && get('SELECT firm_code FROM parties WHERE id = ?', body.party_id)?.firm_code) || 'PM';
  const f = get('SELECT * FROM firms WHERE code = ?', firmCode);
  const items = (body.items || []).map(it => ({ qty: Number(it.qty) || 0, rate: Number(it.rate) || 0, gst_rate: Number(it.gst_rate ?? 5) }));
  const t = L.computeTotals(items, f, L.stateCode(body.state, body.gstin) || body.state_code);
  return { ...t, words: L.inWords(t.total) };
});

route('GET', '/api/email-style', () => ({ font: setting('email_font', 'Arial, Helvetica, sans-serif'), size: Number(setting('email_size', '14')) || 14, color: setting('email_color', '#222222'),
  logo_h: Number(setting('email_logo_h', '60')) || 60, logo_align: setting('email_logo_align', 'left'), footer: setting('email_footer', '1') === '1' }));
route('PUT', '/api/email-style', ({ body }) => {
  if (body.font) setSetting('email_font', String(body.font).replace(/[^A-Za-z0-9 ,'"-]/g, '').slice(0, 80));
  if (body.size) setSetting('email_size', String(Math.max(11, Math.min(20, Number(body.size) || 14))));
  if (body.color && /^#[0-9a-f]{6}$/i.test(body.color)) setSetting('email_color', body.color);
  if (body.logo_h) setSetting('email_logo_h', String(Math.max(24, Math.min(160, Number(body.logo_h) || 60))));
  if (body.logo_align) setSetting('email_logo_align', body.logo_align === 'center' ? 'center' : 'left');
  if (body.footer !== undefined) setSetting('email_footer', Number(body.footer) ? '1' : '0');
  return { ok: true };
});
// a sample email in the chosen look (Settings → Email templates → Email look → Preview)
route('GET', '/api/email-style/preview', ({ q }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', q.firm || 'PM') || {};
  const tpl = q.tid ? get('SELECT body, html FROM email_templates WHERE id = ?', q.tid) : null;
  const msg = mailer.buildMessage({ from: 'x@x', fromName: f.name, to: [], cc: [], subject: 'Preview', html: tpl ? (tpl.html || mailer.textToHtml(tpl.body)) : '<p>Dear Sir / Madam,</p><p>Please find attached our invoice <b>187</b> dated 19.11.2026.</p><p>Regards,<br>' + (f.name || '') + '</p>', logo: brandLogo(f), style: emailStyle(f) });
  const m = msg.match(/Content-Type: text\/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n([\s\S]*?)\r\n--/);
  let html = m ? Buffer.from(m[1].replace(/\s/g, ''), 'base64').toString('utf8') : '';
  if (brandLogo(f)) html = html.replace('cid:companylogo', brandLogo(f));
  return { html };
});
route('GET', '/api/email-templates', () => ({ templates: all('SELECT * FROM email_templates WHERE active = 1 ORDER BY purpose, is_default DESC, name'), vars: TEMPLATE_VARS.map(v => v[0]), reminder_vars: REMINDER_VARS, sample_vars: require('./samplemail').SAMPLE_VARS, sample_auto: setting('auto_sample_email', '0') === '1' }));
function cleanTemplate(b) {
  const o = { name: String(b.name || '').trim(), purpose: String(b.purpose || '').toUpperCase(), body: String(b.body || ''), html: b.html ? cleanHtml(b.html) : null, is_default: Number(b.is_default) ? 1 : 0, auto_send: b.auto_send === undefined ? 1 : Number(b.auto_send) ? 1 : 0 };
  if (!o.name) throw new L.UserError('Give the template a name.');
  if (!['SALE', 'PROFORMA', 'TRANSPORTER', 'REMINDER', 'SAMPLE'].includes(o.purpose)) throw new L.UserError('Choose what the template is for.');
  if (!o.body.trim()) throw new L.UserError('Write the message.');
  return o;
}
route('POST', '/api/email-templates', ({ body }) => {
  const o = cleanTemplate(body);
  if (o.is_default) run('UPDATE email_templates SET is_default = 0 WHERE purpose = ?', o.purpose);
  return { id: Number(run('INSERT INTO email_templates(name, purpose, body, html, is_default, auto_send) VALUES(?,?,?,?,?,?)', o.name, o.purpose, o.body, o.html, o.is_default, o.auto_send).lastInsertRowid) };
});
route('PUT', '/api/email-templates/:id', ({ p, body }) => {
  const o = cleanTemplate(body);
  if (o.is_default) run('UPDATE email_templates SET is_default = 0 WHERE purpose = ?', o.purpose);
  run('UPDATE email_templates SET name = ?, purpose = ?, body = ?, html = ?, is_default = ?, auto_send = ? WHERE id = ?', o.name, o.purpose, o.body, o.html, o.is_default, o.auto_send, p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/email-templates/:id', () => { throw new L.UserError('Email templates cannot be deleted — edit them instead.'); });
// a template filled in for one invoice (the email box uses it when another template is chosen)
route('GET', '/api/invoices/:id/template/:tid', ({ p }) => {
  const inv = L.invoiceFull(p.id), tp = get('SELECT body, html FROM email_templates WHERE id = ?', p.tid);
  if (!inv || !tp) throw new L.UserError('Not found.');
  return fillBoth(tp, inv);
});
// the invoice copy for the transporter (default "Invoice copy to transporter" template)
function trDraft(inv) {
  const tr = trOf(inv), d = inv.date ? inv.date.split('-').reverse().join('.') : '';
  const tpl = get(`SELECT name, body, html FROM email_templates WHERE purpose = 'TRANSPORTER' AND active = 1 ORDER BY is_default DESC, id LIMIT 1`);
  const to = tr ? splitAddr(tr.email) : [];
  const std = `Dear Sir,\n\nPlease find attached the copy of our invoice ${inv.inv_no} dt ${d} for lorry ${inv.lorry_no || ''} (L.R. ${inv.lr_no || '-'}) to ${inv.party_name}.\n\nRegards,\n${inv.firm.name}`;
  const m = tpl ? fillBoth(tpl, inv) : { text: std, html: mailer.textToHtml(std) };
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: `Invoice copy ${inv.inv_no} dt ${d} — lorry ${inv.lorry_no || ''} — ${inv.firm.name}`, text: m.text, html: m.html, template_name: tpl ? tpl.name : 'Standard message' };
}
route('GET', '/api/invoices/:id/email', ({ p, q }) => {
  const inv = L.invoiceFull(p.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  const purpose = q.who === 'transporter' ? 'TRANSPORTER' : 'SALE';
  const templates = all('SELECT id, name, is_default FROM email_templates WHERE purpose = ? AND active = 1 ORDER BY is_default DESC, name', purpose);
  if (q.who === 'transporter') { const t = trDraft(inv);
    return { ...t, who: 'transporter', templates, from: inv.firm.smtp_user || inv.firm.email, ready: !!(inv.firm.smtp_user && inv.firm.smtp_pass), missing: [], no_email: !t.to ? (inv.transporter || 'the transporter') : null }; }
  return { ...emailDraft(inv), who: 'buyer', templates, from: inv.firm.smtp_user || inv.firm.email, ready: !!(inv.firm.smtp_user && inv.firm.smtp_pass), missing: L.missingDispatch(inv) };
});
route('POST', '/api/invoices/:id/email', async ({ p, body }) => sendInvoiceMail(p.id, body));
async function sendInvoiceMail(id, body) {
  const inv = L.invoiceFull(id);
  if (!inv) throw new L.UserError('Invoice not found.');
  const f = inv.firm;
  const toTr = body.who === 'transporter';
  const log = (status, error, att) => run(`INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    inv.firm_code, f.name, toTr ? (inv.transporter || 'Transporter') : inv.party_name, String(body.to || ''), body.template_name || 'Standard message',
    String(inv.inv_no), toTr ? 'Invoice copy to transporter' : (body.auto ? 'Invoice (automatic)' : 'Invoice'), status, error || null, att || null);
  try {
    if (!f.smtp_user || !f.smtp_pass) throw new L.UserError(`Email is not set up for ${f.name}. Open Settings → Email.`);
    const miss = toTr ? [] : L.missingDispatch(inv);
    if (miss.length) throw new L.UserError(`Fill in ${miss.join(', ')} on the invoice and save it before emailing.`);
    const to = splitAddr(body.to), cc = splitAddr(body.cc);
    if (!to.length) throw new L.UserError(toTr ? 'Enter the transporter email address.' : 'Enter the buyer email address.');
    const a = body.attach || { invoice: 1 };
    const attachments = [], done = [];
    let file = null;
    if (a.invoice !== 0 && a.invoice !== false) { file = await makeInvoicePdf(inv.id); attachments.push({ path: file, filename: path.basename(file) }); done.push('Invoice + e-way bill'); }
    const tr = trOf(inv);
    if (a.tds && tr && tr.pan_card && inv.party_id) {
      const d = tdsCert(inv.fy, tr.id, inv.party_id);
      const tf = path.join(pdfFolder(), 'TDS', d.c.fy, safeName(`${d.tr.name} to ${d.party.name} TDS ${d.c.fy}`) + '.pdf');
      await makePdf(`http://127.0.0.1:${PORT}/print/tds/${d.c.id}?shot=1`, tf);
      attachments.push({ path: tf, filename: path.basename(tf) }); done.push('TDS declaration');
    }
    if (a.bank && tr && tr.bank_proof) { attachments.push(...trBankProofFile(tr)); done.push('Transporter bank proof'); }
    if (a.trinv && inv.tr_invoice && tr) { const tf = await makeTrInvoicePdf(inv.id); attachments.push({ path: tf, filename: path.basename(tf) }); done.push('Transporter invoice'); }
    for (const [k, kind, label] of [['test', 'TEST_REPORT', 'Test report'], ['lr', 'LR', 'L.R. copy'], ['trinv', 'TR_INVOICE', 'Transporter invoice']]) {
      if (!a[k]) continue;
      for (const d of all('SELECT * FROM invoice_docs WHERE invoice_id = ? AND kind = ?', inv.id, kind)) {
        const fp = docPath(d); if (fs.existsSync(fp)) { attachments.push({ path: fp, filename: d.name || path.basename(fp) }); done.push(label); }
      }
    }
    if (!attachments.length) throw new L.UserError('Tick at least one thing to attach.');
    await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
      { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || 'Invoice', text: body.text || '', html: body.html || null, attachments });
    const at = new Date().toLocaleString('en-IN');
    if (toTr) run('UPDATE invoices SET transporter_mail_at = ? WHERE id = ?', at, inv.id);
    else run('UPDATE invoices SET email_sent_at = ?, auto_mail_error = NULL WHERE id = ?', at, inv.id);
    if (!toTr && a.tds && tr && inv.party_id) { const c = tds.ensure(inv.fy, tr.id, inv.party_id); if (c) run('UPDATE tds_certs SET sent_buyer_at = COALESCE(sent_buyer_at, ?) WHERE id = ?', at, c.id); }
    if (!toTr && a.bank && tr && inv.party_id) run(`INSERT OR IGNORE INTO sent_docs(party_id, transporter_id, kind, at) VALUES(?,?,'BANK_PROOF',?)`, inv.party_id, tr.id, at);
    log('SENT', null, done.join(', '));
    return { sent: true, at, pdf: file };
  } catch (e) { log('FAILED', e.message); throw e; }
}

// what goes with an invoice email by default (the tick boxes of the email box)
function autoAttach(inv) {
  const tr = trOf(inv), party = inv.party || {};
  const c = tr && inv.party_id ? get('SELECT sent_buyer_at FROM tds_certs WHERE fy = ? AND transporter_id = ? AND party_id = ?', inv.fy, tr.id, inv.party_id) : null;
  const bankSent = tr && inv.party_id ? get(`SELECT 1 FROM sent_docs WHERE party_id = ? AND transporter_id = ? AND kind = 'BANK_PROOF'`, inv.party_id, tr.id) : null;
  const docs = k => !!get('SELECT 1 FROM invoice_docs WHERE invoice_id = ? AND kind = ?', inv.id, k);
  return { invoice: 1, tds: tr && tr.pan_card && !(c && c.sent_buyer_at) ? 1 : 0, bank: tr && tr.bank_proof && !bankSent ? 1 : 0,
    test: party.test_report === 'YES' && docs('TEST_REPORT') ? 1 : 0, lr: docs('LR') ? 1 : 0, trinv: inv.tr_invoice && tr ? 1 : 0 };
}
route('GET', '/api/invoices/:id/attach-options', ({ p }) => {
  const inv = L.invoiceFull(p.id); if (!inv) throw new L.UserError('Invoice not found.');
  const tr = trOf(inv), dflt = autoAttach(inv);
  const docs = all('SELECT id, kind, name FROM invoice_docs WHERE invoice_id = ? ORDER BY id', inv.id);
  const c = tr && inv.party_id ? get('SELECT sent_buyer_at FROM tds_certs WHERE fy = ? AND transporter_id = ? AND party_id = ?', inv.fy, tr.id, inv.party_id) : null;
  return { dflt, docs, has_pan: !!(tr && tr.pan_card), has_bank: !!(tr && tr.bank_proof), tds_sent: c && c.sent_buyer_at, test_needed: (inv.party || {}).test_report === 'YES', transporter: inv.transporter || '', tr_invoice: !!(inv.tr_invoice && tr) };
});
// documents of an invoice (uploaded PDF / picture)
const DOC_KINDS = { TEST_REPORT: 'Test report', LR: 'LR copy', TR_INVOICE: 'Transporter invoice' };
// a document's file: the L.R. copy is kept in the invoice PDF folder (full path); the others in the data folder
const docPath = d => path.isAbsolute(d.file) ? d.file : path.join(DATA_DIR, d.file);
route('POST', '/api/invoices/:id/docs', ({ p, body }) => {
  const inv = get('SELECT id, fy, firm_code, inv_no, lr_no, party_name, b2c_name FROM invoices WHERE id = ?', p.id); if (!inv) throw new L.UserError('Invoice not found.');
  const kind = String(body.kind || ''); if (!DOC_KINDS[kind]) throw new L.UserError('Unknown document.');
  const m = String(body.data || '').match(/^data:([^;]*);base64,(.+)$/); if (!m) throw new L.UserError('Choose a file.');
  const ext = (String(body.name || '').match(/\.([a-z0-9]{2,5})$/i) || [])[1] || (/pdf/.test(m[1]) ? 'pdf' : 'jpg');
  const bytes = Buffer.from(m[2], 'base64'); if (bytes.length > 15e6) throw new L.UserError('The file is too big (15 MB at most).');
  let rel = path.join('docs', inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} ${DOC_KINDS[kind]} ${Date.now()}`) + '.' + ext.toLowerCase());
  if (kind === 'LR') {        // next to the invoice PDF: 187_LR7027_BUYER.jpg (…_2.jpg for a second page)
    const base = safeName(`${inv.inv_no}_LR${inv.lr_no || ''}_${inv.b2c_name || inv.party_name}`).slice(0, 70);
    let n = 1, f; do { f = path.join(pdfFolder(), inv.fy, base + (n > 1 ? '_' + n : '') + '.' + ext.toLowerCase()); n++; } while (fs.existsSync(f));
    rel = f;
  }
  const full = path.isAbsolute(rel) ? rel : path.join(DATA_DIR, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, bytes);
  const name = kind === 'LR' ? path.basename(full) : safeName(`${DOC_KINDS[kind]} ${inv.firm_code} ${inv.inv_no}`) + '.' + ext.toLowerCase();
  return { id: Number(run('INSERT INTO invoice_docs(invoice_id, kind, file, name) VALUES(?,?,?,?)', inv.id, kind, rel, name).lastInsertRowid) };
});
route('DELETE', '/api/invoice-docs/:id', ({ p }) => { const d = get('SELECT * FROM invoice_docs WHERE id = ?', p.id); if (d) { try { fs.unlinkSync(docPath(d)); } catch { /* gone */ } run('DELETE FROM invoice_docs WHERE id = ?', p.id); } return { deleted: true }; });
route('GET', '/api/invoice-docs/:id', ({ p }) => { const d = get('SELECT * FROM invoice_docs WHERE id = ?', p.id); if (!d) throw new L.UserError('Not found.'); return { name: d.name, data: 'data:' + (/\.pdf$/i.test(d.file) ? 'application/pdf' : /\.png$/i.test(d.file) ? 'image/png' : 'image/jpeg') + ';base64,' + fs.readFileSync(docPath(d)).toString('base64') }; });
route('GET', '/api/invoices/:id/docs', ({ p, q }) => all('SELECT id, kind, name, file, created_at AS at FROM invoice_docs WHERE invoice_id = ? AND (? = \'\' OR kind = ?) ORDER BY id', p.id, q.kind || '', q.kind || '')
  .map(d => ({ id: d.id, kind: d.kind, name: d.name, at: d.at, where: docPath(d), pdf: /\.pdf$/i.test(d.file) })));
// Reports → Email log
route('GET', '/api/email-log', ({ q }) => all(`SELECT * FROM email_log WHERE (? = '' OR firm_code = ?) AND (? = '' OR status = ?) AND (? = '' OR substr(at, 1, 10) >= ?) AND (? = '' OR substr(at, 1, 10) <= ?)
  ORDER BY id DESC LIMIT 1000`, q.firm || '', q.firm || '', q.status || '', q.status || '', q.from || '', q.from || '', q.to || '', q.to || ''));

// Automatic invoice email (buyer option): one hour after the invoice is made, or the next time Mineral Saathi starts.
// Sent only once; if it fails it is tried again every hour.
const autoMailBusy = new Set();
// Automatic invoice copy to the transporter: only when switched on in the "Invoice copy to transporter" template (off to start with).
// Sent 10 minutes after the invoice is saved with all dispatch details, to the transporter's email in Master → Logistics → Transporters.
async function autoMailTransporter() {
  if (setting('auto_transporter_email', '0') !== '1') return;
  const stamp = d => new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19).replace('T', ' ');
  const due = all(`SELECT i.id FROM invoices i JOIN transporters t ON upper(trim(t.name)) = upper(trim(i.transporter))
    WHERE i.kind = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND COALESCE(i.legacy, 0) = 0 AND i.transporter_mail_at IS NULL AND COALESCE(t.email, '') <> ''
      AND i.created_at >= ? AND i.created_at <= ? AND i.pf_source_id IS NULL AND (i.auto_mail_try IS NULL OR i.auto_mail_try <= ?) ORDER BY i.id LIMIT 20`,
    setting('auto_transporter_email_since', '9999'), stamp(new Date(Date.now() - 10 * 60e3)), stamp(new Date(Date.now() - 3600e3)));
  for (const { id } of due) {
    const inv = L.invoiceFull(id); if (!inv || L.missingDispatch(inv).length) continue;      // dispatch details not complete yet
    if (autoMailBusy.has('t' + id)) continue; autoMailBusy.add('t' + id);
    try { const d = trDraft(inv); await sendInvoiceMail(id, { who: 'transporter', to: d.to, cc: d.cc, subject: d.subject, text: d.text, html: d.html, auto: 1, template_name: d.template_name, attach: { invoice: 1 } });
      console.log(`  Invoice copy ${inv.firm_code} ${inv.inv_no} emailed to ${inv.transporter} (automatic).`); }
    catch (e) { run('UPDATE invoices SET auto_mail_error = ? WHERE id = ?', ('Transporter: ' + e.message).slice(0, 300), id); }
    finally { autoMailBusy.delete('t' + id); }
  }
}
// Automatic invoice email (Settings → Email templates, one switch, off to start with):
// sent only when the invoice has its L.R. copy attached — 10 minutes after the last L.R. page, so all pages go together.
// The invoice email carries everything: invoice + e-way bill, L.R. copy, transporter TDS declaration and bank proof (when due).
async function autoMail() {
  await autoReminder().catch(e => console.error('Automatic payment reminder:', e.message));
  await autoMailTransporter().catch(e => console.error('Auto email to transporter:', e.message));
  if (setting('auto_invoice_email', '0') !== '1') return;
  const stamp = d => new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19).replace('T', ' ');
  const tenAgo = stamp(new Date(Date.now() - 10 * 60e3)), hourAgo = stamp(new Date(Date.now() - 3600e3)), since = setting('auto_invoice_email_since', '9999');
  const due = all(`SELECT i.id FROM invoices i JOIN parties p ON p.id = i.party_id
    WHERE i.kind = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND COALESCE(i.legacy, 0) = 0 AND i.email_sent_at IS NULL AND COALESCE(p.email, '') <> ''
      AND i.created_at >= ? AND i.pf_source_id IS NULL
      AND (SELECT MAX(created_at) FROM invoice_docs d WHERE d.invoice_id = i.id AND d.kind = 'LR') <= ?
      AND (i.auto_mail_try IS NULL OR i.auto_mail_try <= ?) ORDER BY i.id LIMIT 20`, since, tenAgo, hourAgo);
  for (const { id } of due) {
    if (autoMailBusy.has(id)) continue;
    autoMailBusy.add(id);
    run('UPDATE invoices SET auto_mail_try = ? WHERE id = ?', stamp(new Date()), id);
    try {
      const inv = L.invoiceFull(id), d = emailDraft(inv);
      await sendInvoiceMail(id, { to: inv.party && inv.party.email, subject: d.subject, text: d.text, html: d.html, auto: 1, template_name: d.template_name, attach: autoAttach(inv) });
      console.log(`  Invoice ${inv.firm_code} ${inv.inv_no} emailed to ${inv.party_name} (automatic).`);
    } catch (e) { run('UPDATE invoices SET auto_mail_error = ? WHERE id = ?', String(e.message).slice(0, 300), id); }
    finally { autoMailBusy.delete(id); }
  }
}

// road distance between two pincodes (internet needed): OpenStreetMap place search + OSRM route
const distCache = {};
async function pinPlace(pin) {
  if (distCache[pin]) return distCache[pin];
  const r = await fetch(`https://nominatim.openstreetmap.org/search?postalcode=${pin}&country=India&format=json&limit=1`,
    { headers: { 'User-Agent': 'MineralSaathi/1.0 (billing software)' }, signal: AbortSignal.timeout(8000) });
  const j = await r.json();
  if (!j.length) throw new Error('Pincode ' + pin + ' not found on the map.');
  return (distCache[pin] = { lat: Number(j[0].lat), lon: Number(j[0].lon) });
}
route('GET', '/api/distance', async ({ q }) => {
  const from = String(q.from || '').replace(/\D/g, ''), to = String(q.to || '').replace(/\D/g, '');
  if (from.length !== 6 || to.length !== 6) throw new L.UserError('Both pincodes are needed.');
  if (from === to) return { km: 0, how: 'same pincode' };
  try {
    const a = await pinPlace(from), b = await pinPlace(to);
    try {
      const r = await fetch(`https://router.project-osrm.org/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=false`, { signal: AbortSignal.timeout(10000) });
      const j = await r.json();
      if (j.routes && j.routes[0]) return { km: Math.round(j.routes[0].distance / 1000), how: 'road distance' };
    } catch { /* road service not reachable: straight line below */ }
    const R = 6371, dLat = (b.lat - a.lat) * Math.PI / 180, dLon = (b.lon - a.lon) * Math.PI / 180;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
    return { km: Math.round(2 * R * Math.asin(Math.sqrt(h)) * 1.25), how: 'approx. (straight line + 25%)' };
  } catch (e) { throw new L.UserError('Could not find the distance (is the internet on?): ' + e.message); }
});
route('POST', '/api/invoices/:id/pdf', async ({ p }) => ({ pdf: await makeInvoicePdf(p.id) }));

// ---------- invoice PDF (made after every save) and the e-way bill PDF on the next page ----------
const ewbpdf = require('./ewbpdf');
function invoicePdfName(inv) {
  const items = [...new Set(inv.items.map(i => [i.item_name, i.grade].filter(Boolean).join(' ')))].join(', ');
  const clean = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
  return clean(`${inv.inv_no}_${inv.party_name}_to_${inv.party_city || ''}_of_${items}_by_${inv.firm.name}`).slice(0, 180) + '.pdf';
}
const pdfBusy = new Map();
async function makeInvoicePdf(id) {
  if (pdfBusy.has(id)) return pdfBusy.get(id);
  const job = (async () => {
    const inv = L.invoiceFull(id); if (!inv) throw new L.UserError('Invoice not found.');
    const file = path.join(pdfFolder(), inv.fy, invoicePdfName(inv));
    const tmp = path.join(DATA_DIR, 'tmp', `inv-${id}-${Date.now()}.pdf`);
    await makePdf(`http://127.0.0.1:${PORT}/print/invoice/${inv.id}?copy=0&shot=1`, tmp);
    const ewb = inv.ewb_pdf ? path.join(DATA_DIR, inv.ewb_pdf) : null;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (ewb && fs.existsSync(ewb)) await ewbpdf.join(tmp, [ewb], file); else fs.copyFileSync(tmp, file);
    try { fs.unlinkSync(tmp); } catch { /* ignore */ }
    if (inv.pdf_file && inv.pdf_file !== file) { try { fs.unlinkSync(inv.pdf_file); } catch { /* old name */ } }
    run('UPDATE invoices SET pdf_file = ? WHERE id = ?', file, id);
    return file;
  })();
  pdfBusy.set(id, job);
  try { return await job; } finally { pdfBusy.delete(id); }
}
// the transporter's freight invoice to the buyer, kept next to the invoice PDF
async function makeTrInvoicePdf(id) {
  const inv = L.invoiceFull(id); if (!inv) throw new L.UserError('Invoice not found.');
  const tr = trOf(inv); if (!tr) throw new L.UserError('The transporter is not in the Transporters list.');
  const file = path.join(pdfFolder(), inv.fy, safeName(`${inv.inv_no}_TransporterInvoice_LR${inv.lr_no}_${tr.name}`) + '.pdf');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  await makePdf(`http://127.0.0.1:${PORT}/print/trinvoice/${inv.id}?shot=1`, file);
  if (inv.tr_invoice_pdf && inv.tr_invoice_pdf !== file) { try { fs.unlinkSync(inv.tr_invoice_pdf); } catch { /* old name */ } }
  run('UPDATE invoices SET tr_invoice_pdf = ? WHERE id = ?', file, id);
  return file;
}
function pdfSoon(id) { setTimeout(async () => {
  await makeInvoicePdf(id).catch(e => console.error('Invoice PDF:', e.message));
  if (get('SELECT tr_invoice FROM invoices WHERE id = ?', id)?.tr_invoice) await makeTrInvoicePdf(id).catch(e => console.error('Transporter invoice PDF:', e.message));
}, 800); }

// find the e-way bill PDF of an invoice (saved, or still on the screen) in the e-way bill folder
function ewbInfo(body) {
  if (body.invoice_id) {
    const inv = L.invoiceFull(body.invoice_id); if (!inv) throw new L.UserError('Invoice not found.');
    const r = L.rules(), intra = !(inv.igst > 0);
    return { inv_no: inv.inv_no, total: inv.total, intra, limit: intra ? r.ewb_intra : r.ewb_inter, firm_gstin: inv.firm.gstin, party_gstin: inv.party_gstin };
  }
  return L.invoiceDraft(body);
}
route('POST', '/api/ewb-find', async ({ body }) => {
  const info = ewbInfo(body), folder = ewbFolder();
  const hit = await ewbpdf.find(folder, info);
  return { ...info, folder, found: !!hit, ewb_no: hit && hit.ewb_no, file: hit && path.basename(hit.file), amount_ok: hit && hit.amount, can_skip: info.total <= info.limit };
});
// a PDF chosen by hand: checked the same way, then kept in the e-way bill folder until it is attached
route('POST', '/api/ewb-check', async ({ body }) => {
  const info = ewbInfo(body);
  const bytes = Buffer.from(String(body.data || '').replace(/^data:[^,]*,/, ''), 'base64');
  if (bytes.length < 100 || bytes.slice(0, 5).toString() !== '%PDF-') throw new L.UserError('That file is not a PDF.');
  const r = ewbpdf.check(await ewbpdf.pdfText(bytes), info);
  if (!r.ok) throw new L.UserError('This e-way bill does not belong to the invoice: ' + r.reasons.join('; ') + '.');
  const folder = ewbFolder(); fs.mkdirSync(folder, { recursive: true });
  const name = safeName(`EWB ${r.ewb_no} ${info.inv_no}`) + '.pdf';
  fs.writeFileSync(path.join(folder, name), bytes);
  return { ...info, found: true, ewb_no: r.ewb_no, file: name, amount_ok: r.amount };
});
// keep the e-way bill PDF with the saved invoice, take it out of the folder, and make the invoice PDF again
route('POST', '/api/invoices/:id/ewb-attach', async ({ p, body }) => {
  const inv = L.invoiceFull(p.id); if (!inv) throw new L.UserError('Invoice not found.');
  const src = path.join(ewbFolder(), path.basename(String(body.file || '')));
  if (!fs.existsSync(src)) throw new L.UserError('The e-way bill PDF is no longer in the folder.');
  const rel = path.join('ewb', inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} EWB`) + '.pdf');
  fs.mkdirSync(path.dirname(path.join(DATA_DIR, rel)), { recursive: true });
  fs.copyFileSync(src, path.join(DATA_DIR, rel));
  fs.unlinkSync(src);
  run('UPDATE invoices SET ewb_pdf = ? WHERE id = ?', rel, inv.id);
  if (body.ewb_no && !inv.ewb_no) run('UPDATE invoices SET ewb_no = ? WHERE id = ?', String(body.ewb_no).replace(/\D/g, ''), inv.id);
  return { pdf: await makeInvoicePdf(inv.id) };
});

// settings & backup
route('GET', '/api/settings', () => ({
  backup_folder: backup.folder(), pdf_folder: pdfFolder(), ewb_folder: ewbFolder(), last_backup: setting('last_backup'), edit_password_set: !!setting('edit_password_hash'), comm_password_set: !!setting('comm_password_hash'),
  last_backup_file: setting('last_backup_file'), last_backup_error: setting('last_backup_error'), backups: backup.list(), version: VERSION,
  firms: all(`SELECT id, code, name, smtp_host, smtp_port, smtp_user, CASE WHEN smtp_pass IS NULL OR smtp_pass = '' THEN 0 ELSE 1 END AS has_pass FROM firms`)
}));
route('PUT', '/api/settings', ({ body }) => {
  if (body.ewb_folder !== undefined) {
    const dir = String(body.ewb_folder).trim();
    if (!dir) throw new L.UserError('Enter the e-way bill folder.');
    try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); }
    catch { throw new L.UserError('This computer cannot write to that folder. Check the path.'); }
    savePcSettings({ ewb_folder: dir });
  }
  if (body.backup_folder !== undefined) {
    const dir = String(body.backup_folder).trim();
    if (!dir) throw new L.UserError('Enter a backup folder.');
    try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); }
    catch { throw new L.UserError('The main PC cannot write to that folder. Check the path.'); }
    setSetting('backup_folder', dir);
  }
  if (body.pdf_folder !== undefined) {
    const dir = String(body.pdf_folder).trim();
    if (dir) { try { fs.mkdirSync(dir, { recursive: true }); } catch { throw new L.UserError('Cannot use that PDF folder.'); } }
    setSetting('pdf_folder', dir || null);
  }
  return { ok: true };
});
route('PUT', '/api/settings/email/:code', ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f) throw new L.UserError('Unknown firm.');
  run('UPDATE firms SET smtp_host = ?, smtp_port = ?, smtp_user = ? WHERE id = ?', body.smtp_host || 'smtp.gmail.com', Number(body.smtp_port) || 465, body.smtp_user || null, f.id);
  if (body.smtp_pass) run('UPDATE firms SET smtp_pass = ? WHERE id = ?', String(body.smtp_pass).replace(/\s+/g, ''), f.id);
  return { ok: true };
});
route('POST', '/api/settings/email/:code/test', async ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError('Save the email and app password first.');
  await smtpSend({ host: f.smtp_host, port: f.smtp_port, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to: splitAddr(body.to || f.smtp_user), cc: [], subject: 'Mineral Saathi test email', text: 'Email from Mineral Saathi is working.' });
  return { sent: true };
});
route('POST', '/api/backup', () => ({ file: backup.backupNow('manual') }));

// Settings of THIS computer only (start with Windows, printers, label printer …).
// Kept in config.json in the program folder of this PC: not in the shared data, not touched by updates.
function pcSettings() { return readConfig().pc || {}; }
function savePcSettings(patch) { const cfg = readConfig(); cfg.pc = { ...(cfg.pc || {}), ...patch, updated: new Date().toISOString() }; writeConfig(cfg); return cfg.pc; }
route('GET', '/api/pc-settings', () => ({ pc: os.hostname(), file: path.join(APP_ROOT, 'config.json'), settings: pcSettings() }));
route('PUT', '/api/pc-settings', ({ body }) => {
  const allowed = {};
  for (const [k, v] of Object.entries(body || {})) if (/^[a-z_]{2,40}$/.test(k) && k !== 'updated') allowed[k] = v;
  return { pc: os.hostname(), settings: savePcSettings(allowed) };
});

// ---- page setup of every paper except the sales invoices (like OrderSaathi), per computer ----
const PS = require('./pagesetup')({ pcSettings, savePcSettings });
PS.register(route, { isLocal: req => isLocal(req), port: () => PORT, winprint });

// ---- printers of this computer (invoice A4, 4x6 bag sticker, envelope) ----
const PRINT_KINDS = ['invoice', 'label', 'envelope'];
function printSetup(kind) { return setupFor(kind, pcSettings()['print_' + kind]); }
function singleCopyMt() { return Number(setting('invoice_single_copy_mt', '9')) || 9; }
const isLocal = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
route('GET', '/api/print-setup', ({ req }) => ({
  pc: os.hostname(), local: isLocal(req), direct: winprint.supported(), single_copy_mt: singleCopyMt(), ewb_back: pcSettings().print_ewb_back !== false,
  papers: PAPERS, kinds: Object.fromEntries(PRINT_KINDS.map(k => [k, printSetup(k)]))
}));
route('PUT', '/api/print-setup/:kind', ({ p, body }) => {
  if (!PRINT_KINDS.includes(p.kind)) throw new L.UserError('Unknown print.');
  const keep = ['printer', 'paper', 'w', 'h', 'landscape', 'margin', 'ox', 'oy', 'scale'];
  const o = {}; for (const k of keep) if (body[k] !== undefined) o[k] = k === 'printer' || k === 'paper' ? String(body[k] || '') : (k === 'landscape' ? !!body[k] : Number(body[k]) || 0);
  savePcSettings({ ['print_' + p.kind]: o });
  return printSetup(p.kind);
});
route('PUT', '/api/print-rules', ({ body }) => { if (body.single_copy_mt != null) setSetting('invoice_single_copy_mt', String(Number(body.single_copy_mt) || 9)); return { single_copy_mt: singleCopyMt() }; });
route('GET', '/api/printers', async () => ({ supported: winprint.supported(), ...(await winprint.printers().catch(e => ({ printers: [], error: e.message }))) }));
route('GET', '/api/printers/papers', async ({ q }) => ({ papers: await winprint.papers(q.name).catch(() => []) }));

// print: straight to the printer on this computer (or on the main PC when asked), otherwise the print window
route('POST', '/api/print', async ({ body, req }) => {
  const kind = body.kind;
  if (!PRINT_KINDS.includes(kind)) throw new L.UserError('Unknown print.');
  const inv = L.invoiceFull(body.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  // an invoice made from the Orders book: once printed, the order leaves the book
  if (kind === 'invoice' && inv.order_id) run('DELETE FROM orders WHERE id = ?', inv.order_id);
  const s = kind === 'invoice' ? printSetup(kind) : PS.get(kind);
  const base = `/print/${kind}/${inv.id}`;
  let qs = '', count = 1;
  if (kind === 'invoice') count = (inv.kind === 'PPE_BILL' ? 1 : invoiceCopies(inv, singleCopyMt()).length);
  // both-side printing: the e-way bill on the back of every copy (Settings → This computer → Printers)
  const hasEwb = !!(inv.ewb_pdf && fs.existsSync(path.join(DATA_DIR, inv.ewb_pdf)));
  // the back page: the e-way bill and/or the delivery location QR (printed even without an e-way bill)
  const withEwb = kind === 'invoice' && inv.kind !== 'PPE_BILL' && pcSettings().print_ewb_back !== false && (hasEwb || !!inv.location_url);
  if (withEwb) { qs = 'ewb=1'; count *= 2; }
  if (kind === 'label') {
    const of = Math.max(1, Number(body.of) || 1), from = Math.max(1, Number(body.from) || 1), to = Math.min(of, Math.max(from, Number(body.to) || of));
    qs = `from=${from}&to=${to}&of=${of}`; count = to - from + 1;
    if (count > 300) throw new L.UserError('Print at most 300 stickers at a time.');
  }
  const direct = winprint.supported() && s.printer && (isLocal(req) || body.where === 'main');
  if (!direct) return { browser: true, url: `${base}?print=1${qs ? '&' + qs : ''}`, reason: !s.printer ? 'no-printer' : 'not-this-pc' };
  // draw at most 10 sheets per picture
  const pages = [];
  if (kind === 'label') {
    const of = Number(new URLSearchParams(qs).get('of')), from = Number(new URLSearchParams(qs).get('from')), to = Number(new URLSearchParams(qs).get('to'));
    const md = mediaFor(s);
    for (let a = from; a <= to; a += 10) { const b = Math.min(to, a + 9); pages.push({ url: `http://127.0.0.1:${PORT}${base}?shot=1&from=${a}&to=${b}&of=${of}`, w: md.w, h: md.h, count: sheetCount(s, b - a + 1), paperName: md.paperName, noTurn: md.noTurn }); }
    count = sheetCount(s, count);
  } else if (kind === 'envelope') {
    const md = mediaFor(s); count = sheetCount(s, 1);
    pages.push({ url: `http://127.0.0.1:${PORT}${base}?shot=1`, w: md.w, h: md.h, count, paperName: md.paperName, noTurn: md.noTurn });
  } else pages.push({ url: `http://127.0.0.1:${PORT}${base}?shot=1${qs ? '&' + qs : ''}`, w: s.w, h: s.h, count, wait: withEwb && hasEwb, duplex: withEwb });
  await winprint.printPages(s.printer, pages, `${inv.firm_code} ${inv.inv_no} ${kind}`);
  return { printed: true, printer: s.printer, sheets: withEwb ? count / 2 : count, both_sides: !!withEwb };
});
route('POST', '/api/print/test/:kind', async ({ p }) => {
  const s = printSetup(p.kind);
  const inv = get(`SELECT id FROM invoices WHERE kind = 'SALE' AND cancelled = 0 ORDER BY id DESC LIMIT 1`);
  if (!inv) throw new L.UserError('Make one invoice first, then test.');
  const qs = p.kind === 'label' ? '&from=1&to=1&of=1' : p.kind === 'invoice' ? '&copy=0' : '';
  await winprint.printPages(s.printer, [{ url: `http://127.0.0.1:${PORT}/print/${p.kind}/${inv.id}?shot=1${qs}`, w: s.w, h: s.h, count: 1 }], 'Mineral Saathi test');
  return { printed: true, printer: s.printer };
});

// start with Windows (a shortcut in this PC's Startup folder)
const { execFileSync } = require('node:child_process');
function startupLink() {
  const appdata = process.env.APPDATA;
  return appdata ? path.join(appdata, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Mineral Saathi Server.lnk') : null;
}
// the shortcut starts the server hidden, with its icon near the clock (windows\Start-Tray.vbs)
function makeStartupLink(lnk) {
  const vbs = path.join(APP_ROOT, 'windows', 'Start-Tray.vbs').replace(/'/g, "''");
  const dir = APP_ROOT.replace(/'/g, "''");
  const ps = `$s=(New-Object -ComObject WScript.Shell).CreateShortcut('${lnk.replace(/'/g, "''")}');$s.TargetPath='wscript.exe';$s.Arguments='"${vbs}"';$s.WorkingDirectory='${dir}';$s.Save()`;
  execFileSync('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true, stdio: 'ignore' });
}
// an old start-up shortcut that opens the black server window is changed to the tray icon (once)
setTimeout(() => {
  try {
    const lnk = startupLink();
    if (process.platform === 'win32' && lnk && fs.existsSync(lnk) && !setting('startup_tray')) { makeStartupLink(lnk); setSetting('startup_tray', '1'); }
  } catch (e) { console.error('Start-up shortcut:', e.message); }
}, 4000).unref();
route('GET', '/api/startup', () => {
  const lnk = startupLink();
  return { supported: process.platform === 'win32' && !!lnk, enabled: !!lnk && fs.existsSync(lnk), pc: os.hostname() };
});
route('PUT', '/api/startup', ({ body }) => {
  const lnk = startupLink();
  if (process.platform !== 'win32' || !lnk) throw new L.UserError('This works only on Windows.');
  if (body.enabled) {
    makeStartupLink(lnk);
  } else if (fs.existsSync(lnk)) fs.unlinkSync(lnk);
  savePcSettings({ start_with_windows: fs.existsSync(lnk) });
  return { supported: true, enabled: fs.existsSync(lnk), pc: os.hostname() };
});

// data location & one-computer-at-a-time
route('GET', '/api/data-location', ({ req }) => ({ ...lock.status(), local: isLocal(req), db_size: (() => { try { return fs.statSync(DBF).size; } catch { return 0; } })() }));
// Closing the Mineral Saathi window on this PC (with the data in a shared folder) = "Close for today".
// A page that reloads says hello again within seconds, so only a real close frees the data.
const openPages = new Set(); let closeTimer = null;
route('POST', '/api/hello', ({ body, req }) => {
  if (isLocal(req) && body.page) { openPages.add(String(body.page)); if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; } }
  return { ok: true, shared: lock.status().shared };
});
route('POST', '/api/bye', ({ body, req, q }) => {
  const id = String(body.page || q.page || '');
  if (!isLocal(req) || !lock.status().shared || !openPages.has(id)) return { ok: true };
  openPages.delete(id);
  if (!openPages.size && !closeTimer) closeTimer = setTimeout(() => {
    if (openPages.size) return;
    console.log('\n  The Mineral Saathi window was closed: closed for today. The data is free for another computer.\n');
    shutdown(2);
  }, 12000);
  return { ok: true };
});
route('POST', '/api/close', () => {
  console.log('\n  Closed for today from the app. The data is free for another computer.\n');
  setTimeout(() => shutdown(2), 500);        // Start-Server.bat closes on code 2
  return { closed: true, pc: lock.PC };
});
route('POST', '/api/data-choose', ({ req }) => {
  if (!isLocal(req)) throw new L.UserError('Do this on the computer where the Mineral Saathi server runs.');
  require('./firstrun').askNextStart();
  console.log('\n  Choosing another data folder. Restarting...\n');
  setTimeout(() => shutdown(0), 600);        // Start-Server.bat starts again and shows "Where is the data?"
  return { ok: true };
});
route('POST', '/api/data-location', ({ body }) => {
  const local = !String(body.folder || '').trim();
  const target = local ? path.join(APP_ROOT, 'data') : path.resolve(String(body.folder).trim());
  if (path.resolve(target) === path.resolve(path.dirname(DBF))) throw new L.UserError('The data is already in that folder.');
  try { fs.mkdirSync(target, { recursive: true }); fs.accessSync(target, fs.constants.W_OK); }
  catch { throw new L.UserError('This PC cannot write to that folder. Check the path.'); }
  const dest = path.join(target, 'mineral.db');
  if (fs.existsSync(dest)) {
    if (!body.replace) throw new L.UserError('That folder already has Mineral Saathi data. Tick "replace" to keep the old file aside and move the current data there.');
    const p2 = n => String(n).padStart(2, '0'); const d = new Date();
    fs.renameSync(dest, path.join(target, `mineral-before-move-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.db`));
    try { fs.unlinkSync(path.join(target, 'mineral.lock')); } catch { /* none */ }
    const mdest = path.join(target, 'marketing.db');
    if (fs.existsSync(mdest)) fs.renameSync(mdest, path.join(target, `marketing-before-move-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.db`));
  }
  try { backup.backupNow('before-move'); } catch (e) { console.error(e.message); }
  db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
  require('./marketing/db').backupInto(path.join(target, 'marketing.db'));   // Marketing data moves with it
  const cfg = readConfig();
  if (local) delete cfg.data_folder; else cfg.data_folder = target;
  writeConfig(cfg);
  console.log(`\n  Data moved to ${target}. Restarting...\n`);
  setTimeout(() => shutdown(0), 800);        // Start-Server.bat starts again with the new folder
  return { moved: true, folder: target };
});

// automatic updates
// Marketing (Sampark Saathi): its own data file marketing.db, all requests under /api/mkt/
require('./marketing/routes')(route, { printSetup, isLocal, pdfFolder, port: () => PORT, PS });
// Sample dispatch email + Master → Logistics → Postage & Couriers
require('./samplemail')(route, { smtpSend, brandLogo });

route('GET', '/api/update', () => updater.status());
route('POST', '/api/update/check', ({ body }) => updater.check({ install: !!body.install, force: !!body.install }));
route('PUT', '/api/update/settings', ({ body }) => {
  if (body.auto !== undefined) setSetting('auto_update', body.auto ? '1' : '0');
  if (body.source !== undefined) setSetting('update_source', String(body.source || '').trim() || null);
  return updater.status();
});

// import data file made from an old Excel workbook (buyers + invoices).
// Safe to run twice: existing invoice numbers are skipped, existing buyers are never moved to another firm.
route('POST', '/api/import', ({ body }) => {
  if (body.kind === 'mineral-saathi-buyer-items') return importBuyerItems(body);
  if (body.kind === 'mineral-saathi-delivery-addresses') return importAddresses(body);
  if (body.kind !== 'mineral-saathi-import' || !['PM', 'PF'].includes(body.firm_code)) throw new L.UserError('This is not a Mineral Saathi data file.');
  const firm = body.firm_code;
  const BUYER_COLS = ['gstin', 'pan', 'address', 'city', 'state', 'state_code', 'pincode', 'ship_address', 'email', 'mobile', 'phone', 'transporter', 'km', 'group_name', 'payment_terms', 'notes'];
  const rep = { buyers_added: [], buyers_filled: 0, buyers_other_firm: [], buyers_no_firm: [], invoices_added: 0, invoices_skipped: [], invoices_existing: 0 };
  const findParty = (gstin, name, city) =>
    (gstin && get('SELECT * FROM parties WHERE upper(gstin) = upper(?)', gstin)) ||
    get(`SELECT * FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, name || '', city || '') ||
    (!city ? get('SELECT * FROM parties WHERE upper(name) = upper(?)', name || '') : null);

  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      if (!b.name || (!b.gstin && !b.city && !b.address)) continue;          // skip placeholder rows like "ONLINE"
      if (b.email) b.email = String(b.email).toLowerCase();
      const ex = findParty(b.gstin, b.name, b.city);
      if (!ex) {
        const o = { name: b.name, firm_code: firm, is_b2c: b.gstin ? 0 : 1 };
        for (const c of BUYER_COLS) if (b[c] != null && b[c] !== '') o[c] = b[c];
        const keys = Object.keys(o);
        run(`INSERT INTO parties(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.buyers_added.push(`${b.name}${b.city ? ' — ' + b.city : ''}`);
        continue;
      }
      // fill only empty fields, never overwrite what is already there
      const fill = BUYER_COLS.filter(c => (ex[c] == null || ex[c] === '') && b[c] != null && b[c] !== '');
      if (fill.length) { run(`UPDATE parties SET ${fill.map(c => c + ' = ?').join(', ')} WHERE id = ?`, ...fill.map(c => b[c]), ex.id); rep.buyers_filled++; }
      if (!ex.firm_code) rep.buyers_no_firm.push(ex.name);
      else if (ex.firm_code !== firm) rep.buyers_other_firm.push(`${ex.name}${ex.city ? ' — ' + ex.city : ''}`);
    }
    for (const inv of body.invoices || []) {
      const ex = get('SELECT legacy FROM invoices WHERE firm_code = ? AND fy = ? AND inv_no = ?', firm, inv.fy, inv.inv_no);
      if (ex) { if (ex.legacy) rep.invoices_existing++; else rep.invoices_skipped.push(`${inv.fy} no. ${inv.inv_no}`); continue; }
      const p = findParty(inv.party_gstin, inv.party_name, inv.party_city);
      const cols = ['fy', 'inv_no', 'date', 'party_name', 'party_gstin', 'party_address', 'party_city', 'party_state', 'party_state_code', 'ship_address',
        'supply_type', 'lorry_no', 'transporter', 'lr_no', 'driver_phone', 'plant', 'ewb_no', 'freight_note', 'email_sent_at', 'notes', 'taxable', 'cgst', 'sgst', 'igst', 'total'];
      const r = run(`INSERT INTO invoices(firm_code, kind, legacy, round_off, party_id, party_pan, ${cols.join(',')})
                     VALUES(?, 'SALE', 1, 0, ?, ?, ${cols.map(() => '?').join(',')})`, firm, p ? p.id : null, p ? p.pan : null, ...cols.map(c => inv[c] ?? null));
      const id = Number(r.lastInsertRowid);
      (inv.items || []).forEach((it, i) => run(`INSERT INTO invoice_items(invoice_id, sl, item_name, grade, hsn, qty, unit, rate, amount, gst_rate, bags, pack_size, bag_type, lorry_no)
        VALUES(?,?,?,?,?,?,'MT',?,?,?,?,?,?,?)`, id, i + 1, it.item_name, it.grade, it.hsn, it.qty, it.rate, it.amount, it.gst_rate, it.bags, it.pack_size, it.bag_type, it.lorry_no));
      rep.invoices_added++;
    }
  });
  backup.backupSoon('import');
  return rep;
});

// delivery addresses from the old Excel buyer lists (PLANT 1 … PLANT 11). Adds only addresses the buyer does not have.
function importAddresses(body) {
  const rep = { items_added: 0, buyers_touched: 0, items_existing: 0, buyers_not_found: [] };
  const key = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      const ex = (b.gstin && get('SELECT id, address FROM parties WHERE upper(gstin) = upper(?)', b.gstin)) ||
        get(`SELECT id, address FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, b.name || '', b.city || '');
      if (!ex) { rep.buyers_not_found.push(b.name); continue; }
      const have = all('SELECT address FROM party_addresses WHERE party_id = ? AND active = 1', ex.id).map(r => key(r.address));
      let touched = false;
      for (const a of b.addresses || []) {
        if (!a.address || key(a.address) === key(ex.address) || have.includes(key(a.address))) { rep.items_existing++; continue; }
        const o = cleanAddress({ godown_name: a.godown_name, address: a.address, pincode: a.pincode || null });
        o.party_id = ex.id;
        const keys = Object.keys(o);
        run(`INSERT INTO party_addresses(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        have.push(key(a.address)); rep.items_added++; touched = true;
      }
      if (touched) rep.buyers_touched++;
    }
  });
  backup.backupSoon('import');
  return { ...rep, buyers_added: [], buyers_other_firm: [], buyers_no_firm: [], invoices_skipped: [], invoices_added: 0, buyers_filled: 0, kind: 'items' };
}

// buyer items & rates from the old Excel buyer lists. Adds only item+grade pairs the buyer does not have yet.
function importBuyerItems(body) {
  const rep = { items_added: 0, buyers_touched: 0, items_existing: 0, buyers_not_found: [] };
  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      const ex = (b.gstin && get('SELECT id FROM parties WHERE upper(gstin) = upper(?)', b.gstin)) ||
        get(`SELECT id FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, b.name || '', b.city || '');
      if (!ex) { rep.buyers_not_found.push(b.name); continue; }
      let touched = false;
      for (const it of b.items || []) {
        const o = cleanPartyItem(it);
        if (!o.item_name) continue;
        if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'')`, ex.id, o.item_name, o.grade)) { rep.items_existing++; continue; }
        o.party_id = ex.id;
        const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
        if (!o.hsn) o.hsn = m?.hsn || '2512';
        if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
        const keys = Object.keys(o);
        run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.items_added++; touched = true;
      }
      if (touched) rep.buyers_touched++;
    }
  });
  backup.backupSoon('import');
  return { ...rep, buyers_added: [], buyers_other_firm: [], buyers_no_firm: [], invoices_skipped: [], invoices_added: 0, buyers_filled: 0, kind: 'items' };
}

// reports
route('GET', '/api/reports/monthly', ({ q }) => {
  const fy = q.fy || L.fyOf();
  return {
    sales: all(`SELECT substr(date,1,7) ym, firm_code, COUNT(*) n, ROUND(SUM(qty),3) qty, ROUND(SUM(taxable)) taxable,
                ROUND(SUM(cgst+sgst+igst)) tax, ROUND(SUM(total)) total
                FROM (SELECT i.*, (SELECT SUM(qty) FROM invoice_items WHERE invoice_id = i.id) qty FROM invoices i WHERE fy = ? AND cancelled = 0)
                GROUP BY ym, firm_code ORDER BY ym, firm_code`, fy),
    inward: all(`SELECT substr(date,1,7) ym, COUNT(*) n, ROUND(SUM(rawana_wt),3) rawana, ROUND(SUM(actual_wt),3) actual, ROUND(SUM(freight_amt)) freight
                 FROM inwards WHERE fy = ? GROUP BY ym ORDER BY ym`, fy),
    hsn: all(`SELECT i.firm_code, it.hsn, it.gst_rate, ROUND(SUM(it.qty),3) qty, ROUND(SUM(it.amount),2) taxable
              FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id WHERE i.fy = ? AND i.cancelled = 0 GROUP BY 1,2,3 ORDER BY 1,2`, fy)
  };
});

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const q = Object.fromEntries(url.searchParams);
  try {
    let m;
    if ((m = url.pathname.match(/^\/print\/(invoice|label|envelope)\/(\d+)$/))) {
      const inv = L.invoiceFull(m[2]);
      if (!inv) return send(res, 404, 'Not found', 'text/plain');
      // the sales invoice keeps its own setup; bag stickers and envelope are placed by their page setup
      const opts = m[1] === 'invoice' ? { autoPrint: q.print === '1', shot: q.shot === '1', setup: printSetup(m[1]), singleFromMt: singleCopyMt() }
        : { autoPrint: q.print === '1', shot: q.shot === '1', page: PS.get(m[1]) };
      const ewbUrl = m[1] === 'invoice' && q.ewb === '1' && inv.ewb_pdf && fs.existsSync(path.join(DATA_DIR, inv.ewb_pdf)) ? `/print/ewbfile/${inv.id}` : null;
      const html = m[1] === 'invoice' ? invoiceHtml(inv, { ...opts, copy: q.copy, ewbUrl, back: q.ewb === '1' })   // ewb=1: the back page (e-way bill and/or delivery location)
        : m[1] === 'label' ? labelHtml(inv, { ...opts, from: q.from, to: q.to, of: q.of }) : envelopeHtml(inv, opts);
      return send(res, 200, html, 'text/html; charset=utf-8');
    }
    if (url.pathname.startsWith('/print/mkt/')) return require('./marketing/print').serve(url, q, res, send, PS);   // Marketing papers
    if (url.pathname.startsWith('/print/pagetest/')) return PS.serveTest(url, q, res, send);                             // page setup test
    if ((m = url.pathname.match(/^\/print\/ewbfile\/(\d+)$/))) {         // the e-way bill PDF kept with an invoice
      const r = get('SELECT ewb_pdf FROM invoices WHERE id = ?', m[1]), fp = r && r.ewb_pdf && path.join(DATA_DIR, r.ewb_pdf);
      if (!fp || !fs.existsSync(fp)) return send(res, 404, 'No e-way bill PDF', 'text/plain');
      res.writeHead(200, { 'Content-Type': 'application/pdf', 'Cache-Control': 'no-cache' }); return fs.createReadStream(fp).pipe(res);
    }
    if ((m = url.pathname.match(/^\/vendor\/(pdf\.min\.mjs|pdf\.worker\.min\.mjs)$/))) {
      res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'max-age=86400' }); return fs.createReadStream(path.join(__dirname, 'vendor', m[1])).pipe(res);
    }
    if ((m = url.pathname.match(/^\/print\/trinvoice\/(\d+)$/))) {
      const inv = L.invoiceFull(m[1]), tr = inv && trOf(inv);
      if (!inv || !tr) return send(res, 404, 'No transporter invoice for this invoice.', 'text/plain');
      return send(res, 200, trInvoiceHtml(inv, tr, { autoPrint: q.print === '1', shot: q.shot === '1', setup: setupFor('invoice', { margin: 8 }), page: PS.get('trinvoice') }), 'text/html; charset=utf-8');
    }
    if ((m = url.pathname.match(/^\/print\/wages\/(\d{4}-\d{2})$/))) {
      const d = wages.month(m[1]);
      if (!d.saved) return send(res, 400, 'Save this month in Factory Wages first.', 'text/plain; charset=utf-8');
      return send(res, 200, wagesHtml(d, get(`SELECT * FROM firms WHERE code = 'PM'`), { autoPrint: q.print === '1', shot: q.shot === '1', setup: setupFor('invoice', { margin: 12 }), page: PS.get('wages') }), 'text/html; charset=utf-8');
    }
    if ((m = url.pathname.match(/^\/print\/localfreight\/(\d+)$/))) {
      const lf = get('SELECT * FROM local_freight WHERE id = ?', m[1]), inv = lf && L.invoiceFull(lf.invoice_id);
      if (!inv) return send(res, 404, 'Not found', 'text/plain');
      return send(res, 200, localFreightHtml(inv, lf, trOf(inv) || { name: inv.transporter }, { autoPrint: q.print === '1', shot: q.shot === '1', setup: setupFor('invoice', { margin: 12 }), page: PS.get('localfreight') }), 'text/html; charset=utf-8');
    }
    if ((m = url.pathname.match(/^\/print\/proforma\/(\d+)$/))) {
      const inv = L.proformaFull(m[1]);
      if (!inv) return send(res, 404, 'Not found', 'text/plain');
      return send(res, 200, invoiceHtml(inv, { autoPrint: q.print === '1', shot: q.shot === '1', setup: printSetup('invoice') }), 'text/html; charset=utf-8');
    }
    if ((m = url.pathname.match(/^\/print\/tds\/(\d+)$/))) {
      const d = tds.data(m[1]);
      return d ? send(res, 200, tds.html(d, { shot: q.shot === '1', autoPrint: q.print === '1' }), 'text/html; charset=utf-8') : send(res, 404, 'Not found', 'text/plain');
    }
    if ((m = url.pathname.match(/^\/print\/tds$/))) {
      try { const d = tdsCert(q.fy, q.t, q.p); return send(res, 200, tds.html(d, { autoPrint: q.print === '1' }), 'text/html; charset=utf-8'); }
      catch (e) { return send(res, 400, e.message, 'text/plain; charset=utf-8'); }
    }
    if ((m = url.pathname.match(/^\/print\/voucher\/(\d+)$/))) {
      const w = get('SELECT * FROM inwards WHERE id = ?', m[1]);
      return w ? send(res, 200, voucherHtml(w, { autoPrint: q.print === '1', shot: q.shot === '1', page: PS.get('voucher') }), 'text/html; charset=utf-8') : send(res, 404, 'Not found', 'text/plain');
    }
    if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const mm = url.pathname.match(r.re);
      if (!mm) continue;
      const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {};
      if (req.method !== 'GET' && !url.pathname.startsWith('/api/update')) updater.markWrite();
      const out = await r.fn({ p: mm.groups || {}, q, body, req });
      return send(res, 200, out ?? null);
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    if (!e.status) console.error(new Date().toISOString(), req.method, req.url, e);
    send(res, e.status || 500, { error: e.status ? e.message : 'Something went wrong: ' + e.message });
  }
});

if (require.main === module) {
  server.on('error', async e => {
    if (e.code !== 'EADDRINUSE') { console.error(e); process.exit(1); }
    let ours = false;
    try { const r = await fetch(`http://127.0.0.1:${PORT}/api/version`); ours = r.ok && !!(await r.json()).version; } catch { /* not ours */ }
    if (ours) {
      console.log(`\n  Mineral Saathi server is ALREADY RUNNING on this PC (port ${PORT}).`);
      console.log('  Nothing more to do — this extra window can be closed.\n');
      process.exit(2);
    }
    console.log(`\n  Port ${PORT} is used by another program on this PC.`);
    console.log('  Close that program, or restart the PC, then start Mineral Saathi again.\n');
    process.exit(3);
  });
  server.listen(PORT, '0.0.0.0', () => {
    const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
    console.log(`\n  Mineral Saathi server ${VERSION} is running.`);
    console.log(`  On this PC:      http://localhost:${PORT}`);
    for (const ip of ips) console.log(`  On other PCs:    http://${ip}:${PORT}`);
    console.log(`  Data folder:     ${path.dirname(DBF)}${lock.status().shared ? '  (shared — one computer at a time)' : ''}`);
    console.log(`  Backups go to:   ${backup.folder()}\n  Keep this window open (you can minimise it).\n`);
  });
  server.once('listening', () => {
    lock.claim();
    lock.startHeartbeat(lk => {
      console.log(`\n  The data has been opened on "${lk.pc}". This PC stops now so nothing is overwritten.\n`);
      shutdown(2, false);
    });
    for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) process.on(sig, () => shutdown(2));
    updater.start();
    backup.startHourly();
    try { backup.backupNow('start'); } catch (e) { console.error('Start-up backup failed:', e.message); }
    // automatic invoice emails: check a minute after start, then every 10 minutes
    setTimeout(() => autoMail().catch(e => console.error('Auto email:', e.message)), 60e3);
    setInterval(() => autoMail().catch(e => console.error('Auto email:', e.message)), 10 * 60e3).unref();
  });
}

module.exports = { server, routes };
