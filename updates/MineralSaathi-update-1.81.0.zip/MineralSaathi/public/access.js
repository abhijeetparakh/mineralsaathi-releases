'use strict';
// Settings → Network & Login: let the office PCs in (also on a "Public" network) and give them an ID and password
SETTINGS.network = async box => {
  const a = await GET('/api/access');
  const n = a.main ? await GET('/api/access/network').catch(e => ({ error: e.message })) : null;
  const netCard = !a.main ? `<div class="card"><h3>Network</h3><p class="hint">The network settings can be changed only on the main PC.</p></div>`
    : n.error || !n.windows ? `<div class="card"><h3>Network</h3><p class="hint">${esc(n.error || 'Firewall settings are made on the Windows main PC.')}</p></div>`
    : `<div class="card"><h3>1. Let the office PCs reach this main PC</h3>
      <p style="margin:0 0 8px">This PC's network: ${n.nets.map(x => `<span class="badge ${x.kind === 'Public' ? 'amber' : 'PF'}">${esc(x.name || x.via)} · ${esc(x.kind)}</span>`).join(' ') || '—'}</p>
      <p style="margin:0 0 8px">Windows Firewall: ${!n.rule ? '<b style="color:var(--bad)">no Mineral Saathi rule — other PCs cannot connect</b>'
        : n.public_ok ? `<b style="color:#1e6b39">✔ open for office PCs on every network type</b> <span class="hint">(${esc(n.profiles)}; only ${esc(n.remote || 'local subnet')})</span>`
        : `<b style="color:#b45309">open only on ${esc(n.profiles)} networks — on a Public network the other PCs are blocked</b>`}</p>
      ${n.rule && n.public_ok ? '' : `<button id="nfw">🔓 Allow office PCs on this network</button>`}
      <p class="hint" style="margin:8px 0 0">You do <b>not</b> need to change the network to Private. The rule lets in only PCs of this same office network (local subnet) — not the internet — on port ${n.port}.
        After pressing the button, Windows asks <b>“Do you want to allow this app to make changes?”</b> — press <b>Yes</b>.
        Other PCs open: ${n.ips.map(ip => `<b>http://${esc(ip)}:${n.port}</b>`).join(' or ')}</p></div>`;
  box.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start"><div>${netCard}
    <div class="card"><h3>2. Ask for ID and password on the other PCs</h3>
      <label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="nreq" style="width:auto" ${a.required ? 'checked' : ''} ${a.main ? '' : 'disabled'}> Other PCs must log in</label>
      <p class="hint" style="margin:6px 0 0">The main PC itself never asks. Each user logs in once on a PC and stays logged in for 30 days (or until “Log out”, a new password, or the user is stopped).
        8 wrong tries from a PC stop it for 10 minutes. ${a.users.filter(u => u.active).length ? '' : '<b>Make a user first (right).</b>'}</p>
      ${a.me ? `<p style="margin:10px 0 0">Logged in here as <b>${esc(a.me.name || a.me.login)}</b> (${esc(a.me.login)}) · <a href="/logout">Log out</a></p>` : a.main ? '<p class="hint" style="margin:10px 0 0">This is the main PC.</p>' : ''}</div></div>
    <div class="card"><h3>Users</h3>
      ${a.main ? `<form id="nuf" class="grid g3" style="gap:8px;align-items:end" autocomplete="off" data-nocase>
        <label>User ID<input name="login" placeholder="e.g. office1" autocomplete="off"></label><label>Name<input name="name" placeholder="e.g. RAMESH"></label>
        <label>Password<input name="password" type="password" autocomplete="new-password" placeholder="6 or more"></label>
        <div class="row" style="grid-column:1 / -1"><button type="submit" id="nusave">Add user</button><button type="button" class="sec" id="nucancel" hidden>Cancel</button></div></form>` : '<p class="hint">Users are made on the main PC.</p>'}
      <table class="t" style="margin-top:10px"><thead><tr><th>User ID</th><th>Name</th><th>Status</th><th style="width:210px"></th></tr></thead><tbody>
      ${a.users.map(u => `<tr><td><b>${esc(u.login)}</b></td><td>${esc(u.name || '')}</td><td>${u.active ? '<span class="badge PF">active</span>' : '<span class="badge grey">stopped</span>'}</td>
        <td style="white-space:nowrap">${a.main ? `<button class="small sec" data-ued="${u.id}">Change</button> <button class="small sec" data-uact="${u.id}:${u.active ? 0 : 1}">${u.active ? 'Stop' : 'Start'}</button> <button class="small sec" data-udel="${u.id}">Remove</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No user yet.</td></tr>'}</tbody></table>
      <p class="hint">Change = new name or password (the user is logged out everywhere). Stop = cannot log in, data kept.</p></div></div>`;
  const fw = $('#nfw', box); if (fw) fw.onclick = async () => { await guard(() => POST('/api/access/firewall'));
    toast('Press “Yes” in the Windows window on this PC'); setTimeout(() => SETTINGS.network(box), 6000); };
  const rq = $('#nreq', box); if (rq) rq.onchange = async () => { try { await PUT('/api/access', { required: rq.checked ? 1 : 0 }); toast(rq.checked ? 'Other PCs must now log in' : 'Other PCs open without login'); } catch (e) { toast(e.message, true); rq.checked = !rq.checked; } };
  const f = $('#nuf', box); let editing = null;
  if (f) {
    f.onsubmit = async e => { e.preventDefault(); const v = formData(f);
      await guard(() => editing ? PUT('/api/access/users/' + editing, v) : POST('/api/access/users', v)); toast(editing ? 'User changed' : 'User added'); SETTINGS.network(box); };
    $('#nucancel', box).onclick = () => SETTINGS.network(box);
  }
  box.querySelector('table.t').onclick = async e => {
    const ed = e.target.closest('[data-ued]'), ac = e.target.closest('[data-uact]'), dl = e.target.closest('[data-udel]');
    if (ed) { const u = a.users.find(x => x.id === Number(ed.dataset.ued)); editing = u.id; f.login.value = u.login; f.name.value = u.name || ''; f.password.value = ''; f.password.placeholder = 'leave blank to keep';
      $('#nusave', box).textContent = 'Save'; $('#nucancel', box).hidden = false; f.name.focus(); }
    if (ac) { const [id, v] = ac.dataset.uact.split(':'); await guard(() => PUT('/api/access/users/' + id, { active: Number(v) })); SETTINGS.network(box); }
    if (dl && confirm('Remove this user?')) { await guard(() => DEL('/api/access/users/' + dl.dataset.udel)); SETTINGS.network(box); }
  };
};
// a logged-in user on another PC sees who is logged in, with Log out, at the bottom left
GET('/api/access').then(a => { if (a.me) { const sf = $('#sidefoot'); if (sf) sf.insertAdjacentHTML('beforebegin', `<div class="sidefoot" style="border-top:0">👤 ${esc(a.me.name || a.me.login)} · <a href="/logout" style="color:inherit">Log out</a></div>`); } }).catch(() => {});
