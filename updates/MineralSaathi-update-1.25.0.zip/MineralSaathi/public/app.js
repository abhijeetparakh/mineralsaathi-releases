'use strict';
/* Mineral Saathi — screens. Loaded from the main PC, so every PC always runs the latest version. */

// ---------- small helpers ----------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rs = n => '₹ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');
const qty = n => n == null || n === '' ? '' : (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 });
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const FIRM_NAME = { PPE: 'P.P. Enterprise', PM: 'Parakh Marketing', PF: 'Parakh Fertilizer' };

const S = { meta: null, fy: null, dirty: false, version: null, parties: null, items: null };

async function api(method, url, body) {
  const headers = body ? { 'Content-Type': 'application/json' } : {};
  if (S.commPw && url.startsWith('/api/commission')) headers['X-Comm-Pw'] = encodeURIComponent(S.commPw);
  const r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null;
  try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) throw new Error((data && data.error) || 'Could not reach the main PC. Is the Mineral Saathi server running?');
  return data;
}
const GET = u => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b), DEL = u => api('DELETE', u);

let toastT;
function toast(msg, err) {
  const t = $('#toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, err ? 6000 : 3000);
}
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, true); throw e; } }

function modal(title, html, mount) {
  $('#mtitle').textContent = title; $('#mbody').innerHTML = html; $('#modal').hidden = false;
  if (mount) mount($('#mbody'));
  const first = $('#mbody input, #mbody select, #mbody textarea'); if (first) first.focus();
}
function closeModal() { $('#modal').hidden = true; $('#mbody').innerHTML = ''; }
// Saved invoices are changed or cancelled only with the edit password (Settings → Security). Resolves to the password, or null.
function askEditPassword(what = 'edit this invoice') {
  return new Promise(resolve => {
    let done = false;
    modal('Edit password', `<form id="epf"><p>Enter the edit password to ${esc(what)}.</p>
      <label>Password<input name="pw" type="password" autocomplete="off"></label>
      <div class="row" style="margin-top:12px"><button type="submit">OK</button><span class="hint">Set or change it in Settings → Security.</span></div></form>`, root => {
      $('#epf', root).onsubmit = async e => {
        e.preventDefault(); const pw = e.target.pw.value;
        try { await POST('/api/edit-password/check', { password: pw }); done = true; closeModal(); resolve(pw); }
        catch (err) { toast(err.message, true); e.target.pw.select(); }
      };
    });
    const obs = new MutationObserver(() => { if ($('#modal').hidden) { obs.disconnect(); if (!done) resolve(null); } });
    obs.observe($('#modal'), { attributes: true, attributeFilter: ['hidden'] });
  });
}
$('#mclose').onclick = closeModal;
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

function formData(root) {
  const o = {};
  $$('[name]', root).forEach(el => { o[el.name] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value.trim(); });
  return o;
}
function field(f, v) {
  const val = v ?? f.def ?? '';
  const cls = f.span ? `class="span${f.span}"` : '';
  if (f.type === 'select') return `<label ${cls}>${esc(f.label)}<select name="${f.name}" ${f.disabled ? 'disabled' : ''}>${(f.options || []).map(o => {
    const [k, t] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(k)}" ${String(k) === String(val) ? 'selected' : ''}>${esc(t)}</option>`; }).join('')}</select></label>`;
  if (f.type === 'textarea') return `<label ${cls}>${esc(f.label)}<textarea name="${f.name}">${esc(val)}</textarea></label>`;
  return `<label ${cls}>${esc(f.label)}<input name="${f.name}" type="${f.type || 'text'}" value="${esc(val)}" ${f.list ? `list="${f.list}"` : ''} ${f.step ? `step="${f.step}"` : ''} ${f.ro ? 'readonly' : ''}></label>`;
}
function datalist(id, values) { return `<datalist id="${id}">${[...new Set(values.filter(Boolean))].map(v => `<option value="${esc(v)}">`).join('')}</datalist>`; }
function markDirty(root) { root.addEventListener('input', () => { S.dirty = true; }); }

function downloadCsv(name, rows) {
  if (!rows.length) return toast('Nothing to export.', true);
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(','))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = name; a.click();
}

// Saves a file. Where the browser allows it, the save window opens on the Desktop with the name filled in.
async function saveToDesktop(name, text) {
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name, startIn: 'desktop', types: [{ description: 'JSON file', accept: { 'application/json': ['.json'] } }] });
      const w = await h.createWritable(); await w.write(text); await w.close();
      toast(`Saved ${h.name} — upload it on the e-way bill portal`); return;
    } catch (e) { if (e.name === 'AbortError') return; }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; a.click();
  toast(`${name} downloaded — upload it on the e-way bill portal`);
}

// pick-lists (Items → Item lists)
const LISTS = [
  ['product', 'Item name', 'The products you sell'],
  ['colour', 'Item colour', 'Yellow, white …'],
  ['mesh', 'Mesh size', '150, 300, 325 …'],
  ['form', 'Item form', 'Powder, granules, chips …'],
  ['bag_type', 'Bag type', 'Plain, DEE-E, yellow DEE-E …'],
  ['bag_weight', 'Bag weight (kg)', 'Kg in one bag'],
  ['packing_type', 'Packing type', 'With / without liner …'],
  ['hsn', 'HSN code', 'Code, description and GST %'],
  ['gst_rate', 'GST rate %', 'Tax rates'],
  ['unit', 'Unit', 'MT, KG, bags …'],
  ['condition', 'Inward condition', 'Raw, broken …'],
  ['mines', 'Mines', 'Where material comes from'],
  ['freight_mode', 'Freight payment mode', 'To pay, paid, door delivery … (on the invoice)'],
  ['agent', 'Commission agent', 'People who get commission (buyer items) 🔒'],
  ['plants', 'Plants', 'PPI PLANT, KI PLANT and their address'],
  ['fixed_expense', 'Factory fixed expenses', 'Monthly fixed expenses of each plant (Factory wages)']
];
// lists with an extra number / note column
const LIST_EXTRA = { hsn: { note: 'Description', num: 'GST %' }, form: { num: 'Factory wages ₹ / MT' } };
async function loadLists(force) { if (!S.lists || force) S.lists = await GET('/api/lists'); return S.lists; }
const lv = key => (S.lists && S.lists[key] || []).map(x => x.value);

async function loadParties(force) { if (!S.parties || force) S.parties = await GET('/api/m/parties?limit=2000'); return S.parties; }
async function loadItems(force) { if (!S.items || force) S.items = await GET('/api/m/items'); return S.items; }

// ---------- packing (who gives the bags, liner) ----------
const PACKING = [['', '—'], ['OUR|0', 'Our bags'], ['OUR|1', 'Our bags + liner'], ['BUYER|0', "Buyer's bags"], ['BUYER|1', "Buyer's bags + liner"]];
const BAG_TYPES = ['PLAIN', 'PLAIN LAMINATED', 'PLAIN BAGS WITH LINER', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'PRINTED LAMINATED', '4 COLOUR LAMINATED BAGS', 'ORGASIL', 'VEDANT', 'IDEAL'];
const packKey = (supply, liner) => supply ? `${supply}|${liner ? 1 : 0}` : '';
const packText = (supply, liner) => [supply === 'BUYER' ? "buyer's bags" : supply === 'OUR' ? 'our bags' : '', liner === 1 ? 'with liner' : liner === 0 && supply ? 'no liner' : ''].filter(Boolean).join(' · ');

// House rules while typing:
//  e-mail → small letters · lorry no. → capitals without spaces · pincode / phone → numbers only
//  (amounts and weights are number boxes, so they only take numbers)
const RULES = [
  ['input[name=email], input[name=to], input[name=cc], input[name=smtp_user]', v => v.toLowerCase()],
  ['input[name=lorry_no], input[data-k=lorry_no]', v => v.toUpperCase().replace(/[^A-Z0-9,]/g, '')],
  ['input[name=pincode], input[name=party_pincode]', v => v.replace(/\D/g, '').slice(0, 6)],
  ['input[name=phone], input[name=mobile], input[name=driver_phone]', v => v.replace(/[^0-9,]/g, '')],
  ['input[name=ewb_no]', v => v.replace(/\D/g, '').slice(0, 12)],
  ['input[name=gstin], input[name=party_gstin], input[name=transporter_gstin]', v => v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 15)],
  ['input[name=pan]', v => v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10)]
];
document.addEventListener('input', e => {
  const el = e.target;
  if (!el.matches || el.type === 'number') return;
  for (const [sel, fn] of RULES) {
    if (!el.matches(sel)) continue;
    const nv = fn(el.value);
    if (nv !== el.value) { const pos = Math.max(0, (el.selectionStart || 0) - (el.value.length - nv.length)); el.value = nv; try { el.setSelectionRange(pos, pos); } catch { } }
    break;
  }
});
document.addEventListener('focusin', e => { const el = e.target; if (el.matches && el.matches('input[name=pincode], input[name=phone], input[name=mobile], input[name=driver_phone]')) el.inputMode = 'numeric'; });

// city and state filled from the pincode
function hookPincode(root) {
  const pin = $('[name=pincode]', root), city = $('[name=city]', root), state = $('[name=state]', root);
  if (!pin || !city || !state) return;
  pin.addEventListener('input', async () => {
    const v = pin.value.replace(/\D/g, '');
    if (v.length !== 6) return;
    const r = await GET('/api/pincode/' + v).catch(() => null);
    if (!r || !r.found) { toast('Pincode not found in the list — type city and state.', true); return; }
    city.value = r.city;
    if (state.tagName === 'SELECT' && ![...state.options].some(o => o.value === r.state)) state.add(new Option(r.state, r.state));
    state.value = r.state;
    if ($('[name=state_code]', root)) $('[name=state_code]', root).value = r.state_code || '';
    toast(`${r.city}, ${r.state}`);
  });
}

// ---------- router ----------
const PAGES = {};
const TITLES = { itemlists: 'Item lists', dashboard: 'Dashboard', inward: 'Inward & Freight', ppe: 'P.P. Enterprise → Parakh Marketing Bills', invoices: 'Sales Invoices',
  newinvoice: 'New Sales Invoice', invoice: 'Sales Invoice', buyers: 'Buyers', masters: 'Masters', reports: 'Reports', settings: 'Settings & Backup' };

function go(hash) { location.hash = hash; }
async function route() {
  const [page, arg] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/');
  const fn = PAGES[page] || PAGES.dashboard;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.page === page));
  $('#title').textContent = TITLES[page] || 'Mineral Saathi';
  S.dirty = false;
  if (!(page === 'invoice' && S.unlock && String(S.unlock.id) === arg)) S.unlock = null;   // the unlock is for one invoice only
  if (page !== 'commission') S.commPw = null;                                              // leaving Commission locks it again
  const old = $('#page'), fresh = old.cloneNode(false); old.replaceWith(fresh);   // drop listeners of the previous screen
  fresh.innerHTML = '<div class="empty">Loading…</div>';
  try { await fn($('#page'), arg); } catch (e) { $('#page').innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', route);
$$('#nav a').forEach(a => a.onclick = () => {
  if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return;
  S.dirty = false;
  if (location.hash === '#/' + a.dataset.page) route(); else go('#/' + a.dataset.page);
});
window.addEventListener('beforeunload', e => { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });

// ---------- dashboard ----------
PAGES.dashboard = async (el) => {
  const d = await GET('/api/dashboard?fy=' + S.fy);
  const by = (arr, k) => arr.find(x => x.firm_code === k) || {};
  el.innerHTML = `
  <div class="stats">
    <div class="stat"><div class="k">Parakh Marketing · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PM').total)}</div><div class="s">${by(d.sales, 'PM').n || 0} invoices · this month ${rs(by(d.month_sales, 'PM').total)}</div></div>
    <div class="stat slate"><div class="k">Parakh Fertilizer · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PF').total)}</div><div class="s">${by(d.sales, 'PF').n || 0} invoices · this month ${rs(by(d.month_sales, 'PF').total)}</div></div>
    <div class="stat rust"><div class="k">P.P. Enterprise bills · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PPE').total)}</div><div class="s">${by(d.sales, 'PPE').n || 0} bills to Parakh Marketing</div></div>
    <div class="stat amber"><div class="k">Inward · ${esc(d.fy)}</div><div class="v">${qty(d.inward.actual)} MT</div><div class="s">${d.inward.n} lorries · rawana ${qty(d.inward.rawana)} MT · freight ${rs(d.inward.freight)}</div></div>
  </div>
  <div class="grid g2">
    <div class="card"><h3>Waiting for P.P. Enterprise bill</h3>
      <p><b style="font-size:22px">${d.unbilled.n}</b> lorries · ${qty(d.unbilled.qty)} MT rawana weight</p>
      <button onclick="go('#/ppe')">Make bill</button> <button class="sec" onclick="go('#/inward')">New inward</button> <button class="sec" onclick="go('#/newinvoice')">New sales invoice</button></div>
    <div class="card"><h3>Backup</h3>
      <p>Last backup: <b>${d.last_backup ? new Date(d.last_backup).toLocaleString('en-IN') : 'not yet'}</b></p>
      ${d.backup_error ? `<p class="badge red">Last error: ${esc(d.backup_error)}</p>` : ''}
      <button class="sec" onclick="go('#/settings')">Backup settings</button></div>
  </div>
  <div class="card"><h3>Latest invoices</h3><table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th class="num">Total</th></tr></thead><tbody>
    ${d.recent.map(r => `<tr class="click" onclick="openInvoice(${r.id}, '${r.kind}')"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${r.inv_no}</td><td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td class="num">${money(r.total)}</td></tr>`).join('')}
  </tbody></table></div>`;
};

function openInvoice(id, kind) {
  if (kind === 'PPE_BILL') return window.open('/print/invoice/' + id, '_blank');
  go('#/invoice/' + id);
}

// ---------- inward ----------
PAGES.inward = async (el) => {
  el.innerHTML = `<div class="toolbar"><button id="newin">+ New inward (Ctrl+N)</button>
    <input type="search" id="q" placeholder="Search lorry, voucher, rawana, supplier, owner…">
    <div class="tabs" id="st"><button data-s="" class="on">All</button><button data-s="unbilled">Not billed</button><button data-s="billed">Billed</button></div>
    <span class="spacer"></span><button class="sec" id="csv">Export</button><button class="sec small" id="togact" title="Show / hide actual weight"></button></div>
    <div class="tablewrap" id="list"></div>`;
  let status = '', rows = [];
  const showAct = () => { try { return localStorage.getItem('ms_show_actual') === '1'; } catch { return false; } };
  const setTog = () => { $('#togact').textContent = showAct() ? '👁 Hide actual wt' : '👁 Show actual wt'; };
  setTog();
  $('#togact').onclick = () => { try { localStorage.setItem('ms_show_actual', showAct() ? '0' : '1'); } catch { } setTog(); load(); };
  const load = async () => {
    rows = await GET(`/api/inwards?fy=${S.fy}&status=${status}&q=${encodeURIComponent($('#q').value)}`);
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Voucher</th><th>Received</th><th>From</th><th>To</th><th>Lorry</th><th>Grade</th><th>Plant</th><th>Rawana no.</th>
      <th class="num">Rawana wt</th>${showAct() ? '<th class="num">Actual wt</th>' : ''}<th class="num">Rate</th><th class="num">Freight</th><th>PPE bill</th><th></th></tr></thead><tbody>
      ${rows.map(w => `<tr class="click" data-id="${w.id}"><td><b>${esc(w.voucher_no)}</b></td><td>${dmy(w.date)}</td><td>${esc(w.supplier)}</td><td>${esc(w.to_party || '')}</td><td>${esc(w.lorry_no)}</td>
      <td>${esc(w.grade)}</td><td>${esc(w.plant)}</td><td>${esc(w.rawana_no)}</td><td class="num">${qty(w.rawana_wt)}</td>${showAct() ? `<td class="num">${qty(w.actual_wt)}</td>` : ''}
      <td class="num">${money(w.freight_rate)}</td><td class="num">${money(w.freight_amt)}</td>
      <td>${w.ppe_inv_no ? `<span class="badge PPE">No. ${w.ppe_inv_no}</span>` : (/ENTERPRISE/i.test(w.supplier || '') ? '<span class="badge amber">pending</span>' : '')}</td>
      <td><button class="small sec" data-print="${w.id}">Voucher</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">No inward entries.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#st button').forEach(b => b.onclick = () => { $$('#st button').forEach(x => x.classList.remove('on')); b.classList.add('on'); status = b.dataset.s; load(); });
  $('#list').onclick = e => {
    const p = e.target.closest('[data-print]'); if (p) { e.stopPropagation(); return window.open('/print/voucher/' + p.dataset.print, '_blank'); }
    const tr = e.target.closest('tr[data-id]'); if (tr) inwardForm(Number(tr.dataset.id), load);
  };
  $('#newin').onclick = () => chooseVoucherFirm(load);
  $('#csv').onclick = () => downloadCsv(`inward_${S.fy}.csv`, rows);
  await load();
};

async function chooseVoucherFirm(after) {
  const [ppe, pm] = await Promise.all([GET(`/api/inwards/next?fy=${S.fy}&firm=PPE`), GET(`/api/inwards/next?fy=${S.fy}&firm=PM`)]);
  modal('New inward — which firm makes the freight voucher?', `
    <div class="grid g2">
      <button class="rust" style="padding:22px;font-size:17px" data-f="PPE">P.P. Enterprise<br><small style="font-weight:400">Goods sent by P.P. Enterprise to Parakh Marketing · freight paid by P.P. Enterprise<br>Next voucher <b>${esc(ppe.voucher_no)}</b></small></button>
      <button style="padding:22px;font-size:17px" data-f="PM">Parakh Marketing<br><small style="font-weight:400">Parakh Marketing buys from another supplier · freight paid by Parakh Marketing<br>Next voucher <b>${esc(pm.voucher_no)}</b></small></button>
    </div>`, root => {
    root.onclick = e => { const b = e.target.closest('[data-f]'); if (b) { closeModal(); inwardForm(null, after, b.dataset.f); } };
    $('button', root).focus();
  });
}

async function inwardForm(id, after, vfirm, pw) {
  const [w, suppliers] = await Promise.all([id ? GET('/api/inwards/' + id) : null, GET('/api/m/suppliers'), loadLists()]);
  const v = w || { date: today(), condition: 'RAW', mines: 'BADIARA', plant: S.meta.plants[0]?.name, supplier: vfirm === 'PPE' ? 'P.P.ENTERPRISE' : '', to_party: 'PARAKH MARKETING' };
  if (w) vfirm = /^PPE/i.test(w.voucher_no) ? 'PPE' : 'PM';
  const next = !w ? (await GET(`/api/inwards/next?fy=${S.fy}&firm=${vfirm}`)).voucher_no : null;
  const plants = S.meta.plants.map(p => p.name);
  modal(`${id ? 'Inward ' + v.voucher_no : 'New inward'} — freight voucher by ${FIRM_NAME[vfirm]}`, `
  <form id="inf" autocomplete="off">
    ${datalist('dl-sup', suppliers.map(s => s.name))}${datalist('dl-grade', ['YELLOW', 'WHITE', 'GYPSUM', 'ZEOCLAY', 'BENTONITE', 'SM', 'B-GRADE'])}
    <div class="grid g4">
      ${field({ name: 'voucher_no', label: `Voucher no. (${FIRM_NAME[vfirm]})`, ro: true }, v.voucher_no || next)}
      ${field({ name: 'date', label: 'Date received', type: 'date' }, v.date)}
      ${field({ name: 'supplier', label: vfirm === 'PPE' ? 'From' : 'From (supplier)', list: 'dl-sup', ro: vfirm === 'PPE' }, vfirm === 'PPE' ? 'P.P.ENTERPRISE' : v.supplier)}
      ${field({ name: 'to_party', label: 'To', ro: true }, v.to_party || 'PARAKH MARKETING')}
      ${field({ name: 'mines', label: 'Mines', list: 'dl-mines' }, v.mines)}${datalist('dl-mines', lv('mines'))}
      ${field({ name: 'lorry_no', label: 'Lorry no.' }, v.lorry_no)}
      ${field({ name: 'grade', label: 'Grade', list: 'dl-grade' }, v.grade)}
      ${field({ name: 'condition', label: 'Condition', type: 'select', options: lv('condition').length ? lv('condition') : ['RAW'] }, v.condition)}
      ${field({ name: 'plant', label: 'Plant', type: 'select', options: plants }, v.plant)}
      ${field({ name: 'rawana_no', label: 'Rawana no.' }, v.rawana_no)}
      ${field({ name: 'challan_no', label: 'Challan no.' }, v.challan_no)}
      ${field({ name: 'rawana_wt', label: 'Rawana weight (MT)', type: 'number', step: '0.001' }, v.rawana_wt)}
      ${field({ name: 'actual_wt', label: 'Actual weight received (MT)', type: 'number', step: '0.001' }, v.actual_wt)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div class="freightbox">
        <div class="grid g2">${field({ name: 'freight_rate', label: 'Freight rate per MT (on actual weight)', type: 'number', step: '0.01' }, v.freight_rate)}
          ${field({ name: 'advance', label: 'Advance paid', type: 'number', step: '0.01' }, v.advance)}</div>
        <div style="margin-top:10px">Freight to pay = actual weight × rate = <span class="big" id="famt">₹ 0</span></div>
        <div class="hint" id="fshow">Voucher will show: rawana weight × adjusted rate</div>
      </div>
      <div class="grid g3">
        ${field({ name: 'cash_amt', label: 'Paid cash', type: 'number', step: '0.01' }, v.cash_amt)}
        ${field({ name: 'bank_amt', label: 'Paid bank', type: 'number', step: '0.01' }, v.bank_amt)}
        ${field({ name: 'pay_mode', label: 'Bank / mode', list: 'dl-mode' }, v.pay_mode)}
        ${field({ name: 'chq_no', label: 'Cheque / UTR' }, v.chq_no)}
        ${field({ name: 'upi', label: 'UPI / account', span: 2 }, v.upi)}
        ${datalist('dl-mode', ['KOTAK / ONLINE', 'IDBI / ONLINE', 'BOTH / ONLINE', 'CASH'])}
      </div>
    </div>
    <div class="grid g4" style="margin-top:12px">
      ${field({ name: 'owner_name', label: 'Lorry owner' }, v.owner_name)}
      ${field({ name: 'pan', label: 'Owner PAN' }, v.pan)}
      ${field({ name: 'driver_name', label: 'Driver name' }, v.driver_name)}
      ${field({ name: 'driver_phone', label: 'Driver phone' }, v.driver_phone)}
      ${field({ name: 'royalty', label: 'Royalty', type: 'number', step: '0.01' }, v.royalty)}
      ${field({ name: 'dmft', label: 'DMFT', type: 'number', step: '0.01' }, v.dmft)}
      ${field({ name: 'nmet', label: 'NMET', type: 'number', step: '0.01' }, v.nmet)}
      ${field({ name: 'remarks', label: 'Remarks' }, v.remarks)}
    </div>
    ${v.ppe_invoice_id ? '<p class="badge PPE" style="margin-top:10px">Billed by P.P. Enterprise — rawana weight is locked</p>' : ''}
    ${id && !pw ? `<div class="row" style="margin-top:16px"><button type="button" id="unlockin">🔒 Edit voucher</button><button type="button" class="sec" id="printin">🖨 Print voucher</button>
      <span class="hint">Saved voucher — locked. Editing or deleting needs the edit password.</span></div>`
    : `<div class="row" style="margin-top:16px"><button type="submit">Save</button><button type="button" class="sec" id="saveprint">Save & print voucher</button>
      ${id ? '<span class="hint">🔓 Unlocked with the edit password</span>' : ''}<span class="spacer"></span>${id && !v.ppe_invoice_id ? '<button type="button" class="sec" id="delin">Delete</button>' : ''}</div>`}
  </form>`, root => {
    const f = $('#inf', root);
    if (id && !pw) {                                   // locked: view and print only
      $$('input, select, textarea', f).forEach(x => x.disabled = true);
      $('#printin', root).onclick = () => window.open('/print/voucher/' + id + '?print=1', '_blank');
      $('#unlockin', root).onclick = async () => { const p2 = await askEditPassword('edit this voucher'); if (p2 != null) inwardForm(id, after, vfirm, p2); };
    }
    const calc = () => {
      const d = formData(f);
      const amt = r2((+d.actual_wt || 0) * (+d.freight_rate || 0));
      const shown = +d.rawana_wt ? r2(amt / +d.rawana_wt) : 0;
      $('#famt').textContent = '₹ ' + money(amt);
      $('#fshow').textContent = +d.rawana_wt ? `Voucher will show: ${qty(d.rawana_wt)} MT @ ₹${money(shown)} = ₹${money(amt)}` : 'Enter rawana weight to see the voucher rate';
    };
    f.addEventListener('input', calc); calc();
    if (v.ppe_invoice_id) f.rawana_wt.readOnly = true;
    f.lorry_no.addEventListener('change', async () => {
      const no = f.lorry_no.value.trim(); if (!no) return;
      const r = await GET('/api/lorry/' + encodeURIComponent(no));
      const fill = (k, val) => { if (val && !f[k].value) f[k].value = val; };
      if (r.lorry) { fill('owner_name', r.lorry.owner); fill('pan', r.lorry.pan); fill('driver_name', r.lorry.driver_name); fill('driver_phone', r.lorry.driver_phone); fill('upi', r.lorry.upi); }
      if (r.last) { [...(vfirm === 'PPE' ? [] : ['supplier']), 'mines', 'grade', 'owner_name', 'pan', 'driver_name', 'driver_phone', 'upi', 'freight_rate'].forEach(k => fill(k, r.last[k])); if (r.last.plant) f.plant.value = r.last.plant; }
      calc();
    });
    f.supplier.addEventListener('change', () => { const s = suppliers.find(x => x.name === f.supplier.value); if (s) { if (!f.grade.value) f.grade.value = s.grade || ''; if (!f.freight_rate.value && s.freight_rate) f.freight_rate.value = s.freight_rate; calc(); } });
    const save = async (print) => {
      const d = formData(f); delete d.voucher_no; d.voucher_firm = vfirm; if (id) d.edit_password = pw;
      const r = await guard(() => id ? PUT('/api/inwards/' + id, d) : POST('/api/inwards', d));
      toast('Inward saved'); closeModal(); if (print) window.open('/print/voucher/' + r.id + '?print=1', '_blank'); after && after();
    };
    f.onsubmit = e => { e.preventDefault(); save(false); };
    const sp = $('#saveprint', root); if (sp) sp.onclick = () => save(true);
    const del = $('#delin', root); if (del) del.onclick = async () => { if (confirm('Delete this inward entry?')) { await guard(() => DEL('/api/inwards/' + id + '?pw=' + encodeURIComponent(pw))); closeModal(); after && after(); } };
  });
}

// ---------- P.P. Enterprise bills ----------
PAGES.ppe = async (el) => {
  const [pending, bills] = await Promise.all([
    GET(`/api/inwards?fy=${S.fy}&status=unbilled&supplier=ENTERPRISE`),
    GET(`/api/invoices?fy=${S.fy}&firm=PPE`)
  ]);
  const lastRate = bills.length ? (await GET('/api/invoices/' + bills[0].id)).items[0]?.rate : '';
  el.innerHTML = `
  <div class="card"><h3>1 · Tick the lorries received from P.P. Enterprise</h3>
    <p class="hint">The bill uses the <b>rawana weight</b>. Freight was already paid on the actual weight in the inward entry.</p>
    ${pending.length ? `<div class="tablewrap" style="max-height:340px"><table class="t"><thead><tr><th><input type="checkbox" id="all"></th><th>Voucher</th><th>Received</th><th>Lorry</th><th>Grade</th><th>Rawana no.</th><th>Challan</th><th class="num">Rawana wt</th><th class="num">Actual wt</th></tr></thead><tbody>
      ${pending.map(w => `<tr><td><input type="checkbox" class="pick" value="${w.id}" data-q="${w.rawana_wt}"></td><td>${esc(w.voucher_no)}</td><td>${dmy(w.date)}</td><td><b>${esc(w.lorry_no)}</b></td><td>${esc(w.grade)}</td><td>${esc(w.rawana_no)}</td><td>${esc(w.challan_no)}</td><td class="num">${qty(w.rawana_wt)}</td><td class="num">${qty(w.actual_wt)}</td></tr>`).join('')}
    </tbody></table></div>` : '<div class="empty">All P.P. Enterprise lorries of this year are billed.</div>'}
  </div>
  <div class="card"><h3>2 · Bill details</h3>
    <div class="row">
      <label style="width:160px">Bill date<input type="date" id="bdate" value="${today()}"></label>
      <label style="width:160px">Rate per MT<input type="number" id="brate" step="0.01" value="${esc(lastRate || '')}"></label>
      <label style="width:110px">GST %<input type="number" id="bgst" value="5"></label>
      <label style="width:280px">Item<input id="bitem" value="DIATOMACEOUS EARTH (RAW)"></label>
      <div class="totals" id="btot" style="margin-left:auto"></div>
    </div>
    <div class="row" style="margin-top:14px"><button id="mk">Create bill & print</button></div>
  </div>
  <div class="card"><h3>P.P. Enterprise bills · ${esc(S.fy)}</h3>
    <div class="tablewrap" style="max-height:420px"><table class="t"><thead><tr><th>No.</th><th>Date</th><th>Lorries</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">Total</th><th></th></tr></thead><tbody>
    ${bills.map(b => `<tr><td><b>${b.inv_no}</b> ${b.cancelled ? '<span class="badge red">cancelled</span>' : ''}</td><td>${dmy(b.date)}</td><td>${esc(b.lorry_no)}</td><td class="num">${qty(b.qty)}</td><td class="num">${money(b.taxable)}</td><td class="num">${money(b.total)}</td>
      <td><button class="small sec" onclick="window.open('/print/invoice/${b.id}','_blank')">Print</button> ${!b.legacy && !b.cancelled ? `<button class="small sec" onclick="cancelBill(${b.id})">Cancel</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div></div>`;
  const recalc = () => {
    const picks = $$('.pick:checked'); const q = picks.reduce((s, c) => s + Number(c.dataset.q), 0);
    const taxable = r2(picks.reduce((s, c) => s + r2(Number(c.dataset.q) * (+$('#brate').value || 0)), 0));
    const gst = r2(taxable * (+$('#bgst').value || 0) / 100); const total = Math.round(taxable + gst);
    $('#btot').innerHTML = `<div><span>${picks.length} lorries · ${qty(q)} MT</span><span></span></div><div><span>Taxable</span><b>${money(taxable)}</b></div>
      <div><span>CGST + SGST</span><b>${money(gst)}</b></div><div class="grand"><span>Total</span><span>${rs(total)}</span></div>`;
  };
  el.addEventListener('input', recalc); el.addEventListener('change', recalc); recalc();
  const all = $('#all'); if (all) all.onchange = () => { $$('.pick').forEach(c => c.checked = all.checked); recalc(); };
  $('#mk').onclick = async () => {
    const ids = $$('.pick:checked').map(c => Number(c.value));
    const r = await guard(() => POST('/api/ppe-bills', { inward_ids: ids, rate: $('#brate').value, date: $('#bdate').value, gst_rate: $('#bgst').value, item_name: $('#bitem').value }));
    toast('Bill created'); window.open('/print/invoice/' + r.id + '?print=1', '_blank'); route();
  };
};
async function cancelBill(id) {
  if (!confirm('Cancel this bill? Its lorries will become "not billed" again.')) return;
  const pw = await askEditPassword('cancel this bill'); if (pw == null) return;
  await guard(() => POST(`/api/invoices/${id}/cancel`, { edit_password: pw })); toast('Bill cancelled'); route();
}

// ---------- sales invoices list ----------
PAGES.invoices = async (el) => {
  el.innerHTML = `<div class="toolbar"><button onclick="go('#/newinvoice')">+ New invoice</button>
    <div class="tabs" id="ft"><button data-f="" class="on">PM + PF</button><button data-f="PM">Parakh Marketing</button><button data-f="PF">Parakh Fertilizer</button></div>
    <input type="search" id="q" placeholder="Search party, lorry, invoice no., e-way bill…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div>
    <div class="tablewrap" id="list"></div>`;
  let firm = '', rows = [];
  const load = async () => {
    rows = (await GET(`/api/invoices?fy=${S.fy}&kind=SALE&firm=${firm}&q=${encodeURIComponent($('#q').value)}`));
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th>Type</th><th>Lorry</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">GST</th><th class="num">Total</th><th>E-way bill</th><th>Email</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td><b>${r.inv_no}</b>${r.cancelled ? ' <span class="badge red">cancelled</span>' : ''}${r.legacy ? ' <span class="badge grey">Excel</span>' : ''}</td>
      <td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td>${r.supply_type}</td><td>${esc(r.lorry_no)}</td><td class="num">${qty(r.qty)}${r.lines > 1 ? ` <span class="muted">(${r.lines} items)</span>` : ''}</td>
      <td class="num">${money(r.taxable)}</td><td class="num">${money(r.cgst + r.sgst + r.igst)}</td><td class="num"><b>${money(r.total)}</b></td><td>${esc(r.ewb_no)}</td><td>${r.email_sent_at ? '✓' : ''}</td></tr>`).join('')}
      </tbody></table>` : '<div class="empty">No invoices.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#ft button').forEach(b => b.onclick = () => { $$('#ft button').forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.f; load(); });
  $('#list').onclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) go('#/invoice/' + tr.dataset.id); };
  $('#csv').onclick = () => downloadCsv(`sales_${S.fy}.csv`, rows);
  await load();
};

// ---------- sales invoice form (many items) ----------
PAGES.newinvoice = el => invoiceForm(el, null);
PAGES.invoice = (el, id) => invoiceForm(el, Number(id));

async function invoiceForm(el, id) {
  const [parties, items, transporters, inv] = await Promise.all([loadParties(), loadItems(), GET('/api/m/transporters'), id ? GET('/api/invoices/' + id) : null, loadLists()]);
  const active = parties.filter(p => p.active !== 0 && ['PM', 'PF'].includes(p.firm_code));
  const label = p => `${p.name} — ${p.city || ''} [${p.firm_code}]`;
  const pwOk = inv && S.unlock && S.unlock.id === inv.id ? S.unlock.pw : null;   // unlocked with the edit password
  const locked = inv && (inv.legacy || inv.cancelled || !pwOk);
  const v = inv || { date: today(), items: [{}] };
  let party = inv ? parties.find(p => p.id === inv.party_id) || null : null;
  if (inv && !party) party = { id: null, name: inv.party_name, firm_code: inv.firm_code, gstin: inv.party_gstin, state: inv.party_state, state_code: inv.party_state_code, city: inv.party_city, address: inv.party_address };

  el.innerHTML = `
  ${datalist('dl-party', active.map(label))}${datalist('dl-item', [...lv('product'), ...items.map(i => i.name)])}${datalist('dl-tr', transporters.map(t => t.name))}
  ${datalist('dl-bag', [...lv('bag_type'), ...items.map(i => i.bag_type)])}
  <form id="invf" autocomplete="off">
  <div class="card">
    <div class="grid g4">
      <label class="span2">Buyer (type to search)<input id="partyq" list="dl-party" value="${esc(party ? label(party) : '')}" ${inv ? 'readonly' : ''} placeholder="Start typing the buyer name…"></label>
      ${field({ name: 'inv_no', label: 'Invoice no.', ro: !!inv }, v.inv_no || '')}
      ${field({ name: 'date', label: 'Invoice date', type: 'date' }, v.date)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div class="firmbox" id="firmbox">Choose a buyer. The billing firm comes from the buyer and cannot be changed here.</div>
      <div class="grid g2">
        ${field({ name: 'party_address', label: 'Bill-to address', type: 'textarea' }, v.party_address)}
        <div>
          <label>Deliver to <span class="hint">(Buyers → delivery addresses)</span><select name="delivery_id" id="shipsel"><option value="">Same as bill-to address</option></select></label>
          <div id="shipinfo" class="hint" style="margin:3px 0 8px;min-height:1em"></div>
          <label>E-way bill type <span class="hint">(as on the portal)</span><select name="trans_type" id="ttype">
            <option value="1">Regular — Bill To only</option><option value="2">Bill To – Ship To</option>
            <option value="3">Bill From – Dispatch From</option><option value="4">Combination of 2 and 3</option></select></label>
        </div>
      </div>
    </div>
  </div>
  <div class="card"><h3>Items</h3>
    <div id="pchips" class="row" style="gap:8px;margin-bottom:10px"></div>
    <table class="items"><thead><tr><th style="width:30px">#</th><th>Item</th><th>Grade</th><th style="width:80px">Bags</th><th style="width:70px">Kg / bag</th><th style="width:80px">HSN</th>
      <th style="width:95px">Qty (MT)</th><th style="width:100px">Rate / MT</th><th style="width:60px">GST %</th><th>Bag type</th><th style="width:150px">Packing</th><th style="width:115px" class="num">Amount</th><th></th></tr></thead>
      <tbody id="lines"></tbody></table>
    ${locked ? '' : '<p class="hint" style="margin:8px 0 0">Items, rates, HSN, GST and packing come from the buyer’s items (Buyers menu) and cannot be changed here. Type only the bags.</p>'}
  </div>
  <div class="grid g2">
    <div class="card"><h3>Dispatch</h3><div class="grid g3">
      <label>Lorry no. <span class="badge amber needbig" hidden>required</span><input name="lorry_no" value="${esc(v.lorry_no || '')}"></label>
      <label>Transporter <span class="hint">(buyer's last used)</span> <span class="badge amber needbig" hidden>required</span><input name="transporter" list="dl-tr" value="${esc(v.transporter || '')}"></label>
      <label>Transporter GSTIN <span class="hint">(🔒 from Transporters master)</span> <span class="badge amber needbig" hidden>required</span><input name="transporter_gstin" value="${esc(v.transporter_gstin || '')}" readonly tabindex="-1" class="locked" title="Change it in Masters → Lorries & more → Transporters"><span id="trgst" class="hint" style="display:block;margin-top:3px;font-weight:400"></span></label>
      <label>L.R. no. <span class="badge amber needbig" hidden>required</span><input name="lr_no" value="${esc(v.lr_no || '')}"></label>
      ${field({ name: 'driver_phone', label: 'Driver phone' }, v.driver_phone)}
      <label>Dispatch plant <span class="hint" id="plantnote"></span> <span class="badge amber needbig" hidden>required</span><select name="plant">${['', ...S.meta.plants.map(p => p.name)].map(x => `<option ${x === (v.plant || '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>
      <label>E-way bill no. <span id="ewbreq" class="hint"></span>
        <div class="row" style="gap:6px;flex-wrap:nowrap;margin-top:3px"><input name="ewb_no" value="${esc(v.ewb_no || '')}" inputmode="numeric" maxlength="12" placeholder="12 digits">
        ${locked ? '' : '<button type="button" class="sec small" id="ewbjson" style="white-space:nowrap" title="Make the JSON file to upload on the e-way bill portal">⬇ JSON</button>'}</div></label>
      <label>Freight rate per MT (₹) <span class="badge amber needbig" hidden>required</span><input name="freight_note" value="${esc(v.freight_note || '')}" inputmode="decimal" placeholder="e.g. 2600"></label>
      <label>Total freight <span class="hint">(rate × qty)</span><input id="ftotal" readonly tabindex="-1"></label>
      <label>Freight payment mode <span class="badge amber needbig" hidden>required</span><select name="freight_mode">${(() => {
        const modes = lv('freight_mode').length ? lv('freight_mode') : ['TO PAY', 'PAID', 'TO PAY DOOR DELIVERY', 'PAID DOOR DELIVERY'];
        const cur = inv ? (v.freight_mode || '') : (modes.includes('TO PAY') ? 'TO PAY' : modes[0]);   // new invoices: TO PAY
        return ['', ...modes, ...(cur && !modes.includes(cur) ? [cur] : [])].map(m => `<option ${m === cur ? 'selected' : ''}>${esc(m)}</option>`).join('');
      })()}</select></label>
      ${field({ name: 'advance_freight', label: 'Advance freight', type: 'number' }, v.advance_freight)}
      ${field({ name: 'notes', label: 'Note on invoice', span: 3 }, v.notes)}
    </div></div>
    <div class="card"><h3>Totals</h3><div class="totals" id="tot"></div>
      <div class="row" style="margin-top:14px">
        ${locked ? '' : '<button type="submit">Save</button><button type="button" id="saveprint">Save & print</button>'}
        ${inv && !inv.legacy && !inv.cancelled && !pwOk ? '<button type="button" class="sec" id="unlock">🔒 Edit invoice</button>' : ''}
        ${inv ? `<button type="button" id="print">🖨 Print invoice</button><button type="button" class="sec" id="stickers">🏷 Bag stickers</button><button type="button" class="sec" id="envelope">✉ Envelope</button>
          <button type="button" class="sec" id="preview">Preview / PDF</button>${!inv.legacy ? '<button type="button" class="rust" id="email">Email to buyer</button>' : ''}` : ''}
        <span class="spacer"></span>
        ${inv && !locked ? '<button type="button" class="sec" id="cancel">Cancel invoice</button>' : ''}
      </div>
      ${inv && inv.email_sent_at ? `<p class="hint">Email sent on ${esc(inv.email_sent_at)}</p>` : ''}
      ${inv && inv.legacy ? '<p class="hint">Imported from the old Excel file — view and print only.</p>' : ''}
      ${inv && !inv.legacy && !inv.cancelled ? `<p class="hint">${pwOk ? '🔓 Unlocked with the edit password — save to keep the changes.' : 'Saved invoice — locked. Press “Edit invoice” and enter the edit password to change or cancel it.'}</p>` : ''}
    </div>
  </div>
  </form>`;

  const f = $('#invf');
  const lines = $('#lines');
  const lineHtml = (it = {}, i) => `<tr>
    <td>${i + 1}</td>
    <td><input data-k="item_name" readonly tabindex="-1" value="${esc(it.item_name)}"><input type="hidden" data-k="party_item_id" value="${esc(it.party_item_id || '')}"><input type="hidden" data-k="fixed_plant" value="${esc(it.fixed_plant || '')}"></td>
    <td><input data-k="grade" readonly tabindex="-1" value="${esc(it.grade)}"></td>
    <td><input data-k="bags" type="number" class="num" value="${esc(it.bags ?? '')}" ${it.item_name ? '' : 'disabled'}></td>
    <td><input data-k="pack_size" readonly tabindex="-1" class="num" value="${esc(it.pack_size ?? '')}"></td>
    <td><input data-k="hsn" readonly tabindex="-1" value="${esc(it.hsn || '')}"></td>
    <td><input data-k="qty" type="number" step="0.001" class="num" value="${esc(it.qty ?? '')}" title="Bags × kg per bag ÷ 1000" ${it.item_name ? '' : 'disabled'}></td>
    <td><input data-k="rate" readonly tabindex="-1" class="num" value="${esc(it.rate ?? '')}"></td>
    <td><input data-k="gst_rate" readonly tabindex="-1" class="num" value="${esc(it.gst_rate ?? '')}"></td>
    <td><input data-k="bag_type" readonly tabindex="-1" value="${esc(it.bag_type || '')}"><input type="hidden" data-k="packing_type" value="${esc(it.packing_type || '')}"></td>
    <td><input readonly tabindex="-1" class="packshow" value="${esc([it.packing_type, packText(it.bag_supply, it.liner)].filter(Boolean).join(' · '))}"><input type="hidden" data-k="packing" value="${packKey(it.bag_supply, it.liner)}"></td>
    <td class="num amt">0.00</td>
    <td>${locked ? '' : '<button type="button" class="ghost del" title="Remove">✕</button>'}</td></tr>`;
  const readLines = () => $$('tr', lines).map(tr => {
    const o = {}; $$('[data-k]', tr).forEach(i => o[i.dataset.k] = i.value.trim());
    const [bs, ln] = (o.packing || '').split('|'); delete o.packing;
    o.bag_supply = bs || null; o.liner = bs ? Number(ln) : null; return o;
  });
  let pitems = [];
  const fromBuyer = (name, grade) => pitems.find(x => x.item_name === name && (x.grade || '') === grade) ||
    (!grade && pitems.filter(x => x.item_name === name).length === 1 ? pitems.find(x => x.item_name === name) : null);
  const fillLine = (tr, x) => {
    const set = (k, v) => { const inp = $(`[data-k=${k}]`, tr); if (inp) inp.value = v ?? ''; };
    set('party_item_id', x.id); set('fixed_plant', x.plant || ''); set('gst_rate', x.gst_rate ?? 5); set('rate', x.rate); set('bag_type', x.bag_type); set('pack_size', x.pack_size);
    set('packing', packKey(x.bag_supply, x.liner)); const ps = $('.packshow', tr); if (ps) ps.value = [x.packing_type, packText(x.bag_supply, x.liner)].filter(Boolean).join(' · ');
    $$('[data-k=bags], [data-k=qty]', tr).forEach(i => { i.disabled = false; });
    const mm = items.find(i => i.name === x.item_name && (i.grade || '') === (x.grade || '')) || items.find(i => i.name === x.item_name) || {};
    set('item_name', x.item_name); set('grade', x.grade); set('hsn', x.hsn || mm.hsn); set('packing_type', x.packing_type); set('rate', x.rate); set('pack_size', x.pack_size); set('bag_type', x.bag_type);
    if (x.gst_rate != null) $('[data-k=gst_rate]', tr).value = x.gst_rate;
    if (x.bag_supply) $('[data-k=packing]', tr).value = packKey(x.bag_supply, x.liner);
  };
  const showChips = () => {
    $('#pchips').innerHTML = !party ? '' : pitems.length
      ? `<span class="hint">${esc(party.name)}'s items — click to add:</span>` + pitems.map(x => `<button type="button" class="small sec" data-pi="${x.id}">${esc(x.item_name)} ${esc(x.grade || '')} · ₹${money(x.rate)}${x.pack_size ? ' · ' + qty(x.pack_size) + 'kg' : ''}${x.bag_type ? ' ' + esc(x.bag_type) : ''}${x.packing_type ? ' · ' + esc(x.packing_type) : ''}${packText(x.bag_supply, x.liner) ? ' · ' + esc(packText(x.bag_supply, x.liner)) : ''}</button>`).join('')
      : `<span class="badge amber">No items saved for this buyer</span> <span class="hint">Open Buyers → ${esc(party.name)} → add the items, rates and packing first. Invoices can only use the buyer's items.</span>`;
  };
  const renderLines = arr => { lines.innerHTML = arr.map(lineHtml).join(''); };
  const fillGrades = (tr, i) => {
    const name = $('[data-k=item_name]', tr).value.trim().toUpperCase();
    $(`#dl-grade-${i}`, tr).innerHTML = items.filter(x => x.name === name).map(x => `<option value="${esc(x.grade || '')}">`).join('');
  };

  const showFirm = () => {
    const box = $('#firmbox');
    if (!party) { box.innerHTML = 'Choose a buyer. The billing firm comes from the buyer and cannot be changed here.'; return; }
    box.innerHTML = `Billed by <span class="badge ${party.firm_code}">${FIRM_NAME[party.firm_code]}</span><br>
      <b>${esc(party.name)}</b> · ${esc(party.city || '')}, ${esc(party.state || '')} ${party.state_code ? '(' + esc(party.state_code) + ')' : ''}<br>
      ${party.gstin ? 'GSTIN ' + esc(party.gstin) + ' · B2B' : '<span class="badge amber">No GSTIN · B2C</span>'}
      ${party.email ? '<br><span class="hint">' + esc(party.email) + '</span>' : ''}`;
  };

  const calc = () => {
    const arr = readLines();
    const intra = !party || !party.state_code || party.state_code === '08';
    let taxable = 0, tax = 0;
    $$('tr', lines).forEach((tr, i) => {
      const a = r2((+arr[i].qty || 0) * (+arr[i].rate || 0)); taxable += a; tax += r2(a * (+arr[i].gst_rate || 0) / 100);
      $('.amt', tr).textContent = money(a);
    });
    taxable = r2(taxable); tax = r2(tax);
    const raw = taxable + tax, total = Math.round(raw);
    S.invTotal = total;
    const R = S.meta.rules || { ewb_intra: 25000, ewb_inter: 25000 }, lim = intra ? R.ewb_intra : R.ewb_inter;
    const req = $('#ewbreq'); if (req) req.textContent = total > lim ? `(required above ₹${lim.toLocaleString('en-IN')})` : '';
    $$('.needbig').forEach(x => x.hidden = !(total > lim));
    const totalQty = arr.reduce((s, x) => s + (+x.qty || 0), 0);
    const fr = +(String(f.freight_note.value).replace(/,/g, '').match(/\d+(\.\d+)?/) || [0])[0];
    $('#ftotal').value = fr > 0 && totalQty > 0 ? '₹ ' + money(fr * totalQty) : '';
    $('#tot').innerHTML = `<div><span>Total quantity</span><b>${qty(totalQty)} MT</b></div><div><span>Taxable value</span><b>${money(taxable)}</b></div>
      ${intra ? `<div><span>CGST</span><b>${money(tax / 2)}</b></div><div><span>SGST</span><b>${money(tax / 2)}</b></div>` : `<div><span>IGST (other state)</span><b>${money(tax)}</b></div>`}
      <div><span>Round off</span><b>${money(total - raw)}</b></div><div class="grand"><span>Grand total</span><span>${rs(total)}</span></div>`;
  };

  // a buyer item fixed to a plant decides (and locks) the dispatch plant
  const syncPlant = () => {
    const fixed = [...new Set($$('[data-k=fixed_plant]', lines).map(i => i.value).filter(Boolean))];
    if (fixed.length > 1) toast(`These items are fixed to different plants (${fixed.join(', ')}). Make one invoice per plant.`, true);
    if (fixed.length === 1) { if (![...f.plant.options].some(o => o.value === fixed[0])) f.plant.add(new Option(fixed[0], fixed[0])); f.plant.value = fixed[0]; }
    f.plant.disabled = fixed.length === 1 || !!locked;
    $('#plantnote').textContent = fixed.length === 1 ? '(fixed by item)' : '';
  };
  // transporter GSTIN shown under the transporter
  const showTrGst = (fill) => {
    const tr = transporters.find(x => x.name.trim().toUpperCase() === f.transporter.value.trim().toUpperCase());
    if (fill && !locked) f.transporter_gstin.value = tr && tr.gstin ? tr.gstin : '';
    $('#trgst').innerHTML = !f.transporter.value.trim() || (tr && tr.gstin) ? ''
      : `<span class="badge amber">${tr ? 'no GSTIN saved for this transporter' : 'not in the Transporters list'}</span> add it in <a href="#/masters" style="color:inherit;text-decoration:underline">Lorries & more → Transporters</a>`;
  };;;
  // delivery addresses of the buyer; the e-way bill type follows the pincode
  let addrs = [];
  const shipInfo = () => {
    const a = addrs.find(x => x.id === Number(f.delivery_id.value));
    const regPin = String((party && party.pincode) || '');
    $('#shipinfo').innerHTML = a ? `${esc(a.address)}, ${esc(a.city || '')} - <b>${esc(a.pincode || '')}</b>, ${esc(a.state || '')}`
      + (a.pincode && a.pincode !== regPin ? ' <span class="badge amber">pincode differs from registered</span>' : '') : '';
  };
  const autoType = () => {
    const a = addrs.find(x => x.id === Number(f.delivery_id.value));
    f.trans_type.value = a && a.pincode && a.pincode !== String((party && party.pincode) || '') ? '2' : '1';
  };
  const loadAddrs = async (keep) => {
    addrs = party && party.id ? await GET(`/api/parties/${party.id}/addresses`) : [];
    if (!f.isConnected) return;
    const sel = f.delivery_id;
    sel.innerHTML = '<option value="">Same as bill-to address</option>' + addrs.map(a => `<option value="${a.id}">${esc(a.godown_name || 'DELIVERY')} — ${esc(a.city || '')} ${esc(a.pincode || '')}</option>`).join('');
    if (keep && inv && inv.delivery_id && !addrs.some(a => a.id === inv.delivery_id)) sel.add(new Option(`${inv.ship_name || 'DELIVERY'} — ${inv.ship_city || ''} ${inv.ship_pincode || ''} (removed)`, inv.delivery_id));
    if (keep) sel.value = inv && inv.delivery_id ? String(inv.delivery_id) : '';
    else { const d = addrs.find(a => a.is_default); sel.value = d ? String(d.id) : ''; }
    if (keep && inv && inv.trans_type) f.trans_type.value = String(inv.trans_type); else autoType();
    shipInfo();
  };
  f.delivery_id.addEventListener('change', () => { autoType(); shipInfo(); });
  const choose = async (p) => {
    const changed = (party && party.id) !== (p && p.id);
    party = p; showFirm();
    if (changed && !inv) loadAddrs(false);
    if (!inv && changed) { renderLines([{}]); calc(); syncPlant(); }   // items always come from the chosen buyer
    pitems = p && p.id ? await GET(`/api/parties/${p.id}/items`) : [];
    if (!f.isConnected) return;                       // page was left meanwhile
    if (!locked) showChips();
    if (!p) return;
    if (!inv) {
      f.party_address.value = p.address || '';
      f.transporter.value = p.transporter || ''; showTrGst(true);      // buyer's last used transporter
      const n = await GET(`/api/invoices/next?firm=${p.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no;
    }
    calc();
  };

  renderLines(v.items.length ? v.items : [{}]);
  showFirm(); calc(); showTrGst(); syncPlant();
  await loadAddrs(true);
  if (party && party.id && !locked) { pitems = await GET(`/api/parties/${party.id}/items`); showChips(); }
  $('#pchips').onclick = e => {
    const b = e.target.closest('[data-pi]'); if (!b) return;
    const x = pitems.find(i => i.id === Number(b.dataset.pi));
    let arr = readLines(); const last = arr[arr.length - 1];
    if (last && (last.item_name || last.qty)) { arr.push({ gst_rate: 5 }); renderLines(arr); }
    const tr = $$('tr', lines).pop(); fillLine(tr, x);
    if (x.pack_size) { const b = +$('[data-k=bags]', tr).value; if (b) $('[data-k=qty]', tr).value = String(Math.round(b * x.pack_size) / 1000); }
    calc(); syncPlant(); S.dirty = true; $('[data-k=bags]', tr).focus();
  };
  if (locked) $$('input, select, textarea', f).forEach(x => x.disabled = true);
  else markDirty(f);

  $('#partyq').addEventListener('change', () => choose(active.find(p => label(p) === $('#partyq').value) || null));
  f.date.addEventListener('change', async () => { if (party && !inv) { const n = await GET(`/api/invoices/next?firm=${party.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no; } });
  lines.addEventListener('input', calc);
  f.freight_note.addEventListener('input', calc);
  lines.addEventListener('change', calc);
  f.transporter.addEventListener('change', () => showTrGst(true)); f.transporter.addEventListener('input', () => showTrGst(true));
  // quantity (MT) = bags × kg per bag ÷ 1000
  lines.addEventListener('input', e => {
    const k = e.target.dataset.k; if (k !== 'bags' && k !== 'pack_size') return;
    const tr = e.target.closest('tr');
    const b = +$('[data-k=bags]', tr).value, pk = +$('[data-k=pack_size]', tr).value;
    if (b && pk) { $('[data-k=qty]', tr).value = String(Math.round(b * pk) / 1000); calc(); }
  });
  lines.addEventListener('click', e => { if (e.target.classList.contains('del')) { const arr = readLines(); arr.splice($$('tr', lines).indexOf(e.target.closest('tr')), 1); renderLines(arr.length ? arr : [{}]); calc(); syncPlant(); S.dirty = true; } });


  const save = async () => {
    if (!party || !party.id) { toast('Choose the buyer from the list.', true); return null; }
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    delete body.undefined;
    if (inv) { delete body.inv_no; body.edit_password = pwOk; }
    const r = await guard(() => inv ? PUT('/api/invoices/' + inv.id, body) : POST('/api/invoices', body));
    S.dirty = false; S.unlock = null; toast('Invoice saved'); return r.id;
  };
  f.onsubmit = async e => { e.preventDefault(); const nid = await save(); if (!nid) return; go('#/invoice/' + nid); if (inv) route(); };
  const sp = $('#saveprint'); if (sp) sp.onclick = async () => { const nid = await save(); if (!nid) return; window.open('/print/invoice/' + nid + '?print=1', '_blank'); go('#/invoice/' + nid); if (inv) route(); };
  const ej = $('#ewbjson'); if (ej) ej.onclick = async () => {
    if (!party || !party.id) return toast('Choose the buyer first.', true);
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    const r = await guard(() => POST('/api/ewaybill-json', body));
    if (r.saved) { toast(`Saved ${r.saved} — upload it on the e-way bill portal`); return; }
    delete r.saved; await saveToDesktop('ewaybill.json', JSON.stringify(r, null, 1));
  };
  const pr = $('#print'); if (pr) pr.onclick = () => doPrint('invoice', inv.id);
  const pv = $('#preview'); if (pv) pv.onclick = () => window.open('/print/invoice/' + inv.id, '_blank');
  const en = $('#envelope'); if (en) en.onclick = () => doPrint('envelope', inv.id);
  const stk = $('#stickers'); if (stk) stk.onclick = () => stickerDialog(inv);
  const cn = $('#cancel'); if (cn) cn.onclick = async () => { if (confirm('Cancel this invoice? It stays in the list marked cancelled.')) { await guard(() => POST(`/api/invoices/${inv.id}/cancel`, { edit_password: pwOk })); S.unlock = null; toast('Invoice cancelled'); route(); } };
  const ul = $('#unlock'); if (ul) ul.onclick = async () => { const pw = await askEditPassword('edit this invoice'); if (pw == null) return; S.unlock = { id: inv.id, pw }; route(); };
  const em = $('#email'); if (em) em.onclick = () => emailDialog(inv.id);
}

// ---------- printing ----------
const PRINT_NAME = { invoice: 'Invoice', label: 'Bag stickers', envelope: 'Envelope' };
const printWhere = () => { try { return localStorage.getItem('ms_print_where') || 'window'; } catch { return 'window'; } };
async function doPrint(kind, id, extra = {}) {
  toast(`Printing ${PRINT_NAME[kind].toLowerCase()}…`);
  const r = await guard(() => POST('/api/print', { kind, id, where: printWhere() === 'main' ? 'main' : '', ...extra }));
  if (r.printed) toast(`${PRINT_NAME[kind]} sent to ${r.printer} (${r.sheets} ${r.sheets === 1 ? 'sheet' : 'sheets'})`);
  else window.open(r.url, '_blank');
}
function stickerDialog(inv) {
  const bags = inv.items.reduce((s, it) => s + (Number(it.bags) || 0), 0) || 1;
  modal('Bag / parcel stickers (4 × 6)', `<form id="stf"><div class="grid g3">
      <label>Total bags<input name="of" type="number" min="1" value="${bags}"></label>
      <label>Print from bag no.<input name="from" type="number" min="1" value="1"></label>
      <label>to bag no.<input name="to" type="number" min="1" value="${bags}"></label></div>
      <p class="hint">Each sticker shows "Bag No. n / ${bags}", the buyer's address, invoice and item, and your firm as sender.</p>
      <div class="row"><button type="submit">Print stickers</button><button type="button" class="sec" id="stprev">Preview</button></div></form>`, root => {
    const f = $('#stf', root);
    f.of.addEventListener('input', () => { f.to.value = f.of.value; });
    $('#stprev', root).onclick = () => window.open(`/print/label/${inv.id}?from=${f.from.value}&to=${Math.min(+f.to.value, +f.from.value + 9)}&of=${f.of.value}`, '_blank');
    f.onsubmit = e => { e.preventDefault(); const d = formData(f); closeModal(); doPrint('label', inv.id, d); };
  });
}

async function emailDialog(id) {
  const d = await guard(() => GET(`/api/invoices/${id}/email`));
  modal('Email invoice to buyer', `
    ${d.ready ? '' : '<p class="badge amber">Email is not set up for this firm yet. Open Settings → Companies → Email sending first.</p>'}
    ${d.missing && d.missing.length ? `<p class="badge red">Fill in ${esc(d.missing.join(', '))} on the invoice and save it before emailing.</p>` : ''}
    <form id="emf"><div class="grid g2">
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <label class="span2">Message<textarea name="text" style="min-height:260px">${esc(d.text)}</textarea></label>
    </div><p class="hint">The invoice PDF is attached automatically. Sent from ${esc(d.from || '')}.</p>
    <div class="row"><button type="submit" ${d.ready && !(d.missing && d.missing.length) ? '' : 'disabled'}>Send email</button></div></form>`, root => {
    $('#emf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try { const r = await POST(`/api/invoices/${id}/email`, formData(e.target)); toast('Email sent'); closeModal(); route(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ---------- PAN card of a transporter (for the TDS declaration) ----------
// The picture is cropped to the card: the blank (white) border of a scan or photo is cut away.
function cropBlank(img, maxW = 1100) {
  const c = document.createElement('canvas'); const k = Math.min(1, 2000 / Math.max(img.width, img.height));
  c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
  const { data } = g.getImageData(0, 0, c.width, c.height), W = c.width, H = c.height;
  const ink = (x, y) => { const i = (y * W + x) * 4; return data[i] * .299 + data[i + 1] * .587 + data[i + 2] * .114 < 215; };
  const rows = new Array(H).fill(0), cols = new Array(W).fill(0);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (ink(x, y)) { rows[y]++; cols[x]++; }
  const minR = Math.max(2, W * 0.01), minC = Math.max(2, H * 0.01);       // ignore specks of dust
  let top = rows.findIndex(n => n > minR), bottom = H - 1 - [...rows].reverse().findIndex(n => n > minR);
  let left = cols.findIndex(n => n > minC), right = W - 1 - [...cols].reverse().findIndex(n => n > minC);
  if (top < 0 || left < 0 || bottom <= top || right <= left) { top = 0; left = 0; bottom = H - 1; right = W - 1; }
  const pad = Math.round(Math.min(W, H) * 0.01);
  top = Math.max(0, top - pad); left = Math.max(0, left - pad); bottom = Math.min(H - 1, bottom + pad); right = Math.min(W - 1, right + pad);
  const cw = right - left + 1, ch = bottom - top + 1, s = Math.min(1, maxW / cw);
  const o = document.createElement('canvas'); o.width = Math.round(cw * s); o.height = Math.round(ch * s);
  o.getContext('2d').drawImage(c, left, top, cw, ch, 0, 0, o.width, o.height);
  return o.toDataURL('image/jpeg', 0.85);
}
// signature: cut away the white paper and make it see-through, so it sits nicely on the invoice
function signatureImage(img) {
  const jpg = new Image(); const src = cropBlank(img, 700);
  const c = document.createElement('canvas');
  return new Promise(res => { jpg.onload = () => {
    c.width = jpg.width; c.height = jpg.height; const g = c.getContext('2d'); g.drawImage(jpg, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height), a = d.data;
    for (let i = 0; i < a.length; i += 4) { const l = a[i] * .299 + a[i + 1] * .587 + a[i + 2] * .114; if (l > 200) a[i + 3] = 0; else if (l > 150) a[i + 3] = Math.round(255 * (200 - l) / 50); }
    g.putImageData(d, 0, 0); res(c.toDataURL('image/png'));
  }; jpg.src = src; });
}
async function panCardBox(box, row) {
  if (!row) { box.innerHTML = '<div class="firmbox" style="margin-top:16px">Save the transporter first, then upload the PAN card here.</div>'; return; }
  const { image } = await GET(`/api/transporters/${row.id}/pan-card`);
  box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>PAN card <span class="hint">— attached to the TDS declaration u/s 194C(6)</span></h3>
    <div class="row" style="align-items:flex-start;gap:18px">
      <div style="width:340px;min-height:120px;border:1px dashed var(--line);border-radius:10px;background:#fff;display:flex;align-items:center;justify-content:center;padding:6px">
        ${image ? `<img src="${image}" style="max-width:100%;max-height:220px">` : '<span class="muted">No PAN card yet</span>'}</div>
      <div><input type="file" id="pcfile" accept="image/*" hidden>
        <div class="row"><button type="button" id="pcup">${image ? 'Change PAN card' : 'Upload PAN card'}</button>${image ? '<button type="button" class="sec" id="pcdel">Remove</button>' : ''}</div>
        <p class="hint" style="max-width:420px">A photo or scan (JPG / PNG). The white space around the card is cut away by itself.
          When a PAN card is here, the year's TDS declaration is made and emailed to this transporter and to the buyer with the first invoice of every buyer.</p></div>
    </div></div>`;
  $('#pcup', box).onclick = () => $('#pcfile', box).click();
  $('#pcfile', box).onchange = async () => {
    const file = $('#pcfile', box).files[0]; if (!file) return;
    const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('This file is not a picture.')); i.src = url; }).catch(e => { toast(e.message, true); return null; });
    if (!img) return;
    await guard(() => PUT(`/api/transporters/${row.id}/pan-card`, { image: cropBlank(img) }));
    toast('PAN card saved'); panCardBox(box, row);
  };
  const del = $('#pcdel', box); if (del) del.onclick = async () => { if (!confirm('Remove the PAN card?')) return; await guard(() => PUT(`/api/transporters/${row.id}/pan-card`, { image: null })); panCardBox(box, row); };
}

// ---------- masters ----------
const STATES = () => ['', ...S.meta.states];
const SPECS = {
  parties: {
    title: 'Buyer', wide: true, cols: [['name', 'Name'], ['firm_code', 'Billed by'], ['item_count', 'Items'], ['city', 'City'], ['state', 'State'], ['gstin', 'GSTIN'], ['mobile', 'Mobile'], ['email', 'Email']],
    after: (root, row, reopen) => {
      // pick old invoice names that are not linked to any buyer
      GET('/api/old-buyer-names').then(list => {
        const ta = $('#mf [name=old_names]'); if (!ta || !list.length) return;
        const s = document.createElement('select'); s.style.marginTop = '4px';
        s.innerHTML = '<option value="">+ add an old name from the old invoices…</option>' + list.map(x => `<option value="${esc(x.name)}">${esc(x.name)} — ${x.n} invoices, ${dmy(x.first)} to ${dmy(x.last)}</option>`).join('');
        s.onchange = () => { if (s.value) { ta.value = [ta.value.trim(), s.value].filter(Boolean).join('\n'); S.dirty = true; } s.value = ''; };
        ta.after(s);
      }).catch(() => {});
      root.innerHTML = '<div id="paddr"></div><div id="pitems"></div>';
      partyAddresses($('#paddr', root), row); partyItems($('#pitems', root), row, reopen);
    },
    lists: async () => datalist('dl-m-tr', (await GET('/api/m/transporters')).map(t => t.name)),
    fields: () => [
      { name: 'name', label: 'Buyer name', span: 2 }, { name: 'firm_code', label: 'Billing firm (fixed rule)', type: 'select', options: [['', '— choose —'], ['PM', 'Parakh Marketing'], ['PF', 'Parakh Fertilizer']] },
      { name: 'gstin', label: 'GSTIN (blank for B2C)' }, { name: 'pan', label: 'PAN' }, { name: 'group_name', label: 'Group of company' },
      { name: 'address', label: 'Registered address (bill to)', type: 'textarea', span: 3 },
      { name: 'pincode', label: 'Pincode (fills city & state)' }, { name: 'city', label: 'City' }, { name: 'state', label: 'State', type: 'select', options: STATES() },
      { name: 'email', label: 'Email (use ; for more)', span: 2 }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'transporter', label: 'Transporter (last used)', list: 'dl-m-tr' }, { name: 'km', label: 'Distance km', type: 'number' }, { name: 'payment_terms', label: 'Payment terms' }, { name: 'notes', label: 'Notes', span: 2 },
      { name: 'old_names', label: 'Old names on old Excel invoices (one per line) — links those invoices to this buyer', type: 'textarea', span: 3 }]
  },
  items: { title: 'Item', cols: [['name', 'Item'], ['grade', 'Grade'], ['colour', 'Colour'], ['mesh', 'Mesh'], ['form', 'Form'], ['hsn', 'HSN'], ['gst_rate', 'GST %'], ['bag_type', 'Bag type'], ['pack_size', 'Kg/bag'], ['packing_type', 'Packing'], ['rate', 'Rate']],
    fields: () => {
      const opt = k => ['', ...lv(k)];
      return [
        { name: 'name', label: 'Item name', span: 2, list: 'dl-l-product' }, { name: 'grade', label: 'Grade (fills itself)' }, { name: 'rate', label: 'Usual rate / MT', type: 'number' },
        { name: 'colour', label: 'Item colour', type: 'select', options: opt('colour') }, { name: 'mesh', label: 'Mesh size', type: 'select', options: opt('mesh') },
        { name: 'form', label: 'Item form', type: 'select', options: opt('form') },
        { name: 'hsn', label: 'HSN', type: 'select', options: ['', ...(S.lists.hsn || []).map(x => [x.value, `${x.value}${x.note ? ' — ' + x.note : ''}`])] },
        { name: 'bag_type', label: 'Bag type', type: 'select', options: opt('bag_type') }, { name: 'pack_size', label: 'Bag weight (kg)', type: 'select', options: opt('bag_weight') },
        { name: 'packing_type', label: 'Packing type', type: 'select', options: opt('packing_type') },
        { name: 'gst_rate', label: 'GST %', type: 'select', options: lv('gst_rate'), def: 5 }, { name: 'unit', label: 'Unit', type: 'select', options: lv('unit'), def: 'MT' }];
    },
    lists: async () => { await loadLists(); return datalist('dl-l-product', lv('product')); },
    after: (box, row) => {
      const f = $('#mf'); if (!f) return;
      // a value already saved but missing from a list still shows
      $$('select', f).forEach(s => { const v = row && row[s.name]; if (v != null && v !== '' && ![...s.options].some(o => o.value === String(v))) s.add(new Option(v, v, true, true)); });
      let auto = !row || !row.grade;
      f.grade.addEventListener('input', () => { auto = !f.grade.value; });
      const mk = () => {
        if (!auto) return;
        const form = f.form.value, mesh = f.mesh.value, col = f.colour.value;
        f.grade.value = mesh && (!form || form === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form || '');
      };
      ['colour', 'mesh', 'form'].forEach(n => f[n].addEventListener('change', mk));
      f.hsn.addEventListener('change', () => { const h = (S.lists.hsn || []).find(x => x.value === f.hsn.value); if (h && h.num != null) f.gst_rate.value = String(h.num); });
    } },
  transporters: { title: 'Transporter', wide: true, cols: [['name', 'Name'], ['mobile', 'Mobile'], ['district', 'District'], ['gstin', 'GSTIN'], ['pan', 'PAN'], ['proprietor', 'Proprietor'], ['has_pan_card', 'PAN card']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'contact', label: 'Contact person' }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'email', label: 'Email (TDS declaration is sent here)' }, { name: 'address', label: 'Address', span: 2 }, { name: 'district', label: 'District / place' }, { name: 'state', label: 'State' }, { name: 'gstin', label: 'GSTIN' },
      { name: 'pan', label: 'PAN' }, { name: 'proprietor', label: 'Proprietor / partner (declarant; blank = contact person)' }, { name: 'bank_name', label: 'Bank' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }],
    after: (box, row) => panCardBox(box, row) },
  lorries: { title: 'Lorry', cols: [['lorry_no', 'Lorry no.'], ['owner', 'Owner'], ['pan', 'PAN'], ['mobile', 'Mobile'], ['driver_name', 'Driver'], ['upi', 'UPI'], ['tds_declaration', 'TDS dec.']],
    fields: () => [{ name: 'lorry_no', label: 'Lorry no.' }, { name: 'owner', label: 'Owner', span: 2 }, { name: 'pan', label: 'PAN' }, { name: 'mobile', label: 'Mobile' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'driver_name', label: 'Driver name' }, { name: 'driver_phone', label: 'Driver phone' }, { name: 'bank_name', label: 'Bank' }, { name: 'holder', label: 'Account holder' },
      { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi', label: 'UPI (made from account + IFSC)', span: 2 }, { name: 'tds_declaration', label: 'TDS declaration' }],
    // UPI = <account no>@<IFSC>.ifsc.npci, filled while typing (a UPI typed by hand is kept)
    after: () => {
      const f = $('#mf'); if (!f) return;
      const make = () => {
        const acc = f.bank_account.value.toUpperCase().replace(/[^A-Z0-9]/g, ''), ifsc = f.bank_ifsc.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (f.upi.value && !/\.ifsc\.npci$/i.test(f.upi.value)) return;
        f.upi.value = acc && /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc) ? `${acc}@${ifsc}.ifsc.npci` : '';
      };
      f.bank_ifsc.addEventListener('input', () => { f.bank_ifsc.value = f.bank_ifsc.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 11); make(); });
      f.bank_account.addEventListener('input', () => { f.bank_account.value = f.bank_account.value.replace(/\s/g, ''); make(); });
    } },
  suppliers: { title: 'Supplier', cols: [['name', 'Name'], ['grade', 'Grade'], ['rate', 'Rate'], ['freight_rate', 'Freight / MT'], ['type', 'Type']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'grade', label: 'Grade' }, { name: 'rate', label: 'Rate', type: 'number' }, { name: 'freight_rate', label: 'Freight per MT', type: 'number' },
      { name: 'type', label: 'Type', type: 'select', options: ['REG', 'URD'] }] },
  plants: { title: 'Plant', cols: [['name', 'Short name'], ['full_name', 'Name'], ['address', 'Address']],
    fields: () => [{ name: 'name', label: 'Short name (e.g. PPI PLANT)' }, { name: 'full_name', label: 'Name' }, { name: 'address', label: 'Address', span: 2 }] },
  firms: { title: 'Firm', noAdd: true, cols: [['code', 'Code'], ['name', 'Name'], ['gstin', 'GSTIN'], ['phone', 'Phone'], ['email', 'Email'], ['bank_name', 'Bank']],
    fields: () => [{ name: 'name', label: 'Firm name', span: 2 }, { name: 'gstin', label: 'GSTIN' }, { name: 'pan', label: 'PAN' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'city', label: 'City' }, { name: 'state', label: 'State' }, { name: 'state_code', label: 'State code' }, { name: 'pincode', label: 'Pincode' }, { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email' },
      { name: 'bank_name', label: 'Bank name' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi_id', label: 'UPI id' }, { name: 'terms', label: 'Terms on invoice', type: 'textarea', span: 4 }] }
};

async function masterTable(el, table, extraTools = '') {
  const sp = SPECS[table];
  el.innerHTML = `<div class="toolbar">${sp.noAdd ? '' : `<button id="add">+ Add ${sp.title.toLowerCase()}</button>`}${extraTools}
    <input type="search" id="q" placeholder="Search…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div><div class="tablewrap" id="list"></div>`;
  let rows = [], firm = '';
  const load = async () => {
    rows = await GET(`/api/m/${table}?q=${encodeURIComponent($('#q', el).value)}${firm ? '&firm=' + firm : ''}`);
    $('#list', el).innerHTML = rows.length ? `<table class="t"><thead><tr>${sp.cols.map(c => `<th>${c[1]}</th>`).join('')}</tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}" ${r.active === 0 ? 'style="opacity:.5"' : ''}>${sp.cols.map(([k]) => `<td>${k === 'firm_code' ? `<span class="badge ${r[k] || 'grey'}">${esc(FIRM_NAME[r[k]] || 'not set')}</span>` : k === 'has_pan_card' ? (r[k] ? '<span class="badge slate">✔ uploaded</span>' : '<span class="muted">—</span>') : esc(r[k])}</td>`).join('')}</tr>`).join('')}
      </tbody></table>` : '<div class="empty">Nothing found.</div>';
  };
  const edit = async (row) => {
    const lists = sp.lists ? await sp.lists() : '';
    modal((row ? 'Edit ' : 'New ') + sp.title.toLowerCase(), `${lists}<form id="mf"><div class="grid g4">${sp.fields().map(f => field(f, row ? row[f.name] : undefined)).join('')}</div>
      <div class="row" style="margin-top:16px"><button type="submit">Save</button><span class="spacer"></span>${row && !sp.noAdd ? '<button type="button" class="sec" id="mdel">Delete</button>' : ''}</div></form>
      <div id="mextra"></div>`, root => {
      hookPincode(root);
      if (sp.after) sp.after($('#mextra', root), row);
      $('#mf', root).onsubmit = async e => {
        e.preventDefault(); const d = formData(e.target);
        const r = await guard(() => row ? PUT(`/api/m/${table}/${row.id}`, d) : POST(`/api/m/${table}`, d));
        toast('Saved'); S.parties = null; S.items = null; await load();
        if (!row && table === 'parties') { const nr = await GET(`/api/m/${table}/${r.id}`); edit(nr); toast("Saved — now add this buyer's items below"); }
        else closeModal();
      };
      const del = $('#mdel', root); if (del) del.onclick = async () => {
        if (!confirm('Delete this record?')) return; const r = await guard(() => DEL(`/api/m/${table}/${row.id}`));
        toast(r.hidden ? 'Has invoices, so it was hidden instead of deleted' : 'Deleted'); closeModal(); S.parties = null; load();
      };
    });
  };
  $('#q', el).oninput = debounce(load, 300);
  const add = $('#add', el); if (add) add.onclick = () => edit(null);
  $('#list', el).onclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) edit(rows.find(r => r.id === Number(tr.dataset.id))); };
  $('#csv', el).onclick = () => downloadCsv(`${table}.csv`, rows);
  $$('[data-firm]', el).forEach(b => b.onclick = () => { $$('[data-firm]', el).forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.firm; load(); });
  await load();
}

// Delivery addresses (godowns) of a buyer. Chosen on the invoice as "Deliver to".
async function partyAddresses(box, row) {
  if (!row) return;
  const load = async () => {
    const list = await GET(`/api/parties/${row.id}/addresses`);
    box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>Delivery addresses (godowns) of ${esc(row.name)}
      <span class="hint">— where the goods go when it is not the registered address</span></h3>
      <table class="t"><thead><tr><th>Godown name</th><th>Address</th><th>City</th><th>Pincode</th><th>State</th><th>Contact</th><th class="num">Km</th><th></th></tr></thead><tbody>
      ${list.map(a => `<tr><td><b>${esc(a.godown_name || '—')}</b>${a.is_default ? ' <span class="badge slate">default</span>' : ''}${a.pincode && a.pincode !== String(row.pincode || '') ? ' <span class="badge amber" title="Pincode differs from the registered address — the e-way bill will be Bill To - Ship To">ship-to</span>' : ''}${!a.pincode ? ' <span class="badge amber">add pincode</span>' : ''}</td>
        <td>${esc(a.address)}</td><td>${esc(a.city)}</td><td>${esc(a.pincode)}</td><td>${esc(a.state)}</td><td>${esc([a.contact, a.phone].filter(Boolean).join(' · '))}</td><td class="num">${a.km ?? ''}</td>
        <td style="white-space:nowrap;text-align:right"><button type="button" class="small sec" data-aedit="${a.id}">Edit</button> <button type="button" class="small sec" data-adel="${a.id}">✕</button></td></tr>`).join('')
        || '<tr><td colspan="8" class="muted">No delivery address — goods go to the registered address. Add a godown below if this buyer has one.</td></tr>'}
      </tbody></table>
      <form id="paf" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px" autocomplete="off">
        <div class="grid g4">
          <label>Godown name<input name="godown_name" placeholder="e.g. KISHANGARH GODOWN"></label>
          <label class="span3">Delivery address<input name="address"></label>
          <label>Pincode <span class="hint">(fills city & state)</span><input name="pincode" inputmode="numeric" maxlength="6"></label>
          <label>City<input name="city"></label>
          <label>State<select name="state">${STATES().map(s => `<option>${esc(s)}</option>`).join('')}</select></label>
          <label>Distance km <span class="hint">(for e-way bill)</span><input name="km" type="number"></label>
          <label>Contact person<input name="contact"></label>
          <label>Phone<input name="phone" inputmode="numeric"></label>
          <label class="span2" style="align-self:end"><span><input type="checkbox" name="is_default" style="width:auto"> Use this address by default on new invoices</span></label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit" id="pasave">Add delivery address</button><button type="button" class="sec" id="pacancel" hidden>Cancel</button></div>
      </form></div>`;
    const f = $('#paf', box); let editing = null;
    hookPincode(f);
    box.onclick = async e => {
      const ed = e.target.closest('[data-aedit]'), dl = e.target.closest('[data-adel]');
      if (ed) {
        const a = list.find(x => x.id === Number(ed.dataset.aedit)); editing = a.id;
        for (const k of ['godown_name', 'address', 'pincode', 'city', 'km', 'contact', 'phone']) f[k].value = a[k] ?? '';
        if (a.state && ![...f.state.options].some(o => o.value === a.state)) f.state.add(new Option(a.state, a.state));
        f.state.value = a.state || ''; f.is_default.checked = !!a.is_default;
        $('#pasave', box).textContent = 'Update delivery address'; $('#pacancel', box).hidden = false; f.godown_name.focus();
      }
      if (dl && confirm('Remove this delivery address? Old invoices keep their printed address.')) { await guard(() => DEL('/api/party-addresses/' + dl.dataset.adel)); load(); }
    };
    $('#pacancel', box).onclick = () => load();
    f.onsubmit = async e => {
      e.preventDefault(); e.stopPropagation();
      const d = formData(f);
      if (!d.address) return toast('Type the delivery address.', true);
      if (!/^\d{6}$/.test(d.pincode)) return toast('Type the 6-digit pincode of the delivery address.', true);
      await guard(() => editing ? PUT('/api/party-addresses/' + editing, d) : POST(`/api/parties/${row.id}/addresses`, d));
      toast(editing ? 'Delivery address updated' : 'Delivery address added'); load();
    };
  };
  await load();
}

async function partyItems(box, row) {
  if (!row) { box.innerHTML = `<div class="firmbox" style="margin-top:16px">Save the buyer first, then add this buyer's items, rates and packing here.</div>`; return; }
  await loadLists(true);
  const L = S.lists;
  const sel = (name, key, label, cls = '') => `<label class="${cls}">${label}<select name="${name}"><option value=""></option>${lv(key).map(v => `<option>${esc(v)}</option>`).join('')}</select></label>`;
  const load = async () => {
    const list = await GET(`/api/parties/${row.id}/items`);
    box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>Items, rates & packing for ${esc(row.name)}</h3>
      <table class="t"><thead><tr><th>Item</th><th>Grade</th><th>Plant</th><th>HSN</th><th>Bag</th><th>Packing</th><th class="num">Rate / MT</th><th>Notes</th><th></th></tr></thead><tbody>
      ${list.map(x => `<tr><td><b>${esc(x.item_name)}</b></td><td>${esc(x.grade)}</td><td>${x.plant ? `<span class="badge slate">${esc(x.plant)}</span>` : '<span class="muted">any</span>'}</td><td>${esc(x.hsn)} <span class="hint">${x.gst_rate ?? ''}%</span></td>
        <td>${esc(x.bag_type)}${x.pack_size ? ` · ${qty(x.pack_size)} kg` : ''}</td>
        <td>${[esc(x.packing_type), esc(packText(x.bag_supply, x.liner))].filter(Boolean).join(' · ') || '<span class="muted">—</span>'}</td>
        <td class="num"><b>${money(x.rate)}</b>${x.commission > 0 ? ` <span class="badge grey" title="Commission ₹${x.commission} per MT${x.agent ? ' · ' + esc(x.agent) : ''} (private)">C</span>` : ''}</td><td>${esc(x.notes)}</td>
        <td style="white-space:nowrap;text-align:right"><button type="button" class="small sec" data-edit="${x.id}">Edit</button> <button type="button" class="small sec" data-del="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="9" class="muted">No items yet — add the first one below.</td></tr>'}
      </tbody></table>
      <form id="pif" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px">
        <div class="grid g6">
          <label>Plant <span class="hint">(fixed or blank)</span><select name="plant"><option value="">— any plant —</option>${S.meta.plants.map(pl => `<option>${esc(pl.name)}</option>`).join('')}</select></label>
          ${sel('item_name', 'product', 'Item name')}${sel('colour', 'colour', 'Item colour')}${sel('mesh', 'mesh', 'Mesh size')}${sel('form', 'form', 'Item form')}
          <label>Grade <span class="hint">(fills itself)</span><input name="grade"></label>
          <label class="span2">HSN<select name="hsn"><option value=""></option>${(L.hsn || []).map(h => `<option value="${esc(h.value)}">${esc(h.value)}${h.note ? ' — ' + esc(h.note) : ''}</option>`).join('')}</select></label>
          <label>GST %<select name="gst_rate">${lv('gst_rate').map(v => `<option ${v === '5' ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
          ${sel('bag_type', 'bag_type', 'Bag type')}${sel('pack_size', 'bag_weight', 'Bag weight (kg)')}${sel('packing_type', 'packing_type', 'Packing type')}
          <label>Bags given by<select name="bag_supply"><option value=""></option><option value="OUR">Our bags</option><option value="BUYER">Buyer's own bags</option></select></label>
          <label>Liner<select name="liner"><option value=""></option><option value="1">With liner</option><option value="0">Without liner</option></select></label>
          <label>Rate / MT<input name="rate" type="number" step="0.01"></label>
          <label>Commission ₹ / MT <span class="hint">🔒 private</span><input name="commission" type="number" step="0.01" title="Not printed or emailed. Shown only in the Commission screen."></label>
          ${sel('agent', 'agent', 'Commission agent 🔒')}
          <label class="span3">Notes<input name="notes"></label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit" id="pisave">Add item</button><button type="button" class="sec" id="picancel" hidden>Cancel</button>
          <span class="hint">Values come from Masters → Item lists.</span></div>
      </form></div>`;
    let editing = null, autoGrade = true;
    const f = $('#pif', box);
    const keep = (s, v) => { if (v != null && v !== '' && ![...s.options].some(o => o.value === String(v))) s.add(new Option(v, v)); s.value = v ?? ''; };
    const mkGrade = () => {
      if (!autoGrade) return;
      const form = f.form.value, mesh = f.mesh.value, col = f.colour.value;
      f.grade.value = mesh && (!form || form === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form || '');
    };
    ['colour', 'mesh', 'form'].forEach(n => f[n].addEventListener('change', mkGrade));
    f.grade.addEventListener('input', () => { autoGrade = !f.grade.value; });
    f.hsn.addEventListener('change', () => { const h = (L.hsn || []).find(x => x.value === f.hsn.value); if (h && h.num != null) f.gst_rate.value = String(h.num); });
    box.onclick = async e => {
      const ed = e.target.closest('[data-edit]'), dl = e.target.closest('[data-del]');
      if (ed) {
        const x = list.find(i => i.id === Number(ed.dataset.edit)); editing = x.id; autoGrade = false;
        ['plant', 'item_name', 'colour', 'mesh', 'form', 'hsn', 'bag_type', 'packing_type'].forEach(k => keep(f[k], x[k]));
        keep(f.pack_size, x.pack_size != null ? String(x.pack_size) : ''); keep(f.gst_rate, x.gst_rate != null ? String(x.gst_rate) : '5');
        f.bag_supply.value = x.bag_supply || ''; f.liner.value = x.liner == null ? '' : String(x.liner);
        f.grade.value = x.grade || ''; f.rate.value = x.rate ?? ''; f.notes.value = x.notes || ''; f.commission.value = x.commission ?? ''; keep(f.agent, x.agent);
        $('#pisave', box).textContent = 'Update item'; $('#picancel', box).hidden = false; f.item_name.focus();
      }
      if (dl && confirm('Remove this item from the buyer?')) { await guard(() => DEL('/api/party-items/' + dl.dataset.del)); load(); }
    };
    $('#picancel', box).onclick = () => load();
    f.onsubmit = async e => {
      e.preventDefault(); e.stopPropagation();
      const d = formData(f);
      if (!d.item_name) return toast('Choose the item name.', true);
      await guard(() => editing ? PUT('/api/party-items/' + editing, d) : POST(`/api/parties/${row.id}/items`, d));
      toast(editing ? 'Item updated' : 'Item added'); load();
    };
  };
  await load();
}

async function listsPage(box, key) {
  const lists = await loadLists(true);
  const def = LISTS.find(x => x[0] === key) || LISTS[1];
  key = def[0];
  if (key === 'plants' || key === 'fixed_expense') return specialList(box, key, def, lists);
  const rows = lists[key] || [];
  const isHsn = key === 'hsn', X = LIST_EXTRA[key] || {};
  box.innerHTML = `<div class="grid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${(lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="lf" class="row" style="margin-bottom:14px">
        <label style="flex:1">${isHsn ? 'HSN code' : 'New value'}<input name="value" ${['hsn', 'bag_weight', 'gst_rate'].includes(key) ? 'inputmode="decimal"' : ''}></label>
        ${X.note ? `<label style="flex:2">${X.note}<input name="note"></label>` : ''}${X.num ? `<label style="width:170px">${X.num}<input name="num" type="number" step="0.01"></label>` : ''}
        <button type="submit" id="lsave">Add</button><button type="button" class="sec" id="lcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>${isHsn ? 'HSN code' : 'Value'}</th>${X.note ? `<th>${X.note}</th>` : ''}${X.num ? `<th class="num">${X.num}</th>` : ''}<th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>${X.note ? `<td>${esc(r.note)}</td>` : ''}${X.num ? `<td class="num">${r.num ?? ''}</td>` : ''}
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#lf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f);
    await guard(() => editing ? PUT('/api/lists/' + editing, d) : POST('/api/lists', { ...d, list_key: key }));
    toast(editing ? 'Updated' : 'Added'); S.lists = null; listsPage(box, key);
  };
  $('#lcancel', box).onclick = () => listsPage(box, key);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value; if (X.note) f.note.value = r.note || ''; if (X.num) f.num.value = r.num ?? '';
      $('#lsave', box).textContent = 'Update'; $('#lcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Items that already use it keep it.')) { await guard(() => DEL('/api/lists/' + rm.dataset.rm)); S.lists = null; listsPage(box, key); }
  };
}

// Item lists → Plants and → Factory fixed expenses (their own tables)
async function specialList(box, key, def, lists) {
  const isPl = key === 'plants';
  const rows = await GET(isPl ? '/api/m/plants' : '/api/factory-fixed');
  const plants = isPl ? rows : await GET('/api/m/plants');
  box.innerHTML = `<div class="grid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${k === key ? rows.length : (lists[k] || []).length || ''}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="sf" class="row" style="margin-bottom:14px" autocomplete="off">
        ${isPl ? `<label style="width:170px">Plant short name<input name="name" placeholder="e.g. PPI PLANT"></label><label style="flex:1">Name<input name="full_name"></label><label style="flex:2">Address<input name="address"></label>`
        : `<label style="width:170px">Plant<select name="plant">${plants.map(p => `<option>${esc(p.name)}</option>`).join('')}</select></label>
           <label style="flex:2">Expense name<input name="name" placeholder="e.g. ELECTRICITY, MUNSHI SALARY"></label><label style="width:180px">Amount ₹ per month<input name="amount" type="number" step="0.01"></label>`}
        <button type="submit" id="ssave">Add</button><button type="button" class="sec" id="scancel" hidden>Cancel</button></form>
      <table class="t"><thead><tr>${isPl ? '<th>Plant</th><th>Name</th><th>Address</th>' : '<th>Plant</th><th>Expense</th><th class="num">Amount / month</th>'}<th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr>${isPl ? `<td><b>${esc(r.name)}</b></td><td>${esc(r.full_name)}</td><td>${esc(r.address)}</td>` : `<td>${esc(r.plant)}</td><td><b>${esc(r.name)}</b></td><td class="num">${money(r.amount)}</td>`}
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button>${isPl ? '' : ` <button class="small sec" data-rm="${r.id}">Remove</button>`}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Nothing here yet.</td></tr>'}
      </tbody></table>
      ${isPl ? '<p class="hint">The short name is what invoices use, so it cannot be changed once the plant is in use.</p>' : '<p class="hint">These amounts are added every month to the plant in Factory Wages. A month you have saved keeps its own amounts.</p>'}</div></div>`;
  const f = $('#sf', box); let editing = null;
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f);
    await guard(() => isPl ? (editing ? PUT('/api/m/plants/' + editing, d) : POST('/api/m/plants', d)) : (editing ? PUT('/api/factory-fixed/' + editing, d) : POST('/api/factory-fixed', d)));
    toast(editing ? 'Updated' : 'Added'); if (isPl) S.meta = await GET('/api/meta'); specialList(box, key, def, lists);
  };
  $('#scancel', box).onclick = () => specialList(box, key, def, lists);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id;
      for (const k of ['name', 'full_name', 'address', 'plant', 'amount']) if (f[k]) f[k].value = r[k] ?? '';
      if (isPl) f.name.readOnly = true; $('#ssave', box).textContent = 'Update'; $('#scancel', box).hidden = false; }
    if (rm && confirm('Remove this fixed expense? Months already saved keep it.')) { await guard(() => DEL('/api/factory-fixed/' + rm.dataset.rm)); specialList(box, key, def, lists); }
  };
}

// ---------- Factory wages: Parakh Marketing invoices only ----------
TITLES.wages = 'Factory Wages';
const MONTHS = ['April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March'];
PAGES.wages = async (el) => {
  const st = S.wg = S.wg || {};
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  st.fy = st.fy || S.fy || S.meta.current_fy;
  const y0 = Number(st.fy.slice(0, 4));
  const months = MONTHS.map((n, i) => { const y = i < 9 ? y0 : y0 + 1, m = ((i + 3) % 12) + 1; return [`${y}-${String(m).padStart(2, '0')}`, `${n} ${y}`]; });
  if (!st.month || !months.some(m => m[0] === st.month)) { const now = new Date().toISOString().slice(0, 7); st.month = months.some(m => m[0] === now) ? now : months[0][0]; }
  const d = await guard(() => GET('/api/wages?month=' + st.month));
  const rows = [];   // editable expense rows of both plants
  d.plants.forEach(p => { p.fixed.forEach(x => rows.push({ ...x, plant: p.plant, kind: 'FIXED' })); p.extra.forEach(x => rows.push({ ...x, plant: p.plant, kind: 'EXTRA' })); });
  const plantNames = d.plants.map(p => p.plant);
  const render = () => {
    const tot = p => {
      const mine = rows.filter(r => r.plant === p.plant);
      const fx = mine.filter(r => r.kind === 'FIXED').reduce((s, r) => s + (+r.amount || 0), 0), ex = mine.filter(r => r.kind === 'EXTRA').reduce((s, r) => s + (+r.amount || 0), 0);
      return { fx: r2(fx), ex: r2(ex), all: r2(p.wages + fx + ex) };
    };
    const rowHtml = (r, i) => `<tr data-i="${i}"><td>${r.kind === 'FIXED' ? '<span class="badge slate">fixed</span>' : ''}<input data-k="description" value="${esc(r.description || '')}" style="min-width:150px"></td>
      <td><input data-k="qty" type="number" step="0.001" value="${r.qty ?? ''}" style="width:80px"></td><td><input data-k="rate" type="number" step="0.01" value="${r.rate ?? ''}" style="width:90px"></td>
      <td><input data-k="amount" type="number" step="0.01" value="${r.amount ?? ''}" style="width:110px"></td><td><button type="button" class="small sec" data-del="${i}">✕</button></td></tr>`;
    el.innerHTML = `
    <div class="toolbar"><label>F.Y.<select id="wfy">${fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label>Month<select id="wmo">${months.map(([v, t]) => `<option value="${v}" ${v === st.month ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <span class="hint" style="align-self:end">Only <b>Parakh Marketing</b> invoices · ${d.saved ? 'saved month' : '<b>not saved yet</b>'}</span>
      <span class="spacer"></span><button class="sec" id="wexp">Export</button><button id="wsave">💾 Save</button></div>
    ${d.forms_without_rate.length ? `<div class="firmbox" style="margin-bottom:12px">No wage rate yet for: <b>${d.forms_without_rate.map(esc).join(', ')}</b> — set it in <a href="#/itemlists/form">Item lists → Item form</a>.</div>` : ''}
    ${d.no_plant_qty ? `<div class="firmbox" style="margin-bottom:12px">${qty(d.no_plant_qty)} MT of Parakh Marketing invoices in this month have no dispatch plant and are not counted.</div>` : ''}
    <div class="grid g2" style="align-items:start">${d.plants.map(p => { const t = tot(p); return `<div class="card"><h3>${esc(p.plant)} <span class="hint">${esc(p.full_name || '')}</span></h3>
      <table class="t"><thead><tr><th>Grade</th><th>Form</th><th class="num">Dispatched MT</th><th class="num">Wages / MT</th><th class="num">Amount</th></tr></thead><tbody>
      ${p.dispatch.map(g => `<tr><td><b>${esc(g.grade)}</b></td><td>${esc(g.form)}</td><td class="num">${qty(g.qty)}</td><td class="num">${g.rate ? money(g.rate) : '<span class="badge amber">no rate</span>'}</td><td class="num">${money(g.amount)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">No dispatch in this month.</td></tr>'}
      <tr class="tot"><td colspan="2">Total dispatch & wages</td><td class="num"><b>${qty(p.qty)}</b></td><td></td><td class="num"><b>${money(p.wages)}</b></td></tr></tbody></table>
      <h4 style="margin:14px 0 6px">Fixed & other expenses</h4>
      <table class="t wrows" data-plant="${esc(p.plant)}"><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th><th></th></tr></thead><tbody>
      ${rows.map((r, i) => r.plant === p.plant ? rowHtml(r, i) : '').join('') || '<tr><td colspan="5" class="muted">No expenses.</td></tr>'}</tbody></table>
      <div class="totals" style="margin-top:10px"><div><span>Wages on dispatch</span><b>₹ ${money(p.wages)}</b></div><div><span>Fixed expenses</span><b>₹ ${money(t.fx)}</b></div>
        <div><span>Other expenses</span><b>₹ ${money(t.ex)}</b></div><div class="grand"><span>Total ${esc(p.plant)}</span><b>₹ ${money(t.all)}</b></div></div></div>`; }).join('')}</div>
    <div class="card"><h3>Add expense</h3><form id="wadd" class="row" autocomplete="off">
      <label>Plant<select name="plant">${plantNames.map(n => `<option>${esc(n)}</option>`).join('')}</select></label>
      <label style="flex:2">Description<input name="description"></label><label>Qty<input name="qty" type="number" step="0.001"></label>
      <label>Rate<input name="rate" type="number" step="0.01"></label><label>Amount<input name="amount" type="number" step="0.01"></label>
      <button type="submit">Add</button></form><p class="hint">Qty × rate fills the amount. Press <b>💾 Save</b> to keep the expenses of this month. Dispatch always comes from the invoices and cannot be changed here.</p></div>
    <div class="card" style="text-align:center"><span class="hint">Both plants — ${esc(months.find(m => m[0] === st.month)[1])}</span>
      <div style="font-size:24px;font-weight:800">₹ ${money(d.plants.reduce((s, p) => s + tot(p).all, 0))}</div>
      <span class="hint">${qty(d.plants.reduce((s, p) => s + p.qty, 0))} MT dispatched</span></div>`;
    $('#wfy').onchange = () => { if (S.dirty && !confirm('Leave without saving?')) return; st.fy = $('#wfy').value; st.month = null; S.dirty = false; PAGES.wages(el); };
    $('#wmo').onchange = () => { if (S.dirty && !confirm('Leave without saving?')) return; st.month = $('#wmo').value; S.dirty = false; PAGES.wages(el); };
    $('#wsave').onclick = async () => { await guard(() => PUT('/api/wages', { month: st.month, rows })); S.dirty = false; toast('Saved'); PAGES.wages(el); };
    $('#wexp').onclick = () => downloadCsv(`factory_wages_${st.month}.csv`, [
      ...d.plants.flatMap(p => p.dispatch.map(g => ({ plant: p.plant, type: 'DISPATCH', description: g.grade + ' (' + g.form + ')', qty: g.qty, rate: g.rate, amount: g.amount }))),
      ...rows.map(r => ({ plant: r.plant, type: r.kind, description: r.description, qty: r.qty, rate: r.rate, amount: r.amount }))]);
    const fa = $('#wadd');
    const fill = () => { if (fa.qty.value && fa.rate.value) fa.amount.value = r2(+fa.qty.value * +fa.rate.value); };
    fa.qty.oninput = fill; fa.rate.oninput = fill;
    fa.onsubmit = e => { e.preventDefault(); const v = formData(fa); if (!v.description) return toast('Enter the description.', true);
      if (!v.amount && v.qty && v.rate) v.amount = r2(+v.qty * +v.rate); if (!(+v.amount)) return toast('Enter the amount (or qty and rate).', true);
      rows.push({ ...v, kind: 'EXTRA' }); S.dirty = true; render(); };
  };
  render();
  el.oninput = e => {
    const tr = e.target.closest('.wrows tr[data-i]'); if (!tr) return;
    const r = rows[+tr.dataset.i], k = e.target.dataset.k; r[k] = e.target.value; S.dirty = true;
    if ((k === 'qty' || k === 'rate') && r.qty !== '' && r.qty != null && r.rate !== '' && r.rate != null) { r.amount = r2(+r.qty * +r.rate); $('[data-k=amount]', tr).value = r.amount; }
    if (k === 'amount') r.amount_typed = 1;
  };
  el.onchange = e => { if (e.target.closest('.wrows')) render(); };
  el.onclick = e => { const b = e.target.closest('[data-del]'); if (b) { rows.splice(+b.dataset.del, 1); S.dirty = true; render(); } };
};

PAGES.itemlists = async (el, key) => { await loadLists(true); return listsPage(el, key || 'product'); };

PAGES.buyers = el => masterTable(el, 'parties', `<div class="tabs"><button data-firm="" class="on">All</button><button data-firm="PM">Parakh Marketing</button><button data-firm="PF">Parakh Fertilizer</button><button data-firm="NONE">Firm not set</button></div>`);
PAGES.masters = async (el, tab) => {
  tab = tab || 'lorries';
  if (tab.startsWith('lists')) return go('#/itemlists/' + (tab.split(':')[1] || ''));
  const tabs = [['lorries', 'Lorries & owners'], ['transporters', 'Transporters'], ['suppliers', 'Suppliers'], ['plants', 'Plants']];
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px">${tabs.map(([k, t]) => `<button class="${k === tab.split(':')[0] ? 'on' : ''}" onclick="go('#/masters/${k}')">${t}</button>`).join('')}</div><div id="mt"></div>`;
  await loadLists(true);
  await masterTable($('#mt'), tab);
};

// ---------- reports ----------
PAGES.reports = async (el, tab) => {
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px"><button class="${tab !== 'tds' ? 'on' : ''}" onclick="go('#/reports')">Sales & inward</button>
    <button class="${tab === 'tds' ? 'on' : ''}" onclick="go('#/reports/tds')">Transporter TDS</button></div><div id="rp"></div>`;
  if (tab === 'tds') return tdsReport($('#rp'));
  return salesReport($('#rp'));
};

// ---------- Reports → Transporter TDS: declarations u/s 194C(6), one per F.Y., transporter and buyer ----------
async function tdsReport(el) {
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  let fy = S.tdsFy || S.fy, trId = S.tdsTr || '';
  const load = async () => {
    const rows = await GET('/api/tds?fy=' + fy);
    const trs = [...new Map(rows.map(r => [r.transporter_id, r])).values()];
    if (trId && !trs.some(t => String(t.transporter_id) === String(trId))) trId = '';
    const tr = trs.find(t => String(t.transporter_id) === String(trId));
    const list = rows.filter(r => !trId || String(r.transporter_id) === String(trId));
    el.innerHTML = `<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:10px">
        <label>F.Y.<select id="tfy">${fys.map(x => `<option ${x === fy ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
        <label style="min-width:320px">Transporter<select id="ttr"><option value="">— all transporters (${trs.length}) —</option>${trs.map(t => `<option value="${t.transporter_id}" ${String(t.transporter_id) === String(trId) ? 'selected' : ''}>${esc(t.transporter)}${t.has_pan_card ? '' : ' (no PAN card)'}</option>`).join('')}</select></label>
        <span class="spacer"></span><button class="sec" id="tmpl">✎ Email matter</button></div>
      ${tr ? `<div class="firmbox" style="margin:10px 0">${esc(tr.transporter)} · PAN <b>${esc(tr.pan || '—')}</b> · Declarant <b>${esc(tr.proprietor || '—')}</b> · Email ${esc(tr.tr_email || '—')}
        · PAN card ${tr.has_pan_card ? '<span class="badge slate">✔</span>' : '<span class="badge amber">not uploaded — Masters → Transporters</span>'}</div>` : ''}
      <div class="tablewrap"><table class="t"><thead><tr>${trId ? '' : '<th>Transporter</th>'}<th>Buyer invoiced in ${esc(fy)}</th><th class="num">Invoices</th><th>First invoice</th>
        <th>Sent to transporter</th><th>Sent to buyer</th><th></th></tr></thead><tbody>
      ${list.map(r => `<tr>${trId ? '' : `<td><b>${esc(r.transporter)}</b>${r.has_pan_card ? '' : ' <span class="badge amber">no PAN card</span>'}</td>`}
        <td><b>${esc(r.buyer)}</b><br><span class="hint">${esc([r.city, r.state].filter(Boolean).join(', '))}</span></td><td class="num">${r.invoices}</td><td>${dmy(r.first_date)}</td>
        <td>${r.sent_transporter_at ? '<span class="badge slate">' + esc(r.sent_transporter_at) + '</span>' : '<span class="muted">not sent</span>'}</td>
        <td>${r.sent_buyer_at ? '<span class="badge slate">' + esc(r.sent_buyer_at) + '</span>' : '<span class="muted">not sent</span>'}${r.last_error ? `<div class="hint" style="color:#b42318" title="${esc(r.last_error)}">⚠ ${esc(r.last_error.slice(0, 80))}</div>` : ''}</td>
        <td style="white-space:nowrap;text-align:right"><button class="small sec" data-act="print" data-t="${r.transporter_id}" data-p="${r.party_id}">🖨 Print</button>
          <button class="small sec" data-act="transporter" data-t="${r.transporter_id}" data-p="${r.party_id}">✉ Transporter</button>
          <button class="small sec" data-act="buyer" data-t="${r.transporter_id}" data-p="${r.party_id}">✉ Buyer</button></td></tr>`).join('')
        || `<tr><td colspan="7" class="muted">No invoices with a transporter from the Transporters list in ${esc(fy)}.</td></tr>`}
      </tbody></table></div>
      <p class="hint">One declaration per financial year for every buyer invoiced with the transporter. It is emailed by itself to the transporter and the buyer with the first new invoice, once the transporter's PAN card is uploaded.</p></div>`;
    $('#tfy').onchange = () => { fy = S.tdsFy = $('#tfy').value; load(); };
    $('#ttr').onchange = () => { trId = S.tdsTr = $('#ttr').value; load(); };
    $('#tmpl').onclick = tdsTemplates;
    el.onclick = e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const qs = `fy=${encodeURIComponent(fy)}&t=${b.dataset.t}&p=${b.dataset.p}`;
      if (b.dataset.act === 'print') window.open('/print/tds?' + qs, '_blank');
      else tdsEmail(fy, b.dataset.t, b.dataset.p, b.dataset.act, load);
    };
  };
  await load();
}
async function tdsEmail(fy, t, p, who, after) {
  const d = await guard(() => GET(`/api/tds/draft?fy=${encodeURIComponent(fy)}&t=${t}&p=${p}&who=${who}`));
  const blocking = d.problems.filter(x => !/email/.test(x));
  modal(`Email TDS declaration to the ${who}`, `
    ${d.problems.length ? `<p class="badge ${blocking.length ? 'red' : 'amber'}">Missing: ${esc(d.problems.join(', '))}</p>` : ''}
    ${d.from ? '' : `<p class="badge amber">Email is not set up for ${esc(d.firm)}. Settings → Companies → Email.</p>`}
    <form id="tef"><div class="grid g2">${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, '')}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <label class="span2">Message<textarea name="text" style="min-height:240px">${esc(d.text)}</textarea></label></div>
      <p class="hint">The declaration PDF (with the PAN card) is attached. Sent from ${esc(d.from || '—')} (${esc(d.firm)}).</p>
      <div class="row"><button type="submit" ${blocking.length || !d.from ? 'disabled' : ''}>Send email</button>
        <button type="button" class="sec" onclick="window.open('/print/tds?fy=${encodeURIComponent(fy)}&t=${t}&p=${p}','_blank')">Preview</button></div></form>`, root => {
    $('#tef', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try { await POST('/api/tds/send', { ...formData(e.target), fy, t, p, who }); toast('Declaration sent'); closeModal(); after && after(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}
async function tdsTemplates() {
  const d = await GET('/api/tds/templates');
  modal('Email matter for the TDS declaration', `<form id="ttf">
    <p class="hint">You can use: {transporter} {pan} {proprietor} {buyer} {buyer_city} {fy} {firm}</p>
    <h3>To the transporter</h3>${field({ name: 'tds_subject_transporter', label: 'Subject' }, d.tds_subject_transporter)}
    <label>Message<textarea name="tds_body_transporter" style="min-height:170px">${esc(d.tds_body_transporter)}</textarea></label>
    <h3 style="margin-top:14px">To the buyer</h3>${field({ name: 'tds_subject_buyer', label: 'Subject' }, d.tds_subject_buyer)}
    <label>Message<textarea name="tds_body_buyer" style="min-height:170px">${esc(d.tds_body_buyer)}</textarea></label>
    <div class="row" style="margin-top:12px"><button type="submit">Save</button><button type="button" class="sec" id="ttdef">Back to the default matter</button></div></form>`, root => {
    $('#ttf', root).onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/tds/templates', formData(e.target))); toast('Email matter saved'); closeModal(); };
    $('#ttdef', root).onclick = () => { for (const k of Object.keys(d.defaults)) $('#ttf', root)[k].value = d.defaults[k]; };
  });
}

async function salesReport(el) {
  const d = await GET('/api/reports/monthly?fy=' + S.fy);
  const months = [...new Set([...d.sales.map(r => r.ym), ...d.inward.map(r => r.ym)])].filter(Boolean).sort();
  const cell = (ym, firm, k) => { const r = d.sales.find(x => x.ym === ym && x.firm_code === firm); return r ? r[k] : null; };
  el.innerHTML = `
  <div class="card"><div class="toolbar"><h3 style="margin:0">Month-wise sales · ${esc(S.fy)}</h3><span class="spacer"></span><button class="sec" id="c1">Export</button></div>
    <div class="tablewrap"><table class="t"><thead><tr><th>Month</th>${['PM', 'PF', 'PPE'].map(f => `<th class="num">${f} qty</th><th class="num">${f} total</th>`).join('')}</tr></thead><tbody>
    ${months.map(m => `<tr><td>${m}</td>${['PM', 'PF', 'PPE'].map(f => `<td class="num">${qty(cell(m, f, 'qty'))}</td><td class="num">${cell(m, f, 'total') == null ? '' : money(cell(m, f, 'total'))}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div></div>
  <div class="grid g2">
    <div class="card"><div class="toolbar"><h3 style="margin:0">Inward month-wise</h3><span class="spacer"></span><button class="sec" id="c2">Export</button></div>
      <table class="t"><thead><tr><th>Month</th><th class="num">Lorries</th><th class="num">Rawana MT</th><th class="num">Actual MT</th><th class="num">Freight</th></tr></thead><tbody>
      ${d.inward.map(r => `<tr><td>${r.ym}</td><td class="num">${r.n}</td><td class="num">${qty(r.rawana)}</td><td class="num">${qty(r.actual)}</td><td class="num">${money(r.freight)}</td></tr>`).join('')}</tbody></table></div>
    <div class="card"><div class="toolbar"><h3 style="margin:0">HSN summary (for GST return)</h3><span class="spacer"></span><button class="sec" id="c3">Export</button></div>
      <table class="t"><thead><tr><th>Firm</th><th>HSN</th><th class="num">GST %</th><th class="num">Qty MT</th><th class="num">Taxable</th></tr></thead><tbody>
      ${d.hsn.map(r => `<tr><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${esc(r.hsn)}</td><td class="num">${r.gst_rate}</td><td class="num">${qty(r.qty)}</td><td class="num">${money(r.taxable)}</td></tr>`).join('')}</tbody></table></div>
  </div>`;
  $('#c1').onclick = () => downloadCsv(`sales_monthly_${S.fy}.csv`, d.sales);
  $('#c2').onclick = () => downloadCsv(`inward_monthly_${S.fy}.csv`, d.inward);
  $('#c3').onclick = () => downloadCsv(`hsn_${S.fy}.csv`, d.hsn);
};

// ---------- settings ----------
PAGES.settings = async (el, arg) => {
  const [tab, sub] = (arg || 'company').split(':');
  const TABS = [['company', 'Companies'], ['computer', 'This computer'], ['data', 'Data location'], ['rules', 'Universal rules'], ['security', 'Security'], ['backup', 'Backup & files'], ['import', 'Import'], ['updates', 'Updates'], ['about', 'About']];
  el.innerHTML = `<div class="tabs" style="margin-bottom:16px">${TABS.map(([k, t]) => `<button class="${k === tab ? 'on' : ''}" onclick="go('#/settings/${k}')">${t}</button>`).join('')}</div><div id="st"></div>`;
  const box = $('#st');
  await (SETTINGS[tab] || SETTINGS.company)(box, sub);
};

const SETTINGS = {};

// ----- Companies: one tab for each firm -----
SETTINGS.company = async (box, code) => {
  const firms = await GET('/api/m/firms');
  const s = await GET('/api/settings');
  code = firms.some(f => f.code === code) ? code : 'PM';
  const f = firms.find(x => x.code === code);
  const mail = s.firms.find(x => x.code === code) || {};
  box.innerHTML = `
  <div class="tabs" style="margin-bottom:14px">${firms.map(x => `<button class="${x.code === code ? 'on' : ''}" onclick="go('#/settings/company:${x.code}')"><span class="badge ${x.code}" style="margin-right:6px">${x.code}</span>${esc(x.name)}</button>`).join('')}</div>
  <div class="grid" style="grid-template-columns:300px 1fr;align-items:start">
    <div><div class="card" style="text-align:center"><h3>Company logo</h3>
      <div id="logoprev" style="height:150px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--line);border-radius:10px;background:#fafcfc;margin-bottom:12px">
        ${f.logo ? `<img src="${f.logo}" style="max-height:130px;max-width:240px">` : '<span class="muted">No logo yet</span>'}</div>
      <input type="file" id="logofile" accept="image/png,image/jpeg,image/webp" hidden>
      <div class="row" style="justify-content:center"><button id="logoup">Upload logo</button>${f.logo ? '<button class="sec" id="logodel">Remove</button>' : ''}</div>
      <p class="hint" style="margin-top:10px">Printed at the top of this company's invoices and vouchers. PNG or JPG, square or wide.</p>
    </div>
    ${['signature', 'bank_proof'].map(k => `<div class="card" style="text-align:center;margin-top:0"><h3>${k === 'signature' ? 'Signature' : 'Bank proof'}</h3>
      <div style="height:${k === 'signature' ? 110 : 150}px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--line);border-radius:10px;background:#fafcfc;margin-bottom:12px">
        ${f[k] ? `<img src="${f[k]}" style="max-height:${k === 'signature' ? 100 : 140}px;max-width:240px">` : `<span class="muted">No ${k === 'signature' ? 'signature' : 'bank proof'} yet</span>`}</div>
      <input type="file" id="${k}file" accept="image/png,image/jpeg,image/webp" hidden>
      <div class="row" style="justify-content:center"><button type="button" data-imgup="${k}">Upload</button>${f[k] ? `<button type="button" class="sec" data-imgdel="${k}">Remove</button>` : ''}</div>
      <p class="hint" style="margin-top:10px">${k === 'signature' ? 'Sign on white paper and take a photo. The white space is cut away and the paper made see-through. Printed above “Authorised Signatory” on this company’s invoices and vouchers.' : 'Cancelled cheque or passbook page. The white border is cut away.'}</p>
    </div>`).join('')}</div>
    <div>
      <form id="cf" class="card"><h3>Company details</h3>
        <div class="grid g4">
          ${field({ name: 'name', label: 'Company name', span: 2 }, f.name)}${field({ name: 'gstin', label: 'GSTIN' }, f.gstin)}${field({ name: 'pan', label: 'PAN' }, f.pan)}
          ${field({ name: 'address', label: 'Address', span: 4 }, f.address)}
          ${field({ name: 'pincode', label: 'Pincode (fills city & state)' }, f.pincode)}${field({ name: 'city', label: 'City' }, f.city)}
          ${field({ name: 'state', label: 'State', type: 'select', options: STATES() }, f.state)}${field({ name: 'state_code', label: 'State code', ro: true }, f.state_code)}
          ${field({ name: 'phone', label: 'Phone' }, f.phone)}${field({ name: 'email', label: 'Email', span: 2 }, f.email)}<div></div>
        </div>
        <h3 style="margin-top:18px">Bank & UPI <span class="hint">(printed on invoices)</span></h3>
        <div class="grid g4">
          ${field({ name: 'bank_name', label: 'Bank name' }, f.bank_name)}${field({ name: 'bank_account', label: 'Account no.' }, f.bank_account)}
          ${field({ name: 'bank_ifsc', label: 'IFSC' }, f.bank_ifsc)}${field({ name: 'bank_branch', label: 'Branch' }, f.bank_branch)}
          ${field({ name: 'upi_id', label: 'UPI id (for the QR code)', span: 2 }, f.upi_id)}
        </div>
        <h3 style="margin-top:18px">Terms of sale <span class="hint">(printed on invoices)</span></h3>
        ${field({ name: 'terms', label: '', type: 'textarea' }, f.terms)}
        <div class="row" style="margin-top:14px"><button type="submit">Save company details</button></div>
      </form>
      ${code === 'PPE' ? '' : `
      <form id="ef" class="card"><h3>Email sending <span class="hint">— invoices are emailed from this address, no Outlook needed</span></h3>
        <div class="grid g4">
          <label class="span2">Sender email<input name="smtp_user" placeholder="sender@gmail.com" value="${esc(mail.smtp_user || '')}"></label>
          <label class="span2">App password ${mail.has_pass ? '<span class="badge PF">saved</span>' : ''}<input name="smtp_pass" type="password" placeholder="${mail.has_pass ? 'leave blank to keep the saved one' : '16-letter Google app password'}"></label>
          <label class="span2">Mail server<input name="smtp_host" value="${esc(mail.smtp_host || 'smtp.gmail.com')}"></label>
          <label>Port<input name="smtp_port" value="${esc(mail.smtp_port || 465)}"></label><div></div>
        </div>
        <p class="hint">Gmail: turn on 2-Step Verification, then Google Account → Security → App passwords → create one and paste it here.</p>
        <div class="row"><button type="submit">Save email settings</button><button type="button" class="sec" id="etest">Send test email</button></div>
      </form>`}
    </div>
  </div>`;
  const cf = $('#cf', box);
  hookPincode(cf);
  cf.onsubmit = async e => { e.preventDefault(); const d = formData(cf); delete d.state_code;
    await guard(() => PUT('/api/m/firms/' + f.id, d)); toast(`${d.name} saved`); S.meta = await GET('/api/meta'); route(); };
  $$('[data-imgup]', box).forEach(b => { const k = b.dataset.imgup; b.onclick = () => $('#' + k + 'file', box).click();
    $('#' + k + 'file', box).onchange = async () => {
      const file = $('#' + k + 'file', box).files[0]; if (!file) return;
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('That file is not a picture.')); i.src = URL.createObjectURL(file); }).catch(e => { toast(e.message, true); return null; });
      if (!img) return;
      const data = k === 'signature' ? await signatureImage(img) : cropBlank(img, 1200);
      await guard(() => PUT('/api/m/firms/' + f.id, { [k]: data })); toast('Saved'); route();
    }; });
  $$('[data-imgdel]', box).forEach(b => b.onclick = async () => { if (confirm('Remove this picture?')) { await guard(() => PUT('/api/m/firms/' + f.id, { [b.dataset.imgdel]: '' })); route(); } });
  $('#logoup', box).onclick = () => $('#logofile', box).click();
  $('#logofile', box).onchange = async () => {
    const file = $('#logofile', box).files[0]; if (!file) return;
    const logo = await shrinkImage(file, 600);
    await guard(() => PUT('/api/m/firms/' + f.id, { logo })); toast('Logo saved'); route();
  };
  const ld = $('#logodel', box); if (ld) ld.onclick = async () => { if (confirm('Remove the logo?')) { await guard(() => PUT('/api/m/firms/' + f.id, { logo: '' })); route(); } };
  const ef = $('#ef', box);
  if (ef) {
    ef.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/settings/email/' + code, formData(ef))); toast('Email settings saved'); route(); };
    $('#etest', box).onclick = async () => { const b = $('#etest', box); b.disabled = true; b.textContent = 'Sending…';
      try { await POST(`/api/settings/email/${code}/test`, {}); toast('Test email sent — check the inbox'); } catch (err) { toast(err.message, true); }
      b.disabled = false; b.textContent = 'Send test email'; };
  }
};

// resize an image in the browser so the logo stays small
function shrinkImage(file, max) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('That file is not a picture.'));
    img.src = URL.createObjectURL(file);
  });
}

// ----- This computer: settings kept on this PC only (not in the shared data) -----
SETTINGS.computer = async (box) => {
  const ps = await GET('/api/pc-settings');
  box.innerHTML = `
  <div class="card"><h3>This computer: <span style="color:var(--rust)">${esc(ps.pc)}</span></h3>
    <p class="hint" style="margin:0">Settings on this tab belong to this computer only. They are saved in its own program folder
      (<code>${esc(ps.file)}</code>), not in the shared data, so the office PC, home PC and laptop can each be set differently. Updates never change them.</p></div>
  <div class="card"><h3>Start when Windows starts</h3><div id="startbox" class="hint">Checking…</div></div>
  <div class="card"><h3>Printers</h3><div id="printbox" class="hint">Loading…</div></div>`;
  printersSection($('#printbox', box));
  const showStart = s => {
    const sb = $('#startbox', box);
    if (!s.supported) { sb.textContent = 'Only available when Mineral Saathi runs on Windows.'; return; }
    sb.innerHTML = `<label style="display:flex;gap:10px;align-items:center;font-size:15px;color:var(--text);font-weight:600">
        <input type="checkbox" id="startchk" style="width:auto;transform:scale(1.3)" ${s.enabled ? 'checked' : ''}>
        Start Mineral Saathi automatically when <b>${esc(s.pc)}</b> starts</label>
      <p class="hint" style="margin:8px 0 0">Keep this <b>on</b> for the office PC. Turn it <b>off</b> on the home PC and laptop, so the data is opened there only when you open it yourself.
        This setting is for the computer that runs Mineral Saathi (${esc(s.pc)}).</p>`;
    $('#startchk', box).onchange = async () => showStart(await guard(() => PUT('/api/startup', { enabled: $('#startchk', box).checked })));
  };
  GET('/api/startup').then(showStart).catch(() => { $('#startbox', box).textContent = 'Could not check.'; });
};

async function printersSection(box) {
  const ps = await GET('/api/print-setup');
  const KINDS = [['invoice', 'Invoice (A4)'], ['label', 'Bag / parcel sticker (4 × 6)'], ['envelope', 'Envelope']];
  const PAPER_NAMES = { A4: 'A4 (210 × 297)', A5: 'A5 (148 × 210)', LETTER: 'Letter', LABEL4X6: '4 × 6 inch label (101.6 × 152.4)', ENV_DL: 'Envelope DL (220 × 110)', ENV_C5: 'Envelope C5 (229 × 162)', ENV_10: 'Envelope No.10 (241 × 105)', '': 'Own size' };
  const rules = `<div class="row" style="margin:6px 0 14px"><label style="width:220px">One invoice copy from (MT)<input id="singlemt" type="number" step="0.5" value="${ps.single_copy_mt}"></label>
    <span class="hint">Invoices of ${ps.single_copy_mt} MT or more print 1 copy; smaller ones print 2 (Original + Duplicate). Same rule on every computer.</span><button class="sec small" id="savemt">Save</button></div>`;
  if (!ps.local) {
    const w = printWhere();
    box.innerHTML = `${rules}<p style="color:var(--text)">This computer opens Mineral Saathi from the main PC (${esc(ps.pc)}). Choose how it prints:</p>
      <label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text)"><input type="radio" name="pw" value="window" style="width:auto" ${w !== 'main' ? 'checked' : ''}> Print window on this computer (choose this computer's printer; paper size is set already)</label>
      <label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text);margin-top:6px"><input type="radio" name="pw" value="main" style="width:auto" ${w === 'main' ? 'checked' : ''}> Print straight on the main PC's printers (${esc(ps.pc)}), no print window</label>`;
    $$('[name=pw]', box).forEach(r => r.onchange = () => { try { localStorage.setItem('ms_print_where', r.value); } catch { } toast('Saved for this computer'); });
  } else if (!ps.direct) {
    box.innerHTML = rules + 'Direct printing works when Mineral Saathi runs on Windows. Here the print window is used.';
  } else {
    const pl = await GET('/api/printers');
    box.innerHTML = rules + KINDS.map(([k, title]) => {
      const s = ps.kinds[k];
      return `<form class="pform card" data-k="${k}" style="background:#f7fafb;margin:0 0 12px"><h3 style="margin-bottom:8px">${title}</h3>
        <div class="grid g4">
          <label class="span2">Printer<select name="printer"><option value="">— choose —</option>${pl.printers.map(n => `<option ${n === s.printer ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
          <label class="span2">Paper<select name="paper">${Object.keys(PAPER_NAMES).map(pk => `<option value="${pk}" ${pk === (s.paper || '') ? 'selected' : ''}>${PAPER_NAMES[pk]}</option>`).join('')}</select></label>
          <label>Width mm<input name="w" type="number" step="0.1" value="${s.w}"></label><label>Height mm<input name="h" type="number" step="0.1" value="${s.h}"></label>
          <label>Margin mm<input name="margin" type="number" step="0.5" value="${s.margin}"></label>
          <label>Size %<input name="scale" type="number" step="1" value="${s.scale}"></label>
          <label>Shift right mm<input name="ox" type="number" step="0.5" value="${s.ox}"></label><label>Shift down mm<input name="oy" type="number" step="0.5" value="${s.oy}"></label>
          <label class="span2" style="display:flex;gap:8px;align-items:center;font-size:13px;margin-top:18px"><input type="checkbox" name="landscape" style="width:auto" ${s.landscape ? 'checked' : ''}> Landscape (wide)</label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit">Save</button><button type="button" class="sec ptest">Print a test</button>
          <span class="hint pnote">${pl.default ? 'Windows default printer: ' + esc(pl.default) : ''}</span></div></form>`;
    }).join('') + `<p class="hint">Prints go straight to the chosen printer with no print window. Use "Shift" if the print sits off-centre on the paper.</p>`;
    $$('.pform', box).forEach(f => {
      const k = f.dataset.k;
      const lockSize = () => { const own = !f.paper.value; f.w.readOnly = !own; f.h.readOnly = !own; if (!own) { const [w, h] = ps.papers[f.paper.value]; f.w.value = w; f.h.value = h; } };
      f.paper.onchange = lockSize; lockSize();
      f.onsubmit = async e => { e.preventDefault(); const d = formData(f); d.landscape = f.landscape.checked;
        ps.kinds[k] = await guard(() => PUT('/api/print-setup/' + k, d)); toast('Printer settings saved for this computer'); };
      $('.ptest', f).onclick = async () => { const d = formData(f); d.landscape = f.landscape.checked;
        await guard(() => PUT('/api/print-setup/' + k, d)); toast('Printing a test…');
        const r = await guard(() => POST('/api/print/test/' + k)); toast('Test sent to ' + r.printer); };
    });
  }
  $('#savemt', box).onclick = async () => { await guard(() => PUT('/api/print-rules', { single_copy_mt: $('#singlemt', box).value })); toast('Saved'); printersSection(box); };
}

// ----- Data location: office PC, home PC, laptop — one at a time -----
SETTINGS.data = async (box) => {
  const d = await GET('/api/data-location');
  const lk = d.lock || {};
  box.innerHTML = `
  <div class="card"><h3>Where the data is</h3>
    <div class="grid g3">
      <div class="firmbox"><span class="hint">This computer</span><br><b style="font-size:17px">${esc(d.pc)}</b></div>
      <div class="firmbox"><span class="hint">Data folder</span><br><b>${esc(d.data_folder)}</b><br><span class="hint">${(d.db_size / 1048576).toFixed(1)} MB</span></div>
      <div class="firmbox"><span class="hint">Mode</span><br><b>${d.shared ? 'Shared folder — office, home or laptop, one at a time' : 'Only on this computer'}</b></div>
    </div>
    ${d.shared ? `<div class="row" style="margin-top:14px"><button class="rust" id="closeday">⏻ Close for today</button>
      <span class="hint">Press this before you leave, so the data can be opened on your home PC or laptop. Mineral Saathi stops on this computer.</span></div>` : ''}
  </div>
  ${d.shared ? `
  <div class="card"><h3>Use it at home or on the laptop</h3><ol style="line-height:1.8;margin:0;padding-left:20px">
    <li>On the office PC press <b>Close for today</b> (above). Wait a minute for Google Drive to sync.</li>
    <li>First time only on the home PC / laptop: install Google Drive for desktop (same Google account) and Node.js LTS, unzip the MineralSaathi program and open <b>Open-Mineral-Saathi.bat</b>.
      It asks <b>“Where is your data?”</b> — choose this folder:<br><b>${esc(d.data_folder)}</b> <span class="hint">(the drive letter may be different there)</span></li>
    <li>Open <b>Mineral Saathi</b> from the desktop. It waits until Google Drive has brought the latest data.</li>
    <li>When you finish there, press <b>Close for today</b> on that computer too. Next morning the office PC opens the data by itself.</li>
  </ol><p class="hint">If you forget to close, the other computer will not open the data and tells you where it is open. If that computer is off, use <code>windows\\Take-Over-Data.bat</code>.</p></div>` : ''}
  <div class="card"><h3>${d.shared ? 'Move the data to another folder' : 'Move the data to Google Drive (to use it at home / on the laptop)'}</h3>
    <p class="hint">Use a folder inside Google Drive, e.g. <code>G:\\My Drive\\Mineral Saathi Data</code>. In Google Drive, set this folder to <b>Available offline</b>.
      A backup is taken first; the server restarts by itself in a few seconds.</p>
    <div class="row"><label style="flex:1">New data folder<input id="newdir" placeholder="G:\\My Drive\\Mineral Saathi Data"></label>
      <label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" id="repl" style="width:auto"> replace data already in that folder</label>
      <button id="movego">Move data</button></div>
    ${d.shared ? '<p style="margin-top:12px"><button class="sec" id="moveback">Move the data back to this computer only</button></p>' : ''}
  </div>
  ${d.local ? `<div class="card"><h3>Use data from another folder</h3>
    <p class="hint">Link this computer to Mineral Saathi data that is already somewhere else (Google Drive, another disk, a pen drive). Nothing is copied or moved —
      Mineral Saathi restarts and shows <b>“Where is your data?”</b> to choose the folder.</p>
    <button class="sec" id="choosedata">Choose the data folder…</button></div>` : ''}`;
  const ch = $('#choosedata', box); if (ch) ch.onclick = async () => {
    if (S.dirty && !confirm('You have unsaved changes. Continue anyway?')) return;
    if (!confirm('Mineral Saathi restarts and asks where the data is. Continue?')) return;
    await guard(() => POST('/api/data-choose')); S.dirty = false;
    document.body.innerHTML = '<div style="margin:auto;text-align:center;font-family:Segoe UI,Arial;color:#2F4F5A"><h2>Restarting…</h2><p>The “Where is your data?” page opens in a few seconds.</p></div>';
    for (let i = 0; i < 40; i++) { await new Promise(r => setTimeout(r, 1500)); try { const v = await (await fetch('/api/version')).json(); if (v.setup) { location.href = '/'; return; } } catch {} }
  };
  const cd = $('#closeday', box); if (cd) cd.onclick = closeForToday;

  const mv = async folder => {
    if (!confirm(folder ? `Move the data to\n${folder}\n\nAll PCs will reconnect after a few seconds.` : 'Move the data back to this computer only?')) return;
    const r = await guard(() => POST('/api/data-location', { folder, replace: $('#repl', box).checked }));
    toast(`Data moved to ${r.folder} — restarting…`); setTimeout(() => location.reload(), 9000);
  };
  $('#movego', box).onclick = () => { const f = $('#newdir', box).value.trim(); if (!f) return toast('Type the folder first.', true); mv(f); };
  const mb = $('#moveback', box); if (mb) mb.onclick = () => mv('');
};

async function closeForToday() {
  if (S.dirty && !confirm('You have unsaved changes. Close anyway?')) return;
  if (!confirm('Close Mineral Saathi for today on this computer?\nThe data becomes free for your home PC or laptop.')) return;
  const r = await guard(() => POST('/api/close'));
  S.dirty = false;
  document.body.innerHTML = `<div style="margin:auto;text-align:center;font-family:Segoe UI,Arial;color:#2F4F5A">
    <img src="logo-icon.png" style="width:110px;border-radius:20px"><h1>Closed for today</h1>
    <p>Mineral Saathi has stopped on <b>${esc(r.pc)}</b>. The data is free to open on your home PC or laptop.</p>
    <p style="color:#63757b">Wait about a minute for Google Drive to finish syncing. You can close this window (Alt+F4).</p></div>`;
}

// ---------- Commission (private, own password) ----------
TITLES.commission = 'Commission';
PAGES.commission = async (el) => {
  if (!S.commPw) {
    el.innerHTML = `<div class="card" style="max-width:460px"><h3>🔒 Commission</h3><form id="cpf" autocomplete="off">
      <label>Commission password<input name="pw" type="password"></label>
      <div class="row" style="margin-top:12px"><button type="submit">Open</button><span class="hint">Set it in Settings → Security.</span></div></form></div>`;
    const f = $('#cpf'); f.pw.focus();
    f.onsubmit = async e => {
      e.preventDefault(); S.commPw = f.pw.value;
      try { await POST('/api/commission/check'); PAGES.commission(el); }
      catch (err) { S.commPw = null; toast(err.message, true); f.pw.select(); }
    };
    return;
  }
  const st = S.comm = S.comm || { fy: '', party: '', agent: '' };
  const d = await guard(() => GET(`/api/commission?fy=${encodeURIComponent(st.fy)}&party=${st.party}&agent=${encodeURIComponent(st.agent)}`));
  const buyer = d.buyers.find(b => String(b.id) === String(st.party));
  const buyers = st.agent ? d.buyers.filter(b => b.agents.includes(st.agent)) : d.buyers;
  const who = [st.agent && 'Agent ' + st.agent, buyer && buyer.name].filter(Boolean).join(' · ');
  el.innerHTML = `
  <div class="toolbar"><label>F.Y.<select id="cfy"><option value="">All years</option>${d.fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${esc(y)}</option>`).join('')}</select></label>
    <label>Agent<select id="cag"><option value="">— all agents —</option>${d.agents.map(a => `<option ${a === st.agent ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
    <label style="min-width:320px">Buyer <span class="hint">(only buyers with a commission rate)</span><select id="cpb"><option value="">— all buyers —</option>${buyers.map(b => `<option value="${b.id}" ${String(b.id) === String(st.party) ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></label>
    <label style="align-self:end"><button type="button" id="cxadd">+ Expense</button></label>
    <span class="spacer"></span><button class="sec" id="cimp">⬆ Import old payments</button><button class="sec" id="cexp">Export</button><button class="sec" id="clock">🔒 Lock</button></div>
  ${!d.buyers.length ? '<div class="card"><p>No buyer has a commission rate yet. Add it in Buyers → the buyer → items → <b>Commission ₹ / MT</b>.</p></div>' : `
  <div class="grid comm" style="grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);align-items:start">
    <style>.comm .t { font-size: 12.5px; } .comm .t td, .comm .t th { padding: 6px 8px; } .comm .tablewrap { overflow: auto; }</style>
    <div class="card"><h3>Commission on invoices <span class="hint">${d.lines.length} lines · ${qty(d.qty)} MT</span></h3>
      <div class="tablewrap" style="max-height:58vh"><table class="t"><thead><tr><th>Date</th><th>Invoice</th>${st.party ? '' : '<th>Buyer</th>'}<th>Item</th>${st.agent ? '' : '<th>Agent</th>'}<th class="num">Qty MT</th><th class="num">Rate / MT</th><th class="num">Commission</th></tr></thead><tbody>
      ${[...d.lines.map(l => ({ ...l, _k: 'L' })), ...d.extras.map(x => ({ ...x, _k: 'X' }))].sort((a, b) => (a.date || '').localeCompare(b.date || '')).map(l => l._k === 'L'
        ? `<tr><td>${dmy(l.date)}</td><td><span class="badge ${l.firm_code}">${l.firm_code}</span> <b>${esc(l.inv_no)}</b></td>${st.party ? '' : `<td>${esc(l.buyer)}</td>`}
        <td>${esc(l.item)}</td>${st.agent ? '' : `<td>${esc(l.agent)}</td>`}<td class="num">${qty(l.qty)}</td><td class="num">${money(l.rate)}</td><td class="num"><b>${money(l.commission)}</b></td></tr>`
        : `<tr style="background:#fbf7f4"><td>${dmy(l.date)}</td><td><span class="badge amber">EXPENSE</span></td>${st.party ? '' : `<td>${esc(l.buyer || '')}</td>`}
        <td>${esc(l.description)} <button class="small sec" data-xdel="${l.id}" title="Remove this expense">✕</button></td>${st.agent ? '' : `<td>${esc(l.agent || '')}</td>`}<td></td><td></td><td class="num"><b>${money(l.amount)}</b></td></tr>`).join('')
        || '<tr><td colspan="8" class="muted">No invoices for this choice.</td></tr>'}
      </tbody></table></div></div>
    <div class="card"><h3>Commission paid</h3>
      <div class="tablewrap" style="max-height:40vh"><table class="t"><thead><tr><th>Date</th>${st.party ? '' : '<th>Buyer / agent</th>'}<th class="num">Amount</th><th>Sent to</th><th>Via</th><th></th></tr></thead><tbody>
      ${d.payments.map(x => `<tr><td>${dmy(x.date)}</td>${st.party ? '' : `<td>${esc([x.buyer, x.agent && 'Agent ' + x.agent].filter(Boolean).join(' · '))}</td>`}<td class="num"><b>${money(x.amount)}</b></td><td>${esc(x.sent_to)}</td>
        <td>${esc(x.sent_via)}${x.ref ? `<br><span class="hint">${esc(x.ref)}</span>` : ''}${x.notes ? `<br><span class="hint">${esc(x.notes)}</span>` : ''}</td>
        <td><button class="small sec" data-cdel="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="6" class="muted">Nothing paid yet.</td></tr>'}
      </tbody></table></div>
      ${st.party || st.agent ? `<form id="cpay" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px" autocomplete="off"><h3 style="margin-top:0">Add commission paid — ${esc(who)}</h3>
        <div class="grid g2">
          <label>Date<input name="date" type="date" value="${today()}"></label>
          <label>Amount ₹<input name="amount" type="number" step="0.01"></label>
          <label>Sent to<input name="sent_to" placeholder="Name of the person" value="${esc(st.agent || '')}"></label>
          <label>Sent via<input name="sent_via" list="dl-cvia" placeholder="Cash, UPI, bank…"></label>
          <label>Reference / UTR<input name="ref"></label>
          <label>Note<input name="notes"></label>
        </div>${datalist('dl-cvia', ['CASH', 'UPI', 'BANK TRANSFER', 'CHEQUE'])}
        <div class="row" style="margin-top:10px"><button type="submit">Save payment</button></div></form>` : '<p class="hint" style="margin-top:12px">Choose an agent or a buyer above to add a payment.</p>'}
    </div>
  </div>`}
  <div class="card"><div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;text-align:center">
    <div><span class="hint">Commission on invoices</span><div style="font-size:20px;font-weight:700">₹ ${money(d.commission)}</div></div>
    <div><span class="hint">Expenses</span><div style="font-size:20px;font-weight:700">₹ ${money(d.extra)}</div></div>
    <div><span class="hint">Total to pay</span><div style="font-size:24px;font-weight:800">₹ ${money(d.total)}</div></div>
    <div><span class="hint">Commission paid</span><div style="font-size:24px;font-weight:800;color:#1e6b39">₹ ${money(d.paid)}</div></div>
    <div><span class="hint">Balance to pay</span><div style="font-size:24px;font-weight:800;color:${d.balance > 0 ? '#9A4A2A' : '#1e6b39'}">₹ ${money(d.balance)}</div></div>
  </div><p class="hint" style="text-align:center;margin:8px 0 0">${st.fy ? 'F.Y. ' + esc(st.fy) : 'All years'} · ${who ? esc(who) : 'all agents and buyers'}</p></div>`;
  const re = () => PAGES.commission(el);
  const fy = $('#cfy'); if (fy) fy.onchange = () => { st.fy = fy.value; re(); };
  const pb = $('#cpb'); if (pb) pb.onchange = () => { st.party = pb.value; re(); };
  const ag = $('#cag'); if (ag) ag.onchange = () => { st.agent = ag.value; if (st.party && !d.buyers.find(b => String(b.id) === String(st.party) && (!st.agent || b.agents.includes(st.agent)))) st.party = ''; re(); };
  $('#clock').onclick = () => { S.commPw = null; re(); };
  $('#cexp').onclick = () => downloadCsv(`commission_${st.fy || 'all'}.csv`, d.lines.map(l => ({ date: l.date, invoice: l.firm_code + ' ' + l.inv_no, buyer: l.buyer, agent: l.agent, item: l.item, qty: l.qty, rate: l.rate, commission: l.commission })));
  const cp = $('#cpay'); if (cp) cp.onsubmit = async e => {
    e.preventDefault(); await guard(() => POST('/api/commission/payments', { ...formData(cp), party_id: st.party, agent: st.agent })); toast('Payment saved'); re();
  };
  el.onclick = async e => {
    const b = e.target.closest('[data-cdel]'); if (b && confirm('Remove this payment entry?')) { await guard(() => DEL('/api/commission/payments/' + b.dataset.cdel)); re(); }
    const x = e.target.closest('[data-xdel]'); if (x && confirm('Remove this expense?')) { await guard(() => DEL('/api/commission/extras/' + x.dataset.xdel)); re(); }
  };
  const xa = $('#cxadd'); if (xa) xa.onclick = () => modal('Add expense', `<form id="cxf" autocomplete="off"><div class="grid g3">
      <label>Agent<select name="agent"><option value="">— none —</option>${d.agents.map(a => `<option ${a === st.agent ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
      <label class="span2">Buyer<select name="party_id"><option value="">— none —</option>${d.buyers.map(b => `<option value="${b.id}" ${String(b.id) === String(st.party) ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></label>
      <label>Date<input name="date" type="date" value="${today()}"></label>
      <label class="span2">Description<input name="description" placeholder="e.g. travel, sample, gift"></label>
      <label>Amount ₹<input name="amount" type="number" step="0.01"></label></div>
      <p class="hint">Link the expense to an agent, a buyer, or both. It is added to the amount to be paid.</p><div class="row"><button type="submit">Save expense</button></div></form>`, root => {
    const f = $('#cxf', root);
    // choosing an agent narrows the buyer list to that agent's buyers
    const fill = () => { const a = f.agent.value, cur = f.party_id.value;
      f.party_id.innerHTML = '<option value="">— none —</option>' + d.buyers.filter(b => !a || b.agents.includes(a)).map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('');
      if ([...f.party_id.options].some(o => o.value === cur)) f.party_id.value = cur; };
    f.agent.onchange = fill; fill();
    f.onsubmit = async e => {
      e.preventDefault(); const v = formData(f);
      if (!v.agent && !v.party_id) return toast('Choose the agent or the buyer for this expense.', true);
      await guard(() => POST('/api/commission/extras', v)); toast('Expense saved'); closeModal(); re();
    };
  });
  $('#cimp').onclick = () => importCommissionPayments(st, who, re);
};

// Old commission payments from an Excel (.xlsx) or CSV file: read here on the screen, checked, then saved in one go
async function importCommissionPayments(st, who, after) {
  modal('Import old commission payments', `<p>Choose an Excel (.xlsx) or CSV file. The first row should have headings such as
      <b>Date</b>, <b>Amount</b>, Sent to, Via / Mode, Ref / UTR, Note, and if the file has many agents or buyers, <b>Agent</b> or <b>Buyer</b>.</p>
    ${who ? `<p class="hint">Rows without an Agent / Buyer column are saved for: <b>${esc(who)}</b></p>` : '<p class="hint">Tip: choose the agent (or buyer) first if the file has no Agent / Buyer column.</p>'}
    <input type="file" id="cif" accept=".xlsx,.csv"><div id="cip" style="margin-top:12px"></div>`, root => {
    $('#cif', root).onchange = async e => {
      const file = e.target.files[0]; if (!file) return;
      let rows;
      try { rows = /\.csv$/i.test(file.name) ? parseCsv(await file.text()) : await readXlsx(file); }
      catch (err) { return toast('Could not read the file: ' + err.message, true); }
      const hi = rows.findIndex(r => r.some(c => /date/i.test(String(c))));
      if (hi < 0) return toast('No heading row with "Date" found in the file.', true);
      const head = rows[hi].map(c => String(c || '').trim().toLowerCase());
      const col = re => head.findIndex(h => re.test(h));
      const C = { date: col(/date/), amount: col(/amount|amt/) >= 0 ? col(/amount|amt/) : col(/^rs\b|^paid$|^₹/), agent: col(/agent/), buyer: col(/buyer|party/),
        sent_via: col(/via|mode/), ref: col(/ref|utr|chq|cheque|txn/), notes: col(/note|remark|narration|particular|detail/) };
      C.sent_to = head.findIndex((h, i) => /sent to|paid to|^to$|name|person/.test(h) && !Object.values(C).includes(i));
      if (C.amount < 0) return toast('No "Amount" column found.', true);
      const list = rows.slice(hi + 1).map(r => {
        const g = k => C[k] >= 0 ? r[C[k]] : '';
        return { date: toIsoDate(g('date')), amount: String(g('amount') ?? '').replace(/[^0-9.]/g, ''), agent: g('agent'), buyer: g('buyer'),
          sent_to: g('sent_to'), sent_via: g('sent_via'), ref: g('ref'), notes: g('notes') };
      }).filter(x => x.date || Number(x.amount));
      const bad = list.filter(x => !x.date || !(Number(x.amount) > 0)).length;
      const sum = list.filter(x => x.date && Number(x.amount) > 0).reduce((s, x) => s + (Number(x.amount) || 0), 0);
      $('#cip', root).innerHTML = `<div class="tablewrap" style="max-height:300px"><table class="t"><thead><tr><th>Date</th><th class="num">Amount</th><th>Agent / buyer</th><th>Sent to</th><th>Via</th><th>Ref</th><th>Note</th></tr></thead><tbody>
        ${list.map(x => `<tr ${!x.date || !(Number(x.amount) > 0) ? 'style="background:#fde8e8"' : ''}><td>${x.date ? dmy(x.date) : '<b>?</b>'}</td><td class="num">${money(x.amount)}</td><td>${esc(x.agent || x.buyer || who)}</td>
          <td>${esc(x.sent_to)}</td><td>${esc(x.sent_via)}</td><td>${esc(x.ref)}</td><td>${esc(x.notes)}</td></tr>`).join('')}</tbody></table></div>
        <p><b>${list.length - bad}</b> payments · total ₹ ${money(sum)}${bad ? ` · <span style="color:#b91c1c">${bad} rows without a proper date or amount will be skipped</span>` : ''}. Rows already saved (same date, amount and agent/buyer) are skipped.</p>
        <button id="cigo">Import ${list.length - bad} payments</button>`;
      $('#cigo', root).onclick = async () => {
        const r = await guard(() => POST('/api/commission/payments/bulk', { rows: list, party_id: st.party, agent: st.agent }));
        toast(`${r.added} payments added${r.skipped ? `, ${r.skipped} already there` : ''}${r.errors.length ? `, ${r.errors.length} skipped` : ''}`); closeModal(); after();
      };
    };
  });
}
function toIsoDate(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'number' || /^\d{5}(\.\d+)?$/.test(String(v))) {   // Excel date number
    const d = new Date(Date.UTC(1899, 11, 30) + Math.round(Number(v)) * 86400000); return d.toISOString().slice(0, 10);
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})$/);
  if (m) { const y = m[3].length === 2 ? '20' + m[3] : m[3]; return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
  return '';
}
function parseCsv(text) {
  return text.replace(/\r/g, '').split('\n').filter(l => l.trim()).map(line => {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') q = false; else cur += ch; }
      else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch;
    }
    out.push(cur); return out;
  });
}
// first sheet of an .xlsx file as rows of cells (no extra library: unzip with the browser, read the XML)
async function readXlsx(file) {
  const buf = new Uint8Array(await file.arrayBuffer()), dv = new DataView(buf.buffer);
  let eocd = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('not an .xlsx file');
  const n = dv.getUint16(eocd + 10, true); let p = dv.getUint32(eocd + 16, true);
  const files = {};
  for (let k = 0; k < n; k++) {
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true);
    const off = dv.getUint32(p + 42, true), name = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nl));
    files[name] = { method, csize, off }; p += 46 + nl + el + cl;
  }
  const read = async name => {
    const f = files[name]; if (!f) return null;
    const start = f.off + 30 + dv.getUint16(f.off + 26, true) + dv.getUint16(f.off + 28, true), data = buf.subarray(start, start + f.csize);
    if (f.method === 0) return new TextDecoder().decode(data);
    return await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  };
  const xml = s => new DOMParser().parseFromString(s, 'application/xml');
  const ssx = await read('xl/sharedStrings.xml');
  const shared = ssx ? [...xml(ssx).getElementsByTagName('si')].map(si => [...si.getElementsByTagName('t')].map(t => t.textContent).join('')) : [];
  const sheetName = Object.keys(files).filter(f => /^xl\/worksheets\/sheet\d+\.xml$/.test(f)).sort((a, b) => parseInt(a.match(/\d+/)) - parseInt(b.match(/\d+/)))[0];
  if (!sheetName) throw new Error('no sheet found');
  const doc = xml(await read(sheetName));
  const colIdx = ref => { let c = 0; for (const ch of ref.replace(/\d/g, '')) c = c * 26 + ch.charCodeAt(0) - 64; return c - 1; };
  return [...doc.getElementsByTagName('row')].map(row => {
    const out = [];
    for (const c of row.getElementsByTagName('c')) {
      const t = c.getAttribute('t'), v = c.getElementsByTagName('v')[0];
      let val = t === 'inlineStr' ? [...c.getElementsByTagName('t')].map(x => x.textContent).join('') : v ? v.textContent : '';
      if (t === 's') val = shared[Number(val)] ?? ''; else if (!t || t === 'n') val = val === '' ? '' : Number(val);
      out[colIdx(c.getAttribute('r'))] = val;
    }
    return out;
  });
}

// ----- Security: password to change or cancel saved invoices -----
SETTINGS.security = async (box) => {
  const s = await GET('/api/settings');
  box.innerHTML = `<div class="card" style="max-width:640px"><h3>Invoice edit password</h3>
    <p class="hint">A saved invoice is locked. To change or cancel it (sales invoices and P.P. Enterprise bills), this password is asked.
      ${s.edit_password_set ? '<b style="color:#1e6b39">A password is set.</b>' : '<b style="color:#b45309">No password set yet — saved invoices cannot be changed until you set one.</b>'}</p>
    <form id="pwf" autocomplete="off"><div class="grid g3">
      ${s.edit_password_set ? '<label>Current password<input name="old" type="password"></label>' : ''}
      <label>New password<input name="password" type="password"></label>
      <label>New password again<input name="again" type="password"></label></div>
      <div class="row" style="margin-top:12px"><button type="submit">${s.edit_password_set ? 'Change password' : 'Set password'}</button></div></form></div>`;
  box.insertAdjacentHTML('beforeend', `<div class="card" style="max-width:640px"><h3>🔒 Commission password</h3>
    <p class="hint">Opens the Commission screen. Keep it different from the edit password.
      ${s.comm_password_set ? '<b style="color:#1e6b39">A password is set.</b>' : '<b style="color:#b45309">No password set yet — the Commission screen cannot be opened until you set one.</b>'}</p>
    <form id="cwf" autocomplete="off"><div class="grid g3">
      ${s.comm_password_set ? '<label>Current password<input name="old" type="password"></label>' : ''}
      <label>New password<input name="password" type="password"></label>
      <label>New password again<input name="again" type="password"></label></div>
      <div class="row" style="margin-top:12px"><button type="submit">${s.comm_password_set ? 'Change password' : 'Set password'}</button></div></form></div>`);
  $('#cwf', box).onsubmit = async e => {
    e.preventDefault(); const d = formData(e.target);
    if (d.password !== d.again) return toast('The two new passwords are not the same.', true);
    await guard(() => PUT('/api/comm-password', d)); toast('Commission password saved'); SETTINGS.security(box);
  };
  $('#pwf', box).onsubmit = async e => {
    e.preventDefault(); const d = formData(e.target);
    if (d.password !== d.again) return toast('The two new passwords are not the same.', true);
    await guard(() => PUT('/api/edit-password', d)); toast('Password saved'); SETTINGS.security(box);
  };
};

// ----- Universal rules: apply everywhere in the program -----
SETTINGS.rules = async (box) => {
  const r = await GET('/api/rules');
  box.innerHTML = `<form id="rf" class="card" style="max-width:720px" autocomplete="off"><h3>Universal rules</h3>
    <h4 style="margin:6px 0">E-way bill limit</h4>
    <p class="hint">An invoice above this amount cannot be saved without the e-way bill number, lorry no., transporter, L.R. no., freight and plant.</p>
    <div class="grid g2">
      <label>1. Within the state (₹)<input name="ewb_intra" type="number" value="${r.ewb_intra}"></label>
      <label>2. Outside the state (₹)<input name="ewb_inter" type="number" value="${r.ewb_inter}"></label></div>
    <h4 style="margin:16px 0 6px">Mobile number</h4>
    <div class="grid g2"><label>Number of digits<input name="mobile_digits" type="number" value="${r.mobile_digits}"></label>
      <p class="hint" style="align-self:end">Checked in every mobile and driver-phone box (buyers, lorries, transporters, invoices, inward). A leading 0 or 91 is removed.</p></div>
    <div class="row" style="margin-top:14px"><button type="submit">Save rules</button></div></form>`;
  $('#rf', box).onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/rules', formData(e.target))); S.meta = await GET('/api/meta'); toast('Rules saved'); };
};

// ----- Backup & files -----
SETTINGS.backup = async (box) => {
  const s = await GET('/api/settings');
  box.innerHTML = `
  <div class="card"><h3>Backup folder</h3>
    <p class="hint">A full copy of the data is saved here after every new or changed invoice, and every hour. A Google Drive folder on the main PC works well, e.g. <code>G:\\My Drive\\Mineral Saathi Backup</code>.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="bf" value="${esc(s.backup_folder)}"></label><button id="savebf">Save folder</button><button class="sec" id="bnow">Backup now</button></div>
    <p>Last backup: <b>${s.last_backup ? new Date(s.last_backup).toLocaleString('en-IN') : 'not yet'}</b> ${s.last_backup_file ? `<span class="hint">${esc(s.last_backup_file)}</span>` : ''}</p>
    ${s.last_backup_error ? `<p class="badge red">Last error: ${esc(s.last_backup_error)}</p>` : ''}
    <details><summary>Latest backup files (${s.backups.length})</summary><ul>${s.backups.map(b => `<li>${esc(b.name)} <span class="hint">${(b.size / 1048576).toFixed(1)} MB</span></li>`).join('')}</ul></details>
  </div>
  <div class="card"><h3>E-way bill folder <span class="hint">(this computer)</span></h3>
    <p class="hint">The ⬇ JSON button on the invoice saves <b>ewaybill.json</b> here (a copy of every file goes into the <b>old</b> folder inside it). Upload it on the e-way bill portal.</p>
    <div class="row"><label style="flex:1">Folder<input id="ef" value="${esc(s.ewb_folder)}"></label><button id="saveef">Save folder</button></div>
  </div>
  <div class="card"><h3>Invoice PDF folder</h3>
    <p class="hint">PDFs made for emails are saved here, by financial year.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="pf" value="${esc(s.pdf_folder)}"></label><button id="savepf">Save folder</button></div>
  </div>`;
  $('#savebf').onclick = async () => { await guard(() => PUT('/api/settings', { backup_folder: $('#bf').value })); toast('Backup folder saved'); route(); };
  $('#bnow').onclick = async () => { await guard(() => POST('/api/backup')); toast('Backup saved'); route(); };
  $('#saveef').onclick = async () => { await guard(() => PUT('/api/settings', { ewb_folder: $('#ef').value })); toast('E-way bill folder saved'); };
  $('#savepf').onclick = async () => { await guard(() => PUT('/api/settings', { pdf_folder: $('#pf').value })); toast('PDF folder saved'); };
};

// ----- Import -----
SETTINGS.import = async (box) => {
  box.innerHTML = `<div class="card"><h3>Import data from an old Excel file</h3>
    <p class="hint">Choose a data file prepared from an old billing workbook (for example <b>parakh-fertilizer-data.json</b> or <b>buyer-items-and-rates.json</b>).
      New buyers are added, empty details of existing buyers are filled in, and old invoices are added as view-only. Running it twice does not make duplicates.</p>
    <div class="row"><input type="file" id="impf" accept=".json" style="max-width:420px"><button id="impgo">Import</button></div>
    <div id="imprep" style="margin-top:12px"></div></div>`;
  $('#impgo').onclick = async () => {
    const file = $('#impf').files[0]; if (!file) return toast('Choose the data file first.', true);
    let data; try { data = JSON.parse(await file.text()); } catch { return toast('That file is not a Mineral Saathi data file.', true); }
    const isItems = data.kind === 'mineral-saathi-buyer-items';
    if (!confirm(isItems ? `Import items & rates for ${data.buyers?.length || 0} buyers?` : `Import ${data.buyers?.length || 0} buyers and ${data.invoices?.length || 0} invoices for ${FIRM_NAME[data.firm_code] || '?'}?`)) return;
    const b = $('#impgo'); b.disabled = true; b.textContent = 'Importing…';
    try {
      const r = await POST('/api/import', data); S.parties = null;
      const list = (title, arr) => arr.length ? `<p><b>${title} (${arr.length})</b><br>${arr.map(esc).join('<br>')}</p>` : '';
      if (r.kind === 'items') {
        $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.items_added} items added to ${r.buyers_touched} buyers${r.items_existing ? `, ${r.items_existing} were already there` : ''}.</p>
          ${list('Buyers in the file that are not in Buyers (not added)', r.buyers_not_found)}</div>`;
      } else {
        $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.invoices_added} invoices added${r.invoices_existing ? `, ${r.invoices_existing} were already imported` : ''}.
          ${r.buyers_added.length} new buyers added, ${r.buyers_filled} existing buyers had empty details filled in.</p>
          ${list('New buyers added (billing firm: ' + FIRM_NAME[data.firm_code] + ')', r.buyers_added)}
          ${list('Already in Buyers but linked to the other firm — check in Buyers', r.buyers_other_firm)}
          ${list('Already in Buyers with no firm set — set it in Buyers', r.buyers_no_firm)}
          ${list('Invoice numbers NOT imported because a new invoice with that number already exists', r.invoices_skipped)}</div>`;
      }
      toast('Import finished');
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = 'Import';
  };
};

// ----- Updates -----
SETTINGS.updates = async (box) => {
  box.innerHTML = `<div class="card"><h3>Automatic updates</h3><div id="upd"></div></div>`;
  const showUpd = u => {
    $('#upd').innerHTML = `<p>Installed version <b>${esc(u.current)}</b>${u.latest ? ` · newest available <b>${esc(u.latest)}</b>` : ''}
      ${u.last_check ? `<span class="hint"> · last checked ${new Date(u.last_check).toLocaleString('en-IN')}</span>` : ''}</p>
      ${u.message ? `<p class="firmbox">${esc(u.message)}</p>` : ''}
      <p class="hint">The main PC checks for a new version every 30 minutes and installs it by itself when nobody has saved anything for 5 minutes.
        It takes a backup first and never touches your data. All PCs switch to the new version automatically.</p>
      <div class="row"><label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text)"><input type="checkbox" id="updauto" style="width:auto" ${u.auto ? 'checked' : ''}> Install updates automatically</label>
        <span class="spacer"></span><button class="sec" id="updcheck">Check now</button><button id="updnow">Install update now</button></div>`;
    $('#updauto').onchange = async () => showUpd(await guard(() => PUT('/api/update/settings', { auto: $('#updauto').checked })));
    $('#updcheck').onclick = async () => { $('#updcheck').textContent = 'Checking…'; showUpd(await guard(() => POST('/api/update/check', { install: false }))); };
    $('#updnow').onclick = async () => {
      $('#updnow').textContent = 'Installing…'; $('#updnow').disabled = true;
      const r = await guard(() => POST('/api/update/check', { install: true }));
      if (r.installing) { toast(`Installing version ${r.installing} — the app will reload in a few seconds`); setTimeout(() => location.reload(), 9000); }
      else showUpd(r);
    };
  };
  showUpd(await GET('/api/update'));
};

// ----- About -----
SETTINGS.about = async (box) => {
  box.innerHTML = `<div class="card" style="display:flex;gap:20px;align-items:center"><img src="logo-icon.png" style="width:96px;border-radius:18px">
    <div><h3 style="margin:0 0 6px">Mineral Saathi</h3><p style="margin:0">Version <b>${esc(S.meta.version)}</b> · billing for P.P. Enterprise, Parakh Marketing and Parakh Fertilizer.</p>
    <p class="hint">Every PC loads the screens from the main PC (${esc(S.meta.host)}), so updating the main PC updates all PCs automatically.</p></div></div>`;
};

// ---------- misc ----------
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key.toLowerCase() === 'n' && $('#modal').hidden) {
    e.preventDefault();
    if (location.hash.startsWith('#/inward')) $('#newin')?.click(); else go('#/newinvoice');
  }
});

$('#fsbtn').onclick = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => {});
setInterval(() => { if (!$('#clock')) return; $('#clock').textContent = new Date().toLocaleString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); }, 1000);

// Auto-update: when the main PC gets a new version, every PC reloads it.
async function checkVersion() {
  if (!$('#sidefoot')) return;          // closed for today
  try {
    const { version } = await GET('/api/version');
    if (S.version && version !== S.version) {
      if (!S.dirty && $('#modal').hidden) location.reload();
      else { const b = $('#banner'); b.hidden = false; b.innerHTML = `New version ${esc(version)} is installed. Save your work, then <button class="sec small" onclick="location.reload()">Reload now</button>`; }
    }
    $('#sidefoot').textContent = `Version ${version} · connected`;
  } catch { $('#sidefoot').textContent = '⚠ Main PC not reachable'; }
}

(async function start() {
  try {
    S.meta = await GET('/api/meta');
  } catch (e) {
    $('#page').innerHTML = `<div class="card"><h3>Cannot reach the main PC</h3><p>${esc(e.message)}</p><button onclick="location.reload()">Try again</button></div>`; return;
  }
  S.version = S.meta.version;
  // closing this window on the main PC (data in Google Drive) = "Close for today"
  S.pageId = Math.random().toString(36).slice(2);
  POST('/api/hello', { page: S.pageId }).catch(() => {});
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/bye?page=' + S.pageId, JSON.stringify({ page: S.pageId })); } catch { } });
  if (S.meta.shared) {
    const b = document.createElement('button'); b.className = 'ghost'; b.textContent = '⏻ Close for today';
    b.style.cssText = 'color:#f3c9a8;font-size:13px;margin:6px 10px;text-align:left'; b.onclick = closeForToday;
    $('#side').insertBefore(b, $('#sidefoot'));
  }
  S.fy = localStorage.getItem('ms_fy') && S.meta.fys.includes(localStorage.getItem('ms_fy')) ? localStorage.getItem('ms_fy') : S.meta.current_fy;
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  $('#fy').innerHTML = fys.map(f => `<option ${f === S.fy ? 'selected' : ''}>${f}</option>`).join('');
  $('#fy').onchange = () => { S.fy = $('#fy').value; try { localStorage.setItem('ms_fy', S.fy); } catch { } route(); };
  checkVersion(); setInterval(checkVersion, 60000);
  route();
})();
