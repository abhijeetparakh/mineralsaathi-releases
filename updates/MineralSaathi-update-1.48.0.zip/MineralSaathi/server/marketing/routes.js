'use strict';
// Marketing (Sampark Saathi) requests: /api/mkt/...
// Marketing data comes from marketing.db (./db). Settings are the shared Mineral Saathi settings,
// saved in mineral.db under names that start with "mkt." — they are settings, not marketing data.
const M = require('./db');
const { setting, setSetting, all: mAll } = require('../db');

const LIST_KEYS = {
  sample_size: 'Sample size',
  courier: 'Courier / sent by',
  response: 'Call response',
  followup_reason: 'Follow-up reason'
};

const SETTING_DEFAULTS = {
  enabled: '0',                                              // the Marketing menu stays hidden until switched on
  followup_days: '10',                                       // first "Did the sample arrive?" call after this many days
  calendar_url: '',                                          // Google Apps Script web-app link for the calendar push
  tracking_url: 'https://t.17track.net/en#nums={tracking_no}',
  default_firm: 'PM'                                         // sender on Marketing printouts (Settings -> Companies)
};

function settings() {
  const o = {};
  for (const [k, d] of Object.entries(SETTING_DEFAULTS)) { const v = setting('mkt.' + k); o[k] = v == null ? d : v; }
  o.enabled = o.enabled === '1';
  o.followup_days = Number(o.followup_days) || 10;
  return o;
}

const clean = v => String(v ?? '').trim().replace(/\s+/g, ' ');

module.exports = function register(route) {
  // status + settings: always answer, even when marketing.db could not be opened (the screens show why)
  route('GET', '/api/mkt/status', () => ({ ...M.status(), settings: settings() }));
  route('GET', '/api/mkt/settings', () => ({ ...settings(), firms: mAll('SELECT code, name FROM firms ORDER BY id') }));
  route('PUT', '/api/mkt/settings', ({ body }) => {
    if (body.enabled !== undefined) setSetting('mkt.enabled', body.enabled ? '1' : '0');
    if (body.followup_days !== undefined) {
      const n = Math.round(Number(body.followup_days));
      if (!(n >= 0 && n <= 365)) throw new M.MktError('Days until the first call: enter 0 to 365.');
      setSetting('mkt.followup_days', String(n));
    }
    if (body.calendar_url !== undefined) {
      const u = String(body.calendar_url || '').trim();
      if (u && !/^https:\/\/script\.google\.com\//.test(u)) throw new M.MktError('The calendar link must be a Google Apps Script link (https://script.google.com/...).');
      setSetting('mkt.calendar_url', u || null);
    }
    if (body.tracking_url !== undefined) {
      const u = String(body.tracking_url || '').trim();
      if (u && (!/^https?:\/\//.test(u) || !u.includes('{tracking_no}'))) throw new M.MktError('The tracking link must start with http and contain {tracking_no}.');
      setSetting('mkt.tracking_url', u || null);
    }
    if (body.default_firm !== undefined) {
      const firms = mAll('SELECT code FROM firms');
      if (firms.length && !firms.some(f => f.code === body.default_firm)) throw new M.MktError('Choose a company from Settings → Companies.');
      setSetting('mkt.default_firm', body.default_firm);
    }
    return settings();
  });

  // ---- Marketing lists ----
  route('GET', '/api/mkt/lists', () => {
    const out = Object.fromEntries(Object.keys(LIST_KEYS).map(k => [k, []]));
    for (const r of M.all('SELECT * FROM mkt_lists WHERE active = 1 ORDER BY list_key, sort, value')) if (out[r.list_key]) out[r.list_key].push(r);
    return out;
  });
  route('POST', '/api/mkt/lists', ({ body }) => {
    const key = body.list_key, value = clean(body.value).toUpperCase();
    if (!LIST_KEYS[key]) throw new M.MktError('Unknown list.');
    if (!value) throw new M.MktError('Enter a value.');
    const old = M.get('SELECT id, active FROM mkt_lists WHERE list_key = ? AND value = ?', key, value);
    if (old && old.active) throw new M.MktError(`"${value}" is already in the list.`);
    if (old) { M.run('UPDATE mkt_lists SET active = 1 WHERE id = ?', old.id); return { id: old.id }; }
    const sort = (M.get('SELECT MAX(sort) m FROM mkt_lists WHERE list_key = ?', key).m ?? -1) + 1;
    return { id: Number(M.run('INSERT INTO mkt_lists(list_key, value, sort) VALUES(?, ?, ?)', key, value, sort).lastInsertRowid) };
  });
  route('PUT', '/api/mkt/lists/:id', ({ p, body }) => {
    const r = M.get('SELECT * FROM mkt_lists WHERE id = ?', p.id);
    if (!r) throw new M.MktError('Not found.');
    const value = clean(body.value).toUpperCase();
    if (!value) throw new M.MktError('Enter a value.');
    if (M.get('SELECT 1 FROM mkt_lists WHERE list_key = ? AND value = ? AND id <> ? AND active = 1', r.list_key, value, r.id)) throw new M.MktError(`"${value}" is already in the list.`);
    M.run('DELETE FROM mkt_lists WHERE list_key = ? AND value = ? AND id <> ? AND active = 0', r.list_key, value, r.id);
    M.run('UPDATE mkt_lists SET value = ? WHERE id = ?', value, r.id);
    return { id: r.id };
  });
  route('DELETE', '/api/mkt/lists/:id', ({ p }) => { M.run('UPDATE mkt_lists SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

  // ---- WhatsApp message templates ----
  route('GET', '/api/mkt/templates', () => M.all('SELECT * FROM message_templates WHERE active = 1 ORDER BY sort, id'));
  const tpl = b => {
    const name = clean(b.name), body = String(b.body ?? '').replace(/\r\n/g, '\n').trim();
    if (!name) throw new M.MktError('Enter a name for the message.');
    if (!body) throw new M.MktError('Enter the message text.');
    return { name, body };
  };
  route('POST', '/api/mkt/templates', ({ body }) => {
    const t = tpl(body), sort = (M.get('SELECT MAX(sort) m FROM message_templates').m ?? -1) + 1;
    return { id: Number(M.run('INSERT INTO message_templates(name, body, sort) VALUES(?, ?, ?)', t.name, t.body, sort).lastInsertRowid) };
  });
  route('PUT', '/api/mkt/templates/:id', ({ p, body }) => {
    const t = tpl(body);
    if (!M.run('UPDATE message_templates SET name = ?, body = ? WHERE id = ?', t.name, t.body, p.id).changes) throw new M.MktError('Not found.');
    return { id: Number(p.id) };
  });
  route('DELETE', '/api/mkt/templates/:id', ({ p }) => { M.run('UPDATE message_templates SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });
};
module.exports.LIST_KEYS = LIST_KEYS;
