'use strict';
// "Where is the data?" — shown on a new installation (or when the data could not be opened).
// A small server that only answers on this PC. The person picks the folder that holds mineral.db
// (Google Drive, a pen drive, another disk) or starts with new data. The choice is saved in
// config.json and Mineral Saathi starts normally with that data.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { ROOT, readConfig, writeConfig } = require('./paths');

const PORT = Number(process.env.MS_PORT || 8765);
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;
const WIN = process.platform === 'win32';
const P = WIN ? path.win32 : path.posix;
const NOTE_FILE = path.join(ROOT, 'data-problem.txt');      // written when the data could not be opened
const FLAG_FILE = path.join(ROOT, 'choose-data.flag');      // "ask where the data is" at the next start

const SKIP = /^(\$recycle\.bin|system volume information|windows|program files( \(x86\))?|programdata|appdata|node_modules|\.git|\.cache|recovery|perflogs|msocache|config\.msi)$/i;

// Every disk call has a time limit: a sleeping network drive, an empty card reader or Google Drive
// fetching a folder list must never freeze this page.
const fsp = fs.promises;
const limit = (pr, ms, dflt) => Promise.race([pr.catch(() => dflt), new Promise(r => setTimeout(() => r(dflt), ms))]);
async function drives() {
  if (!WIN) return ['/'];
  const letters = []; for (let c = 67; c <= 90; c++) letters.push(String.fromCharCode(c) + ':\\');   // C: to Z: (A:, B: are floppy)
  const ok = await Promise.all(letters.map(d => limit(fsp.access(d).then(() => true), 1500, false)));
  return letters.filter((d, i) => ok[i]);
}
async function dirs(dir, ms = 4000) {
  const list = await limit(fsp.readdir(dir, { withFileTypes: true }), ms, []);
  return list.filter(e => e.isDirectory() && !e.name.startsWith('.') && !SKIP.test(e.name)).map(e => e.name).sort((a, b) => a.localeCompare(b));
}
async function info(folder, ms = 3000) {
  const st = await limit(fsp.stat(P.join(folder, 'mineral.db')), ms, null);
  if (!st) return null;
  const lock = await limit(fsp.readFile(P.join(folder, 'mineral.lock'), 'utf8').then(JSON.parse), 1500, null);
  return { folder, size: st.size, modified: st.mtime.toISOString(), lock };
}

// look for Mineral Saathi data in the likely places (Google Drive first)
async function scan() {
  const found = new Map();
  const deadline = Date.now() + 12000;
  const exists = p => limit(fsp.access(p).then(() => true), 1500, false);
  const walk = async (dir, depth) => {
    if (Date.now() > deadline || depth < 0) return;
    const i = await info(dir, 1500); if (i) found.set(dir.toLowerCase(), i);
    for (const n of await dirs(dir, 2000)) { if (Date.now() > deadline) return; await walk(P.join(dir, n), depth - 1); }
  };
  const home = os.homedir();
  const roots = [];
  const cfgDir = readConfig().data_folder; if (cfgDir) roots.push([cfgDir, 0]);
  roots.push([P.join(ROOT, 'data'), 0]);
  const ds = await drives();
  for (const d of ds) for (const g of ['My Drive', 'Shared drives']) { const p = P.join(d, g); if (await exists(p)) roots.push([p, 3]); }
  for (const g of ['Google Drive', 'My Drive', 'GoogleDrive', 'Documents', 'Desktop']) { const p = P.join(home, g); if (await exists(p)) roots.push([p, 3]); }
  for (const d of ds) if (!/^c:/i.test(d)) roots.push([d, 3]);
  for (const [r, depth] of roots) await walk(r, depth);
  return [...found.values()];
}

// is the file complete and readable? (a half-downloaded Google Drive file is not)
function check(folder) {
  const f = P.join(folder, 'mineral.db');
  if (!fs.existsSync(f)) return { ok: false, msg: 'There is no mineral.db in this folder.' };
  try {
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(f, { readOnly: true });
    const r = db.prepare('PRAGMA quick_check').all().map(x => Object.values(x)[0]);
    const firms = db.prepare('SELECT count(*) c FROM firms').get().c;
    db.close();
    if (!(r.length === 1 && r[0] === 'ok')) return { ok: false, msg: 'The file is damaged or not fully downloaded yet: ' + r.slice(0, 2).join(' | ') };
    if (!firms) return { ok: false, msg: 'This file has no Mineral Saathi data in it.' };
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: /malformed|not a database|corrupt/i.test(e.message)
      ? 'The file is damaged or not fully downloaded yet (' + e.message + '). In Google Drive set this folder to "Available offline", wait for syncing to finish and try again.'
      : 'Cannot read the file: ' + e.message };
  }
}

function finish(cfg) {
  writeConfig(cfg);
  for (const f of [NOTE_FILE, FLAG_FILE]) try { fs.unlinkSync(f); } catch { /* none */ }
  console.log('\n  Data location saved' + (cfg.data_folder ? ': ' + cfg.data_folder : ' (this PC)') + '. Starting Mineral Saathi...\n');
  setTimeout(() => process.exit(0), 600);          // Start-Server.bat starts the program again with this data
}

let TAKEOVER = null;                 // lock note of a computer that did not close the data properly
const when = iso => iso ? new Date(iso).toLocaleString('en-IN') : '?';

function page() {
  let note = ''; try { note = fs.readFileSync(NOTE_FILE, 'utf8'); } catch { /* none */ }
  const cur = readConfig().data_folder || '';
  return `<!doctype html><html><head><meta charset="utf-8"><title>Mineral Saathi — where is the data?</title>
<link rel="icon" href="/favicon.png"><link rel="stylesheet" href="/styles.css">
<style>
 body{background:#eef3f4} .wrap{max-width:980px;margin:28px auto;padding:0 18px}
 .opt{border:1px solid var(--line,#d5dee0);border-radius:10px;padding:12px 14px;margin:8px 0;display:flex;gap:12px;align-items:center;background:#fff}
 .opt .p{flex:1;word-break:break-all} .crumbs a{cursor:pointer;color:#16839a} .fl{max-height:300px;overflow:auto;border:1px solid #d5dee0;border-radius:8px;background:#fff}
 .fl div{padding:7px 12px;border-bottom:1px solid #eef;cursor:pointer} .fl div:hover{background:#eef7f8} .fl .has{font-weight:700;color:#1e6b39}
 .warn{background:#fff4e5;border:1px solid #f0c27a;border-radius:10px;padding:12px 14px;margin-bottom:14px;white-space:pre-wrap}
 h1{display:flex;gap:12px;align-items:center;margin:0 0 6px} h1 img{height:44px}
</style></head><body><div class="wrap">
<h1><img src="/logo-icon.png" alt=""> Where is your Mineral Saathi data?</h1>
<p class="hint">This computer does not know yet which data to use. Choose the folder that has the data file <b>mineral.db</b> —
usually the Mineral Saathi folder in Google Drive. Only one computer can use the data at a time.</p>
${TAKEOVER ? `<div class="card" style="border:2px solid #d97706"><h3>The data was not closed on “${esc(TAKEOVER.pc)}”</h3>
 <p>Mineral Saathi was last used on <b>${esc(TAKEOVER.pc)}</b> (last seen <b>${esc(when(TAKEOVER.heartbeat || TAKEOVER.started))}</b>) and that computer did not press
 <b>Close for today</b> — for example it was shut down or lost power.</p>
 <p>If <b>${esc(TAKEOVER.pc)}</b> is switched off, or Mineral Saathi is closed there, you can open the data here.
 <span class="hint">Entries made there in its last minutes may not have reached Google Drive. Next time, press “Close for today” before shutting down.</span></p>
 <div class="row"><button class="rust" id="takeover">Open the data on this computer</button>
 <span class="hint">Data folder: ${esc(readConfig().data_folder || path.join(ROOT, 'data'))}</span></div></div>
 <p class="hint" style="margin:14px 0 4px">Or link this computer to other data:</p>` : ''}
${note ? `<div class="warn"><b>The data could not be opened last time:</b>\n${esc(note)}</div>` : ''}
${cur ? `<p class="hint">Saved location so far: <b>${esc(cur)}</b></p>` : ''}

<div class="card"><h3>1. Data found on this computer</h3><div id="found"><p class="hint">Searching Google Drive and the disks…</p></div></div>

<div class="card"><h3>2. Choose the folder yourself</h3>
 <div class="row" style="gap:8px;flex-wrap:nowrap"><input id="path" placeholder="e.g. G:\\My Drive\\Mineral Saathi Data" style="flex:1">
  <button id="usepath">Use this folder</button></div>
 <p class="crumbs hint" id="crumbs" style="margin:10px 0 6px"></p><div class="fl" id="fl"></div>
 <p class="hint">Folders in <b style="color:#1e6b39">green</b> have Mineral Saathi data. Click a folder to open it.</p></div>

<div class="card"><h3>3. First computer? Start with new, empty data</h3>
 <p class="hint">Only for the very first installation. The firms, buyers and invoices start empty.</p>
 <div class="row"><button class="sec" id="newlocal">New data on this computer</button>
 <button class="sec" id="newhere">New data in the folder chosen above (e.g. Google Drive)</button></div></div>
<p class="hint">Version ${esc(VERSION)} · You can change this later in Settings → Data location.</p>
</div>
<div id="toast" class="toast" hidden></div>
<script>
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const api = async (u, b) => { const r = await fetch(u, b ? { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify(b) } : {}); const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Error'); return j; };
const toast = (m, bad) => { const t = $('#toast'); t.textContent = m; t.className = 'toast' + (bad ? ' bad' : ''); t.hidden = false; clearTimeout(t._t); t._t = setTimeout(() => t.hidden = true, 7000); };
const when = s => s ? new Date(s).toLocaleString('en-IN') : '';
const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB';
async function use(folder, fresh, started) {
  if (!started) {
  if (fresh && !confirm('Start with NEW, EMPTY data' + (folder ? ' in ' + folder : ' on this computer') + '?\\nDo this only on the first computer.')) return;
  try { await api('/api/setup/use', { folder, fresh: !!fresh }); }
  catch (e) { return toast(e.message, true); }
  }
  document.body.innerHTML = '<div class="wrap"><div class="card"><h3>Saved. Starting Mineral Saathi…</h3><p class="hint">This takes a few seconds.</p></div></div>';
  for (let i = 0; i < 60; i++) { await new Promise(r => setTimeout(r, 1500)); try { const v = await (await fetch('/api/version')).json(); if (!v.setup) { location.href = '/'; return; } } catch {} }
  document.body.innerHTML += '<div class="wrap"><p>Mineral Saathi did not start. Look at the "Mineral Saathi Server" window on the taskbar.</p></div>';
}
async function found() {
  const r = await api('/api/setup/scan');
  $('#found').innerHTML = r.length ? r.map((x, i) => '<div class="opt"><div class="p"><b>' + esc(x.folder) + '</b><br><span class="hint">' + kb(x.size) + ' · changed ' + when(x.modified)
    + (x.lock ? (x.lock.released ? ' · last closed on ' + esc(x.lock.pc) + ' ' + when(x.lock.released_at) : ' · <b style="color:#b45309">OPEN on ' + esc(x.lock.pc) + '</b> — press "Close for today" there first') : '')
    + '</span></div><button data-i="' + i + '">Use this data</button></div>').join('')
    : '<p class="hint">No Mineral Saathi data found. If it is in Google Drive, check that Google Drive is installed and signed in here, then choose the folder below.</p>';
  $('#found').onclick = e => { const b = e.target.closest('[data-i]'); if (b) use(r[+b.dataset.i].folder); };
}
let cur = '';
async function browse(dir) {
  const r = await api('/api/setup/browse?dir=' + encodeURIComponent(dir || ''));
  cur = r.dir; if (r.dir) $('#path').value = r.dir;
  $('#crumbs').innerHTML = '<a data-d="">This PC</a>' + (r.dir ? ' › ' + esc(r.dir) + (r.parent !== null ? ' · <a data-d="' + esc(r.parent) + '">⬆ up</a>' : '') : '');
  $('#fl').innerHTML = (r.has ? '<div class="has" data-use="1">✔ This folder has Mineral Saathi data — click here to use it</div>' : '')
    + r.items.map(x => '<div data-d="' + esc(x.path) + '" class="' + (x.has ? 'has' : '') + '">📁 ' + esc(x.name) + (x.has ? ' — has data' : '') + '</div>').join('')
    || '<div class="hint">No folders here.</div>';
}
document.addEventListener('click', e => { const d = e.target.closest('[data-d]'); if (d) browse(d.dataset.d); if (e.target.closest('[data-use]')) use(cur); });
$('#usepath').onclick = () => use($('#path').value.trim());
const to = $('#takeover'); if (to) to.onclick = async () => {
  if (!confirm('Is Mineral Saathi closed (or the computer switched off) there?\nOpen the data on this computer?')) return;
  try { await api('/api/setup/takeover', {}); } catch (e) { return toast(e.message, true); }
  await use(null, false, true);
};
$('#newlocal').onclick = () => use('', true);
$('#newhere').onclick = () => { const p = $('#path').value.trim(); if (!p) return toast('Choose or type the folder first (section 2).', true); use(p, true); };
found(); browse(${JSON.stringify(cur ? P.dirname(cur) : '')}).catch(() => browse(''));
</script></body></html>`;
}
function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

function run(opts = {}) {
  TAKEOVER = opts.takeover || null;
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    const json = (o, s = 200) => { res.writeHead(s, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(o)); };
    try {
      if (u.pathname === '/api/version') return json({ version: VERSION, setup: true });
      if (u.pathname === '/api/setup/scan') return json(await scan());
      if (u.pathname === '/api/setup/takeover' && req.method === 'POST') {
        if (!TAKEOVER) return json({ error: 'Nothing to take over.' }, 400);
        const { LOCK_FILE } = require('./paths');
        let now = null; try { now = JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8')); } catch { /* none */ }
        if (now && !now.released && now.pc !== os.hostname() && (now.heartbeat || now.started) !== (TAKEOVER.heartbeat || TAKEOVER.started))
          return json({ error: `"${now.pc}" has just opened the data again. Press "Close for today" there first.` }, 400);
        // mark the data as free (taken over by this PC); the normal start then opens it
        fs.writeFileSync(LOCK_FILE, JSON.stringify({ pc: os.hostname(), released: true, released_at: new Date().toISOString(), taken_over_from: TAKEOVER.pc }, null, 1));
        console.log(`\n  Data taken over from ${TAKEOVER.pc}. Starting Mineral Saathi...\n`);
        setTimeout(() => process.exit(0), 600);
        return json({ ok: true });
      }
      if (u.pathname === '/api/setup/browse') {
        const dir = u.searchParams.get('dir') || '';
        if (!dir) return json({ dir: '', parent: null, has: false, items: (await drives()).map(d => ({ name: d, path: d, has: false })) });
        const full = P.resolve(dir);
        const up = P.dirname(full);
        const names = await dirs(full);
        const has = await Promise.all(names.map(n => info(P.join(full, n), 1500).then(Boolean)));
        return json({ dir: full, parent: up === full ? '' : up, has: !!(await info(full, 1500)), items: names.map((n, i) => ({ name: n, path: P.join(full, n), has: has[i] })) });
      }
      if (u.pathname === '/api/setup/use' && req.method === 'POST') {
        let body = ''; for await (const c of req) body += c;
        const b = JSON.parse(body || '{}');
        const cfg = readConfig();
        const folder = String(b.folder || '').trim().replace(/^"|"$/g, '');
        if (b.fresh && !folder) {
          if (fs.existsSync(path.join(ROOT, 'data', 'mineral.db'))) return json({ error: 'This computer already has data in the program folder. Use it from section 1.' }, 400);
          delete cfg.data_folder; cfg.data_local = true; finish(cfg); return json({ ok: true });
        }
        if (!folder) return json({ error: 'Choose a folder.' }, 400);
        const full = P.resolve(folder);
        try { fs.mkdirSync(full, { recursive: true }); fs.accessSync(full, fs.constants.W_OK); }
        catch { return json({ error: 'This computer cannot write to that folder. Check the path.' }, 400); }
        if (b.fresh) {
          if (fs.existsSync(P.join(full, 'mineral.db'))) return json({ error: 'That folder already has Mineral Saathi data. Use it instead of starting new.' }, 400);
        } else {
          const c = check(full); if (!c.ok) return json({ error: c.msg }, 400);
          let lk = null; try { lk = JSON.parse(fs.readFileSync(P.join(full, 'mineral.lock'), 'utf8')); } catch { /* none */ }
          if (lk && !lk.released && lk.pc !== os.hostname() && Date.now() - new Date(lk.heartbeat || lk.started).getTime() < 10 * 60000)
            return json({ error: `This data is OPEN on "${lk.pc}" right now. Press "Close for today" there, wait a minute, then try again.` }, 400);
        }
        const isLocal = P.resolve(full) === P.resolve(P.join(ROOT, 'data'));
        if (isLocal) { delete cfg.data_folder; cfg.data_local = true; } else { cfg.data_folder = full; delete cfg.data_local; }
        finish(cfg); return json({ ok: true });
      }
      // static files for the page
      const name = u.pathname === '/' ? null : path.basename(u.pathname);
      if (name && ['styles.css', 'favicon.png', 'logo-icon.png'].includes(name)) {
        res.writeHead(200, { 'Content-Type': name.endsWith('.css') ? 'text/css' : 'image/png' });
        return res.end(fs.readFileSync(path.join(ROOT, 'public', name)));
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(page());
    } catch (e) { json({ error: e.message }, 500); }
  });
  server.on('error', e => {
    if (e.code === 'EADDRINUSE') { console.log(`\n  Port ${PORT} is busy. Close the other Mineral Saathi window, then start again.\n`); process.exit(3); }
    throw e;
  });
  server.listen(PORT, '127.0.0.1', () => {
    if (TAKEOVER) return console.log(`  Waiting for your choice at http://localhost:${PORT} ...\n`);
    console.log(`\n  Mineral Saathi ${VERSION} — this computer does not know where the data is yet.`);
    console.log(`  Choose the data folder in the window that opens (http://localhost:${PORT}).\n`);
  });
}

// needed when: config has no data choice and the program folder has no data, or Start-Server.bat asks for it
function needed() {
  if (process.env.MS_DATA_DIR) return false;
  if (fs.existsSync(FLAG_FILE)) return true;
  const cfg = readConfig();
  if (cfg.data_folder || cfg.data_local) return false;
  return !fs.existsSync(path.join(ROOT, 'data', 'mineral.db'));
}

// ask at the next start (the server then exits and Start-Server.bat starts it again)
function askNextStart(problem) {
  try { if (problem) fs.writeFileSync(NOTE_FILE, problem); fs.writeFileSync(FLAG_FILE, new Date().toISOString()); } catch { /* read-only folder */ }
}

module.exports = { run, needed, askNextStart };
