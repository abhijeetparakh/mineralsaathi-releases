'use strict';
// ✨ Refine a typed note — free, on this PC, no API key:
//   1. the AI built into the browser (Microsoft Edge / Google Chrome on-device model: Rewriter or Prompt API), when this PC has it;
//   2. otherwise an offline tidy-up: spaces, capital letters, full stops and common short forms (rcvd → received, pls → please …).
const REFINE_SHORT = { rcvd: 'received', recd: 'received', rcv: 'receive', pls: 'please', plz: 'please', pymt: 'payment', pmt: 'payment', qty: 'quantity', smpl: 'sample', smpls: 'samples',
  nr: 'no response', 'n/r': 'no response', nrr: 'no response', cb: 'call back', cbl: 'call back later', tmrw: 'tomorrow', tmr: 'tomorrow', tom: 'tomorrow', wk: 'week', mnth: 'month',
  msg: 'message', nxt: 'next', mt: 'MT', mts: 'MT', kgs: 'kg', rs: 'Rs.',  ord: 'order', reqd: 'required', req: 'requirement', govt: 'government', b4: 'before', bcz: 'because', coz: 'because', abt: 'about', thru: 'through', u: 'you', ur: 'your',
  wd: 'would', shd: 'should', cud: 'could', asap: 'as soon as possible', fyi: 'for your information', wo: 'without', tbd: 'to be decided', approx: 'approximately', mob: 'mobile', no: 'no' };
// soft: inside formatted email text (no full stop added at line ends); {Fields} of templates are never touched
function refineOffline(t, soft) {
  const keep = []; let s = String(t || '').replace(/\{[^{}]*\}/g, m => `\u0001${keep.push(m) - 1}\u0002`);
  s = s.replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!soft && s === s.toUpperCase() && /[A-Z]{4}/.test(s)) s = s.toLowerCase();       // typed in CAPITALS → normal letters
  s = s.replace(/\b([A-Za-z/]+)\b/g, (w) => { const k = w.toLowerCase(); return w === k && REFINE_SHORT[k] && k !== 'no' ? REFINE_SHORT[k] : w; });   // only short forms typed in small letters
  s = s.replace(/\s+([,.!?;:])/g, '$1').replace(/([,.!?;:])(?=[A-Za-z])/g, '$1 ').replace(/\.{2,}/g, '.').replace(/,{2,}/g, ',');
  s = s.split('\n').map(line => {
    line = line.trim(); if (!line) return line;
    line = line.replace(soft ? /([.!?]\s+)([a-z])/g : /(^|[.!?]\s+)([a-z])/g, (m, a, b) => a + b.toUpperCase()).replace(/\bi\b/g, 'I');
    if (!soft && !/[.!?:)\u0002]$/.test(line)) line += '.';
    return line;
  }).join('\n');
  return s.replace(/\u0001(\d+)\u0002/g, (m, i) => keep[+i]);
}
const REFINE_CTX = 'Notes of a sales call by an Indian mineral company (diatomaceous earth, bentonite, gypsum …) with a customer about samples, orders, rates and payment. Rewrite the note in clear, short, correct business English. Keep every fact, name, number, date, rate and quantity exactly. Do not add anything new. Plain text only, no heading.';
async function refineAI(text, onStatus) {
  if (self.Rewriter) {
    const a = await Rewriter.availability({ tone: 'as-is', format: 'plain-text', length: 'as-is' }).catch(() => 'unavailable');
    if (a !== 'unavailable') {
      const rw = await Rewriter.create({ tone: 'as-is', format: 'plain-text', length: 'as-is', sharedContext: REFINE_CTX,
        monitor(m) { m.addEventListener('downloadprogress', e => onStatus && onStatus(`Getting the AI model ready… ${Math.round(e.loaded * 100)}%`)); } });
      try { return { text: (await rw.rewrite(text, { context: 'Make it clear and correct; keep all facts.' })).trim(), how: 'AI built into the browser' }; } finally { rw.destroy && rw.destroy(); }
    }
  }
  if (self.LanguageModel) {
    const a = await LanguageModel.availability().catch(() => 'unavailable');
    if (a !== 'unavailable') {
      const lm = await LanguageModel.create({ initialPrompts: [{ role: 'system', content: REFINE_CTX }],
        monitor(m) { m.addEventListener('downloadprogress', e => onStatus && onStatus(`Getting the AI model ready… ${Math.round(e.loaded * 100)}%`)); } });
      try { return { text: (await lm.prompt('Rewrite this note:\n\n' + text)).trim(), how: 'AI built into the browser' }; } finally { lm.destroy && lm.destroy(); }
    }
  }
  return null;
}
// a "✨ Refine" button for a textarea; ↶ Undo puts the typed text back
function refineButton(ta, label) {
  if (!ta || ta.dataset.rf) return; ta.dataset.rf = '1';
  const bar = document.createElement('div'); bar.className = 'row'; bar.style.cssText = 'gap:6px;margin-top:4px;align-items:center';
  bar.innerHTML = `<button type="button" class="small sec" data-rf>✨ Refine${label ? ' ' + label : ''}</button><button type="button" class="small sec" data-undo hidden>↶ Undo</button><span class="hint" data-rfs></span>`;
  ta.after(bar);
  let before = null; const st = $('[data-rfs]', bar), undo = $('[data-undo]', bar), btn = $('[data-rf]', bar);
  btn.onclick = async () => {
    const t = ta.value.trim(); if (!t) return toast('Type the note first, then press Refine.', true);
    btn.disabled = true; st.textContent = 'Refining…';
    let r = null;
    try { r = await refineAI(t, s => { st.textContent = s; }); } catch (e) { r = null; }
    if (!r || !r.text) r = { text: refineOffline(t), how: 'offline tidy-up (no AI in this browser)' };
    before = ta.value; ta.value = r.text; ta.dispatchEvent(new Event('input', { bubbles: true }));
    undo.hidden = false; btn.disabled = false; st.textContent = `Refined — ${r.how}. Check it before saving.`;
  };
  undo.onclick = () => { if (before != null) { ta.value = before; ta.dispatchEvent(new Event('input', { bubbles: true })); } undo.hidden = true; st.textContent = 'Your text is back.'; };
}

// ✨ on every note box of the software: any visible text box for notes / messages / remarks gets the button by itself
const REFINE_SKIP = /^(address|ship_address|old_names|party_address|html|body)$/i;
function refineScan(root) {
  $$('textarea', root || document).forEach(ta => {
    if (ta.dataset.rf || ta.hidden || ta.readOnly || ta.disabled || ta.closest('.richwrap,[data-norefine],.comp') || ta.matches('[data-a]') || REFINE_SKIP.test(ta.name || '')) return;
    refineButton(ta);
  });
  // one-line note boxes (Note, Notes, Remark …)
  $$('input', root || document).forEach(i => {
    if (i.dataset.rf || i.hidden || i.readOnly || i.disabled || !/^(d_)?(notes?|remarks?)$/i.test(i.name || '') || (i.type && i.type !== 'text') || i.closest('[data-norefine]')) return;
    refineButton(i);
  });
  $$('.richwrap', root || document).forEach(w => { if (!w.dataset.rf) refineRich(w); });
}
// formatted email editors (templates and email boxes): ✨ in the toolbar; formatting and {Fields} are kept by the offline tidy-up
function refineRich(w) {
  w.dataset.rf = '1';
  const bar = $('.richbar', w), box = $('.richbox', w); if (!bar || !box) return;
  bar.insertAdjacentHTML('beforeend', '<button type="button" class="small sec" data-rrf title="Refine the text — free AI built into the browser, or an offline tidy-up">✨ Refine</button><button type="button" class="small sec" data-rru hidden title="Put back what was there">↶</button>');
  let before = null; const sync = () => { if (typeof richSync === 'function') richSync(w); };
  $('[data-rrf]', bar).onmousedown = async e => {
    e.preventDefault(); const text = box.innerText.trim(); if (!text) return toast('Write the message first.', true);
    before = box.innerHTML; let how = 'offline tidy-up';
    let r = null; try { r = await refineAI(text); } catch { r = null; }
    const fields = s => (s.match(/\{[^{}]*\}/g) || []).sort().join('|');
    if (r && r.text && fields(r.text) === fields(text)) { box.innerHTML = textToHtmlC(r.text); how = r.how; }
    else {                                     // offline: change only the words, keep the look
      const walk = document.createTreeWalker(box, NodeFilter.SHOW_TEXT); const nodes = []; while (walk.nextNode()) nodes.push(walk.currentNode);
      nodes.forEach(n => { if (n.nodeValue.trim()) { const lead = n.nodeValue.match(/^\s*/)[0], tail = n.nodeValue.match(/\s*$/)[0]; n.nodeValue = lead + refineOffline(n.nodeValue, true) + tail; } });
    }
    sync(); $('[data-rru]', bar).hidden = false; toast(`Refined — ${how}. Check it before saving or sending.`);
  };
  $('[data-rru]', bar).onmousedown = e => { e.preventDefault(); if (before != null) { box.innerHTML = before; sync(); } $('[data-rru]', bar).hidden = true; };
}
new MutationObserver(muts => { if (muts.some(m => m.addedNodes.length)) { clearTimeout(refineScan.t); refineScan.t = setTimeout(() => refineScan(document), 60); } })
  .observe(document.documentElement, { childList: true, subtree: true });
