'use strict';
/* Mineral Saathi — screens. Loaded from the main PC, so every PC always runs the latest version. */

// ---------- small helpers ----------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// 2026-04 → April 2026
const monthName = ym => /^\d{4}-\d{2}$/.test(String(ym || '')) ? new Date(Number(ym.slice(0, 4)), Number(ym.slice(5)) - 1, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }) : (ym || '');
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rs = n => '₹ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');
// tonnes: 3 decimals (21.545, 21.500), a round figure without decimals (35)
const qty = n => { if (n == null || n === '') return ''; const v = Math.round((Number(n) || 0) * 1000) / 1000;
  return v.toLocaleString('en-IN', Number.isInteger(v) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 3, maximumFractionDigits: 3 }); };
const q3 = v => { if (v == null || v === '' || isNaN(Number(v))) return v ?? ''; const n = Math.round(Number(v) * 1000) / 1000; return Number.isInteger(n) ? String(n) : n.toFixed(3); };   // value of a quantity box
const kg = n => n == null || n === '' ? '' : (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 });
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const FIRM_NAME = { PPE: 'P.P. Enterprise', PM: 'Parakh Marketing', PF: 'Parakh Fertilizer' };

const S = { meta: null, fy: null, dirty: false, version: null, parties: null, items: null };

async function api(method, url, body) {
  const headers = body ? { 'Content-Type': 'application/json' } : {};
  if (S.commPw && url.startsWith('/api/commission')) headers['X-Comm-Pw'] = encodeURIComponent(S.commPw);
  const r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null;
  try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) throw new Error((data && data.error) || 'Could not reach the main PC. Is the Mineral Saathi server running?');
  return data;
}
const GET = u => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b), DEL = u => api('DELETE', u);

let toastT;
function toast(msg, err) {
  const t = $('#toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, err ? 6000 : 3000);
}
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, true); throw e; } }

function modal(title, html, mount) {
  $('#mtitle').textContent = title; $('#mbody').innerHTML = html; $('#modal').hidden = false;
  if (mount) mount($('#mbody'));
  const first = $('#mbody input, #mbody select, #mbody textarea'); if (first) first.focus();
}
function closeModal() { $('#modal').hidden = true; $('#mbody').innerHTML = ''; }
// Saved invoices are changed or cancelled only with the edit password (Settings → Security). Resolves to the password, or null.
function askEditPassword(what = 'edit this invoice') {
  return new Promise(resolve => {
    let done = false;
    modal('Edit password', `<form id="epf">${/invoice/.test(what) ? '<p class="badge amber" style="display:block;padding:8px 10px">⚠ This invoice is already saved and may be with the buyer, the transporter and on the e-way bill. Change it only if you are sure.</p>' : ''}<p>Enter the edit password to ${esc(what)}.</p>
      <label>Password<input name="pw" type="password" autocomplete="off"></label>
      <div class="row" style="margin-top:12px"><button type="submit">OK</button><span class="hint">Set or change it in Settings → Security.</span></div></form>`, root => {
      $('#epf', root).onsubmit = async e => {
        e.preventDefault(); const pw = e.target.pw.value;
        try { await POST('/api/edit-password/check', { password: pw }); done = true; closeModal(); resolve(pw); }
        catch (err) { toast(err.message, true); e.target.pw.select(); }
      };
    });
    const obs = new MutationObserver(() => { if ($('#modal').hidden) { obs.disconnect(); if (!done) resolve(null); } });
    obs.observe($('#modal'), { attributes: true, attributeFilter: ['hidden'] });
  });
}
$('#mclose').onclick = closeModal;
// Every quantity box (step 0.001) shows 3 decimals once you leave it: 21.5 → 21.500
document.addEventListener('focusout', e => { const i = e.target;
  if (i.tagName === 'INPUT' && i.type === 'number' && i.step === '0.001' && i.value !== '' && !i.readOnly) { const v = q3(i.value); if (v !== i.value) { i.value = v; i.dispatchEvent(new Event('input', { bubbles: true })); } } });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

function formData(root) {
  const o = {};
  $$('[name]', root).forEach(el => { o[el.name] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value.trim(); });
  return o;
}
function field(f, v) {
  const val = v ?? f.def ?? '';
  const cls = f.span ? `class="span${f.span}"` : '';
  if (f.type === 'select') { const opts = [...(f.options || [])]; if (val !== '' && !opts.some(o => String(Array.isArray(o) ? o[0] : o) === String(val))) opts.push(val);
    return `<label ${cls}>${esc(f.label)}<select name="${f.name}" ${f.disabled ? 'disabled' : ''}>${opts.map(o => {
    const [k, t] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(k)}" ${String(k) === String(val) ? 'selected' : ''}>${esc(t)}</option>`; }).join('')}</select></label>`; }
  if (f.type === 'textarea') return `<label ${cls}>${esc(f.label)}<textarea name="${f.name}">${esc(val)}</textarea></label>`;
  return `<label ${cls}>${esc(f.label)}<input name="${f.name}" type="${f.type || 'text'}" value="${esc(f.step === '0.001' ? q3(val) : val)}" ${f.list ? `list="${f.list}"` : ''} ${f.step ? `step="${f.step}"` : ''} ${f.ro ? 'readonly' : ''}></label>`;
}
function datalist(id, values) { return `<datalist id="${id}">${[...new Set(values.filter(Boolean))].map(v => `<option value="${esc(v)}">`).join('')}</datalist>`; }
function markDirty(root) { root.addEventListener('input', () => { S.dirty = true; }); }

function downloadCsv(name, rows) {
  if (!rows.length) return toast('Nothing to export.', true);
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(','))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = name; a.click();
}

// Saves a file. Where the browser allows it, the save window opens on the Desktop with the name filled in.
async function saveToDesktop(name, text) {
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name, startIn: 'desktop', types: [{ description: 'JSON file', accept: { 'application/json': ['.json'] } }] });
      const w = await h.createWritable(); await w.write(text); await w.close();
      toast(`Saved ${h.name} — upload it on the e-way bill portal`); return;
    } catch (e) { if (e.name === 'AbortError') return; }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; a.click();
  toast(`${name} downloaded — upload it on the e-way bill portal`);
}

// pick-lists (Items → Item lists)
const LISTS = [
  ['product', 'Item name', 'The products you sell'],
  ['item_group', 'Item group', 'Groups of item names (used by Analysis Reports)'],
  ['raw_material', 'Raw material', 'What comes in — inward vouchers, Stock IN, suppliers'],
  ['colour', 'Item colour', 'Yellow, white …'],
  ['mesh', 'Mesh size', '150, 300, 325 …'],
  ['form', 'Item form', 'Powder, granules, chips …'],
  ['bag_type', 'Bag type', 'Plain, DEE-E, yellow DEE-E …'],
  ['bag_weight', 'Bag weight (kg)', 'Kg in one bag'],
  ['packing_type', 'Packing type', 'With / without liner …'],
  ['hsn', 'HSN code', 'Code, description and GST %'],
  ['gst_rate', 'GST rate %', 'Tax rates'],
  ['unit', 'Unit', 'MT, KG, bags …'],
  ['condition', 'Inward condition', 'Raw, broken …'],
  ['mines', 'Mines', 'Where material comes from'],
  ['freight_mode', 'Freight payment mode', 'To pay, paid, door delivery … (on the invoice)'],
  ['agent', 'Commission agent', 'People who get commission (buyer items) 🔒'],
  ['group_company', 'Group of companies', 'Groups that have several buyer companies'],
  ['sale_medium', 'Sale medium (B2C)', 'Website, self … (B2C / Online Sale invoices)'],
  ['payment_terms', 'Payment terms', '100% advance, after delivery, credit … (buyers)'],
  ['plants', 'Plants', 'PPI PLANT, KI PLANT and their address'],
  ['fixed_expense', 'Factory fixed expenses', 'Monthly fixed expenses of each plant (Factory wages)']
].filter(x => x[0] !== 'fixed_expense').sort((a, b) => a[1].localeCompare(b[1]));   // Factory fixed expenses: Master menu
// lists with an extra number / note column
const LIST_EXTRA = { raw_material: { note: 'HSN' }, hsn: { note: 'Description', num: 'GST %' }, form: { note: 'Moisture range (e.g. 8-12%)', num: 'Factory wages ₹ / MT', flag: 'Uses fuel' } };
async function loadLists(force) { if (!S.lists || force) S.lists = await GET('/api/lists'); return S.lists; }
const abc = (a, b) => String(a).localeCompare(String(b), 'en', { numeric: true, sensitivity: 'base' });   // A→Z, 2 before 10
const lv = key => (S.lists && S.lists[key] || []).map(x => x.value).sort(abc);

async function loadParties(force) { if (!S.parties || force) S.parties = await GET('/api/m/parties?limit=2000'); return S.parties; }
async function loadItems(force) { if (!S.items || force) S.items = await GET('/api/m/items'); return S.items; }

// ---------- packing (who gives the bags, liner) ----------
const PACKING = [['', '—'], ['OUR|0', 'Our bags'], ['OUR|1', 'Our bags + liner'], ['BUYER|0', "Buyer's bags"], ['BUYER|1', "Buyer's bags + liner"]];
const BAG_TYPES = ['PLAIN', 'PLAIN LAMINATED', 'PLAIN BAGS WITH LINER', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'PRINTED LAMINATED', '4 COLOUR LAMINATED BAGS', 'ORGASIL', 'VEDANT', 'IDEAL'];
const packKey = (supply, liner) => supply ? `${supply}|${liner ? 1 : 0}` : '';
const packText = (supply, liner) => [supply === 'BUYER' ? "buyer's bags" : supply === 'OUR' ? 'our bags' : '', liner === 1 ? 'with liner' : liner === 0 && supply ? 'no liner' : ''].filter(Boolean).join(' · ');

// House rules while typing:
//  e-mail → small letters · lorry no. → capitals without spaces · pincode / phone → numbers only
//  (amounts and weights are number boxes, so they only take numbers)
const RULES = [
  ['input[name=email], input[name=to], input[name=cc], input[name=smtp_user]', v => v.toLowerCase()],
  ['input[name=lorry_no], input[data-k=lorry_no]', v => v.toUpperCase().replace(/[^A-Z0-9,]/g, '')],
  ['input[name=pincode], input[name=party_pincode]', v => v.replace(/\D/g, '').slice(0, 6)],
  ['input[name=phone], input[name=mobile], input[name=driver_phone]', v => v.replace(/[^0-9,]/g, '')],
  ['input[name=ewb_no]', v => v.replace(/\D/g, '').slice(0, 12)],
  ['input[name=gstin], input[name=party_gstin], input[name=transporter_gstin]', v => v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 15)],
  ['input[name=pan]', v => v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10)]
];
document.addEventListener('input', e => {
  const el = e.target;
  if (!el.matches || el.type === 'number') return;
  for (const [sel, fn] of RULES) {
    if (!el.matches(sel)) continue;
    const nv = fn(el.value);
    if (nv !== el.value) { const pos = Math.max(0, (el.selectionStart || 0) - (el.value.length - nv.length)); el.value = nv; try { el.setSelectionRange(pos, pos); } catch { } }
    break;
  }
});
document.addEventListener('focusin', e => { const el = e.target; if (el.matches && el.matches('input[name=pincode], input[name=phone], input[name=mobile], input[name=driver_phone]')) el.inputMode = 'numeric'; });

// city and state filled from the pincode
function hookPincode(root) {
  const pin = $('[name=pincode]', root), city = $('[name=city]', root), state = $('[name=state]', root);
  if (!pin || !city || !state) return;
  pin.addEventListener('input', async () => {
    const v = pin.value.replace(/\D/g, '');
    if (v.length !== 6) return;
    const r = await GET('/api/pincode/' + v).catch(() => null);
    if (!r || !r.found) { toast('Pincode not found in the list — type city and state.', true); return; }
    city.value = r.city;
    if (state.tagName === 'SELECT' && ![...state.options].some(o => o.value === r.state)) state.add(new Option(r.state, r.state));
    state.value = r.state;
    if ($('[name=state_code]', root)) $('[name=state_code]', root).value = r.state_code || '';
    toast(`${r.city}, ${r.state}`);
  });
}

// ---------- router ----------
const PAGES = {};
const TITLES = { itemlists: 'Item lists', dashboard: 'Dashboard', inward: 'Inward & Freight', ppe: 'P.P. Enterprise → Parakh Marketing Bills', invoices: 'Sales Invoices',
  newinvoice: 'New Sales Invoice', invoice: 'Sales Invoice', buyers: 'Buyers B2B', masters: 'Masters', reports: 'Reports', settings: 'Settings & Backup' };

function go(hash) { location.hash = hash; }
async function route() {
  const [page, arg] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/');
  const fn = PAGES[page] || PAGES.dashboard;
  if (!$('#modal').hidden) closeModal();          // a box left open belongs to the previous screen
  // menu: the exact link (#/reports/tds) or the page (#/invoice/12 → none); its groups open
  const h = '#/' + (location.hash.replace(/^#\/?/, '') || 'dashboard');
  const links = $$('#nav a'), hit = links.find(a => a.dataset.href === h) || links.find(a => a.dataset.href === '#/' + page + (arg ? '/' + arg.split(':')[0] : ''))
    || links.find(a => a.dataset.href === '#/' + page) || (page === 'invoice' ? links.find(a => a.dataset.href === '#/invoices') : null)
    || (page === 'proforma' || page === 'newproforma' ? links.find(a => a.dataset.href === '#/proformas') : null) || (page === 'orders' ? links.find(a => a.dataset.href === '#/neworder') : null);
  links.forEach(a => a.classList.toggle('on', a === hit));
  if (hit) {      // only the groups of this page stay open
    const path = []; let g = hit.closest('.navgrp'); while (g) { path.push(g); g = g.parentElement.closest('.navgrp'); }
    $$('#nav .navgrp').forEach(x => x.classList.toggle('open', path.includes(x)));
  }
  const exact = hit && hit.dataset.href === h ? hit.textContent.replace(/^[^A-Za-z0-9]+/, '').trim() : null;
  $('#title').textContent = (['reports', 'settings', 'masters'].includes(page) && exact) || TITLES[page] || exact || 'Mineral Saathi';
  S.dirty = false;
  if (!(page === 'invoice' && S.unlock && String(S.unlock.id) === arg)) S.unlock = null;   // the unlock is for one invoice only
  if (page !== 'commission') S.commPw = null;
  if (page !== 'settings') S.impOk = false;                                                // important settings lock again                                              // leaving Commission locks it again
  const old = $('#page'), fresh = old.cloneNode(false); old.replaceWith(fresh);   // drop listeners of the previous screen
  fresh.innerHTML = '<div class="empty">Loading…</div>';
  try { await fn($('#page'), arg); } catch (e) { $('#page').innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', route);
$$('#nav a').forEach(a => a.onclick = () => {
  if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return;
  S.dirty = false;
  if (location.hash === a.dataset.href) route(); else go(a.dataset.href);
});
// collapsible menu groups (open ones are remembered on this computer)
{ let open = []; try { open = JSON.parse(localStorage.getItem('ms_nav') || '[]'); } catch { /* none */ }
  $$('#nav .navgrp').forEach(g => { if (open.includes(g.dataset.g)) g.classList.add('open');
    $(':scope > .navtoggle', g).onclick = () => { const opening = !g.classList.contains('open'); g.classList.toggle('open');
      // opening a group closes the others at the same level (and what is inside them)
      if (opening) [...g.parentElement.children].filter(x => x !== g && x.classList.contains('navgrp')).forEach(x => { x.classList.remove('open'); $$('.navgrp', x).forEach(y => y.classList.remove('open')); });
      try { localStorage.setItem('ms_nav', JSON.stringify($$('#nav .navgrp.open').map(x => x.dataset.g))); } catch { /* private */ } }; }); }
window.addEventListener('beforeunload', e => { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });

// ---------- dashboard ----------
PAGES.dashboard = async (el) => {
  const [d, orders, mst, firms] = await Promise.all([GET('/api/dashboard?fy=' + S.fy), GET('/api/orders').catch(() => []), GET('/api/mkt/status').catch(() => null), GET('/api/m/firms').catch(() => [])]);
  // Marketing: today's calls — only when Marketing is switched on
  const calls = mst && mst.settings && mst.settings.enabled ? await GET('/api/mkt/calls').catch(() => null) : null;
  const callList = calls ? [...calls.overdue, ...calls.due.filter(c => c.status === 'PENDING')] : [];
  const by = (arr, k) => arr.find(x => x.firm_code === k) || {};
  const today = new Date().toISOString().slice(0, 10);
  const due = o => !o.dispatch_by ? '<span class="hint">no date</span>' : o.dispatch_by < today ? `<span class="badge red">${dmy(o.dispatch_by)} · late</span>`
    : o.dispatch_by === today ? `<span class="badge amber">${dmy(o.dispatch_by)} · today</span>` : dmy(o.dispatch_by);
  const ordersCard = `<div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Orders Book · ${orders.length} order${orders.length === 1 ? '' : 's'} to dispatch</h3>
      <span><button class="small sec" onclick="go('#/neworder')">+ New order</button> <button class="small sec" onclick="go('#/orders')">Open Orders Book</button></span></div>
    ${orders.length ? `<div class="tablewrap" style="max-height:340px;margin-top:10px"><table class="t"><thead><tr><th>Firm</th><th>Dispatch by</th><th>Buyer</th><th>Items</th><th class="num">Qty (MT)</th><th></th></tr></thead><tbody>
      ${orders.map(o => `<tr class="click" data-dord="${o.id}" title="Click to make the invoice for this order">
        <td><span class="badge ${o.firm_code}">${o.firm_code}</span></td><td>${due(o)}</td>
        <td><b>${esc(o.buyer || o.party.name || '')}</b>${o.b2c_id ? ' <span class="badge amber">B2C</span>' : ''}<br><span class="hint">${esc(o.city || o.party.city || '')}</span></td>
        <td>${o.items.map(i => esc([i.item_name, i.grade].filter(Boolean).join(' '))).join('<br>')}${o.notes ? `<br><span class="hint">${esc(o.notes)}</span>` : ''}</td>
        <td class="num">${o.items.map(i => i.qty ? qty(i.qty) : '—').join('<br>')}</td>
        <td style="text-align:right"><button class="small">+ Make invoice</button></td></tr>`).join('')}
      </tbody></table></div><p class="hint">Click an order to make its sales invoice — the buyer and items are filled in. The order leaves the book when the invoice is printed.</p>`
      : '<p class="hint" style="margin-top:8px">No orders in the book.</p>'}</div>`;
  // big icons with a notification number (like a phone's message app)
  const ppe = firms.find(f => f.code === 'PPE') || {};
  const app = (id, icon, label, n, sub, href, warn) => `<a class="dapp" id="${id}" href="${href}"><span class="dico">${icon}${n != null ? `<span class="dbadge${n ? '' : ' zero'}${warn ? ' warn' : ''}">${n}</span>` : ''}</span>
      <b>${label}</b><span class="dsub">${sub || ''}</span></a>`;
  const ppeIcon = ppe.logo ? `<img src="${ppe.logo}" alt="" style="max-width:72px;max-height:56px">` : '🏭';
  el.innerHTML = `<style>.dapps { display:grid; grid-template-columns:repeat(auto-fill, minmax(170px, 1fr)); gap:14px; margin:0 0 16px; }
      .dapp { display:flex; flex-direction:column; align-items:center; gap:6px; padding:16px 10px 14px; background:#fff; border:1px solid var(--line); border-radius:16px; text-decoration:none; color:var(--text); box-shadow:0 1px 3px rgba(0,0,0,.04); transition:transform .1s, box-shadow .1s; }
      .dapp:hover { transform:translateY(-2px); box-shadow:0 6px 16px rgba(0,0,0,.08); }
      .dapp .dico { position:relative; width:84px; height:84px; border-radius:22px; background:#eef6f8; display:flex; align-items:center; justify-content:center; font-size:44px; }
      .dapp .dbadge { position:absolute; top:-8px; right:-10px; min-width:30px; height:30px; padding:0 8px; border-radius:15px; background:#e34948; color:#fff; font-size:16px; font-weight:800; display:flex; align-items:center; justify-content:center; border:3px solid #fff; }
      .dapp .dbadge.zero { background:#9aa8ad; } .dapp b { font-size:15px; text-align:center; } .dapp .dsub { font-size:12.5px; color:var(--muted); text-align:center; min-height:16px; }
      .dapps.small .dapp { padding:12px 8px; flex-direction:row; justify-content:center; } .dapps.small .dico { width:52px; height:52px; font-size:28px; border-radius:14px; }</style>
  ${ordersCard}
  <div class="dapps">
    ${app('dexp', '🔮', 'Orders Expected', '…', 'studying past orders…', '#/expected')}
    ${app('dppe', ppeIcon, 'P.P. Enterprise', d.unbilled.n, `<b style="color:${d.unbilled.n ? 'var(--bad)' : 'var(--ok)'}">${d.unbilled.n} Bill${d.unbilled.n === 1 ? '' : 's'} Due</b>${d.unbilled.n ? ` · ${qty(d.unbilled.qty)} MT` : ''}`, '#/ppe')}
    ${calls ? app('dcalls', '📞', "Today's Calls", callList.length, calls.overdue.length ? `<b style="color:var(--bad)">${calls.overdue.length} late</b>` : callList.length ? 'for today' : 'none today', '#/mkt/calls') : ''}
  </div>
  <div class="dapps small">
    ${app('', '📥', 'Stock IN', null, '', '#/stock')}${app('', '🚚', 'Inward Entry', null, '', '#/inward')}${app('', '🧾', 'Create Invoice', null, '', '#/newinvoice')}${app('', '📝', 'New Order', null, '', '#/neworder')}
  </div>
  <div class="card"><h3>Latest invoices</h3><table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th class="num">Total</th></tr></thead><tbody>
    ${d.recent.map(r => `<tr class="click" onclick="openInvoice(${r.id}, '${r.kind}')"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${r.inv_no}</td><td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td class="num">${money(r.total)}</td></tr>`).join('')}
  </tbody></table></div>`;
  el.onclick = e => { const r = e.target.closest('[data-dord]'); if (!r) return; S.fromOrder = orders.find(o => String(o.id) === r.dataset.dord); go('#/newinvoice'); };
  if (typeof dashExpected === 'function') dashExpected($('#dexp', el));      // the number: orders expected in the last month and the next month
};

function openInvoice(id, kind) {
  if (kind === 'PPE_BILL') return window.open('/print/invoice/' + id, '_blank');
  go('#/invoice/' + id);
}

// ---------- inward ----------
PAGES.inward = async (el) => {
  el.innerHTML = `<div class="toolbar"><button id="newin">+ New inward (Ctrl+N)</button>
    <input type="search" id="q" placeholder="Search lorry, voucher, rawana, supplier, owner…">
    <div class="tabs" id="st"><button data-s="" class="on">All</button><button data-s="unbilled">Not billed</button><button data-s="billed">Billed</button></div>
    <span class="spacer"></span><button class="sec" id="csv">Export</button><button class="sec small" id="togact" title="Show / hide actual weight"></button></div>
    <div class="tablewrap" id="list"></div>`;
  let status = '', rows = [];
  const showAct = () => { try { return localStorage.getItem('ms_show_actual') === '1'; } catch { return false; } };
  const setTog = () => { $('#togact').textContent = showAct() ? '👁 Hide actual wt' : '👁 Show actual wt'; };
  setTog();
  $('#togact').onclick = () => { try { localStorage.setItem('ms_show_actual', showAct() ? '0' : '1'); } catch { } setTog(); load(); };
  const load = async () => {
    rows = await GET(`/api/inwards?fy=${S.fy}&status=${status}&q=${encodeURIComponent($('#q').value)}`);
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Voucher</th><th>Received</th><th>From</th><th>To</th><th>Lorry</th><th>Grade</th><th>Plant</th><th>Rawana no.</th>
      <th class="num">Rawana wt</th>${showAct() ? '<th class="num">Actual wt</th>' : ''}<th class="num">Rate</th><th class="num">Freight</th><th>PPE bill</th><th></th></tr></thead><tbody>
      ${rows.map(w => `<tr class="click" data-id="${w.id}"><td><b>${esc(w.voucher_no)}</b></td><td>${dmy(w.date)}</td><td>${esc(w.supplier)}</td><td>${esc(w.to_party || '')}</td><td>${esc(w.lorry_no)}</td>
      <td>${esc(w.grade)}</td><td>${esc(w.plant)}</td><td>${esc(w.rawana_no)}</td><td class="num">${qty(w.rawana_wt)}</td>${showAct() ? `<td class="num">${qty(w.actual_wt)}</td>` : ''}
      <td class="num">${money(w.freight_rate)}</td><td class="num">${money(w.freight_amt)}</td>
      <td>${w.ppe_inv_no ? `<span class="badge PPE">No. ${w.ppe_inv_no}</span>` : (/ENTERPRISE/i.test(w.supplier || '') ? '<span class="badge amber">pending</span>' : '')}</td>
      <td><button class="small sec" data-print="${w.id}">Voucher</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">No inward entries.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#st button').forEach(b => b.onclick = () => { $$('#st button').forEach(x => x.classList.remove('on')); b.classList.add('on'); status = b.dataset.s; load(); });
  $('#list').onclick = e => {
    const p = e.target.closest('[data-print]'); if (p) { e.stopPropagation(); return window.open('/print/voucher/' + p.dataset.print, '_blank'); }
    const tr = e.target.closest('tr[data-id]'); if (tr) inwardForm(Number(tr.dataset.id), load);
  };
  $('#newin').onclick = () => chooseVoucherFirm(load);
  $('#csv').onclick = () => downloadCsv(`inward_${S.fy}.csv`, rows);
  await load();
};

async function chooseVoucherFirm(after) {
  const [ppe, pm] = await Promise.all([GET(`/api/inwards/next?fy=${S.fy}&firm=PPE`), GET(`/api/inwards/next?fy=${S.fy}&firm=PM`)]);
  modal('New inward — which firm makes the freight voucher?', `
    <div class="grid g2">
      <button class="rust" style="padding:22px;font-size:17px" data-f="PPE">P.P. Enterprise<br><small style="font-weight:400">Goods sent by P.P. Enterprise to Parakh Marketing · freight paid by P.P. Enterprise<br>Next voucher <b>${esc(ppe.voucher_no)}</b></small></button>
      <button style="padding:22px;font-size:17px" data-f="PM">Parakh Marketing<br><small style="font-weight:400">Parakh Marketing buys from another supplier · freight paid by Parakh Marketing<br>Next voucher <b>${esc(pm.voucher_no)}</b></small></button>
    </div>`, root => {
    root.onclick = e => { const b = e.target.closest('[data-f]'); if (b) { closeModal(); inwardForm(null, after, b.dataset.f); } };
    $('button', root).focus();
  });
}

// Rawana QR box: a scanner (or the phone) types the link from the QR on the rawana; the page is read and the boxes filled.
function rawanaBox(id = 'rwq') {
  return `<div class="firmbox" style="display:flex;gap:10px;align-items:center;margin-bottom:12px;padding:8px 12px">
    <b style="white-space:nowrap">📷 Rawana QR</b><input id="${id}" placeholder="Scan the QR code on the rawana here — or paste the link / type the rawana no. and press Enter" style="flex:1">
    <button type="button" class="small sec" id="${id}-go">Read</button><span class="hint" id="${id}-msg"></span></div>`;
}
function hookRawana(root, id, fill, useSupplier) {
  const box = $('#' + id, root), msg = $('#' + id + '-msg', root);
  const readIt = async () => {
    const code = box.value.trim(); if (!code) return;
    msg.textContent = 'Opening the rawana…';
    try {
      const r = await GET('/api/rawana?code=' + encodeURIComponent(code));
      const n = fill(r);
      const used = r.used.inward ? `already on voucher ${r.used.inward}` : r.used.stock ? `already in Stock IN ${r.used.stock}` : '';
      msg.innerHTML = `${used ? `<span class="badge red">⚠ Rawana ${esc(r.rawana_no)} ${used}</span> ` : ''}Filled ${n} box${n === 1 ? '' : 'es'}${r.found.length < 4 ? ` · not found on the page: ${['lorry_no', 'rawana_wt', 'driver_name', 'driver_phone'].filter(k => !r.found.includes(k)).map(k => ({ lorry_no: 'lorry no.', rawana_wt: 'net weight', driver_name: 'driver name', driver_phone: 'driver mobile' })[k]).join(', ')}` : ''}`;
      if (r.lessee && !r.supplier && useSupplier) {
        msg.insertAdjacentHTML('beforeend', `<br><span class="badge amber">${esc(r.lessee)}${r.gstin ? ' · ' + esc(r.gstin) : ''} is not in Suppliers</span> <button type="button" class="small" id="${id}-add">+ Add to Suppliers</button>`);
        $('#' + id + '-add', root).onclick = async () => {
          const d = { name: r.lessee, lessee_name: r.lessee, gstin: r.gstin || '', item: r.item || '', ibm_no: r.ibm_no || '', type: 'REG' };
          await guard(() => POST('/api/m/suppliers', d)); useSupplier(d); toast(r.lessee + ' added to Suppliers'); $('#' + id + '-add', root).replaceWith('✔ added');
        };
      }
      box.value = ''; toast('Rawana ' + r.rawana_no + ' read');
    } catch (e) { msg.textContent = ''; toast(e.message, true); box.select(); }
  };
  box.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); readIt(); } });
  box.addEventListener('paste', () => setTimeout(readIt, 50));
  $('#' + id + '-go', root).onclick = readIt;
}

async function inwardForm(id, after, vfirm, pw) {
  const [w, suppliers] = await Promise.all([id ? GET('/api/inwards/' + id) : null, GET('/api/m/suppliers'), loadLists()]);
  const v = w || { date: today(), condition: 'RAW', mines: 'BADIARA', plant: S.meta.plants[0]?.name, supplier: vfirm === 'PPE' ? 'P.P.ENTERPRISE' : '', to_party: 'PARAKH MARKETING' };
  if (w) vfirm = /^PPE/i.test(w.voucher_no) ? 'PPE' : 'PM';
  const next = !w ? (await GET(`/api/inwards/next?fy=${S.fy}&firm=${vfirm}`)).voucher_no : null;
  const plants = S.meta.plants.map(p => p.name);
  modal(`${id ? 'Inward ' + v.voucher_no : 'New inward'} — freight voucher by ${FIRM_NAME[vfirm]}`, `
  <form id="inf" autocomplete="off">${id ? '' : rawanaBox('rwq')}
    ${datalist('dl-sup', suppliers.map(s => s.name))}${datalist('dl-grade', ['YELLOW', 'WHITE', 'GYPSUM', 'ZEOCLAY', 'BENTONITE', 'SM', 'B-GRADE'])}
    <div class="grid g4">
      ${field({ name: 'voucher_no', label: `Voucher no. (${FIRM_NAME[vfirm]})`, ro: true }, v.voucher_no || next)}
      ${field({ name: 'date', label: 'Date received', type: 'date' }, v.date)}
      ${vfirm === 'PPE' ? field({ name: 'supplier', label: 'From', ro: true }, 'P.P.ENTERPRISE')
        : field({ name: 'supplier', label: 'From (supplier — Master → Suppliers)', type: 'select', options: [['', '— choose —'], ...suppliers.map(s => s.name)] }, v.supplier || '')}
      ${field({ name: 'to_party', label: 'To', ro: true }, v.to_party || 'PARAKH MARKETING')}
      ${field({ name: 'mines', label: 'Mines', list: 'dl-mines' }, v.mines)}${datalist('dl-mines', lv('mines'))}
      ${field({ name: 'lorry_no', label: 'Lorry no.' }, v.lorry_no)}
      ${field({ name: 'item', label: 'Raw material', type: 'select', options: [['', '— choose —'], ...lv('raw_material')] }, v.item || (suppliers.find(s => s.name === (vfirm === 'PPE' ? 'P.P.ENTERPRISE' : v.supplier)) || {}).item || '')}
      ${field({ name: 'grade', label: 'Grade', list: 'dl-grade' }, v.grade)}
      ${field({ name: 'condition', label: 'Condition', type: 'select', options: lv('condition').length ? lv('condition') : ['RAW'] }, v.condition)}
      ${field({ name: 'plant', label: 'Plant', type: 'select', options: plants }, v.plant)}
      ${field({ name: 'rawana_no', label: 'Rawana no.' }, v.rawana_no)}
      ${field({ name: 'challan_no', label: 'Challan no.' }, v.challan_no)}
      ${field({ name: 'rawana_wt', label: 'Rawana weight (MT)', type: 'number', step: '0.001' }, v.rawana_wt)}
      ${field({ name: 'actual_wt', label: 'Actual weight received (MT)', type: 'number', step: '0.001' }, v.actual_wt)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div class="freightbox">
        <div class="grid g2">${field({ name: 'freight_rate', label: 'Freight rate per MT (on actual weight)', type: 'number', step: '0.01' }, v.freight_rate)}
          ${field({ name: 'advance', label: 'Advance paid', type: 'number', step: '0.01' }, v.advance)}</div>
        <div style="margin-top:10px">Freight to pay = actual weight × rate = <span class="big" id="famt">₹ 0</span></div>
        <div class="hint" id="fshow">Voucher will show: rawana weight × adjusted rate</div>
      </div>
      <div class="grid g3">
        ${field({ name: 'cash_amt', label: 'Paid cash', type: 'number', step: '0.01' }, v.cash_amt)}
        ${field({ name: 'bank_amt', label: 'Paid bank', type: 'number', step: '0.01' }, v.bank_amt)}
        ${field({ name: 'pay_mode', label: 'Bank / mode', list: 'dl-mode' }, v.pay_mode)}
        ${field({ name: 'chq_no', label: 'Cheque / UTR' }, v.chq_no)}
        ${field({ name: 'upi', label: 'UPI / account', span: 2 }, v.upi)}
        ${datalist('dl-mode', ['KOTAK / ONLINE', 'IDBI / ONLINE', 'BOTH / ONLINE', 'CASH'])}
      </div>
    </div>
    <div class="grid g4" style="margin-top:12px">
      ${field({ name: 'owner_name', label: 'Lorry owner' }, v.owner_name)}
      ${field({ name: 'pan', label: 'Owner PAN' }, v.pan)}
      ${field({ name: 'driver_name', label: 'Driver name' }, v.driver_name)}
      ${field({ name: 'driver_phone', label: 'Driver phone' }, v.driver_phone)}
      ${field({ name: 'royalty', label: 'Royalty', type: 'number', step: '0.01' }, v.royalty)}
      ${field({ name: 'dmft', label: 'DMFT', type: 'number', step: '0.01' }, v.dmft)}
      ${field({ name: 'nmet', label: 'NMET', type: 'number', step: '0.01' }, v.nmet)}
      ${field({ name: 'remarks', label: 'Remarks' }, v.remarks)}
    </div>
    ${v.ppe_invoice_id ? '<p class="badge PPE" style="margin-top:10px">Billed by P.P. Enterprise — rawana weight is locked</p>' : ''}
    ${id && !pw ? `<div class="row" style="margin-top:16px"><button type="button" id="unlockin">🔒 Edit voucher</button><button type="button" class="sec" id="printin">🖨 Print voucher</button>
      <span class="hint">Saved voucher — locked. Editing or deleting needs the edit password.</span></div>`
    : `<div class="row" style="margin-top:16px"><button type="submit">Save</button><button type="button" class="sec" id="saveprint">Save & print voucher</button>
      ${id ? '<span class="hint">🔓 Unlocked with the edit password</span>' : ''}<span class="spacer"></span>${id && !v.ppe_invoice_id ? '<button type="button" class="sec" id="delin">Delete</button>' : ''}</div>`}
  </form>`, root => {
    const f = $('#inf', root);
    if ($('#rwq', root)) { hookRawana(root, 'rwq', r => { let n = 0; const set = (k, v) => { if (v != null && f[k]) { f[k].value = k === 'rawana_wt' ? q3(v) : v; n++; } };
      set('rawana_no', r.rawana_no); set('lorry_no', r.lorry_no); set('rawana_wt', r.rawana_wt); set('driver_name', r.driver_name); set('driver_phone', r.driver_phone);
      set('royalty', r.royalty); set('dmft', r.dmft); set('nmet', r.nmet);
      if (r.supplier && f.supplier.tagName === 'SELECT' && [...f.supplier.options].some(o => o.value === r.supplier)) { f.supplier.value = r.supplier; f.supplier.dispatchEvent(new Event('change')); n++; }
      if (r.item && [...f.item.options].some(o => o.value === r.item)) { f.item.value = r.item; n++; }
      f.dispatchEvent(new Event('input', { bubbles: true })); if (f.lorry_no) f.lorry_no.dispatchEvent(new Event('change', { bubbles: true })); return n; },
      vfirm === 'PPE' ? null : s => { suppliers.push(s); f.supplier.insertAdjacentHTML('beforeend', `<option>${esc(s.name)}</option>`); f.supplier.value = s.name; f.supplier.dispatchEvent(new Event('change')); });
      setTimeout(() => $('#rwq', root).focus(), 50); }
    if (id && !pw) {                                   // locked: view and print only
      $$('input, select, textarea', f).forEach(x => x.disabled = true);
      $('#printin', root).onclick = () => window.open('/print/voucher/' + id + '?print=1', '_blank');
      $('#unlockin', root).onclick = async () => { const p2 = await askEditPassword('edit this voucher'); if (p2 != null) inwardForm(id, after, vfirm, p2); };
    }
    const calc = () => {
      const d = formData(f);
      const amt = r2((+d.actual_wt || 0) * (+d.freight_rate || 0));
      const shown = +d.rawana_wt ? r2(amt / +d.rawana_wt) : 0;
      $('#famt').textContent = '₹ ' + money(amt);
      $('#fshow').textContent = +d.rawana_wt ? `Voucher will show: ${qty(d.rawana_wt)} MT @ ₹${money(shown)} = ₹${money(amt)}` : 'Enter rawana weight to see the voucher rate';
    };
    f.addEventListener('input', calc); calc();
    if (v.ppe_invoice_id) f.rawana_wt.readOnly = true;
    f.lorry_no.addEventListener('change', async () => {
      const no = f.lorry_no.value.trim(); if (!no) return;
      const r = await GET('/api/lorry/' + encodeURIComponent(no));
      const fill = (k, val) => { if (val && !f[k].value) f[k].value = val; };
      if (r.lorry) { fill('owner_name', r.lorry.owner); fill('pan', r.lorry.pan); fill('driver_name', r.lorry.driver_name); fill('driver_phone', r.lorry.driver_phone); fill('upi', r.lorry.upi); }
      if (r.last) { [...(vfirm === 'PPE' ? [] : ['supplier']), 'mines', 'grade', 'owner_name', 'pan', 'driver_name', 'driver_phone', 'upi', 'freight_rate'].forEach(k => fill(k, r.last[k])); if (r.last.plant) f.plant.value = r.last.plant; }
      calc();
    });
    f.supplier.addEventListener('change', () => { const s = suppliers.find(x => x.name === f.supplier.value); if (s) { if (s.item) f.item.value = s.item; if (!f.grade.value) f.grade.value = s.grade || ''; if (!f.freight_rate.value && s.freight_rate) f.freight_rate.value = s.freight_rate; calc(); } });
    const save = async (print) => {
      const d = formData(f); delete d.voucher_no; d.voucher_firm = vfirm; if (id) d.edit_password = pw;
      const r = await guard(() => id ? PUT('/api/inwards/' + id, d) : POST('/api/inwards', d));
      toast('Inward saved'); closeModal(); if (print) window.open('/print/voucher/' + r.id + '?print=1', '_blank'); after && after();
    };
    f.onsubmit = e => { e.preventDefault(); save(false); };
    const sp = $('#saveprint', root); if (sp) sp.onclick = () => save(true);
    const del = $('#delin', root); if (del) del.onclick = async () => { if (confirm('Delete this inward entry?')) { await guard(() => DEL('/api/inwards/' + id + '?pw=' + encodeURIComponent(pw))); closeModal(); after && after(); } };
  });
}

// ---------- P.P. Enterprise bills ----------
PAGES.ppe = async (el) => {
  const [pending, bills] = await Promise.all([
    GET(`/api/inwards?fy=${S.fy}&status=unbilled&supplier=ENTERPRISE`),
    GET(`/api/invoices?fy=${S.fy}&firm=PPE`)
  ]);
  const lastRate = bills.length ? (await GET('/api/invoices/' + bills[0].id)).items[0]?.rate : '';
  el.innerHTML = `
  <div class="card"><h3>1 · Tick the lorries received from P.P. Enterprise</h3>
    <p class="hint">The bill uses the <b>rawana weight</b>. Freight was already paid on the actual weight in the inward entry.</p>
    ${pending.length ? `<div class="tablewrap" style="max-height:340px"><table class="t"><thead><tr><th><input type="checkbox" id="all"></th><th>Voucher</th><th>Received</th><th>Lorry</th><th>Grade</th><th>Rawana no.</th><th>Challan</th><th class="num">Rawana wt</th><th class="num">Actual wt</th></tr></thead><tbody>
      ${pending.map(w => `<tr><td><input type="checkbox" class="pick" value="${w.id}" data-q="${w.rawana_wt}"></td><td>${esc(w.voucher_no)}</td><td>${dmy(w.date)}</td><td><b>${esc(w.lorry_no)}</b></td><td>${esc(w.grade)}</td><td>${esc(w.rawana_no)}</td><td>${esc(w.challan_no)}</td><td class="num">${qty(w.rawana_wt)}</td><td class="num">${qty(w.actual_wt)}</td></tr>`).join('')}
    </tbody></table></div>` : '<div class="empty">All P.P. Enterprise lorries of this year are billed.</div>'}
  </div>
  <div class="card"><h3>2 · Bill details</h3>
    <div class="row">
      <label style="width:160px">Bill date<input type="date" id="bdate" value="${today()}"></label>
      <label style="width:160px">Rate per MT<input type="number" id="brate" step="0.01" value="${esc(lastRate || '')}"></label>
      <label style="width:110px">GST %<input type="number" id="bgst" value="5"></label>
      <label style="width:280px">Item<input id="bitem" value="DIATOMACEOUS EARTH (RAW)"></label>
      <div class="totals" id="btot" style="margin-left:auto"></div>
    </div>
    <div class="row" style="margin-top:14px"><button id="mk">Create bill & print</button></div>
  </div>
  <div class="card"><h3>P.P. Enterprise bills · ${esc(S.fy)}</h3>
    <div class="tablewrap" style="max-height:420px"><table class="t"><thead><tr><th>No.</th><th>Date</th><th>Lorries</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">Total</th><th></th></tr></thead><tbody>
    ${bills.map(b => `<tr><td><b>${b.inv_no}</b> ${b.cancelled ? '<span class="badge red">cancelled</span>' : ''}</td><td>${dmy(b.date)}</td><td>${esc(b.lorry_no)}</td><td class="num">${qty(b.qty)}</td><td class="num">${money(b.taxable)}</td><td class="num">${money(b.total)}</td>
      <td><button class="small sec" onclick="window.open('/print/invoice/${b.id}','_blank')">Print</button> ${!b.legacy && !b.cancelled ? `<button class="small sec" onclick="cancelBill(${b.id})">Cancel</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div></div>`;
  const recalc = () => {
    const picks = $$('.pick:checked'); const q = picks.reduce((s, c) => s + Number(c.dataset.q), 0);
    const taxable = r2(picks.reduce((s, c) => s + r2(Number(c.dataset.q) * (+$('#brate').value || 0)), 0));
    const gst = r2(taxable * (+$('#bgst').value || 0) / 100); const total = Math.round(taxable + gst);
    $('#btot').innerHTML = `<div><span>${picks.length} lorries · ${qty(q)} MT</span><span></span></div><div><span>Taxable</span><b>${money(taxable)}</b></div>
      <div><span>CGST + SGST</span><b>${money(gst)}</b></div><div class="grand"><span>Total</span><span>${rs(total)}</span></div>`;
  };
  el.addEventListener('input', recalc); el.addEventListener('change', recalc); recalc();
  const all = $('#all'); if (all) all.onchange = () => { $$('.pick').forEach(c => c.checked = all.checked); recalc(); };
  $('#mk').onclick = async () => {
    const ids = $$('.pick:checked').map(c => Number(c.value));
    const r = await guard(() => POST('/api/ppe-bills', { inward_ids: ids, rate: $('#brate').value, date: $('#bdate').value, gst_rate: $('#bgst').value, item_name: $('#bitem').value }));
    toast('Bill created'); window.open('/print/invoice/' + r.id + '?print=1', '_blank'); route();
  };
};
async function cancelBill(id) {
  if (!confirm('Cancel this bill? Its lorries will become "not billed" again.')) return;
  const pw = await askEditPassword('cancel this bill'); if (pw == null) return;
  await guard(() => POST(`/api/invoices/${id}/cancel`, { edit_password: pw })); toast('Bill cancelled'); route();
}

// ---------- sales invoices list ----------
PAGES.invoices = async (el) => {
  el.innerHTML = `<div class="toolbar"><button onclick="go('#/newinvoice')">+ New invoice</button>
    <div class="tabs" id="ft"><button data-f="" class="on">PM + PF</button><button data-f="PM">Parakh Marketing</button><button data-f="PF">Parakh Fertilizer</button></div>
    <input type="search" id="q" placeholder="Search party, lorry, invoice no., e-way bill…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div>
    <div class="tablewrap" id="list"></div>`;
  let firm = '', rows = [];
  const load = async () => {
    rows = (await GET(`/api/invoices?fy=${S.fy}&kind=SALE&firm=${firm}&q=${encodeURIComponent($('#q').value)}`));
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th>Type</th><th>Lorry</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">GST</th><th class="num">Total</th><th>E-way bill</th><th>Email</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td><b>${r.inv_no}</b>${r.cancelled ? ' <span class="badge red">cancelled</span>' : ''}${r.legacy ? ' <span class="badge grey">Excel</span>' : ''}</td>
      <td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td>${r.supply_type}</td><td>${esc(r.lorry_no)}</td><td class="num">${qty(r.qty)}${r.lines > 1 ? ` <span class="muted">(${r.lines} items)</span>` : ''}</td>
      <td class="num">${money(r.taxable)}</td><td class="num">${money(r.cgst + r.sgst + r.igst)}</td><td class="num"><b>${money(r.total)}</b></td><td>${esc(r.ewb_no)}</td><td>${r.email_sent_at ? '✓' : ''}</td></tr>`).join('')}
      </tbody></table>` : '<div class="empty">No invoices.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#ft button').forEach(b => b.onclick = () => { $$('#ft button').forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.f; load(); });
  // click opens the invoice; double-click opens the email box with the "Attach the following" ticks
  let clickT = null;
  $('#list').onclick = e => { const tr = e.target.closest('tr[data-id]'); if (!tr) return; clearTimeout(clickT); clickT = setTimeout(() => go('#/invoice/' + tr.dataset.id), 280); };
  $('#list').ondblclick = e => { const tr = e.target.closest('tr[data-id]'); if (!tr) return; clearTimeout(clickT); const r = rows.find(x => String(x.id) === tr.dataset.id);
    if (r && (r.legacy || r.cancelled)) return toast('Old Excel or cancelled invoices are not emailed.', true); emailDialog(Number(tr.dataset.id), 'buyer', true); };
  $('#csv').onclick = () => downloadCsv(`sales_${S.fy}.csv`, rows);
  await load();
};

// ---------- sales invoice form (many items) ----------
PAGES.newinvoice = el => invoiceForm(el, null);
PAGES.newb2c = el => { S.b2cNew = true; return invoiceForm(el, null); };
TITLES.newproforma = 'New Proforma Invoice'; TITLES.proforma = 'Proforma Invoice'; TITLES.proformas = 'Proforma Invoices';
// new proforma: first choose the selling firm (like the inward voucher), then only its buyers can be chosen
PAGES.newproforma = async el => {
  el.innerHTML = '<div class="empty">Choose the firm that sends the proforma invoice…</div>';
  const date = today();
  const [pm, pf] = await Promise.all([GET(`/api/proformas/next?firm=PM&date=${date}`), GET(`/api/proformas/next?firm=PF&date=${date}`)]);
  modal('New proforma invoice — which firm sends it?', `
    <div class="grid g2">
      <button style="padding:22px;font-size:17px" data-f="PM">Parakh Marketing<br><small style="font-weight:400">Only buyers billed by Parakh Marketing<br>Next proforma <b>${esc(pm.inv_no)}</b></small></button>
      <button style="padding:22px;font-size:17px;background:var(--ok)" data-f="PF">Parakh Fertilizer<br><small style="font-weight:400">Only buyers billed by Parakh Fertilizer<br>Next proforma <b>${esc(pf.inv_no)}</b></small></button>
    </div>`, root => {
    root.onclick = e => { const b = e.target.closest('[data-f]'); if (!b) return; closeModal(); TITLES.newproforma = 'New Proforma Invoice — ' + FIRM_NAME[b.dataset.f]; $('#title').textContent = TITLES.newproforma; invoiceForm(el, null, true, b.dataset.f); };
    $('button', root).focus();
  });
};
PAGES.proforma = (el, id) => invoiceForm(el, Number(id), true);
PAGES.proformas = async (el) => {
  let firm = '';
  el.innerHTML = `<div class="toolbar"><button onclick="go('#/newproforma')">+ New proforma invoice</button>
    <div class="tabs" id="pft"><button data-f="" class="on">All</button><button data-f="PM">Parakh Marketing</button><button data-f="PF">Parakh Fertilizer</button></div>
    <input type="search" id="pq" placeholder="Search buyer…"><span class="spacer"></span><button class="sec" id="pcsv">Export</button></div><div class="tablewrap" id="plist"></div>`;
  let rows = [];
  const load = async () => {
    rows = await GET(`/api/proformas?fy=${S.fy}&firm=${firm}`);
    const qq = $('#pq').value.trim().toUpperCase(), show = rows.filter(r => !qq || String(r.party_name).toUpperCase().includes(qq));
    $('#plist').innerHTML = show.length ? `<table class="t"><thead><tr><th>Firm</th><th>Proforma no.</th><th>Date</th><th>Buyer</th><th class="num">Qty MT</th><th class="num">Total</th><th>Email</th><th></th></tr></thead><tbody>
      ${show.map(r => `<tr class="click" data-id="${r.id}"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td><b>${esc(r.pi_no)}</b></td><td>${dmy(r.date)}</td><td>${esc(r.party_name)} <span class="hint">${esc(r.party_city || '')}</span></td>
        <td class="num">${qty(r.qty)}</td><td class="num"><b>${money(r.total)}</b></td><td>${r.email_sent_at ? '✓' : ''}</td>
        <td style="white-space:nowrap"><button class="small sec" data-pv="${r.id}">PDF</button> <button class="small sec" data-pe="${r.id}">Email</button></td></tr>`).join('')}</tbody></table>`
      : '<div class="empty">No proforma invoices in this year.</div>';
  };
  $$('#pft button').forEach(b => b.onclick = () => { $$('#pft button').forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.f; load(); });
  $('#pq').oninput = debounce(load, 250);
  $('#plist').onclick = e => {
    const pv = e.target.closest('[data-pv]'), pe = e.target.closest('[data-pe]'), tr = e.target.closest('tr[data-id]');
    if (pv) return window.open('/print/proforma/' + pv.dataset.pv, '_blank');
    if (pe) return proformaEmail(Number(pe.dataset.pe));
    if (tr) go('#/proforma/' + tr.dataset.id);
  };
  $('#pcsv').onclick = () => downloadCsv(`proforma_${S.fy}.csv`, rows);
  await load();
};
// email a proforma: the proforma PDF, our bank proof, the transporter's bank proof
async function proformaEmail(id) {
  const d = await guard(() => GET(`/api/proformas/${id}/email`));
  const o = d.options;
  const att = [['proforma', 'Proforma invoice', true, true, ''], ['seller_bank', 'Seller bank proof', o.seller_bank, o.seller_bank, o.seller_bank ? '' : 'add it in Settings → Companies'],
    ['tr_bank', 'Transporter bank proof', o.tr_bank, o.tr_bank && !o.tr_bank_sent, !o.transporter ? 'no transporter on the proforma' : !o.tr_bank ? 'no bank proof in the transporter master' : o.tr_bank_sent ? 'sent to this buyer before' : '']];
  modal('Email proforma invoice to buyer', `${d.ready ? '' : '<p class="badge amber">Email is not set up for this firm yet. Open Settings → Companies → Email sending first.</p>'}
    <form id="pef"><div class="card" style="margin:0 0 12px;background:#f7fafb;padding:10px 14px"><b>Attach the following with email</b>
      <div class="grid g3" style="margin-top:6px">${att.map(([k, label, can, on, note]) => `<label style="display:flex;gap:8px;align-items:center;font-weight:500;${can ? '' : 'opacity:.55'}" title="${esc(note)}">
        <input type="checkbox" data-att="${k}" style="width:auto" ${can && on ? 'checked' : ''} ${can ? '' : 'disabled'}> ${label}${note ? ` <span class="hint">${esc(note)}</span>` : ''}</label>`).join('')}</div></div>
      <div class="grid g2">
      ${d.templates.length ? `<label class="span2">Email template<select id="pftpl">${d.templates.map(x => `<option value="${x.id}">${esc(x.name)}${x.is_default ? ' (default)' : ''}</option>`).join('')}</select></label>` : ''}
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text', d.html || textToHtmlC(d.text), 220)}</div></div>
      <div class="row"><button type="submit" ${d.ready ? '' : 'disabled'}>Send email</button><span class="hint">Sent from ${esc(d.from || '')}.</span></div></form>`, root => {
    richInit(root);
    const ts = $('#pftpl', root); if (ts) ts.onchange = async () => { const r = await guard(() => GET(`/api/proformas/${id}/template/${ts.value}`)); richSet(root, 'text', r.html || textToHtmlC(r.text)); };
    $('#pef', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const v = { to: e.target.to.value, cc: e.target.cc.value, subject: e.target.subject.value, text: e.target.text.value, html: e.target.html.value, attach: {},
        template_name: ts ? ts.selectedOptions[0].text.replace(' (default)', '') : 'Standard message' };
      $$('[data-att]', root).forEach(c => { v.attach[c.dataset.att] = c.checked ? 1 : 0; });
      try { await POST(`/api/proformas/${id}/email`, v); toast('Email sent'); closeModal(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ---------- Orders book: coming orders, to plan production ----------
TITLES.orders = 'Orders Book'; TITLES.neworder = 'Orders Book';
PAGES.neworder = el => PAGES.orders(el);
PAGES.orders = async (el, editId) => {
  const [orders, parties, custs, led] = await Promise.all([GET('/api/orders'), loadParties(), GET('/api/b2c').catch(() => []), GET('/api/b2c-ledger').catch(() => ({})), loadLists()]);
  const cur = editId ? orders.find(o => String(o.id) === String(editId)) : null;
  const buyers = parties.filter(p => p.active !== 0 && ['PM', 'PF'].includes(p.firm_code) && !p.is_online);
  let kind = cur ? (cur.b2c_id ? 'B2C' : 'B2B') : (S.ordKind || 'B2B');
  const firm0 = cur ? cur.firm_code : (S.ordFirm || 'PM');
  const inDays = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
  const custLabel = c => `${c.name}${c.mobile ? ' · ' + c.mobile : ''}${c.city ? ' · ' + c.city : ''}`;
  const calBadge = o => !o.dispatch_by ? '' : o.calendar_status === 'SENT' ? '<span class="badge grey" title="Shows on Google Calendar from 3 days before the dispatch date">📅 on calendar</span>'
    : o.calendar_status === 'FAILED' ? `<span class="badge amber" title="${esc(o.calendar_error || '')}">📅 not sent — tried again every 10 min</span>` : o.calendar_status === 'QUEUED' ? '<span class="badge grey">📅 sending…</span>' : '';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.5fr);align-items:start">
    <form id="of" class="card" autocomplete="off"><h3>${cur ? 'Change order' : 'New order'}</h3>
      <div class="tabs" style="margin-bottom:10px"><button type="button" data-kind="B2B" class="${kind === 'B2B' ? 'on' : ''}" ${cur ? 'disabled' : ''}>B2B order</button><button type="button" data-kind="B2C" class="${kind === 'B2C' ? 'on' : ''}" ${cur ? 'disabled' : ''}>B2C order (Online sale)</button></div>
      <div class="grid g2">
        <label class="b2bonly">Billing firm<select name="firm_code">${[['PM', 'Parakh Marketing'], ['PF', 'Parakh Fertilizer']].map(([k, n]) => `<option value="${k}" ${k === firm0 ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label class="b2conly">Billing firm<input value="Parakh Marketing — ONLINE SALE" readonly></label>
        <label>Dispatch by<input name="dispatch_by" type="date" value="${cur ? cur.dispatch_by || '' : inDays(7)}"></label>
        <label class="span2 b2bonly">Buyer<input id="obq" list="dl-ob" placeholder="Type to search the buyer" value="${cur && !cur.b2c_id ? esc(cur.party.name) : ''}"><datalist id="dl-ob"></datalist></label>
        <label class="span2 b2conly">Customer <span class="hint">(Buyers B2C — type name or mobile)</span><div class="row" style="gap:6px;flex-wrap:nowrap;margin-top:3px"><input id="ocq" list="dl-oc" placeholder="Type to search the customer" style="flex:1"
          value="${cur && cur.b2c_id ? esc(custLabel(cur.customer || {})) : ''}"><button type="button" class="sec small" id="ocnew">+ New</button></div><datalist id="dl-oc">${custs.map(c => `<option value="${esc(custLabel(c))}">`).join('')}</datalist></label>
      </div>
      <div id="oitems" style="margin-top:10px"><p class="hint">Choose the buyer to see the buyer's items.</p></div>
      <label style="margin-top:10px">Note<input name="notes" value="${esc(cur ? cur.notes || '' : '')}"></label>
      <div class="row" style="margin-top:12px"><button type="submit">${cur ? 'Save changes' : 'Add to orders book'}</button>${cur ? '<button type="button" class="sec" id="ocancel">Cancel</button>' : ''}</div>
      <p class="hint" style="margin-top:8px">📅 With the Google Calendar link (Settings → Data Location), each order shows on the calendar from 3 days before its dispatch date until the dispatch date.</p>
    </form>
    <div class="card"><h3>Orders to dispatch <span class="hint">${orders.length} orders · earliest first</span></h3>
      ${orders.map(o => { const late = o.dispatch_by && o.dispatch_by < today();
        return `<div class="ordrow" data-o="${o.id}" style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:8px;cursor:pointer;${String(o.id) === String(S.ordSel) ? 'outline:2px solid #1A9BB5;' : ''}">
        <div class="row" style="justify-content:space-between"><span><span class="badge ${o.firm_code}">${o.firm_code}</span>${o.b2c_id ? ' <span class="badge amber">B2C</span>' : ''} <b>${esc(o.buyer || '?')}</b> <span class="hint">${esc(o.city || '')}</span>
          ${o.proforma_id ? ' <span class="badge slate">from proforma</span>' : ''}</span>
          <span>${calBadge(o)} <span class="${late ? 'badge red' : 'badge grey'}">dispatch by ${o.dispatch_by ? dmy(o.dispatch_by) : '—'}</span></span></div>
        <div style="margin-top:4px">${o.items.map(i => `${esc(i.item_name)} ${esc(i.grade || '')}${i.bags ? ` — <b>${kg(i.bags)} ${i.pack_size ? 'bags' : ''}</b>${i.rate_bag ? ` @ ₹${money(i.rate_bag)}/bag` : ''}` : i.qty ? ` — <b>${qty(i.qty)} MT</b>` : ''}${i.pack_size ? ` <span class="hint">${kg(i.pack_size)} kg ${esc(i.bag_type || '')}</span>` : ''}`).join('<br>')}</div>
        ${o.notes ? `<div class="hint">${esc(o.notes)}</div>` : ''}
        <div class="row" style="margin-top:6px"><button type="button" class="small" data-inv="${o.id}">➜ Create ${o.b2c_id ? 'B2C ' : ''}sales invoice</button>
          <button type="button" class="small sec" data-oed="${o.id}">Edit</button><button type="button" class="small sec" data-odel="${o.id}">✕ Delete</button>
          ${o.dispatch_by && o.calendar_status !== 'SENT' ? `<button type="button" class="small sec" data-ocal="${o.id}">📅 Send to calendar</button>` : ''}</div></div>`; }).join('') || '<p class="muted">No orders in the book.</p>'}
      <p class="hint">An order leaves the book when its sales invoice is saved and printed.</p></div></div>`;
  const f = $('#of'); let party = cur && !cur.b2c_id ? buyers.find(b => b.id === cur.party_id) : null;
  let cust = cur && cur.b2c_id ? custs.find(c => c.id === cur.b2c_id) || cur.customer : null;
  const showKind = () => { $$('.b2bonly', f).forEach(x => x.hidden = kind !== 'B2B'); $$('.b2conly', f).forEach(x => x.hidden = kind !== 'B2C');
    $$('[data-kind]', f).forEach(b => b.classList.toggle('on', b.dataset.kind === kind)); };
  const fillBuyers = () => { $('#dl-ob').innerHTML = buyers.filter(b => b.firm_code === f.firm_code.value).map(b => `<option value="${esc(b.name)} — ${esc(b.city || '')}">`).join(''); };
  const showItems = async () => {
    const b2c = kind === 'B2C';
    if (b2c ? !cust : !party) { $('#oitems').innerHTML = `<p class="hint">Choose the ${b2c ? 'customer' : 'buyer'} to see the items.</p>`; return; }
    if (b2c && !led.id) { $('#oitems').innerHTML = '<p class="badge amber">The ledger ONLINE SALE is not in Buyers B2B.</p>'; return; }
    const its = await GET(b2c ? `/api/parties/${led.id}/items?b2c=${cust.id}&all=1` : `/api/parties/${party.id}/items`);
    $('#oitems').innerHTML = its.length ? `<table class="t"><thead><tr><th></th><th>Item</th><th>Packing</th><th style="width:110px">${b2c ? 'Bags / packs' : 'Qty (MT)'}</th>${b2c ? '<th style="width:120px">Rate / bag (₹)</th>' : ''}</tr></thead><tbody>
      ${its.map(x => { const had = cur && cur.items.find(i => i.party_item_id === x.id);
        return `<tr><td><input type="checkbox" data-oi="${x.id}" style="width:auto" ${had ? 'checked' : ''}></td><td><b>${esc(x.item_name)}</b> ${esc(x.grade || '')}${b2c && !x.b2c_id ? ' <span class="hint">(ONLINE SALE)</span>' : ''}</td>
          <td class="hint">${x.pack_size ? kg(x.pack_size) + ' kg ' : ''}${esc(x.bag_type || '')}${x.packing_type ? ' · ' + esc(x.packing_type) : ''}</td>
          <td><input data-oq="${x.id}" type="number" style="width:100px" step="${b2c ? '1' : '0.001'}" value="${had ? (b2c ? had.bags || '' : had.qty ? q3(had.qty) : '') : ''}"></td>
          ${b2c ? `<td><input data-orb="${x.id}" type="number" step="0.01" style="width:100px" value="${had && had.rate_bag ? had.rate_bag : x.rate || ''}"></td>` : ''}</tr>`; }).join('')}</tbody></table>
        ${b2c ? '<p class="hint" style="margin:4px 0 0">B2C: type the bags and the rate of one bag — the proforma invoice and the sales invoice use them.</p>' : ''}`
      : `<p class="badge amber">${esc(b2c ? cust.name : party.name)} has no items yet — add them in ${b2c ? 'Buyer B2C (Edit the customer)' : 'Buyers'}.</p>`;
    $$('[data-oq]').forEach(q => q.oninput = () => { if (q.value) $(`[data-oi="${q.dataset.oq}"]`).checked = true; });
  };
  $$('[data-kind]', f).forEach(b => b.onclick = () => { if (cur) return; kind = S.ordKind = b.dataset.kind; showKind(); showItems(); (kind === 'B2C' ? $('#ocq') : $('#obq')).focus(); });
  f.firm_code.onchange = () => { S.ordFirm = f.firm_code.value; fillBuyers(); if (party && party.firm_code !== f.firm_code.value) { party = null; $('#obq').value = ''; showItems(); } };
  $('#obq').onchange = () => { const np = buyers.find(b => `${b.name} — ${b.city || ''}` === $('#obq').value && b.firm_code === f.firm_code.value) || null;
    if ((np && np.id) !== (party && party.id)) { party = np; showItems(); } };
  $('#ocq').onchange = () => { const nc = custs.find(c => custLabel(c) === $('#ocq').value) || null; if ((nc && nc.id) !== (cust && cust.id)) { cust = nc; showItems(); } };
  $('#ocnew').onclick = () => b2cDialog(null, c => { if (!c) return; custs.push(c); $('#dl-oc').innerHTML += `<option value="${esc(custLabel(c))}">`; cust = c; $('#ocq').value = custLabel(c); showItems(); });
  showKind(); fillBuyers(); showItems();
  f.onsubmit = async e => {
    e.preventDefault(); const b2c = kind === 'B2C';
    if (b2c ? !cust : !party) return toast(b2c ? 'Choose the customer from Buyers B2C.' : 'Choose the buyer from the list.', true);
    const items = $$('[data-oi]').filter(c => c.checked).map(c => { const v = $(`[data-oq="${c.dataset.oi}"]`).value; return b2c ? { party_item_id: Number(c.dataset.oi), bags: v, rate_bag: $(`[data-orb="${c.dataset.oi}"]`).value } : { party_item_id: Number(c.dataset.oi), qty: v }; });
    const d = b2c ? { b2c_id: cust.id, dispatch_by: f.dispatch_by.value, notes: f.notes.value, items } : { firm_code: f.firm_code.value, party_id: party.id, dispatch_by: f.dispatch_by.value, notes: f.notes.value, items };
    const r = await guard(() => cur ? PUT('/api/orders/' + cur.id, d) : POST('/api/orders', d));
    toast(cur ? 'Order changed' : 'Order added');
    // a new order: send a proforma invoice to the buyer / B2C customer? (asked when the book is shown again)
    if (!cur && r && r.id) S.askPf = { id: r.id, party: b2c ? { name: cust.name, email: cust.email, payment_terms: cust.payment_terms, transporter: '', b2c: 1 } : party };
    if (location.hash === '#/orders') route(); else go('#/orders');
  };
  const oc = $('#ocancel'); if (oc) oc.onclick = () => go('#/orders');
  el.onclick = async e => {
    const iv = e.target.closest('[data-inv]'), ed = e.target.closest('[data-oed]'), dl = e.target.closest('[data-odel]'), row = e.target.closest('[data-o]'), cl = e.target.closest('[data-ocal]');
    if (iv) { S.fromOrder = orders.find(o => String(o.id) === iv.dataset.inv); go('#/newinvoice'); return; }
    if (ed) { go('#/orders/' + ed.dataset.oed); return; }
    if (dl) { if (confirm('Delete this order from the book? (Entries already on Google Calendar stay there.)')) { await guard(() => DEL('/api/orders/' + dl.dataset.odel)); route(); } return; }
    if (cl) { const r = await guard(() => POST(`/api/orders/${cl.dataset.ocal}/calendar`, {})); toast(r.calendar_status === 'SENT' ? 'Sent to Google Calendar' : 'Not sent: ' + (r.calendar_error || ''), r.calendar_status !== 'SENT'); route(); return; }
    if (row) { S.ordSel = row.dataset.o; $$('.ordrow').forEach(r => r.style.outline = r.dataset.o === S.ordSel ? '2px solid #1A9BB5' : ''); }
  };
  if (!cur) (kind === 'B2C' ? $('#ocq') : $('#obq')).focus();
  if (S.askPf) { const a = S.askPf; S.askPf = null; askProforma(a.id, a.party); }
};
// after a new B2B order is saved: Yes → the proforma invoice is made from the order and emailed to the buyer; No → nothing more
async function askProforma(orderId, party) {
  const trs = await GET('/api/m/transporters').catch(() => []);
  modal('Send a proforma invoice?', `<p style="font-size:15px">The order of <b>${esc(party.name)}</b> is saved.<br>Send a copy of the <b>proforma invoice</b> to the buyer?</p>
    <p class="hint">Yes: the proforma invoice is made from this order (today's date, the buyer's items, rates and packing, the order quantities, payment terms <b>${esc(party.payment_terms || '—')}</b> from Buyers) and emailed to ${party.email ? '<b>' + esc(party.email) + '</b>' : 'the buyer'}
      with the default proforma template, the proforma PDF and our bank proof. No: only the order is saved.</p>
    <div class="firmbox" style="margin-top:10px"><div class="grid g2" style="align-items:end">
      <label>Transporter<input id="aptr" list="dl-aptr" value="${esc(party.transporter || '')}" placeholder="Type the transporter"><datalist id="dl-aptr">${trs.map(t => `<option value="${esc(t.name)}">`).join('')}</datalist></label>
      <label style="display:flex;gap:8px;align-items:center;font-weight:600;padding-bottom:8px"><input type="checkbox" id="apnotr" style="width:auto"> Do not send transporter details</label></div>
      <p class="hint" id="aptrh" style="margin:6px 0 0"></p></div>
    <div class="row" style="margin-top:12px"><button id="apyes">Yes, send the proforma invoice</button><button class="sec" id="apno">No</button></div><div id="apmsg" style="margin-top:10px"></div>`, root => {
    const tr = $('#aptr', root), no = $('#apnotr', root), hint = $('#aptrh', root);
    const showTr = () => { tr.disabled = no.checked; const t = trs.find(x => x.name === tr.value.trim().toUpperCase());
      hint.innerHTML = no.checked ? 'No transporter on the proforma invoice and no transporter bank proof.'
        : !tr.value.trim() ? 'No transporter chosen.' : t ? `The proforma shows ${esc(t.name)}${t.has_bank_proof ? '; its bank proof goes with the email if it has not been sent to this buyer before' : ' (no bank proof in Master → Transporters)'}.`
        : 'This transporter is not in Master → Logistics → Transporters — only its name goes on the proforma.'; };
    tr.oninput = showTr; no.onchange = showTr; showTr();
    $('#apno', root).onclick = closeModal;
    $('#apyes', root).onclick = async e => {
      const b = e.target; b.disabled = true; $('#apno', root).disabled = true; b.textContent = 'Making and sending…';
      try {
        const r = await POST(`/api/orders/${orderId}/proforma`, { transporter: tr.value, no_transporter: no.checked ? 1 : 0 });
        if (r.sent) { closeModal(); toast(`Proforma invoice ${r.pi_no} sent to ${r.to}`); if (location.hash.startsWith('#/orders')) route(); return; }
        $('#apmsg', root).innerHTML = `<p class="badge amber" style="display:block;padding:8px 10px">Proforma invoice ${esc(r.pi_no)} is made but not sent: ${esc(r.error || '')}</p>
          <div class="row"><button id="apopen">Open the email to send it</button><button class="sec" id="apclose">Close</button></div>`;
        $('#apopen', root).onclick = () => proformaEmail(r.proforma_id); $('#apclose', root).onclick = closeModal;
        b.hidden = true; $('#apno', root).hidden = true;
      } catch (err) { $('#apmsg', root).innerHTML = `<p class="badge red" style="display:block;padding:8px 10px">${esc(err.message)}</p>`; b.disabled = false; $('#apno', root).disabled = false; b.textContent = 'Yes, send the proforma invoice'; }
    };
  });
}
PAGES.invoice = (el, id) => invoiceForm(el, Number(id));

// add / change a B2C customer (Buyers B2C)
const STATES_IN = ['ANDHRA PRADESH', 'ARUNACHAL PRADESH', 'ASSAM', 'BIHAR', 'CHHATTISGARH', 'GOA', 'GUJARAT', 'HARYANA', 'HIMACHAL PRADESH', 'JHARKHAND', 'KARNATAKA', 'KERALA',
  'MADHYA PRADESH', 'MAHARASHTRA', 'MANIPUR', 'MEGHALAYA', 'MIZORAM', 'NAGALAND', 'ODISHA', 'PUNJAB', 'RAJASTHAN', 'SIKKIM', 'TAMIL NADU', 'TELANGANA', 'TRIPURA',
  'UTTAR PRADESH', 'UTTARAKHAND', 'WEST BENGAL', 'ANDAMAN AND NICOBAR ISLANDS', 'CHANDIGARH', 'DADRA AND NAGAR HAVELI AND DAMAN AND DIU', 'DELHI', 'JAMMU AND KASHMIR', 'LADAKH', 'LAKSHADWEEP', 'PUDUCHERRY'];
const STATE_SC = { 'JAMMU AND KASHMIR': '01', 'HIMACHAL PRADESH': '02', PUNJAB: '03', CHANDIGARH: '04', UTTARAKHAND: '05', HARYANA: '06', DELHI: '07', RAJASTHAN: '08', 'UTTAR PRADESH': '09', BIHAR: '10',
  SIKKIM: '11', 'ARUNACHAL PRADESH': '12', NAGALAND: '13', MANIPUR: '14', MIZORAM: '15', TRIPURA: '16', MEGHALAYA: '17', ASSAM: '18', 'WEST BENGAL': '19', JHARKHAND: '20', ODISHA: '21',
  CHHATTISGARH: '22', 'MADHYA PRADESH': '23', GUJARAT: '24', 'DADRA AND NAGAR HAVELI AND DAMAN AND DIU': '26', MAHARASHTRA: '27', KARNATAKA: '29', GOA: '30', LAKSHADWEEP: '31', KERALA: '32',
  'TAMIL NADU': '33', PUDUCHERRY: '34', 'ANDAMAN AND NICOBAR ISLANDS': '35', TELANGANA: '36', 'ANDHRA PRADESH': '37', LADAKH: '38' };
function b2cDialog(c, after) {
  const v = c || { state: '' };
  modal(c ? 'Change B2C customer' : 'New B2C customer', `<form id="b2f" autocomplete="off"><div class="grid g2">
    ${field({ name: 'name', label: 'Customer name', span: 2 }, v.name)}
    ${field({ name: 'contact_person', label: 'Contact person', span: 2 }, v.contact_person)}
    ${field({ name: 'mobile', label: 'Mobile' }, v.mobile)}${field({ name: 'email', label: 'Email (more than one: put a comma between)' }, v.email)}
    ${field({ name: 'address', label: 'Address', type: 'textarea', span: 2 }, v.address)}
    ${field({ name: 'pincode', label: 'Pincode' }, v.pincode)}${field({ name: 'city', label: 'City' }, v.city)}
    <label class="span2">State <span class="hint">(GST depends on it)</span><select name="state"><option value="">— choose —</option>${STATES_IN.map(s => `<option ${s === String(v.state || '').toUpperCase() ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
    ${field({ name: 'payment_terms', label: 'Payment terms', type: 'select', options: lv('payment_terms').length ? lv('payment_terms') : ['100% ADVANCE'], def: '100% ADVANCE' }, v.payment_terms)}
    ${field({ name: 'pay_days', label: 'Payment by (days from invoice date)', type: 'select', options: [['', '— not set —'], ...Array.from({ length: 45 }, (x, i) => [String(i + 1), (i + 1) + (i ? ' days' : ' day')])] }, v.pay_days)}
    ${field({ name: 'pay_reminder', label: 'Send payment reminder', type: 'select', options: ['NO', 'YES'], def: 'NO' }, v.pay_reminder)}
    ${field({ name: 'location_url', label: 'Delivery location link (Google Maps → Share → Copy link) — QR on the back of the invoice', span: 2 }, v.location_url)}
    ${field({ name: 'print_loc', label: 'Print location QR on the invoice', type: 'select', options: ['YES', 'NO'], def: 'YES' }, v.print_loc)}
    ${field({ name: 'notes', label: 'Note', span: 2 }, v.notes)}</div>
    <div class="row" style="margin-top:12px"><button type="submit">${c ? 'Save changes' : 'Add customer'}</button></div></form>
    ${c ? '<div class="row" style="margin:10px 0"><button type="button" class="sec" id="b2comp">📇 Send company details</button></div><div id="paddr"></div><div id="pitems"></div>' : '<div class="firmbox" style="margin-top:16px">Save the customer first, then add the delivery addresses and the items, rates and packing here.</div>'}`, async root => {
    const f = $('#b2f', root);
    const bc = $('#b2comp', root); if (bc) bc.onclick = () => companyMail({ b2c: c.id });
    if (c) {      // the customer's own delivery addresses and items (kept under the ONLINE SALE ledger)
      const led = await GET('/api/b2c-ledger');
      if (led.id) { const row = { id: led.id, name: c.name, is_online: 1, b2c: c.id, pincode: c.pincode };
        partyAddresses($('#paddr', root), row); partyItems($('#pitems', root), row); }
      else $('#pitems', root).innerHTML = '<p class="badge amber">The ledger ONLINE SALE is not in Buyers B2B.</p>';
    }
    f.pincode.addEventListener('change', async () => { if (!/^\d{6}$/.test(f.pincode.value.trim())) return;
      const r = await GET('/api/pincode/' + f.pincode.value.trim()).catch(() => null);
      if (r && r.city && !f.city.value) f.city.value = String(r.city).toUpperCase(); if (r && r.state) { const s = STATES_IN.find(x => x === String(r.state).toUpperCase()); if (s) f.state.value = s; } });
    f.onsubmit = async e => { e.preventDefault(); const d = formData(f);
      const r = await guard(() => c ? PUT('/api/b2c/' + c.id, d) : POST('/api/b2c', d));
      const list = await GET('/api/b2c'); closeModal(); toast(c ? 'Customer saved' : 'Customer added'); after && after(list.find(x => x.id === (c ? c.id : r.id))); };
  });
}
// ---------- Buyers B2C: customers of the ledger ONLINE SALE ----------
TITLES.b2c = 'Buyers B2C'; TITLES.newb2c = 'New B2C Invoice';
PAGES.b2c = async (el, selId) => {
  const st = S.b2cq = S.b2cq || { q: '' };
  const [rows] = await Promise.all([GET('/api/b2c?q=' + encodeURIComponent(st.q)), loadLists()]);
  const sel = rows.find(r => String(r.id) === String(selId));
  const invs = sel ? await GET(`/api/b2c/${sel.id}/invoices`) : [];
  el.innerHTML = `<div class="toolbar"><button id="b2add">+ Add customer</button><input type="search" id="b2s" placeholder="Search name, mobile, city…" value="${esc(st.q)}">
      <span class="spacer"></span><button class="sec" onclick="go('#/newb2c')">+ New B2C Invoice</button><button class="sec" id="b2x">Export</button></div>
    <p class="hint" style="margin:0 0 10px">B2C customers are kept apart from the B2B buyers. Their invoices are made under the ledger <b>ONLINE SALE</b> (Parakh Marketing); the reports show ONLINE SALE. Add the items of ONLINE SALE in Buyers B2B.</p>
    <div class="grid" style="grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);align-items:start">
    <div class="card"><div class="tablewrap" style="max-height:70vh"><table class="t"><thead><tr><th>Customer</th><th>Mobile</th><th>City / state</th><th class="num">Invoices</th><th class="num">Amount</th><th>Last</th><th></th></tr></thead><tbody>
    ${rows.map(r => `<tr class="click" data-b2="${r.id}" ${sel && sel.id === r.id ? 'style="background:#eef6ff"' : ''}><td><b>${esc(r.name)}</b>${r.email ? `<br><span class="hint">${esc(r.email)}</span>` : ''}</td><td>${esc(r.mobile || '')}</td>
      <td>${esc(r.city || '')}<br><span class="hint">${esc(r.state || '')}</span></td><td class="num">${r.invoices}</td><td class="num">${r.amount ? money(r.amount) : ''}</td><td>${r.last_date ? dmy(r.last_date) : ''}</td>
      <td style="white-space:nowrap;text-align:right"><button class="small sec" data-b2ed="${r.id}">Edit</button></td></tr>`).join('') || '<tr><td colspan="7" class="muted">No B2C customers yet.</td></tr>'}</tbody></table></div></div>
    <div class="card">${sel ? `<h3>${esc(sel.name)}</h3><p class="hint">${esc([sel.mobile, sel.email].filter(Boolean).join(' · '))}<br>${esc([sel.address, sel.city, sel.pincode, sel.state].filter(Boolean).join(', '))}</p>
      <table class="t"><thead><tr><th>Invoice</th><th>Date</th><th>Medium</th><th class="num">Qty</th><th class="num">Amount</th></tr></thead><tbody>
      ${invs.map(i => `<tr class="click" onclick="go('#/invoice/${i.id}')"><td><b>${i.inv_no}</b> <span class="hint">${esc(i.fy)}</span>${i.cancelled ? ' <span class="badge red">cancelled</span>' : ''}</td><td>${dmy(i.date)}</td><td>${esc(i.sale_medium || '')}</td><td class="num">${qty(i.qty)}</td><td class="num">${money(i.total)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">No invoices yet.</td></tr>'}</tbody></table>`
      : '<p class="muted">Click a customer to see their invoices.</p>'}</div></div>`;
  $('#b2add').onclick = () => b2cDialog(null, () => PAGES.b2c(el, selId));
  let tm; $('#b2s').oninput = e => { clearTimeout(tm); tm = setTimeout(() => { st.q = e.target.value; PAGES.b2c(el, selId).then(() => { const s = $('#b2s'); s.focus(); s.setSelectionRange(s.value.length, s.value.length); }); }, 300); };
  $('#b2x').onclick = () => downloadCsv('buyers_b2c.csv', rows.map(r => ({ name: r.name, mobile: r.mobile, email: r.email, address: r.address, city: r.city, pincode: r.pincode, state: r.state, invoices: r.invoices, amount: r.amount })));
  el.onclick = e => { const ed = e.target.closest('[data-b2ed]'); if (ed) { b2cDialog(rows.find(r => String(r.id) === ed.dataset.b2ed), () => PAGES.b2c(el, selId)); return; }
    const r = e.target.closest('[data-b2]'); if (r) go('#/b2c/' + r.dataset.b2); };
};

// ---------- formatted email editor: fonts, size, bold, colour, lists, alignment, links ----------
// richArea(name, html) → toolbar + editable box; the form gets two hidden fields: `name` (plain text) and `name + 'html'` → see richHtmlName
const RICH_FONTS = [['Arial, Helvetica, sans-serif', 'Arial'], ['Calibri, Arial, sans-serif', 'Calibri'], ['Verdana, Geneva, sans-serif', 'Verdana'], ['Tahoma, Geneva, sans-serif', 'Tahoma'],
  ['"Segoe UI", Arial, sans-serif', 'Segoe UI'], ['Georgia, serif', 'Georgia'], ['"Times New Roman", Times, serif', 'Times New Roman'], ['"Courier New", monospace', 'Courier New']];
const richHtmlName = name => name === 'text' ? 'html' : name === 'body' ? 'html' : name.replace(/^text/, 'html');
const textToHtmlC = s => String(s || '').replace(/\r/g, '').split(/\n\s*\n/).map(p => p.trim() ? `<p>${esc(p).replace(/\n/g, '<br>')}</p>` : '').join('');
function richArea(name, html, minH = 240) {
  const b = (cmd, label, title, arg = '') => `<button type="button" class="small sec" data-rc="${cmd}" data-ra="${esc(arg)}" title="${title}" style="min-width:30px">${label}</button>`;
  return `<div class="richwrap" data-rich="${name}" style="border:1px solid var(--line);border-radius:8px;overflow:hidden;background:#fff">
    <div class="richbar" style="display:flex;flex-wrap:wrap;gap:4px;align-items:center;padding:6px;background:#f5f8f9;border-bottom:1px solid var(--line)">
      <select data-rs="fontName" title="Font" style="width:auto;padding:3px 6px;font-weight:500">${RICH_FONTS.map(([v, n]) => `<option value='${v}'>${n}</option>`).join('')}</select>
      <select data-rs="fontSize" title="Size" style="width:auto;padding:3px 6px;font-weight:500"><option value="2">Small</option><option value="3" selected>Normal</option><option value="4">Large</option><option value="5">Larger</option><option value="6">Heading</option></select>
      ${b('bold', '<b>B</b>', 'Bold')}${b('italic', '<i>I</i>', 'Italic')}${b('underline', '<u>U</u>', 'Underline')}
      <label title="Text colour" style="display:inline-flex;align-items:center;gap:3px;margin:0;font-size:12px">A<input type="color" data-rcol value="#1a3e4a" style="width:28px;height:24px;padding:0;border:0"></label>
      ${b('insertUnorderedList', '• List', 'Bullet list')}${b('insertOrderedList', '1. List', 'Numbered list')}
      ${b('justifyLeft', '⯇', 'Align left')}${b('justifyCenter', '≡', 'Centre')}${b('createLink', '🔗', 'Link')}${b('insertHorizontalRule', '—', 'Line')}${b('removeFormat', '⌫', 'Clear formatting')}
    </div>
    <div class="richbox" contenteditable="true" style="min-height:${minH}px;max-height:52vh;overflow:auto;padding:12px 14px;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:1.55;outline:none;font-weight:400">${html || ''}</div>
    <textarea name="${name}" hidden></textarea><textarea name="${richHtmlName(name)}" hidden></textarea></div>`;
}
function richSync(w) { const box = $('.richbox', w), n = w.dataset.rich; $(`[name="${n}"]`, w).value = box.innerText.replace(/\n{3,}/g, '\n\n').trim(); $(`[name="${richHtmlName(n)}"]`, w).value = box.innerHTML; }
function richInit(root) {
  $$('.richwrap', root).forEach(w => {
    const box = $('.richbox', w);
    try { document.execCommand('styleWithCSS', false, false); } catch { /* old */ }
    box.addEventListener('input', () => richSync(w)); richSync(w);
    // paste keeps the words, not the look of the other program
    box.addEventListener('paste', e => { const tx = (e.clipboardData || window.clipboardData).getData('text/plain'); if (tx) { e.preventDefault(); document.execCommand('insertHTML', false, textToHtmlC(tx)); } });
    $$('[data-rc]', w).forEach(bt => bt.onmousedown = e => { e.preventDefault(); box.focus();
      const c = bt.dataset.rc; if (c === 'createLink') { const u = prompt('Link (https://…)'); if (u) document.execCommand('createLink', false, u); } else document.execCommand(c, false, bt.dataset.ra || null); richSync(w); });
    $$('[data-rs]', w).forEach(s => s.onchange = () => { box.focus(); document.execCommand(s.dataset.rs, false, s.value); richSync(w); });
    const col = $('[data-rcol]', w); col.oninput = () => { box.focus(); document.execCommand('foreColor', false, col.value); richSync(w); };
  });
}
function richSet(root, name, html) { const w = $(`.richwrap[data-rich="${name}"]`, root); if (!w) return; $('.richbox', w).innerHTML = html || ''; richSync(w); }
// put a {field} where the cursor is
function richInsert(root, name, text) { const w = $(`.richwrap[data-rich="${name}"]`, root), box = $('.richbox', w); box.focus(); document.execCommand('insertText', false, text); richSync(w); }

// "🔍 Get details from GST" under a GSTIN box: captcha from the GST portal, then name, address, pincode, state and PAN fill in
function gstFetchBox(input, f) {
  if (!input) return;
  const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'small sec'; btn.textContent = '🔍 Get details from GST'; btn.style.marginTop = '4px';
  const panel = document.createElement('div'); panel.className = 'span4'; panel.hidden = true;
  panel.style.cssText = 'grid-column:1 / -1;flex:1 1 100%;border:1px solid #cfe3e8;background:#f5fbfc;border-radius:8px;padding:10px 12px;margin:2px 0 6px';
  input.after(btn); input.closest('label').parentElement.insertBefore(panel, input.closest('label').nextSibling);
  let sid = null;
  const load = async () => {
    panel.innerHTML = '<span class="hint">Opening the GST portal…</span>';
    try {
      const c = await GET('/api/gst-captcha' + (sid ? '?id=' + sid : '')); sid = c.id;
      panel.innerHTML = `<div class="row" style="gap:10px;align-items:center;flex-wrap:wrap"><b>GST portal</b>
        <img src="${c.image}" alt="captcha" style="height:44px;border:1px solid #ccc;border-radius:4px;background:#fff">
        <button type="button" class="small sec" data-g="new" title="New captcha">↻</button>
        <input data-g="cap" placeholder="Type the characters" style="width:170px" autocomplete="off">
        <button type="button" class="small" data-g="go">Get details</button><span class="hint" data-g="msg"></span></div><div data-g="res"></div>`;
      const cap = $('[data-g=cap]', panel); cap.focus();
      cap.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); fetchIt(); } };
      $('[data-g=new]', panel).onclick = load; $('[data-g=go]', panel).onclick = fetchIt;
    } catch (e) { panel.innerHTML = `<span class="badge red">${esc(e.message)}</span> <button type="button" class="small sec" data-g="retry">Try again</button>`; $('[data-g=retry]', panel).onclick = load; }
  };
  const fetchIt = async () => {
    const msg = $('[data-g=msg]', panel), cap = $('[data-g=cap]', panel);
    if (!cap.value.trim()) return cap.focus();
    msg.textContent = 'Searching…';
    try {
      const r = await POST('/api/gst-lookup', { id: sid, gstin: input.value, captcha: cap.value }); sid = null;
      const set = (n, v) => { const el = f.querySelector(`[name=${n}]`); if (!el || !v) return;
        if (el.tagName === 'SELECT') { const o = [...el.options].find(x => x.value.toUpperCase() === String(v).toUpperCase() || x.text.toUpperCase() === String(v).toUpperCase()); if (o) el.value = o.value; else el.add(new Option(String(v).toUpperCase(), String(v).toUpperCase(), true, true)); }
        else el.value = v; };
      const name = f.querySelector('[name=name]');
      if (name && !name.value.trim()) name.value = (r.trade_name || r.legal_name).toUpperCase();
      set('address', r.address); set('lessee_name', String(r.legal_name || '').toUpperCase()); set('pincode', r.pincode); set('city', String(r.city || '').toUpperCase()); set('district', String(r.district || '').toUpperCase()); set('state', r.state); set('pan', r.pan);
      S.dirty = true;
      const hasAddr = !!f.querySelector('[name=address]');
      panel.innerHTML = `<div><b>${esc(r.legal_name)}</b>${r.trade_name && r.trade_name !== r.legal_name ? ` · trade name <b>${esc(r.trade_name)}</b>` : ''}
        · <span class="badge ${/active/i.test(r.status) ? 'slate' : 'red'}">${esc(r.status || '—')}</span> <span class="hint">${esc(r.type || '')}${r.since ? ' · since ' + esc(r.since) : ''}</span></div>
        <div class="hint" style="margin:3px 0">${esc(r.full_address || r.address)}</div>
        <div class="row" style="gap:6px">${name ? `<button type="button" class="small sec" data-n="${esc(r.legal_name)}">Use legal name</button>${r.trade_name ? `<button type="button" class="small sec" data-n="${esc(r.trade_name)}">Use trade name</button>` : ''}` : ''}
        <span class="hint">${hasAddr ? 'Address, pincode, city, state and PAN are filled in' : 'Lessee name is the legal name'} — check and save.</span></div>`;
      $$('[data-n]', panel).forEach(b => b.onclick = () => { name.value = b.dataset.n.toUpperCase(); S.dirty = true; });
      if (!/active/i.test(r.status)) toast(`This GSTIN is ${r.status || 'not active'} on the GST portal.`, true);
    } catch (e) { msg.textContent = ''; toast(e.message, true); if (/captcha/i.test(e.message)) load(); }
  };
  btn.onclick = () => {
    if (!/^\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]{3}$/i.test(input.value.trim())) return toast('Type the 15-character GSTIN first.', true);
    input.value = input.value.trim().toUpperCase(); panel.hidden = false; load();
  };
}

async function invoiceForm(el, id, pro = false, sellFirm = null) {
  const API = pro ? '/api/proformas' : '/api/invoices';
  const [parties, items, transporters, inv] = await Promise.all([loadParties(), loadItems(), GET('/api/m/transporters'), id ? GET(API + '/' + id) : null, loadLists()]);
  // a new proforma: only the buyers of the chosen selling firm
  const active = parties.filter(p => p.active !== 0 && ['PM', 'PF'].includes(p.firm_code) && (!sellFirm || p.firm_code === sellFirm) && !(pro && p.is_online));
  const label = p => `${p.name} — ${p.city || ''} [${p.firm_code}]`;
  const pwOk = inv && S.unlock && S.unlock.id === inv.id ? S.unlock.pw : null;   // unlocked with the edit password
  const locked = pro ? false : inv && (inv.cancelled || (inv.legacy && !inv.party_id) || !pwOk);
  const v = inv || { date: today(), items: [{}] };
  let party = inv ? parties.find(p => p.id === inv.party_id) || null : null;
  if (inv && !party) party = { id: null, name: inv.party_name, firm_code: inv.firm_code, gstin: inv.party_gstin, state: inv.party_state, state_code: inv.party_state_code, city: inv.party_city, address: inv.party_address };

  el.innerHTML = `
  ${datalist('dl-party', active.map(label))}${datalist('dl-item', [...lv('product'), ...items.map(i => i.name)])}${datalist('dl-tr', transporters.map(t => t.name))}
  ${datalist('dl-bag', [...lv('bag_type'), ...items.map(i => i.bag_type)])}
  <form id="invf" autocomplete="off">
  <div class="card">
    <div class="grid g4">
      <label class="span2">Buyer (type to search)<input id="partyq" list="dl-party" value="${esc(party ? label(party) : '')}" ${inv ? 'readonly' : ''} placeholder="Start typing the buyer name…"></label>
      ${field({ name: 'inv_no', label: 'Invoice no.', ro: !!inv }, v.inv_no || '')}
      ${field({ name: 'date', label: 'Invoice date', type: 'date' }, v.date)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div><div class="firmbox" id="firmbox">Choose a buyer. The billing firm comes from the buyer and cannot be changed here.</div>
        <div id="b2cbox" class="card" hidden style="margin:10px 0 0;padding:10px 14px;background:#fff8ee;border-color:#f0c98c">
          <b>🛒 B2C — Online Sale</b> <span class="hint">GSTIN: UNREGISTERED · reports show ONLINE SALE</span>
          <div class="grid g2" style="margin-top:8px">
            <label>Medium of sale<select name="sale_medium">${['', ...(lv('sale_medium').length ? lv('sale_medium') : ['WEBSITE', 'SELF']), ...(v.sale_medium && !lv('sale_medium').includes(v.sale_medium) ? [v.sale_medium] : [])].map(m => `<option ${m === (v.sale_medium || '') ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></label>
            <label>Customer <span class="hint">(Buyers B2C — type name or mobile)</span><div class="row" style="gap:6px;flex-wrap:nowrap;margin-top:3px"><input id="b2cq" list="dl-b2c" placeholder="Search the customer…"><button type="button" class="small" id="b2cnew" style="white-space:nowrap">+ New</button></div></label>
          </div><input type="hidden" name="b2c_id" value="${esc(v.b2c_id || '')}"><datalist id="dl-b2c"></datalist>
          <div id="b2cinfo" class="hint" style="margin-top:6px"></div></div></div>
      <div class="grid g2">
        ${field({ name: 'party_address', label: 'Bill-to address', type: 'textarea' }, v.party_address)}
        <div>
          <label>Deliver to <span class="hint">(Buyers → delivery addresses)</span><select name="delivery_id" id="shipsel"><option value="">Same as bill-to address</option></select></label>
          <div id="shipinfo" class="hint" style="margin:3px 0 8px;min-height:1em"></div>
          <label>E-way bill type <span class="hint">(as on the portal)</span><select name="trans_type" id="ttype">
            <option value="1">Regular — Bill To only</option><option value="2">Bill To – Ship To</option>
            <option value="3">Bill From – Dispatch From</option><option value="4">Combination of 2 and 3</option></select></label>
        </div>
      </div>
    </div>
  </div>
  <div class="card"><h3>Items</h3>
    <div id="pchips" class="row" style="gap:8px;margin-bottom:10px"></div>
    <table class="items"><thead><tr><th style="width:30px">#</th><th>Item</th><th>Grade</th><th style="width:80px">Bags</th><th style="width:70px">Kg / bag</th><th style="width:80px">HSN</th>
      <th style="width:95px">Qty (MT)</th><th style="width:100px" id="rateh">Rate / MT</th><th style="width:60px">GST %</th><th>Bag type</th><th style="width:150px">Packing</th><th style="width:120px">Plant</th><th style="width:115px" class="num">Amount</th><th style="width:110px">Lot No.</th><th></th></tr></thead>
      <tbody id="lines"></tbody></table>
    ${locked ? '' : '<p class="hint" style="margin:8px 0 0">Items, rates, HSN, GST and packing come from the buyer’s items (Buyers menu) and cannot be changed here. Type only the bags.</p>'}
  </div>
  <div class="grid g2">
    <div class="card"><h3>Dispatch</h3>
      <div id="sendbox" class="grid g3" hidden style="margin-bottom:10px">
        <label>Sent by<select name="send_by"><option value="LORRY" ${v.send_by !== 'COURIER' ? 'selected' : ''}>Lorry / transporter</option><option value="COURIER" ${v.send_by === 'COURIER' ? 'selected' : ''}>Courier / parcel</option></select></label>
        <label class="courier">Courier name<input name="courier" list="dl-courier" value="${esc(v.courier || '')}"><datalist id="dl-courier"><option value="DTDC"><option value="BLUE DART"><option value="DELHIVERY"><option value="INDIA POST"><option value="PROFESSIONAL COURIERS"></datalist></label>
        <label class="courier">Docket no.<input name="docket_no" value="${esc(v.docket_no || '')}"></label></div>
      <div class="grid g3 lorrybox">
      <label>Lorry no. <span class="badge amber needbig" hidden>required</span><input name="lorry_no" value="${esc(v.lorry_no || '')}"></label>
      <label>Transporter <span class="hint">(buyer's last used)</span> <span class="badge amber needbig" hidden>required</span><input name="transporter" list="dl-tr" value="${esc(v.transporter || '')}"></label>
      <label>Transporter GSTIN <span class="hint">(🔒 from Transporters master)</span> <span class="badge amber needbig" hidden>required</span><input name="transporter_gstin" value="${esc(v.transporter_gstin || '')}" readonly tabindex="-1" class="locked" title="Change it in Masters → Lorries & more → Transporters"><span id="trgst" class="hint" style="display:block;margin-top:3px;font-weight:400"></span></label>
      <label>L.R. no. <span class="badge amber needbig" hidden>required</span><input name="lr_no" value="${esc(v.lr_no || '')}"></label>
      <label>Driver phone <span class="hint">(last used for this lorry)</span><input name="driver_phone" list="dl-dph" value="${esc(v.driver_phone || '')}"><datalist id="dl-dph"></datalist></label>
      <label>E-way bill no. <span id="ewbreq" class="hint"></span>
        <div class="row" style="gap:6px;flex-wrap:nowrap;margin-top:3px"><input name="ewb_no" value="${esc(v.ewb_no || '')}" inputmode="numeric" maxlength="12" placeholder="12 digits">
        ${locked ? '' : '<button type="button" class="sec small" id="ewbjson" style="white-space:nowrap" title="Make the JSON file to upload on the e-way bill portal">⬇ JSON</button>'}</div></label>
      <label>Freight rate per MT (₹) <span class="badge amber needbig" hidden>required</span><input name="freight_note" value="${esc(v.freight_note || '')}" inputmode="decimal" placeholder="e.g. 2600"></label>
      <label>Total freight <span class="hint">(rate × qty)</span><input id="ftotal" readonly tabindex="-1"></label>
      <label>Freight payment mode <span class="badge amber needbig" hidden>required</span><select name="freight_mode">${(() => {
        const modes = lv('freight_mode').length ? lv('freight_mode') : ['TO PAY', 'PAID', 'TO PAY DOOR DELIVERY', 'PAID DOOR DELIVERY'];
        const cur = inv ? (v.freight_mode || '') : (modes.includes('TO PAY') ? 'TO PAY' : modes[0]);   // new invoices: TO PAY
        return ['', ...modes, ...(cur && !modes.includes(cur) ? [cur] : [])].map(m => `<option ${m === cur ? 'selected' : ''}>${esc(m)}</option>`).join('');
      })()}</select></label>
      ${field({ name: 'advance_freight', label: 'Advance freight', type: 'number' }, v.advance_freight)}
      ${pro ? '' : `<label style="display:flex;gap:8px;align-items:center;grid-column:span 2;align-self:end;padding-bottom:8px"><input type="checkbox" name="tr_invoice" style="width:auto" ${v.tr_invoice ? 'checked' : ''}>
        <span>🚚 Make transporter invoice <span class="hint">— No. = L.R. no., amount = total freight; saved with the invoice PDF and emailed with it</span></span></label>`}
      ${field({ name: 'notes', label: 'Note on invoice', span: 3 }, v.notes)}
    </div></div>
    <div class="card"><h3>Totals</h3><div class="totals" id="tot"></div>
      <div class="row" style="margin-top:14px">
        ${pro ? `<button type="submit">Save</button><button type="button" id="saveprint">Save & show PDF</button>
          ${inv ? `<button type="button" class="sec" id="pfprint">🖨 Print</button><button type="button" class="sec" id="pfview">Preview / PDF</button><button type="button" class="rust" id="pfemail">${inv.email_sent_at ? '↻ Re-send email' : 'Email to buyer'}</button>` : ''}` : ''}
        ${!pro && !locked ? '<button type="submit">Save</button><button type="button" id="saveprint">Save & print</button>' : ''}
        ${!pro && inv && !inv.cancelled && !(inv.legacy && !inv.party_id) && !pwOk ? '<button type="button" class="sec" id="unlock">🔒 Edit invoice</button>' : ''}
        ${!pro && inv ? `<button type="button" id="print">🖨 Print invoice</button><button type="button" class="sec" id="stickers">🏷 Bag stickers</button><button type="button" class="sec" id="envelope">✉ Envelope</button>
          <button type="button" class="sec" id="preview">Preview / PDF</button><button type="button" class="sec" id="lrcopy" title="Upload or paste the L.R. copy">📎 L.R. copy</button>${inv.tr_invoice ? '<button type="button" class="sec" id="trinvb">🚚 Transporter invoice</button>' : ''}${(() => { const bags = inv.items.reduce((s, i) => s + (Number(i.bags) || 0), 0);
            return `<button type="button" class="sec" id="lfl" ${bags < 200 && !inv.cancelled ? '' : 'disabled'} title="${bags < 200 ? 'Letter to the transporter to pay the local tempo' : 'Only for invoices under 200 bags (this one has ' + bags + ')'}">🛺 Local Freight Letter</button>`; })()}${!inv.legacy ? `<button type="button" class="rust" id="email">${inv.email_sent_at ? '↻ Re-send email' : 'Email to buyer'}</button>`+'<button type="button" class="sec" id="emailtr">🚚 Email to transporter</button><button type="button" class="sec" id="wainv" title="Send the invoice on WhatsApp (linked template)">💬 WhatsApp</button>' : ''}` : ''}
        <span class="spacer"></span>
        ${!pro && inv && !locked ? '<button type="button" class="sec" id="cancel">Cancel invoice</button>' : ''}
      </div>
      ${inv && inv.email_sent_at ? `<p class="hint">Email sent on ${esc(inv.email_sent_at)}</p>` : ''}
      ${inv && inv.transporter_mail_at ? `<p class="hint">Copy emailed to the transporter on ${esc(inv.transporter_mail_at)}</p>` : ''}
      ${inv && !inv.email_sent_at && inv.auto_mail_error ? `<p class="badge amber">Automatic email not sent yet: ${esc(inv.auto_mail_error)} — tried again every hour.</p>` : ''}
      ${inv && inv.legacy ? `<p class="hint">Imported from the old Excel file${inv.party_id ? ' — press “Edit invoice” to change it (the items must be in the buyer’s items).' : ' and not linked to a buyer — view and print only.'}</p>` : ''}
      ${pro ? `<p class="hint">Proforma invoice ${inv ? '<b>' + esc(inv.pi_no) + '</b>' : ''} — not a tax invoice. Saving a new one also puts it in the Orders book (dispatch in 7 days).</p>` : ''}
      ${!pro && inv && !inv.cancelled && (!inv.legacy || pwOk) ? `<p class="hint">${pwOk ? '🔓 Unlocked with the edit password — save to keep the changes.' : 'Saved invoice — locked. Press “Edit invoice” and enter the edit password to change or cancel it.'}</p>` : ''}
    </div>
  </div>
  </form>`;

  const f = $('#invf');
  const lines = $('#lines');
  const lineHtml = (it = {}, i) => `<tr>
    <td>${i + 1}</td>
    <td><input data-k="item_name" readonly tabindex="-1" value="${esc(it.item_name)}"><input type="hidden" data-k="party_item_id" value="${esc(it.party_item_id || '')}"><input type="hidden" data-k="fixed_plant" value="${esc(it.fixed_plant || '')}"></td>
    <td><input data-k="grade" readonly tabindex="-1" value="${esc(it.grade)}"></td>
    <td><input data-k="bags" type="number" class="num" value="${esc(it.bags ?? '')}" ${it.item_name ? '' : 'disabled'}></td>
    <td><input data-k="pack_size" readonly tabindex="-1" class="num" value="${esc(it.pack_size ?? '')}"></td>
    <td><input data-k="hsn" readonly tabindex="-1" value="${esc(it.hsn || '')}"></td>
    <td><input data-k="qty" type="number" step="0.001" class="num" value="${esc(q3(it.qty))}" title="Bags × kg per bag ÷ 1000" ${it.item_name ? '' : 'disabled'}></td>
    <td>${party && party.is_online ? `<input data-k="rate_bag" ${locked ? 'readonly' : ''} type="number" step="0.01" class="num" title="B2C: price of one bag / pack" value="${esc(it.rate_bag ?? (it.rate && it.pack_size ? r2(it.rate * it.pack_size / 1000) : ''))}"><input type="hidden" data-k="rate" value="${esc(it.rate ?? '')}">`
      : `<input data-k="rate" readonly tabindex="-1" class="num" value="${esc(it.rate ?? '')}">`}</td>
    <td><input data-k="gst_rate" readonly tabindex="-1" class="num" value="${esc(it.gst_rate ?? '')}"></td>
    <td><input data-k="bag_type" readonly tabindex="-1" value="${esc(it.bag_type || '')}"><input type="hidden" data-k="packing_type" value="${esc(it.packing_type || '')}"></td>
    <td><input readonly tabindex="-1" class="packshow" value="${esc([it.packing_type, packText(it.bag_supply, it.liner)].filter(Boolean).join(' · '))}"><input type="hidden" data-k="packing" value="${packKey(it.bag_supply, it.liner)}"></td>
    <td><select data-k="plant" ${it.fixed_plant ? 'disabled title="Fixed by the buyer\'s item"' : ''}>${['', ...S.meta.plants.map(p => p.name), ...(it.plant && !S.meta.plants.some(p => p.name === it.plant) ? [it.plant] : [])].map(x => `<option ${x === (it.fixed_plant || it.plant || '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></td>
    <td class="num amt">0.00</td>
    <td><input data-k="lot_no" value="${esc(it.lot_no || '')}" placeholder="${it.lot_needed ? 'required' : ''}"><input type="hidden" data-k="lot_needed" value="${it.lot_needed ? 1 : ''}"></td>
    <td>${locked ? '' : '<button type="button" class="ghost del" title="Remove">✕</button>'}</td></tr>`;
  const readLines = () => $$('tr', lines).map(tr => {
    const o = {}; $$('[data-k]', tr).forEach(i => o[i.dataset.k] = i.value.trim());
    const [bs, ln] = (o.packing || '').split('|'); delete o.packing;
    if (o.rate_bag !== undefined) o.rate = +o.rate_bag && +o.pack_size ? String(+o.rate_bag * 1000 / +o.pack_size) : '';   // B2C: per bag → per MT
    o.bag_supply = bs || null; o.liner = bs ? Number(ln) : null; return o;
  });
  let pitems = [];
  const fromBuyer = (name, grade) => pitems.find(x => x.item_name === name && (x.grade || '') === grade) ||
    (!grade && pitems.filter(x => x.item_name === name).length === 1 ? pitems.find(x => x.item_name === name) : null);
  const fillLine = (tr, x) => {
    const set = (k, v) => { const inp = $(`[data-k=${k}]`, tr); if (inp) inp.value = v ?? ''; };
    set('party_item_id', x.id); set('fixed_plant', x.plant || ''); set('lot_needed', x.lot_needed === 'YES' ? 1 : '');
    const ps0 = $('[data-k=plant]', tr); if (ps0) { ps0.value = x.plant || ps0.value; ps0.disabled = !!x.plant; }
    const ln = $('[data-k=lot_no]', tr); if (ln) ln.placeholder = x.lot_needed === 'YES' ? 'required' : ''; set('gst_rate', x.gst_rate ?? 5); set('rate', x.rate); set('rate_bag', x.rate); set('bag_type', x.bag_type); set('pack_size', x.pack_size);
    set('packing', packKey(x.bag_supply, x.liner)); const ps = $('.packshow', tr); if (ps) ps.value = [x.packing_type, packText(x.bag_supply, x.liner)].filter(Boolean).join(' · ');
    $$('[data-k=bags], [data-k=qty]', tr).forEach(i => { i.disabled = false; });
    const mm = items.find(i => i.name === x.item_name && (i.grade || '') === (x.grade || '')) || items.find(i => i.name === x.item_name) || {};
    set('item_name', x.item_name); set('grade', x.grade); set('hsn', x.hsn || mm.hsn); set('packing_type', x.packing_type); set('rate', x.rate); set('pack_size', x.pack_size); set('bag_type', x.bag_type);
    if (x.gst_rate != null) $('[data-k=gst_rate]', tr).value = x.gst_rate;
    if (x.bag_supply) $('[data-k=packing]', tr).value = packKey(x.bag_supply, x.liner);
  };
  const showChips = () => {
    $('#pchips').innerHTML = !party ? '' : pitems.length
      ? `<span class="hint">Items of ${esc((() => { try { return party.is_online && cust ? cust.name + ' and ' + party.name : party.name; } catch { return party.name; } })())} — click to add:</span>` + pitems.map(x => `<button type="button" class="small sec" data-pi="${x.id}">${esc(x.item_name)} ${esc(x.grade || '')} · ₹${money(x.rate)}${x.pack_size ? ' · ' + kg(x.pack_size) + 'kg' : ''}${x.bag_type ? ' ' + esc(x.bag_type) : ''}${x.packing_type ? ' · ' + esc(x.packing_type) : ''}${packText(x.bag_supply, x.liner) ? ' · ' + esc(packText(x.bag_supply, x.liner)) : ''}</button>`).join('')
      : `<span class="badge amber">No items saved for this buyer</span> <span class="hint">Open Buyers → ${esc(party.name)} → add the items, rates and packing first. Invoices can only use the buyer's items.</span>`;
  };
  const renderLines = arr => { lines.innerHTML = arr.map(lineHtml).join(''); };
  const fillGrades = (tr, i) => {
    const name = $('[data-k=item_name]', tr).value.trim().toUpperCase();
    $(`#dl-grade-${i}`, tr).innerHTML = items.filter(x => x.name === name).map(x => `<option value="${esc(x.grade || '')}">`).join('');
  };

  const showFirm = () => {
    const box = $('#firmbox');
    if (!party) { box.innerHTML = 'Choose a buyer. The billing firm comes from the buyer and cannot be changed here.'; return; }
    box.innerHTML = `Billed by <span class="badge ${party.firm_code}">${FIRM_NAME[party.firm_code]}</span><br>
      <b>${esc(party.name)}</b> · ${esc(party.city || '')}, ${esc(party.state || '')} ${party.state_code ? '(' + esc(party.state_code) + ')' : ''}<br>
      ${party.gstin ? 'GSTIN ' + esc(party.gstin) + ' · B2B' : '<span class="badge amber">No GSTIN · B2C</span>'}
      ${party.email ? '<br><span class="hint">' + esc(party.email) + '</span>' : ''}`;
  };

  // ----- B2C (ledger ONLINE SALE): customer from Buyers B2C, medium of sale, courier or lorry -----
  let b2cList = [], cust = null;
  const custLabel = c => `${c.name}${c.mobile ? ' · ' + c.mobile : ''}${c.city ? ' · ' + c.city : ''}`;
  const showCust = () => {
    $('#b2cinfo').innerHTML = cust ? `<b>${esc(cust.name)}</b>${cust.mobile ? ' · ' + esc(cust.mobile) : ''}${cust.email ? ' · ' + esc(cust.email) : ''}<br>${esc([cust.address, cust.city, cust.pincode, cust.state].filter(Boolean).join(', '))}
      ${cust.state ? '' : ' <span class="badge red">state missing</span>'} <a href="#" id="b2cedit">edit</a>` : 'Choose the customer, or press + New to add one.';
    const ed = $('#b2cedit'); if (ed) ed.onclick = e => { e.preventDefault(); b2cDialog(cust, c => setCust(c, true)); };
  };
  // B2C: the chosen customer's own items and delivery addresses (Buyers B2C), with the ONLINE SALE items
  const b2cQs = () => party && party.is_online && f.b2c_id.value ? `?b2c=${f.b2c_id.value}&all=1` : '';
  const setCust = (c, reload) => {
    const changed = String(f.b2c_id.value || '') !== String(c ? c.id : '');
    cust = c; f.b2c_id.value = c ? c.id : '';
    if (changed && party && party.id && !locked) {
      if (!inv) loadAddrs(false);
      GET(`/api/parties/${party.id}/items${b2cQs()}`).then(x => { pitems = x; if (f.isConnected) showChips(); });
    }
    if (c) { $('#b2cq').value = custLabel(c); if (!locked) f.party_address.value = c.address || ''; }
    showCust(); calc(); S.dirty = true;
    if (reload) GET('/api/b2c').then(l => { b2cList = l; $('#dl-b2c').innerHTML = l.map(x => `<option value="${esc(custLabel(x))}">`).join(''); });
  };
  const sendMode = () => { const c = f.send_by.value === 'COURIER'; $$('.courier', f).forEach(x => x.hidden = !c); $('.lorrybox', f).style.display = c ? 'none' : ''; };
  const showB2c = async () => {
    const on = !!(party && party.is_online);
    $('#b2cbox').hidden = !on; $('#sendbox').hidden = !on; $('#rateh').textContent = on ? 'Rate / bag' : 'Rate / MT';
    if (!on) { f.b2c_id.value = ''; f.send_by.value = 'LORRY'; sendMode(); cust = null; return; }
    if (!b2cList.length) { b2cList = await GET('/api/b2c'); $('#dl-b2c').innerHTML = b2cList.map(x => `<option value="${esc(custLabel(x))}">`).join(''); }
    if (f.b2c_id.value && !cust) cust = b2cList.find(x => String(x.id) === String(f.b2c_id.value)) || (inv && inv.customer) || null;
    if (cust) $('#b2cq').value = custLabel(cust);
    sendMode(); showCust();
  };
  $('#b2cq').addEventListener('change', () => { const c = b2cList.find(x => custLabel(x) === $('#b2cq').value); if (c) setCust(c); });
  $('#b2cnew').onclick = () => b2cDialog(null, c => setCust(c, true));
  f.send_by.addEventListener('change', sendMode);

  const calc = () => {
    const arr = readLines();
    const custSc = party && party.is_online && cust ? (STATE_SC[String(cust.state || '').toUpperCase()] || '') : null;
    const intra = custSc != null ? (!custSc || custSc === '08') : (!party || !party.state_code || party.state_code === '08');
    let taxable = 0, tax = 0;
    $$('tr', lines).forEach((tr, i) => {
      const a = r2((+arr[i].qty || 0) * (+arr[i].rate || 0)); taxable += a; tax += r2(a * (+arr[i].gst_rate || 0) / 100);
      $('.amt', tr).textContent = money(a);
    });
    taxable = r2(taxable); tax = r2(tax);
    const raw = taxable + tax, total = Math.round(raw);
    S.invTotal = total;
    const R = S.meta.rules || { ewb_intra: 25000, ewb_inter: 25000 }, lim = intra ? R.ewb_intra : R.ewb_inter;
    const req = $('#ewbreq'); if (req) req.textContent = total > lim ? `(required above ₹${lim.toLocaleString('en-IN')})` : '';
    $$('.needbig').forEach(x => x.hidden = !(total > lim));
    const totalQty = arr.reduce((s, x) => s + (+x.qty || 0), 0);
    const fr = +(String(f.freight_note.value).replace(/,/g, '').match(/\d+(\.\d+)?/) || [0])[0];
    $('#ftotal').value = fr > 0 && totalQty > 0 ? '₹ ' + money(fr * totalQty) : '';
    $('#tot').innerHTML = `<div><span>Total quantity</span><b>${qty(totalQty)} MT</b></div><div><span>Taxable value</span><b>${money(taxable)}</b></div>
      ${intra ? `<div><span>CGST</span><b>${money(tax / 2)}</b></div><div><span>SGST</span><b>${money(tax / 2)}</b></div>` : `<div><span>IGST (other state)</span><b>${money(tax)}</b></div>`}
      <div><span>Round off</span><b>${money(total - raw)}</b></div><div class="grand"><span>Grand total</span><span>${rs(total)}</span></div>`;
  };

  // a buyer item fixed to a plant decides (and locks) the dispatch plant
  const syncPlant = () => {};      // each line has its own plant now;
  // transporter GSTIN shown under the transporter
  const showTrGst = (fill) => {
    const tr = transporters.find(x => x.name.trim().toUpperCase() === f.transporter.value.trim().toUpperCase());
    if (fill && !locked) f.transporter_gstin.value = tr && tr.gstin ? tr.gstin : '';
    $('#trgst').innerHTML = !f.transporter.value.trim() || (tr && tr.gstin) ? ''
      : `<span class="badge amber">${tr ? 'no GSTIN saved for this transporter' : 'not in the Transporters list'}</span> add it in <a href="#/masters/transporters" style="color:inherit;text-decoration:underline">Master → Logistics → Transporters</a>`;
  };;;
  // delivery addresses of the buyer; the e-way bill type follows the pincode
  let addrs = [];
  const shipInfo = () => {
    const a = addrs.find(x => x.id === Number(f.delivery_id.value));
    const regPin = String((party && party.pincode) || '');
    $('#shipinfo').innerHTML = a ? `${esc(a.address)}, ${esc(a.city || '')} - <b>${esc(a.pincode || '')}</b>, ${esc(a.state || '')}`
      + (a.pincode && a.pincode !== regPin ? ' <span class="badge amber">pincode differs from registered</span>' : '') : '';
  };
  const autoType = () => {
    const a = addrs.find(x => x.id === Number(f.delivery_id.value));
    f.trans_type.value = a && a.pincode && a.pincode !== String((party && party.pincode) || '') ? '2' : '1';
  };
  const loadAddrs = async (keep) => {
    addrs = party && party.id ? await GET(`/api/parties/${party.id}/addresses${b2cQs()}`) : [];
    if (!f.isConnected) return;
    const sel = f.delivery_id;
    sel.innerHTML = '<option value="">Same as bill-to address</option>' + addrs.map(a => `<option value="${a.id}">${esc(a.godown_name || 'DELIVERY')} — ${esc(a.city || '')} ${esc(a.pincode || '')}</option>`).join('');
    if (keep && inv && inv.delivery_id && !addrs.some(a => a.id === inv.delivery_id)) sel.add(new Option(`${inv.ship_name || 'DELIVERY'} — ${inv.ship_city || ''} ${inv.ship_pincode || ''} (removed)`, inv.delivery_id));
    if (keep) sel.value = inv && inv.delivery_id ? String(inv.delivery_id) : '';
    else { const d = addrs.find(a => a.is_default); sel.value = d ? String(d.id) : ''; }
    if (keep && inv && inv.trans_type) f.trans_type.value = String(inv.trans_type); else autoType();
    shipInfo();
  };
  f.delivery_id.addEventListener('change', () => { autoType(); shipInfo(); });
  const choose = async (p) => {
    const changed = (party && party.id) !== (p && p.id);
    party = p; showFirm(); showB2c();
    if (changed && !inv) loadAddrs(false);
    if (!inv && changed) { renderLines([{}]); calc(); syncPlant(); }   // items always come from the chosen buyer
    pitems = p && p.id ? await GET(`/api/parties/${p.id}/items${b2cQs()}`) : [];
    if (!f.isConnected) return;                       // page was left meanwhile
    if (!locked) showChips();
    if (!p) return;
    if (!inv) {
      if (!p.is_online) f.party_address.value = p.address || '';
      f.transporter.value = p.transporter || ''; showTrGst(true);      // buyer's last used transporter
      const n = await GET(`${API}/next?firm=${p.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no;
    }
    calc();
  };

  renderLines(v.items.length ? v.items : [{}]);
  showFirm(); await showB2c(); calc(); showTrGst(); syncPlant();
  if (!inv && !pro && S.b2cNew) { S.b2cNew = false; const ol = active.find(p => p.is_online); if (ol) { $('#partyq').value = label(ol); await choose(ol); renderLines([{}]); $('#b2cq').focus(); } }
  await loadAddrs(true);
  if (party && party.id && !locked) { pitems = await GET(`/api/parties/${party.id}/items${b2cQs()}`); showChips(); }
  // opened from the Orders book: buyer and items come from the order; the bags / qty are typed here
  let orderId = null;
  if (!inv && !pro && S.fromOrder) {
    const o = S.fromOrder; S.fromOrder = null; orderId = o.id;
    const p = active.find(x => x.id === o.party_id);
    if (p) {
      $('#partyq').value = label(p); await choose(p);
      if (o.b2c_id) {        // B2C order: the customer, its items and bags
        if (!b2cList.length) b2cList = await GET('/api/b2c');
        const c = b2cList.find(x => x.id === o.b2c_id); if (c) setCust(c);
        pitems = await GET(`/api/parties/${p.id}/items${b2cQs()}`); if (!locked) showChips();
      }
      const arr = o.items.map(oi => pitems.find(x => x.id === oi.party_item_id)).filter(Boolean);
      if (arr.length) { renderLines(arr.map(() => ({}))); $$('tr', lines).forEach((tr, i) => { fillLine(tr, arr[i]); const oi = o.items.find(x => x.party_item_id === arr[i].id), bg = $('[data-k=bags]', tr); if (oi && oi.bags && bg) { bg.value = oi.bags; const pk = +$('[data-k=pack_size]', tr).value; if (pk) $('[data-k=qty]', tr).value = String(Math.round(oi.bags * pk) / 1000); } const rb = $('[data-k=rate_bag]', tr); if (oi && oi.rate_bag && rb) rb.value = oi.rate_bag; }); calc(); }
      const fb = $('[data-k=bags]', lines); if (fb) fb.focus();
      toast(`From the Orders book (dispatch by ${o.dispatch_by ? dmy(o.dispatch_by) : '—'}). Type the bags.`);
    }
  }
  $('#pchips').onclick = e => {
    const b = e.target.closest('[data-pi]'); if (!b) return;
    const x = pitems.find(i => i.id === Number(b.dataset.pi));
    let arr = readLines(); const last = arr[arr.length - 1];
    if (last && (last.item_name || last.qty)) { arr.push({ gst_rate: 5 }); renderLines(arr); }
    const tr = $$('tr', lines).pop(); fillLine(tr, x);
    if (x.pack_size) { const b = +$('[data-k=bags]', tr).value; if (b) $('[data-k=qty]', tr).value = String(Math.round(b * x.pack_size) / 1000); }
    calc(); syncPlant(); S.dirty = true; $('[data-k=bags]', tr).focus();
  };
  if (locked) $$('input, select, textarea', f).forEach(x => x.disabled = true);
  else markDirty(f);

  $('#partyq').addEventListener('change', () => choose(active.find(p => label(p) === $('#partyq').value) || null));
  f.date.addEventListener('change', async () => { if (party && !inv) { const n = await GET(`${API}/next?firm=${party.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no; } });
  lines.addEventListener('input', calc);
  f.freight_note.addEventListener('input', calc);
  lines.addEventListener('change', calc);
  // driver phone: numbers used before with this lorry (latest first)
  const loadPhones = async (setLast) => {
    const no = f.lorry_no.value.trim(); if (!no) return;
    const list = await GET('/api/lorry-phones/' + encodeURIComponent(no)).catch(() => []);
    $('#dl-dph').innerHTML = list.map(x => `<option value="${esc(x)}">`).join('');
    if (setLast && list.length && !f.driver_phone.value) { f.driver_phone.value = list[0]; S.dirty = true; }
  };
  f.lorry_no.addEventListener('change', () => loadPhones(true)); if (!locked) loadPhones(false);
  f.transporter.addEventListener('change', () => showTrGst(true)); f.transporter.addEventListener('input', () => showTrGst(true));
  // quantity (MT) = bags × kg per bag ÷ 1000
  lines.addEventListener('input', e => {
    const k = e.target.dataset.k; if (k !== 'bags' && k !== 'pack_size') return;
    const tr = e.target.closest('tr');
    const b = +$('[data-k=bags]', tr).value, pk = +$('[data-k=pack_size]', tr).value;
    if (b && pk) { $('[data-k=qty]', tr).value = String(Math.round(b * pk) / 1000); calc(); }
  });
  lines.addEventListener('click', e => { if (e.target.classList.contains('del')) { const arr = readLines(); arr.splice($$('tr', lines).indexOf(e.target.closest('tr')), 1); renderLines(arr.length ? arr : [{}]); calc(); syncPlant(); S.dirty = true; } });


  const save = async () => {
    if (!party || !party.id) { toast('Choose the buyer from the list.', true); return null; }
    const noLot = readLines().findIndex(x => x.item_name && x.lot_needed && !x.lot_no);
    if (noLot >= 0) { toast(`Line ${noLot + 1}: enter the Lot No. — this buyer's item needs it.`, true); $$('[data-k=lot_no]', lines)[noLot].focus(); return null; }
    const noPlant = readLines().findIndex(x => x.item_name && !x.plant);
    if (noPlant >= 0 && $$('.needbig').some(x => !x.hidden)) { toast(`Line ${noPlant + 1}: choose the dispatch plant.`, true); return null; }
    if (!pro && inv && !confirm(`You are changing saved invoice ${inv.inv_no} (${inv.party_name}).\nThis changes a GST document. Save the changes?`)) return null;
    if (party.is_online && !pro) {
      if (!f.sale_medium.value) { toast('Choose the medium of sale (Website / Self).', true); f.sale_medium.focus(); return null; }
      if (!f.b2c_id.value) { toast('Choose the customer from Buyers B2C, or press + New.', true); $('#b2cq').focus(); return null; }
    }
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    delete body.undefined;
    if (orderId) body.order_id = orderId;
    if (inv) { delete body.inv_no; if (!pro) body.edit_password = pwOk; }
    if (pro) { delete body.inv_no; delete body.ewb_no; }
    const r = await guard(() => inv ? PUT(API + '/' + inv.id, body) : POST(API, body));
    S.dirty = false; S.unlock = null; toast(pro ? (inv ? 'Proforma saved' : 'Proforma saved and added to the Orders book') : 'Invoice saved');
    if (r.linked && r.linked.error) setTimeout(() => toast(r.linked.error, true), 1500);
    else if (r.linked && r.linked.id) setTimeout(() => toast('Parakh Marketing → Parakh Fertilizer invoice made as well'), 1500);
    return r.id;
  };
  f.onsubmit = async e => { e.preventDefault(); const nid = await save(); if (!nid) return; go((pro ? '#/proforma/' : '#/invoice/') + nid); if (inv) route(); };
  // Save & print: find the e-way bill PDF of this invoice in the e-way bill folder (or let the user choose it),
  // put its number on the invoice, save, keep the PDF with the invoice (next page of the invoice PDF) and print
  if (pro) {      // proforma: no e-way bill; Save shows the PDF preview, with print and email
    const ew = f.ewb_no && f.ewb_no.closest('label'); if (ew) ew.style.display = 'none';
    $$('.needbig').forEach(x => x.remove());
    const show = nid => window.open('/print/proforma/' + nid, '_blank');
    const sp2 = $('#saveprint'); if (sp2) sp2.onclick = async () => { const nid = await save(); if (!nid) return; show(nid); go('#/proforma/' + nid); if (inv) route(); };
    const pp = $('#pfprint'); if (pp) pp.onclick = () => window.open('/print/proforma/' + inv.id + '?print=1', '_blank');
    const pv2 = $('#pfview'); if (pv2) pv2.onclick = () => show(inv.id);
    const pe = $('#pfemail'); if (pe) pe.onclick = () => proformaEmail(inv.id);
    return;
  }
  const sp = $('#saveprint'); if (sp) sp.onclick = async () => {
    if (!party || !party.id) return toast('Choose the buyer from the list.', true);
    let ewb = null;
    if (!(inv && inv.ewb_pdf)) {
      const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
      sp.disabled = true; sp.textContent = 'Looking for the e-way bill…';
      let r; try { r = await guard(() => POST('/api/ewb-find', body)); } finally { sp.disabled = false; sp.textContent = 'Save & print'; }
      ewb = r.found ? r : await ewbDialog(r, body);
      if (ewb === null) return;
      if (ewb.found) { f.ewb_no.value = ewb.ewb_no; S.dirty = true; toast(`E-way bill ${ewb.ewb_no} found${ewb.amount_ok === false ? ' (check the amount)' : ''}`); }
    }
    const nid = await save(); if (!nid) return;
    if (ewb && ewb.found) await guard(() => POST(`/api/invoices/${nid}/ewb-attach`, { file: ewb.file, ewb_no: ewb.ewb_no }));
    await doPrint('invoice', nid);
    await printLinked(nid);
    go('#/invoice/' + nid); if (inv) route();
  };
  const ej = $('#ewbjson'); if (ej) ej.onclick = async () => {
    if (!party || !party.id) return toast('Choose the buyer first.', true);
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    const r = await guard(() => POST('/api/ewaybill-json', body));
    if (r.saved) { toast(`Saved ${r.saved} — upload it on the e-way bill portal`); return; }
    if (r.save_error) toast(r.save_error + ' — choose where to save it.', true);
    delete r.saved; delete r.save_error; await saveToDesktop('ewaybill.json', JSON.stringify(r, null, 1));
  };
  const pr = $('#print'); if (pr) pr.onclick = async () => { await doPrint('invoice', inv.id); await printLinked(inv.id); };
  const pv = $('#preview'); if (pv) pv.onclick = () => window.open('/print/invoice/' + inv.id + (inv.ewb_pdf || inv.location_url ? '?ewb=1' : ''), '_blank');   // with the e-way bill after each copy
  const tb = $('#trinvb'); if (tb) tb.onclick = () => window.open('/print/trinvoice/' + inv.id, '_blank');
  const lfb = $('#lfl'); if (lfb) lfb.onclick = () => localFreightDialog(inv);
  const lrb = $('#lrcopy'); if (lrb) { lrb.onclick = () => lrDialog(inv, n => { lrb.textContent = n ? `📎 L.R. copy (${n})` : '📎 L.R. copy'; });
    GET(`/api/invoices/${inv.id}/docs?kind=LR`).then(l => { if (l.length) lrb.textContent = `📎 L.R. copy (${l.length})`; }).catch(() => {}); }
  const en = $('#envelope'); if (en) en.onclick = () => doPrint('envelope', inv.id);
  const stk = $('#stickers'); if (stk) stk.onclick = () => stickerDialog(inv);
  const cn = $('#cancel'); if (cn) cn.onclick = async () => { if (confirm('Cancel this invoice? It stays in the list marked cancelled.')) { await guard(() => POST(`/api/invoices/${inv.id}/cancel`, { edit_password: pwOk })); S.unlock = null; toast('Invoice cancelled'); route(); } };
  const ul = $('#unlock'); if (ul) ul.onclick = async () => { const pw = await askEditPassword('edit this invoice'); if (pw == null) return; S.unlock = { id: inv.id, pw }; route(); };
  const em = $('#email'); if (em) em.onclick = () => emailDialog(inv.id);
  const et = $('#emailtr'); if (et) et.onclick = () => emailDialog(inv.id, 'transporter');
  const wi = $('#wainv'); if (wi) wi.onclick = () => waFor(inv.b2c_id ? 'B2C' : 'SALE', { id: inv.id });
}

// e-way bill PDF not found in the folder: choose it by hand, or skip (only when the invoice is below the limit)
function ewbDialog(r, body) {
  return new Promise(resolve => {
    let done = false; const finish = v => { done = true; closeModal(); resolve(v); };
    modal('E-way bill PDF', `<p>The e-way bill PDF of invoice <b>${esc(r.inv_no)}</b> (₹ ${money(r.total)}) was not found in<br><code>${esc(r.folder)}</code></p>
      <p class="hint">Download it from the e-way bill portal into this folder, or choose it here. It is checked against the seller and buyer GSTIN and the invoice number.</p>
      <input type="file" id="ewbf" accept=".pdf,application/pdf" hidden>
      <div class="row" style="margin-top:12px"><button type="button" id="ewbpick">📄 Choose the e-way bill PDF…</button>
        <button type="button" class="sec" id="ewbagain">🔄 Look again</button>
        ${r.can_skip ? `<button type="button" class="sec" id="ewbskip">Skip e-way bill (below ₹${Number(r.limit).toLocaleString('en-IN')})</button>` : `<span class="hint">Above ₹${Number(r.limit).toLocaleString('en-IN')} the e-way bill is needed.</span>`}</div>`, root => {
      $('#ewbpick', root).onclick = () => $('#ewbf', root).click();
      $('#ewbf', root).onchange = async () => {
        const file = $('#ewbf', root).files[0]; if (!file) return;
        const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(file); });
        try { finish(await POST('/api/ewb-check', { ...body, data })); } catch (e) { toast(e.message, true); }
      };
      $('#ewbagain', root).onclick = async () => { const x = await guard(() => POST('/api/ewb-find', body)); if (x.found) finish(x); else toast('Still not there.', true); };
      const sk = $('#ewbskip', root); if (sk) sk.onclick = () => finish({ skip: true });
    });
    const obs = new MutationObserver(() => { if ($('#modal').hidden) { obs.disconnect(); if (!done) resolve(null); } });
    obs.observe($('#modal'), { attributes: true, attributeFilter: ['hidden'] });
  });
}

// a Parakh Fertilizer invoice prints its Parakh Marketing → Parakh Fertilizer invoice too (2 copies)
async function printLinked(id) {
  const l = await GET(`/api/invoices/${id}/linked`).catch(() => ({}));
  if (l && l.id) { await new Promise(r => setTimeout(r, 1200)); await doPrint('invoice', l.id); }
}

// ---------- printing ----------
const PRINT_NAME = { invoice: 'Invoice', label: 'Bag stickers', envelope: 'Envelope' };
const printWhere = () => { try { return localStorage.getItem('ms_print_where') || 'window'; } catch { return 'window'; } };
async function doPrint(kind, id, extra = {}) {
  toast(`Printing ${PRINT_NAME[kind].toLowerCase()}…`);
  const r = await guard(() => POST('/api/print', { kind, id, where: printWhere() === 'main' ? 'main' : '', ...extra }));
  if (r.printed) toast(`${PRINT_NAME[kind]} sent to ${r.printer} (${r.sheets} ${r.sheets === 1 ? 'sheet' : 'sheets'}${r.both_sides ? ', e-way bill on the back' : ''})`);
  else window.open(r.url, '_blank');
}
// shrink a photo / screenshot: at most 1600 px on the long side, JPEG — keeps the L.R. copy readable and small
function shrinkPhoto(blob, maxPx = 1600, quality = 0.78) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob), img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxPx / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('This picture could not be read.')); };
    img.src = url;
  });
}
const readAsDataUrl = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('The file could not be read.')); r.readAsDataURL(f); });
// Invoice → 📎 L.R. copy: upload a photo / PDF or paste a picture (Ctrl+V); saved next to the invoice PDF and attached to the email
async function lrDialog(inv, after) {
  const show = async root => {
    const list = await GET(`/api/invoices/${inv.id}/docs?kind=LR`);
    after && after(list.length);
    $('#lremailrow', root).hidden = !list.length || !!inv.legacy;
    $('#lrlist', root).innerHTML = list.length ? list.map(d => `<div class="row" style="justify-content:space-between;border-bottom:1px solid var(--line);padding:6px 0">
        <span><b>${esc(d.name)}</b><br><span class="hint">${esc(d.where)}</span></span>
        <span style="white-space:nowrap"><button type="button" class="small sec" data-lrv="${d.id}">View</button> <button type="button" class="small sec" data-lrd="${d.id}">✕</button></span></div>`).join('')
      : '<p class="hint">No L.R. copy yet.</p>';
  };
  const send = async (root, data, name) => {
    $('#lrmsg', root).textContent = 'Saving…';
    try { await POST(`/api/invoices/${inv.id}/docs`, { kind: 'LR', data, name }); toast('L.R. copy saved'); $('#lrmsg', root).textContent = ''; await show(root); }
    catch (e) { $('#lrmsg', root).textContent = ''; toast(e.message, true); }
  };
  const take = async (root, file) => {
    if (!file) return;
    if (/^image\//.test(file.type)) { const data = await shrinkPhoto(file); return send(root, data, 'lr.jpg'); }
    if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) { if (file.size > 15e6) return toast('The PDF is too big (15 MB at most).', true); return send(root, await readAsDataUrl(file), file.name); }
    toast('Choose a photo (JPG, PNG) or a PDF.', true);
  };
  modal(`L.R. copy — invoice ${inv.inv_no}${inv.lr_no ? ' · L.R. ' + inv.lr_no : ''}`, `
    <div id="lrdrop" tabindex="0" style="border:2px dashed #9cc7d1;border-radius:10px;padding:26px;text-align:center;background:#f5fbfc;outline:none">
      <div style="font-size:30px">📋</div><b>Paste the L.R. copy here (Ctrl + V)</b><div class="hint">a photo or screenshot copied from WhatsApp, the phone or the screen</div>
      <div style="margin:10px 0 4px">or</div><button type="button" id="lrpick">⬆ Choose a file (photo or PDF)</button>
      <input type="file" id="lrfile" accept="image/*,application/pdf" hidden><div id="lrmsg" class="hint" style="margin-top:8px"></div></div>
    <p class="hint">Photos are made smaller (good for email) and saved in the invoice folder with the invoice PDF. They go with the invoice email when “L.R. copy” is ticked.</p>
    <div id="lrlist"></div>
    <div class="row" style="margin-top:12px" id="lremailrow" hidden><button type="button" class="rust" id="lremail">✉ Email the L.R. copy to the buyer</button><span class="hint">Opens the invoice email with the L.R. copy ticked.</span></div>`, root => {
    const drop = $('#lrdrop', root); setTimeout(() => drop.focus(), 50);
    $('#lrpick', root).onclick = () => $('#lrfile', root).click();
    $('#lrfile', root).onchange = e => { take(root, e.target.files[0]); e.target.value = ''; };
    const onPaste = e => { if ($('#modal').hidden) return document.removeEventListener('paste', onPaste);
      const it = [...(e.clipboardData || {}).items || []].find(x => x.kind === 'file'); if (!it) return toast('There is no picture to paste — copy the L.R. picture first.', true);
      e.preventDefault(); take(root, it.getAsFile()); };
    document.addEventListener('paste', onPaste);
    drop.ondragover = e => { e.preventDefault(); drop.style.background = '#e6f4f7'; }; drop.ondragleave = () => { drop.style.background = '#f5fbfc'; };
    drop.ondrop = e => { e.preventDefault(); drop.style.background = '#f5fbfc'; take(root, e.dataTransfer.files[0]); };
    root.addEventListener('click', async e => {
      const v = e.target.closest('[data-lrv]'), d = e.target.closest('[data-lrd]');
      if (v) { const r = await guard(() => GET('/api/invoice-docs/' + v.dataset.lrv)); const w = window.open(); if (w) w.document.write(/^data:application\/pdf/.test(r.data) ? `<iframe src="${r.data}" style="border:0;width:100%;height:100vh"></iframe>` : `<img src="${r.data}" style="max-width:100%">`); }
      if (d && confirm('Remove this L.R. copy?')) { await guard(() => DEL('/api/invoice-docs/' + d.dataset.lrd)); show(root); }
    });
    $('#lremail', root).onclick = async () => { closeModal(); await emailDialog(inv.id, 'buyer', true);
      const c = $('#mbody [data-att=lr]'); if (c && !c.disabled) c.checked = true; };
    show(root);
  });
}

function stickerDialog(inv) {
  const bags = inv.items.reduce((s, it) => s + (Number(it.bags) || 0), 0) || 1;
  modal('Bag / parcel stickers (4 × 6)', `<form id="stf"><div class="grid g3">
      <label>Total bags<input name="of" type="number" min="1" value="${bags}"></label>
      <label>Print from bag no.<input name="from" type="number" min="1" value="1"></label>
      <label>to bag no.<input name="to" type="number" min="1" value="${bags}"></label></div>
      <p class="hint">Each sticker shows "Bag No. n / ${bags}", the buyer's address, invoice and item, and your firm as sender.</p>
      <div class="row"><button type="submit">Print stickers</button><button type="button" class="sec" id="stprev">Preview</button></div></form>`, root => {
    const f = $('#stf', root);
    f.of.addEventListener('input', () => { f.to.value = f.of.value; });
    $('#stprev', root).onclick = () => window.open(`/print/label/${inv.id}?from=${f.from.value}&to=${Math.min(+f.to.value, +f.from.value + 9)}&of=${f.of.value}`, '_blank');
    f.onsubmit = e => { e.preventDefault(); const d = formData(f); closeModal(); doPrint('label', inv.id, d); };
  });
}

async function emailDialog(id, who = 'buyer', withAttach = false) {
  const d = await guard(() => GET(`/api/invoices/${id}/email?who=${who}`));
  const ao = withAttach ? await guard(() => GET(`/api/invoices/${id}/attach-options`)) : null;
  const doc = k => ao.docs.filter(x => x.kind === k);
  const att = ao ? [
    ['invoice', 'Invoice and e-way bill copy', true, true, ''],
    ['anrep', 'Analysis report' + (ao.anreps.length ? ' — ' + ao.anreps.map(r => r.name).join(', ') : ''), ao.anreps.length > 0, !!ao.dflt.anrep, ao.anreps.length ? '' : 'no report fits these items (Master → Analysis Reports)'],
    ['tds', 'Transporter TDS certificate', ao.has_pan, !!ao.dflt.tds, !ao.has_pan ? 'no PAN card of the transporter in the master' : ao.tds_sent ? 'sent to this buyer before (' + ao.tds_sent + ')' : ''],
    ['test', 'Test report', doc('TEST_REPORT').length > 0, !!ao.dflt.test, (ao.test_needed ? 'compulsory for this buyer · ' : '') + (doc('TEST_REPORT').length ? '' : 'upload it'), 'TEST_REPORT'],
    ['bank', 'Transporter bank proof', ao.has_bank, !!ao.dflt.bank, !ao.has_bank ? 'no bank proof of the transporter in the master' : !ao.dflt.bank ? 'sent to this buyer before' : ''],
    ['lr', 'L.R. copy', doc('LR').length > 0, doc('LR').length > 0, doc('LR').length ? '' : 'upload it', 'LR'],
    ao.tr_invoice ? ['trinv', 'Transporter invoice (made with the invoice)', true, true, '']
      : ['trinv', 'Transporter invoice', doc('TR_INVOICE').length > 0, doc('TR_INVOICE').length > 0, doc('TR_INVOICE').length ? '' : 'upload it — or tick “Make transporter invoice” on the invoice', 'TR_INVOICE']] : null;
  modal(who === 'transporter' ? 'Email invoice copy to transporter' : 'Email invoice to buyer', `
    ${d.ready ? '' : '<p class="badge amber">Email is not set up for this firm yet. Open Settings → Companies → Email sending first.</p>'}
    ${d.missing && d.missing.length ? `<p class="badge red">Fill in ${esc(d.missing.join(', '))} on the invoice and save it before emailing.</p>` : ''}
    ${d.no_email ? `<p class="badge amber">No email saved for ${esc(d.no_email)} — type it below, or add it in Master → Logistics → Transporters.</p>` : ''}
    <form id="emf">
      ${att ? `<div class="card" style="margin:0 0 12px;background:#f7fafb;padding:10px 14px"><b>Attach the following with email</b>
        <div class="grid g2" style="margin-top:6px">${att.map(([k, label, can, on, note, kind]) => `<div style="display:flex;gap:8px;align-items:center">
          <label style="display:flex;gap:8px;align-items:center;font-weight:500;${can ? '' : 'opacity:.55'}"><input type="checkbox" data-att="${k}" style="width:auto" ${can && on ? 'checked' : ''} ${can ? '' : 'disabled'}> ${label}</label>
          ${kind ? `<button type="button" class="small sec" data-upl="${kind}" title="Upload a PDF or photo">⬆</button>` : ''}${note ? `<span class="hint">${esc(note)}</span>` : ''}
          ${k === 'anrep' ? ao.anreps.map(r => `<a class="small sec" style="text-decoration:none;padding:2px 8px;border-radius:6px;border:1px solid var(--line)" target="_blank" href="/print/anreport/${r.id}?inv=${id}" title="${esc(r.name)}">👁 Preview</a>`).join(' ') : ''}</div>`).join('')}</div>
        <input type="file" id="attfile" accept=".pdf,image/*" hidden></div>` : ''}
      <div class="grid g2">
      ${d.templates && d.templates.length ? `<label class="span2">Email template<select id="emtpl">${d.templates.map(x => `<option value="${x.id}">${esc(x.name)}${x.is_default ? ' (default)' : ''}</option>`).join('')}</select></label>` : ''}
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text', d.html || textToHtmlC(d.text), 240)}</div>
    </div><p class="hint">The invoice PDF is attached automatically. Sent from ${esc(d.from || '')}.</p>
    <div class="row"><button type="submit" ${d.ready && !(d.missing && d.missing.length) ? '' : 'disabled'}>Send email</button></div></form>`, root => {
    $('#emf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try {
        const v = formData(e.target); delete v.emtpl; for (const k of Object.keys(v)) if (!['to', 'cc', 'subject', 'text', 'html'].includes(k)) delete v[k];
        const ts0 = $('#emtpl', root); v.template_name = ts0 ? ts0.selectedOptions[0].text.replace(' (default)', '') : 'Standard message';
        if (att) { v.attach = {}; $$('[data-att]', root).forEach(c => { v.attach[c.dataset.att] = c.checked ? 1 : 0; }); }
        const r = await POST(`/api/invoices/${id}/email`, { ...v, who }); toast('Email sent'); closeModal(); if (!withAttach) route();
      }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
    // upload a test report / L.R. copy / transporter invoice for this invoice, then reopen the box
    let upKind = null;
    $$('[data-upl]', root).forEach(b => b.onclick = () => { upKind = b.dataset.upl; $('#attfile', root).click(); });
    const af = $('#attfile', root); if (af) af.onchange = async () => {
      const file = af.files[0]; if (!file || !upKind) return;
      const img = /^image\//.test(file.type), data = img ? await shrinkPhoto(file) : await readAsDataUrl(file);
      const keep = { to: $('#emf [name=to]', root).value, cc: $('#emf [name=cc]', root).value, subject: $('#emf [name=subject]', root).value, html: $('#emf [name=html]', root).value };
      await guard(() => POST(`/api/invoices/${id}/docs`, { kind: upKind, name: img ? 'photo.jpg' : file.name, data })); toast('File added');
      await emailDialog(id, who, true);
      for (const [k, v] of Object.entries(keep)) { if (k === 'html') { richSet($('#mbody'), 'text', v); continue; } const el = $(`#emf [name=${k}]`); if (el) el.value = v; }
    };
    richInit(root);
    const ts = $('#emtpl', root); if (ts) ts.onchange = async () => { const r = await guard(() => GET(`/api/invoices/${id}/template/${ts.value}`)); richSet(root, 'text', r.html || textToHtmlC(r.text)); };
  });
}

// ---------- PAN card of a transporter (for the TDS declaration) ----------
// The picture is cropped to the card: the blank (white) border of a scan or photo is cut away.
function cropBlank(img, maxW = 1100) {
  const c = document.createElement('canvas'); const k = Math.min(1, 2000 / Math.max(img.width, img.height));
  c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
  const { data } = g.getImageData(0, 0, c.width, c.height), W = c.width, H = c.height;
  const ink = (x, y) => { const i = (y * W + x) * 4; return data[i] * .299 + data[i + 1] * .587 + data[i + 2] * .114 < 215; };
  const rows = new Array(H).fill(0), cols = new Array(W).fill(0);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (ink(x, y)) { rows[y]++; cols[x]++; }
  const minR = Math.max(2, W * 0.01), minC = Math.max(2, H * 0.01);       // ignore specks of dust
  let top = rows.findIndex(n => n > minR), bottom = H - 1 - [...rows].reverse().findIndex(n => n > minR);
  let left = cols.findIndex(n => n > minC), right = W - 1 - [...cols].reverse().findIndex(n => n > minC);
  if (top < 0 || left < 0 || bottom <= top || right <= left) { top = 0; left = 0; bottom = H - 1; right = W - 1; }
  const pad = Math.round(Math.min(W, H) * 0.01);
  top = Math.max(0, top - pad); left = Math.max(0, left - pad); bottom = Math.min(H - 1, bottom + pad); right = Math.min(W - 1, right + pad);
  const cw = right - left + 1, ch = bottom - top + 1, s = Math.min(1, maxW / cw);
  const o = document.createElement('canvas'); o.width = Math.round(cw * s); o.height = Math.round(ch * s);
  o.getContext('2d').drawImage(c, left, top, cw, ch, 0, 0, o.width, o.height);
  return o.toDataURL('image/jpeg', 0.85);
}
// signature: cut away the white paper and make it see-through, so it sits nicely on the invoice
function signatureImage(img) {
  const jpg = new Image(); const src = cropBlank(img, 700);
  const c = document.createElement('canvas');
  return new Promise(res => { jpg.onload = () => {
    c.width = jpg.width; c.height = jpg.height; const g = c.getContext('2d'); g.drawImage(jpg, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height), a = d.data;
    for (let i = 0; i < a.length; i += 4) { const l = a[i] * .299 + a[i + 1] * .587 + a[i + 2] * .114; if (l > 200) a[i + 3] = 0; else if (l > 150) a[i + 3] = Math.round(255 * (200 - l) / 50); }
    g.putImageData(d, 0, 0); res(c.toDataURL('image/png'));
  }; jpg.src = src; });
}
async function panCardBox(box, row) {
  if (!row) { box.innerHTML = '<div class="firmbox" style="margin-top:16px">Save the transporter first, then upload the PAN card, bank proof and signature here.</div>'; return; }
  const im = await GET(`/api/transporters/${row.id}/images`);
  const KINDS = [['pan-card', 'pan_card', 'PAN card', 'Attached to the TDS declaration u/s 194C(6). When a PAN card is here, the year\'s declaration is emailed to this transporter and to the buyer with the first invoice of every buyer.'],
    ['bank-proof', 'bank_proof', 'Bank proof', 'Cancelled cheque or passbook. Sent to the buyer together with the TDS declaration the first time.'],
    ['signature', 'signature', 'Signature', 'Printed on the TDS declaration. Sign on white paper and take a photo.']];
  box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>Documents of this transporter <span class="hint">— the white space is cut away by itself</span></h3>
    <div class="grid g3">${KINDS.map(([k, col, label, hint]) => `<div>
      <b>${label}</b>
      <div style="height:170px;margin:6px 0;border:1px dashed var(--line);border-radius:10px;background:#fff;display:flex;align-items:center;justify-content:center;padding:6px">
        ${im[col] ? `<img src="${im[col]}" style="max-width:100%;max-height:156px">` : `<span class="muted">No ${label.toLowerCase()} yet</span>`}</div>
      <input type="file" data-file="${k}" accept="image/*" hidden>
      <div class="row"><button type="button" class="small" data-up="${k}">${im[col] ? 'Change' : 'Upload'}</button>${im[col] ? `<button type="button" class="small sec" data-rm="${k}">Remove</button>` : ''}</div>
      <p class="hint">${hint}</p></div>`).join('')}</div></div>`;
  $$('[data-up]', box).forEach(b => b.onclick = () => $(`[data-file="${b.dataset.up}"]`, box).click());
  $$('[data-file]', box).forEach(inp => inp.onchange = async () => {
    const file = inp.files[0]; if (!file) return; const k = inp.dataset.file;
    const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('This file is not a picture.')); i.src = url; }).catch(e => { toast(e.message, true); return null; });
    if (!img) return;
    const data = k === 'signature' ? await signatureImage(img) : cropBlank(img);
    await guard(() => PUT(`/api/transporters/${row.id}/image/${k}`, { image: data }));
    toast('Saved'); panCardBox(box, row);
  });
  $$('[data-rm]', box).forEach(b => b.onclick = async () => { if (!confirm('Remove this picture?')) return; await guard(() => PUT(`/api/transporters/${row.id}/image/${b.dataset.rm}`, { image: null })); panCardBox(box, row); });
}

// ---------- masters ----------
const STATES = () => ['', ...S.meta.states];
const SPECS = {
  parties: {
    title: 'Buyer', wide: true, cols: [['name', 'Name'], ['firm_code', 'Billed by'], ['item_count', 'Items'], ['city', 'City'], ['state', 'State'], ['gstin', 'GSTIN'], ['mobile', 'Mobile'], ['email', 'Email']],
    after: (root, row, reopen) => {
      const mf = $('#mf');
      // old names: hidden (only a few buyers need it) unless already filled
      const on = $('[name=old_names]', mf).closest('label');
      if (!(row && row.old_names)) { on.style.display = 'none'; const a = document.createElement('a'); a.href = 'javascript:void 0'; a.className = 'hint span4'; a.textContent = '+ Old names on old Excel invoices';
        a.onclick = () => { on.style.display = ''; a.remove(); }; on.after(a); }
      // distance from our billing firm's pincode, when the internet is on
      const km = $('[name=km]', mf), pin = $('[name=pincode]', mf), firm = $('[name=firm_code]', mf);
      const kb = document.createElement('button'); kb.type = 'button'; kb.className = 'small sec'; kb.textContent = '↻ find km'; kb.style.marginTop = '4px'; km.after(kb);
      const findKm = async (quiet) => {
        const fm = S.meta.firms.find(x => x.code === (firm.value || 'PM')); const fp = fm && fm.pincode;
        if (!fp || !/^\d{6}$/.test(pin.value)) { if (!quiet) toast('Enter the 6-digit pincode first.', true); return; }
        kb.textContent = '…';
        try { const r = await GET(`/api/distance?from=${fp}&to=${pin.value}`); km.value = r.km; S.dirty = true; if (!quiet) toast(`${r.km} km (${r.how})`); }
        catch (e) { if (!quiet) toast(e.message, true); } finally { kb.textContent = '↻ find km'; }
      };
      kb.onclick = () => findKm(false);
      // GSTIN → name and address from the GST portal (type the captcha)
      gstFetchBox($('[name=gstin]', mf), mf);
      pin.addEventListener('input', () => { if (/^\d{6}$/.test(pin.value) && (!km.value || km.dataset.auto)) { km.dataset.auto = 1; findKm(true); } });
      // pick old invoice names that are not linked to any buyer
      GET('/api/old-buyer-names').then(list => {
        const ta = $('#mf [name=old_names]'); if (!ta || !list.length) return;
        const s = document.createElement('select'); s.style.marginTop = '4px';
        s.innerHTML = '<option value="">+ add an old name from the old invoices…</option>' + list.map(x => `<option value="${esc(x.name)}">${esc(x.name)} — ${x.n} invoices, ${dmy(x.first)} to ${dmy(x.last)}</option>`).join('');
        s.onchange = () => { if (s.value) { ta.value = [ta.value.trim(), s.value].filter(Boolean).join('\n'); S.dirty = true; } s.value = ''; };
        ta.after(s);
      }).catch(() => {});
      root.innerHTML = `${row && row.id ? '<div class="row" style="margin:10px 0"><button type="button" class="sec" id="pcomp">📇 Send company details to this buyer</button><span class="hint">GST, PAN, bank proof, MSME certificate and our vendor form by email</span></div>' : ''}<div id="paddr"></div><div id="pitems"></div>`;
      const pc = $('#pcomp', root); if (pc) pc.onclick = () => companyMail({ party: row.id });
      partyAddresses($('#paddr', root), row); partyItems($('#pitems', root), row, reopen);
    },
    lists: async () => { await loadLists(); return datalist('dl-m-tr', (await GET('/api/m/transporters')).map(t => t.name)); },
    fields: () => [
      { name: 'name', label: 'Buyer name', span: 2 }, { name: 'firm_code', label: 'Billing firm (fixed rule)', type: 'select', options: [['', '— choose —'], ['PM', 'Parakh Marketing'], ['PF', 'Parakh Fertilizer']] },
      { name: 'contact_person', label: 'Contact person', span: 2 }, { name: 'gstin', label: 'GSTIN (blank for B2C)' }, { name: 'pan', label: 'PAN' },
      { name: 'group_name', label: 'Group of companies', type: 'select', options: ['', ...lv('group_company')] },
      { name: 'address', label: 'Registered address (bill to)', type: 'textarea', span: 3 },
      { name: 'pincode', label: 'Pincode (fills city & state)' }, { name: 'city', label: 'City' }, { name: 'state', label: 'State', type: 'select', options: STATES() },
      { name: 'email', label: 'Email (more than one: put a comma between)', span: 2 }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'transporter', label: 'Transporter (last used)', list: 'dl-m-tr' }, { name: 'km', label: 'Distance km (from our firm)', type: 'number' },
      { name: 'payment_terms', label: 'Payment terms', type: 'select', options: lv('payment_terms').length ? lv('payment_terms') : ['100% ADVANCE'], def: '100% ADVANCE' },
      { name: 'test_report', label: 'Test report compulsory', type: 'select', options: ['NO', 'YES'], def: 'NO' },
      { name: 'pay_days', label: 'Payment by (days from invoice date)', type: 'select', options: [['', '— not set —'], ...Array.from({ length: 45 }, (x, i) => [String(i + 1), (i + 1) + (i ? ' days' : ' day')])] },
      { name: 'pay_reminder', label: 'Send payment reminder', type: 'select', options: ['NO', 'YES'], def: 'NO' },
      { name: 'location_url', label: 'Delivery location link (Google Maps → Share → Copy link) — QR on the back of the invoice', span: 3 },
      { name: 'print_loc', label: 'Print location QR', type: 'select', options: ['YES', 'NO'], def: 'YES' },
      { name: 'notes', label: 'Notes', span: 3 },
      { name: 'old_names', label: 'Old names on old Excel invoices (one per line) — links those invoices to this buyer', type: 'textarea', span: 4 }]
  },
  items: { title: 'Item', cols: [['name', 'Item'], ['grade', 'Grade'], ['colour', 'Colour'], ['mesh', 'Mesh'], ['form', 'Form'], ['hsn', 'HSN'], ['gst_rate', 'GST %'], ['bag_type', 'Bag type'], ['pack_size', 'Kg/bag'], ['packing_type', 'Packing'], ['rate', 'Rate']],
    fields: () => {
      const opt = k => ['', ...lv(k)];
      return [
        { name: 'name', label: 'Item name', span: 2, list: 'dl-l-product' }, { name: 'grade', label: 'Grade (fills itself)' }, { name: 'rate', label: 'Usual rate / MT', type: 'number' },
        { name: 'colour', label: 'Item colour', type: 'select', options: opt('colour') }, { name: 'mesh', label: 'Mesh size', type: 'select', options: opt('mesh') },
        { name: 'form', label: 'Item form', type: 'select', options: opt('form') },
        { name: 'hsn', label: 'HSN', type: 'select', options: ['', ...(S.lists.hsn || []).map(x => [x.value, `${x.value}${x.note ? ' — ' + x.note : ''}`])] },
        { name: 'bag_type', label: 'Bag type', type: 'select', options: opt('bag_type') }, { name: 'pack_size', label: 'Bag weight (kg)', type: 'select', options: opt('bag_weight') },
        { name: 'packing_type', label: 'Packing type', type: 'select', options: opt('packing_type') },
        { name: 'gst_rate', label: 'GST %', type: 'select', options: lv('gst_rate'), def: 5 }, { name: 'unit', label: 'Unit', type: 'select', options: lv('unit'), def: 'MT' }];
    },
    lists: async () => { await loadLists(); return datalist('dl-l-product', lv('product')); },
    after: (box, row) => {
      const f = $('#mf'); if (!f) return;
      // a value already saved but missing from a list still shows
      $$('select', f).forEach(s => { const v = row && row[s.name]; if (v != null && v !== '' && ![...s.options].some(o => o.value === String(v))) s.add(new Option(v, v, true, true)); });
      let auto = !row || !row.grade;
      f.grade.addEventListener('input', () => { auto = !f.grade.value; });
      const mk = () => {
        if (!auto) return;
        const form = f.form.value, mesh = f.mesh.value, col = f.colour.value;
        f.grade.value = mesh && (!form || form === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form || '');
      };
      ['colour', 'mesh', 'form'].forEach(n => f[n].addEventListener('change', mk));
      f.hsn.addEventListener('change', () => { const h = (S.lists.hsn || []).find(x => x.value === f.hsn.value); if (h && h.num != null) f.gst_rate.value = String(h.num); });
    } },
  transporters: { title: 'Transporter', wide: true, cols: [['name', 'Name'], ['mobile', 'Mobile'], ['district', 'District'], ['gstin', 'GSTIN'], ['pan', 'PAN'], ['proprietor', 'Proprietor'], ['has_pan_card', 'PAN card'], ['has_bank_proof', 'Bank proof']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'contact', label: 'Contact person' }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'email', label: 'Email (TDS declaration is sent here)' }, { name: 'address', label: 'Address', span: 2 }, { name: 'district', label: 'District / place' }, { name: 'state', label: 'State' }, { name: 'gstin', label: 'GSTIN' },
      { name: 'pan', label: 'PAN' }, { name: 'proprietor', label: 'Proprietor / partner (declarant; blank = contact person)' }, { name: 'bank_name', label: 'Bank' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }],
    after: (box, row) => panCardBox(box, row) },
  lorries: { title: 'Lorry', cols: [['lorry_no', 'Lorry no.'], ['owner', 'Owner'], ['pan', 'PAN'], ['mobile', 'Mobile'], ['driver_name', 'Driver'], ['upi', 'UPI'], ['tds_declaration', 'TDS dec.']],
    fields: () => [{ name: 'lorry_no', label: 'Lorry no.' }, { name: 'owner', label: 'Owner', span: 2 }, { name: 'pan', label: 'PAN' }, { name: 'mobile', label: 'Mobile' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'driver_name', label: 'Driver name' }, { name: 'driver_phone', label: 'Driver phone' }, { name: 'bank_name', label: 'Bank' }, { name: 'holder', label: 'Account holder' },
      { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi', label: 'UPI (made from account + IFSC)', span: 2 }, { name: 'tds_declaration', label: 'TDS declaration' }],
    // UPI = <account no>@<IFSC>.ifsc.npci, filled while typing (a UPI typed by hand is kept)
    after: () => {
      const f = $('#mf'); if (!f) return;
      const make = () => {
        const acc = f.bank_account.value.toUpperCase().replace(/[^A-Z0-9]/g, ''), ifsc = f.bank_ifsc.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (f.upi.value && !/\.ifsc\.npci$/i.test(f.upi.value)) return;
        f.upi.value = acc && /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc) ? `${acc}@${ifsc}.ifsc.npci` : '';
      };
      f.bank_ifsc.addEventListener('input', () => { f.bank_ifsc.value = f.bank_ifsc.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 11); make(); });
      f.bank_account.addEventListener('input', () => { f.bank_account.value = f.bank_account.value.replace(/\s/g, ''); make(); });
    } },
  suppliers: { title: 'Supplier', cols: [['name', 'Name'], ['grade', 'Grade'], ['rate', 'Rate'], ['freight_rate', 'Freight / MT'], ['type', 'Type']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'grade', label: 'Grade' }, { name: 'rate', label: 'Rate', type: 'number' }, { name: 'freight_rate', label: 'Freight per MT', type: 'number' },
      { name: 'type', label: 'Type', type: 'select', options: ['REG', 'URD'] }] },
  plants: { title: 'Plant', cols: [['name', 'Short name'], ['full_name', 'Name'], ['address', 'Address']],
    fields: () => [{ name: 'name', label: 'Short name (e.g. PPI PLANT)' }, { name: 'full_name', label: 'Name' }, { name: 'address', label: 'Address', span: 2 }] },
  firms: { title: 'Firm', noAdd: true, cols: [['code', 'Code'], ['name', 'Name'], ['gstin', 'GSTIN'], ['phone', 'Phone'], ['email', 'Email'], ['bank_name', 'Bank']],
    fields: () => [{ name: 'name', label: 'Firm name', span: 2 }, { name: 'gstin', label: 'GSTIN' }, { name: 'pan', label: 'PAN' },
      { name: 'owner_aadhaar', label: 'Owner Aadhaar no.' }, { name: 'udyam_no', label: 'Udyam (MSME) no. — UDYAM-RJ-00-0000000' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'city', label: 'City' }, { name: 'state', label: 'State' }, { name: 'state_code', label: 'State code' }, { name: 'pincode', label: 'Pincode' }, { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email' },
      { name: 'bank_name', label: 'Bank name' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi_id', label: 'UPI id' }, { name: 'terms', label: 'Terms on invoice', type: 'textarea', span: 4 }] }
};

async function masterTable(el, table, extraTools = '') {
  const sp = SPECS[table];
  el.innerHTML = `<div class="toolbar">${sp.noAdd ? '' : `<button id="add">+ Add ${sp.title.toLowerCase()}</button>`}${extraTools}
    <input type="search" id="q" placeholder="Search…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div><div class="tablewrap" id="list"></div>`;
  let rows = [], firm = '', sortK = null, sortDir = 1;
  const show = () => {
    if (sortK) rows.sort((a, b) => { const x = a[sortK] ?? '', y = b[sortK] ?? '';
      return (typeof x === 'number' || typeof y === 'number' ? (Number(x) || 0) - (Number(y) || 0) : String(x).localeCompare(String(y))) * sortDir; });
    $('#list', el).innerHTML = rows.length ? `<table class="t"><thead><tr>${sp.cols.map(c => `<th data-sort="${c[0]}" style="cursor:pointer;white-space:nowrap" title="Click to sort">${c[1]} ${sortK === c[0] ? (sortDir > 0 ? '▲' : '▼') : '<span class="muted">⇅</span>'}</th>`).join('')}</tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}" ${r.active === 0 ? 'style="opacity:.5"' : ''}>${sp.cols.map(([k]) => `<td>${k === 'firm_code' ? `<span class="badge ${r[k] || 'grey'}">${esc(FIRM_NAME[r[k]] || 'not set')}</span>` : (k === 'has_pan_card' || k === 'has_bank_proof') ? (r[k] ? '<span class="badge slate">✔ uploaded</span>' : '<span class="muted">—</span>') : k === 'item_count' ? (r[k] ? `<b style="color:#1e6b39">✔</b> ${r[k]}` : '<span class="muted">—</span>') : esc(r[k])}</td>`).join('')}</tr>`).join('')}
      </tbody></table>` : '<div class="empty">Nothing found.</div>';
  };
  const load = async () => { rows = await GET(`/api/m/${table}?q=${encodeURIComponent($('#q', el).value)}${firm ? '&firm=' + firm : ''}`); show(); };
  const edit = async (row) => {
    const lists = sp.lists ? await sp.lists() : '';
    modal((row ? 'Edit ' : 'New ') + sp.title.toLowerCase(), `${lists}<form id="mf"><div class="grid g4">${sp.fields().map(f => field(f, row ? row[f.name] : undefined)).join('')}</div>
      <div class="row" style="margin-top:16px"><button type="submit">Save</button><span class="spacer"></span>${row && !sp.noAdd ? '<button type="button" class="sec" id="mdel">Delete</button>' : ''}</div></form>
      <div id="mextra"></div>`, root => {
      hookPincode(root);
      if (sp.after) sp.after($('#mextra', root), row);
      $('#mf', root).onsubmit = async e => {
        e.preventDefault(); const d = formData(e.target);
        const r = await guard(() => row ? PUT(`/api/m/${table}/${row.id}`, d) : POST(`/api/m/${table}`, d));
        toast('Saved'); S.parties = null; S.items = null; await load();
        if (!row && table === 'parties') { const nr = await GET(`/api/m/${table}/${r.id}`); edit(nr); toast("Saved — now add this buyer's items below"); }
        else closeModal();
      };
      const del = $('#mdel', root); if (del) del.onclick = async () => {
        if (!confirm('Delete this record?')) return; const r = await guard(() => DEL(`/api/m/${table}/${row.id}`));
        toast(r.hidden ? 'Has invoices, so it was hidden instead of deleted' : 'Deleted'); closeModal(); S.parties = null; load();
      };
    });
  };
  $('#q', el).oninput = debounce(load, 300);
  const add = $('#add', el); if (add) add.onclick = () => edit(null);
  $('#list', el).onclick = e => {
    const th = e.target.closest('th[data-sort]'); if (th) { const k = th.dataset.sort; sortDir = sortK === k ? -sortDir : (k === 'item_count' ? -1 : 1); sortK = k; return show(); }
    const tr = e.target.closest('tr[data-id]'); if (tr) edit(rows.find(r => r.id === Number(tr.dataset.id))); };
  $('#csv', el).onclick = () => downloadCsv(`${table}.csv`, rows);
  $$('[data-firm]', el).forEach(b => b.onclick = () => { $$('[data-firm]', el).forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.firm; load(); });
  await load();
}

// Delivery addresses (godowns) of a buyer. Chosen on the invoice as "Deliver to".
async function partyAddresses(box, row) {
  if (!row) return;
  const load = async () => {
    const list = await GET(`/api/parties/${row.id}/addresses${row.b2c ? '?b2c=' + row.b2c : ''}`);
    const open = S.paOpen === row.id || list.length > 0;
    box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb">
      <label style="display:flex;gap:8px;align-items:center;font-weight:600;cursor:pointer"><input type="checkbox" id="pashow" style="width:auto" ${open ? 'checked' : ''} ${list.length ? 'disabled title="Remove the delivery addresses to turn this off"' : ''}>
        Delivery address different from Reg. address</label>
      <div id="pabody" ${open ? '' : 'hidden'}><h3 style="margin-top:12px">Delivery addresses (godowns) of ${esc(row.name)}
      <span class="hint">— where the goods go when it is not the registered address</span></h3>
      <table class="t"><thead><tr><th>Godown name</th><th>Address</th><th>City</th><th>Pincode</th><th>State</th><th>Contact</th><th class="num">Km</th><th></th></tr></thead><tbody>
      ${list.map(a => `<tr><td><b>${esc(a.godown_name || '—')}</b>${a.is_default ? ' <span class="badge slate">default</span>' : ''}${a.pincode && a.pincode !== String(row.pincode || '') ? ' <span class="badge amber" title="Pincode differs from the registered address — the e-way bill will be Bill To - Ship To">ship-to</span>' : ''}${!a.pincode ? ' <span class="badge amber">add pincode</span>' : ''}</td>
        <td>${esc(a.address)}</td><td>${esc(a.city)}</td><td>${esc(a.pincode)}</td><td>${esc(a.state)}</td><td>${esc([a.contact, a.phone].filter(Boolean).join(' · '))}</td><td class="num">${a.km ?? ''}</td>
        <td style="white-space:nowrap;text-align:right"><button type="button" class="small sec" data-aedit="${a.id}">Edit</button> <button type="button" class="small sec" data-adel="${a.id}">✕</button></td></tr>`).join('')
        || '<tr><td colspan="8" class="muted">No delivery address — goods go to the registered address. Add a godown below if this buyer has one.</td></tr>'}
      </tbody></table>
      <form id="paf" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px" autocomplete="off">
        <div class="grid g4">
          <label>Godown name<input name="godown_name" placeholder="e.g. KISHANGARH GODOWN"></label>
          <label class="span3">Delivery address<input name="address"></label>
          <label>Pincode <span class="hint">(fills city & state)</span><input name="pincode" inputmode="numeric" maxlength="6"></label>
          <label>City<input name="city"></label>
          <label>State<select name="state">${STATES().map(s => `<option>${esc(s)}</option>`).join('')}</select></label>
          <label>Distance km <span class="hint">(for e-way bill)</span><input name="km" type="number"></label>
          <label>Contact person<input name="contact"></label>
          <label>Phone<input name="phone" inputmode="numeric"></label>
          <label class="span2">Location link <span class="hint">(Google Maps → Share → Copy link; QR on the back of the invoice)</span><input name="location_url"></label>
          <label class="span2" style="align-self:end"><span><input type="checkbox" name="is_default" style="width:auto"> Use this address by default on new invoices</span></label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit" id="pasave">Add delivery address</button><button type="button" class="sec" id="pacancel" hidden>Cancel</button></div>
      </form></div></div>`;
    $('#pashow', box).onchange = e => { S.paOpen = e.target.checked ? row.id : null; $('#pabody', box).hidden = !e.target.checked; };
    const f = $('#paf', box); let editing = null;
    hookPincode(f);
    box.onclick = async e => {
      const ed = e.target.closest('[data-aedit]'), dl = e.target.closest('[data-adel]');
      if (ed) {
        const a = list.find(x => x.id === Number(ed.dataset.aedit)); editing = a.id;
        for (const k of ['godown_name', 'address', 'pincode', 'city', 'km', 'contact', 'phone', 'location_url']) f[k].value = a[k] ?? '';
        if (a.state && ![...f.state.options].some(o => o.value === a.state)) f.state.add(new Option(a.state, a.state));
        f.state.value = a.state || ''; f.is_default.checked = !!a.is_default;
        $('#pasave', box).textContent = 'Update delivery address'; $('#pacancel', box).hidden = false; f.godown_name.focus();
      }
      if (dl && confirm('Remove this delivery address? Old invoices keep their printed address.')) { await guard(() => DEL('/api/party-addresses/' + dl.dataset.adel)); load(); }
    };
    $('#pacancel', box).onclick = () => load();
    f.onsubmit = async e => {
      e.preventDefault(); e.stopPropagation();
      const d = formData(f);
      if (!d.address) return toast('Type the delivery address.', true);
      if (!/^\d{6}$/.test(d.pincode)) return toast('Type the 6-digit pincode of the delivery address.', true);
      await guard(() => editing ? PUT('/api/party-addresses/' + editing, d) : POST(`/api/parties/${row.id}/addresses${row.b2c ? '?b2c=' + row.b2c : ''}`, d));
      toast(editing ? 'Delivery address updated' : 'Delivery address added'); load();
    };
  };
  await load();
}

async function partyItems(box, row) {
  if (!row) { box.innerHTML = `<div class="firmbox" style="margin-top:16px">Save the buyer first, then add this buyer's items, rates and packing here.</div>`; return; }
  await loadLists(true);
  const L = S.lists;
  const sel = (name, key, label, cls = '') => `<label class="${cls}">${label}<select name="${name}"><option value=""></option>${lv(key).map(v => `<option>${esc(v)}</option>`).join('')}</select></label>`;
  const load = async () => {
    const list = await GET(`/api/parties/${row.id}/items${row.b2c ? '?b2c=' + row.b2c : ''}`);
    box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>Items, rates & packing for ${esc(row.name)}</h3>
      <table class="t"><thead><tr><th>Item</th><th>Grade</th><th>Plant</th><th>HSN</th><th>Bag</th><th>Packing</th><th class="num">${row.is_online ? "Rate / bag (B2C)" : "Rate / MT"}</th><th>Notes</th><th></th></tr></thead><tbody>
      ${list.map(x => `<tr><td><b>${esc(x.item_name)}</b></td><td>${esc(x.grade)}</td><td>${x.plant ? `<span class="badge slate">${esc(x.plant)}</span>` : '<span class="muted">any</span>'}</td><td>${esc(x.hsn)} <span class="hint">${x.gst_rate ?? ''}%</span></td>
        <td>${esc(x.bag_type)}${x.pack_size ? ` · ${kg(x.pack_size)} kg` : ''}</td>
        <td>${[esc(x.packing_type), esc(packText(x.bag_supply, x.liner))].filter(Boolean).join(' · ') || '<span class="muted">—</span>'}</td>
        <td class="num"><b>${money(x.rate)}</b>${x.commission > 0 ? ` <span class="badge grey" title="Commission ₹${x.commission} per MT${x.agent ? ' · ' + esc(x.agent) : ''} (private)">C</span>` : ''}</td><td>${x.lot_needed === 'YES' ? '<span class="badge slate">Lot no.</span> ' : ''}${esc(x.notes)}</td>
        <td style="white-space:nowrap;text-align:right"><button type="button" class="small sec" data-edit="${x.id}">Edit</button> <button type="button" class="small sec" data-dup="${x.id}" title="Copy this item into a new one">⧉ Duplicate</button> <button type="button" class="small sec" data-del="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="9" class="muted">No items yet.</td></tr>'}
      </tbody></table>
      <div class="row" style="margin-top:10px" id="piopen"><button type="button" id="pinew">+ Add new item</button></div>
      <form id="pif" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px" hidden>
        <h4 style="margin:0 0 8px" id="pititle">New item</h4>
        <div class="grid g6">
          <label>Plant <span class="hint">(fixed or blank)</span><select name="plant"><option value="">— any plant —</option>${S.meta.plants.map(pl => `<option>${esc(pl.name)}</option>`).join('')}</select></label>
          ${sel('item_name', 'product', 'Item name')}${sel('colour', 'colour', 'Item colour')}${sel('mesh', 'mesh', 'Mesh size')}${sel('form', 'form', 'Item form')}
          <label>Grade <span class="hint">(fills itself)</span><input name="grade"></label>
          <label class="span2">HSN<select name="hsn"><option value=""></option>${(L.hsn || []).map(h => `<option value="${esc(h.value)}">${esc(h.value)}${h.note ? ' — ' + esc(h.note) : ''}</option>`).join('')}</select></label>
          <label>GST %<select name="gst_rate">${lv('gst_rate').map(v => `<option ${v === '5' ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
          ${sel('bag_type', 'bag_type', 'Bag type')}${sel('pack_size', 'bag_weight', 'Bag weight (kg)')}${sel('packing_type', 'packing_type', 'Packing type')}
          <label>Bags given by<select name="bag_supply"><option value=""></option><option value="OUR">Our bags</option><option value="BUYER">Buyer's own bags</option></select></label>
          <label>Liner<select name="liner"><option value=""></option><option value="1">With liner</option><option value="0">Without liner</option></select></label>
          <label>${row.is_online ? "Rate / bag (B2C)" : "Rate / MT"}<input name="rate" type="number" step="0.01"></label>
          <label>Commission ₹ / MT <span class="hint">🔒 private</span><input name="commission" type="number" step="0.01" title="Not printed or emailed. Shown only in the Commission screen."></label>
          ${sel('agent', 'agent', 'Commission agent 🔒')}
          <label>Lot no. needed<select name="lot_needed"><option value="NO">No</option><option value="YES">Yes</option></select></label>
          <label class="span2">Notes<input name="notes"></label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit" id="pisave">Add item</button><button type="button" class="sec" id="picancel" hidden>Cancel</button>
          <span class="hint">Values come from Masters → Item lists.</span></div>
      </form></div>`;
    let editing = null, autoGrade = true;
    const f = $('#pif', box);
    const keep = (s, v) => { if (v != null && v !== '' && ![...s.options].some(o => o.value === String(v))) s.add(new Option(v, v)); s.value = v ?? ''; };
    const mkGrade = () => {
      if (!autoGrade) return;
      const form = f.form.value, mesh = f.mesh.value, col = f.colour.value;
      f.grade.value = mesh && (!form || form === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form || '');
    };
    ['colour', 'mesh', 'form'].forEach(n => f[n].addEventListener('change', mkGrade));
    f.grade.addEventListener('input', () => { autoGrade = !f.grade.value; });
    f.hsn.addEventListener('change', () => { const h = (L.hsn || []).find(x => x.value === f.hsn.value); if (h && h.num != null) f.gst_rate.value = String(h.num); });
    let dupOf = null;
    const openForm = (title) => { f.hidden = false; $('#piopen', box).hidden = true; $('#pititle', box).textContent = title; $('#picancel', box).hidden = false; };
    $('#pinew', box).onclick = () => { editing = null; dupOf = null; openForm('New item'); $('#pisave', box).textContent = 'Add item'; f.item_name.focus(); };
    box.onclick = async e => {
      const ed = e.target.closest('[data-edit]') || e.target.closest('[data-dup]'), dl = e.target.closest('[data-del]');
      if (ed) {
        const isDup = !!ed.dataset.dup;
        const x = list.find(i => i.id === Number(ed.dataset.edit || ed.dataset.dup)); editing = isDup ? null : x.id; dupOf = isDup ? x : null; autoGrade = false;
        openForm(isDup ? `New item — copy of ${x.item_name} ${x.grade || ''}` : `Edit ${x.item_name} ${x.grade || ''}`);
        f.lot_needed.value = x.lot_needed || 'NO';
        ['plant', 'item_name', 'colour', 'mesh', 'form', 'hsn', 'bag_type', 'packing_type'].forEach(k => keep(f[k], x[k]));
        keep(f.pack_size, x.pack_size != null ? String(x.pack_size) : ''); keep(f.gst_rate, x.gst_rate != null ? String(x.gst_rate) : '5');
        f.bag_supply.value = x.bag_supply || ''; f.liner.value = x.liner == null ? '' : String(x.liner);
        f.grade.value = x.grade || ''; f.rate.value = x.rate ?? ''; f.notes.value = x.notes || ''; f.commission.value = x.commission ?? ''; keep(f.agent, x.agent);
        $('#pisave', box).textContent = isDup ? 'Add as new item' : 'Update item'; f.item_name.focus();
      }
      if (dl && confirm('Remove this item from the buyer?')) { await guard(() => DEL('/api/party-items/' + dl.dataset.del)); load(); }
    };
    $('#picancel', box).onclick = () => load();
    f.onsubmit = async e => {
      e.preventDefault(); e.stopPropagation();
      const d = formData(f);
      if (!d.item_name) return toast('Choose the item name.', true);
      // a duplicate must differ from the item it was copied from (and from every other item of the buyer)
      if (!editing) {
        const same = list.find(x => ['plant', 'item_name', 'grade', 'bag_type', 'packing_type', 'bag_supply'].every(k => String(x[k] ?? '').toUpperCase() === String(d[k] ?? '').toUpperCase())
          && Number(x.pack_size || 0) === Number(d.pack_size || 0) && String(x.liner ?? '') === String(d.liner ?? ''));
        if (same) return toast('This new item has the same item, grade, plant and packing as one already there. Change something first (e.g. grade, bag or packing), or use Edit.', true);
      }
      await guard(() => editing ? PUT('/api/party-items/' + editing, d) : POST(`/api/parties/${row.id}/items${row.b2c ? '?b2c=' + row.b2c : ''}`, d));
      toast(editing ? 'Item updated' : 'Item added'); load();
    };
  };
  await load();
}

async function listsPage(box, key) {
  const lists = await loadLists(true);
  const def = LISTS.find(x => x[0] === key) || LISTS[0];
  key = def[0];
  if (key === 'plants' || key === 'fixed_expense') return specialList(box, key, def, lists);
  if (key === 'suppliers') return supplierList(box, def, lists);
  if (key === 'local_freight') return localDriverList(box, def, lists);
  if (key === 'item_group') return itemGroupList(box, def, lists);
  const rows = [...(lists[key] || [])].sort((a, b) => abc(a.value, b.value));
  const isHsn = key === 'hsn', X = LIST_EXTRA[key] || {};
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${(lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="lf" class="row" style="margin-bottom:14px">
        <label style="flex:1">${isHsn ? 'HSN code' : 'New value'}<input name="value" ${['hsn', 'bag_weight', 'gst_rate'].includes(key) ? 'inputmode="decimal"' : ''}></label>
        ${X.note ? `<label style="flex:2">${X.note}<input name="note"></label>` : ''}${X.num ? `<label style="width:170px">${X.num}<input name="num" type="number" step="0.01"></label>` : ''}
        ${X.flag ? `<label style="display:flex;gap:6px;align-items:center;align-self:end;padding-bottom:8px;white-space:nowrap"><input type="checkbox" name="flag" style="width:auto"> ⛽ ${X.flag}</label>` : ''}
        <button type="submit" id="lsave">Add</button><button type="button" class="sec" id="lcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>${isHsn ? 'HSN code' : 'Value'}</th>${X.note ? `<th>${X.note}</th>` : ''}${X.num ? `<th class="num">${X.num}</th>` : ''}${X.flag ? `<th>${X.flag}</th>` : ''}<th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>${X.note ? `<td>${esc(r.note)}</td>` : ''}${X.num ? `<td class="num">${r.num ?? ''}</td>` : ''}${X.flag ? `<td>${r.flag ? '<span class="badge amber">⛽ fuel</span>' : ''}</td>` : ''}
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#lf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f);
    await guard(() => editing ? PUT('/api/lists/' + editing, d) : POST('/api/lists', { ...d, list_key: key }));
    toast(editing ? 'Updated' : 'Added'); S.lists = null; listsPage(box, key);
  };
  $('#lcancel', box).onclick = () => listsPage(box, key);
  if (key === 'bag_type' && typeof bagListExtras === 'function') bagListExtras(box);      // bag stock settings (Factory → Bags)
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value; if (X.note) f.note.value = r.note || ''; if (X.num) f.num.value = r.num ?? ''; if (X.flag) f.flag.checked = !!r.flag;
      $('#lsave', box).textContent = 'Update'; $('#lcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Items that already use it keep it.')) { await guard(() => DEL('/api/lists/' + rm.dataset.rm)); S.lists = null; listsPage(box, key); }
  };
}

// Item lists → Plants and → Factory fixed expenses (their own tables)
// Item lists → Local freight: tempo drivers for the Local Freight Letter
async function localDriverList(box, def, lists) {
  const rows = await GET('/api/m/local_drivers');
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === 'local_freight' ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${k === 'local_freight' ? rows.length : (lists[k] || []).length || ''}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="ldf" class="row" autocomplete="off" style="margin-bottom:14px;flex-wrap:wrap">
        <label style="flex:2;min-width:200px">Name of the driver<input name="name"></label>
        <label style="flex:1;min-width:150px">Tempo number<input name="tempo_no" placeholder="RJ19GB9808"></label>
        <label style="flex:1;min-width:150px">Mobile number<input name="mobile" inputmode="numeric"></label>
        <button type="submit" id="ldsave" style="align-self:end">Add</button><button type="button" class="sec" id="ldcancel" hidden style="align-self:end">Cancel</button></form>
      <table class="t"><thead><tr><th>Driver</th><th>Tempo no.</th><th>Mobile</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.name)}</b></td><td>${esc(r.tempo_no || '')}</td><td>${esc(r.mobile || '')}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">No drivers yet — they are also added from the Local Freight Letter.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#ldf', box); let editing = null; f.name.focus();
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f); d.name = d.name.toUpperCase(); d.tempo_no = d.tempo_no.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!d.name) return toast('Enter the driver name.', true);
    await guard(() => editing ? PUT('/api/m/local_drivers/' + editing, d) : POST('/api/m/local_drivers', d));
    toast(editing ? 'Updated' : 'Added'); localDriverList(box, def, lists);
  };
  $('#ldcancel', box).onclick = () => localDriverList(box, def, lists);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; for (const k of ['name', 'tempo_no', 'mobile']) f[k].value = r[k] ?? '';
      $('#ldsave', box).textContent = 'Update'; $('#ldcancel', box).hidden = false; }
    if (rm && confirm('Remove this driver?')) { await guard(() => DEL('/api/m/local_drivers/' + rm.dataset.rm)); localDriverList(box, def, lists); }
  };
}
// Invoice → Local Freight Letter (under 200 bags): pick the tempo driver, amount → one printed letter
async function localFreightDialog(inv) {
  const d = await guard(() => GET(`/api/invoices/${inv.id}/local-freight`));
  const last = d.last || {}, label = r => `${r.name}${r.tempo_no ? ' · ' + r.tempo_no : ''}`;
  modal('Local Freight Letter', `<form id="lff" autocomplete="off">
    <p class="hint" style="margin-top:0">Invoice <b>${esc(inv.inv_no)}</b> · ${esc(inv.party_name)} · <b>${d.bags}</b> bags · to <b>${esc(d.transporter || '—')}</b></p>
    ${datalist('dl-ldrv', d.drivers.map(label))}
    <div class="grid g2">
      <label class="span2">Driver <span class="hint">(type to search; a new name is added to Master → Logistics → Local Freight)</span><input name="pick" list="dl-ldrv" value="${esc(last.driver ? label({ name: last.driver, tempo_no: last.tempo_no }) : '')}"></label>
      ${field({ name: 'driver', label: 'Name of the driver' }, last.driver || '')}
      ${field({ name: 'tempo_no', label: 'Tempo number' }, last.tempo_no || '')}
      ${field({ name: 'mobile', label: 'Mobile number' }, last.mobile || '')}
      ${field({ name: 'amount', label: 'Amount (₹)', type: 'number', step: '0.01' }, last.amount || '')}
      ${field({ name: 'from_place', label: 'From our factory at' }, d.from_place)}
      ${field({ name: 'signer', label: 'Signed by' }, d.signer)}</div>
    <div class="row" style="margin-top:12px"><button type="submit">🖨 Print letter</button><span class="hint">One copy is printed.</span></div></form>`, root => {
    const f = $('#lff', root);
    f.pick.oninput = () => { const r = d.drivers.find(x => label(x) === f.pick.value) || d.drivers.find(x => x.name === f.pick.value.toUpperCase());
      if (r) { f.driver.value = r.name; f.tempo_no.value = r.tempo_no || ''; f.mobile.value = r.mobile || ''; f.amount.focus(); }
      else f.driver.value = f.pick.value.toUpperCase(); };
    f.onsubmit = async e => {
      e.preventDefault(); const v = formData(f); delete v.pick;
      const r = await guard(() => POST(`/api/invoices/${inv.id}/local-freight`, v));
      closeModal(); window.open(`/print/localfreight/${r.id}?print=1`, '_blank');
    };
  });
}

// Item lists → Suppliers: name, IBM no., item. Used by the inward voucher and Stock IN.
async function supplierList(box, def, lists) {
  const rows = await GET('/api/m/suppliers'), raws = lists.raw_material || [], items = raws.map(x => x.value), hsns = lists.hsn || [];
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === 'suppliers' ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${k === 'suppliers' ? rows.length : (lists[k] || []).length || ''}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="spf" autocomplete="off" style="margin-bottom:14px"><div class="row" style="flex-wrap:wrap">
        <label style="flex:2;min-width:220px">Name<input name="name"></label>
        <label style="flex:1;min-width:170px">IBM no.<input name="ibm_no" placeholder="IBM/18993/2014"></label>
        <label style="flex:1;min-width:170px">GSTIN<input name="gstin" maxlength="15" placeholder="08AAFFP8488E1ZS"></label>
        <label style="flex:1.5;min-width:200px">Lessee name <span class="hint">(as on the rawana)</span><input name="lessee_name"></label>
        <label style="flex:3;min-width:300px">Address<input name="address"></label>
        <label style="width:120px">Pincode<input name="pincode" inputmode="numeric" maxlength="6"></label>
        <label style="flex:1;min-width:150px">City<input name="city"></label>
        <label style="flex:1;min-width:170px">State<select name="state"><option value=""></option>${S.meta.states.map(s => `<option>${esc(s)}</option>`).join('')}</select></label>
        <label style="width:140px">PAN<input name="pan" maxlength="10"></label>
        <label style="flex:1.5;min-width:200px">Email<input name="email" type="email"></label>
        <label style="width:150px">Mobile<input name="mobile" inputmode="numeric"></label>
        <label style="width:150px">Phone<input name="phone"></label>
        <label style="flex:1.5;min-width:200px">Raw material<select name="item"><option value="">— choose —</option>${items.map(i => `<option>${esc(i)}</option>`).join('')}</select></label>
        <label style="width:150px">HSN<select name="hsn"><option value="">—</option>${hsns.map(h => `<option value="${esc(h.value)}" title="${esc(h.note || '')}">${esc(h.value)}${h.note ? ' · ' + esc(String(h.note).slice(0, 22)) : ''}</option>`).join('')}</select></label>
        <label style="width:120px">Grade<input name="grade" list="dl-spg" placeholder="YELLOW"></label>${datalist('dl-spg', ['YELLOW', 'WHITE', 'GYPSUM', 'SM', 'B-GRADE', ...rows.map(r => r.grade)])}
        <label style="width:120px">Freight / MT<input name="freight_rate" type="number" step="0.01"></label>
        <label style="width:90px">Type<select name="type"><option>REG</option><option>URD</option></select></label>
        <button type="submit" id="spsave" style="align-self:end">Add</button><button type="button" class="sec" id="spcancel" hidden style="align-self:end">Cancel</button></div></form>
      <div class="tablewrap" style="max-height:65vh"><table class="t"><thead><tr><th>Name</th><th>Contact</th><th>IBM no.</th><th>GSTIN</th><th>Raw material</th><th>HSN</th><th>Grade</th><th class="num">Freight / MT</th><th>Type</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.name)}</b>${r.lessee_name && r.lessee_name !== r.name ? `<br><span class="hint">lessee: ${esc(r.lessee_name)}</span>` : ''}${r.city || r.state ? `<br><span class="hint">${esc([r.city, r.state].filter(Boolean).join(', '))}</span>` : ''}</td>
        <td class="hint" style="font-size:12px">${[r.mobile, r.phone].filter(Boolean).map(esc).join(', ')}${r.email ? `<br>${esc(r.email)}` : ''}</td><td>${esc(r.ibm_no || '')}</td><td>${esc(r.gstin || '')}</td><td>${r.item ? esc(r.item) : '<span class="badge amber">not set</span>'}</td><td>${esc(r.hsn || '')}</td><td>${esc(r.grade || '')}</td>
        <td class="num">${r.freight_rate ? money(r.freight_rate) : ''}</td><td>${esc(r.type || '')}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="10" class="muted">No suppliers yet.</td></tr>'}
      </tbody></table></div>
      <p class="hint">The raw material fills in by itself on the inward voucher and in Stock IN when you choose the supplier. Add raw materials in Item lists → Raw material; its HSN fills in here.</p></div></div>`;
  const f = $('#spf', box); let editing = null;
  f.name.focus();
  gstFetchBox(f.gstin, f);
  f.pincode.addEventListener('change', async () => { if (!/^\d{6}$/.test(f.pincode.value.trim())) return;
    const r = await GET('/api/pincode/' + f.pincode.value.trim()).catch(() => null); if (!r) return;
    if (r.city && !f.city.value) f.city.value = String(r.city).toUpperCase();
    if (r.state && !f.state.value) { const s = [...f.state.options].find(o => o.value.toUpperCase() === String(r.state).toUpperCase()); if (s) f.state.value = s.value; } });
  f.item.onchange = () => { const r = raws.find(x => x.value === f.item.value); if (r && r.note) { if (![...f.hsn.options].some(o => o.value === r.note)) f.hsn.insertAdjacentHTML('beforeend', `<option>${esc(r.note)}</option>`); f.hsn.value = r.note; } };
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f); d.name = d.name.toUpperCase(); d.ibm_no = d.ibm_no.toUpperCase(); d.grade = d.grade.toUpperCase(); d.gstin = d.gstin.toUpperCase().replace(/\s/g, ''); d.lessee_name = d.lessee_name.toUpperCase();
    d.city = d.city.toUpperCase(); d.pan = d.pan.toUpperCase(); d.address = d.address.toUpperCase();
    if (d.pincode && !/^\d{6}$/.test(d.pincode)) return toast('The pincode must have 6 digits.', true);
    if (d.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) return toast('The email address is not right.', true);
    if (d.gstin && !/^\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]{3}$/.test(d.gstin)) return toast('The GSTIN is not right — 15 letters and numbers, e.g. 08AAFFP8488E1ZS.', true);
    if (!d.name) return toast('Enter the supplier name.', true);
    await guard(() => editing ? PUT('/api/m/suppliers/' + editing, d) : POST('/api/m/suppliers', d));
    toast(editing ? 'Supplier updated' : 'Supplier added'); supplierList(box, def, lists);
  };
  $('#spcancel', box).onclick = () => supplierList(box, def, lists);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id;
      for (const k of ['name', 'ibm_no', 'gstin', 'lessee_name', 'grade', 'freight_rate', 'type', 'address', 'pincode', 'city', 'pan', 'email', 'mobile', 'phone']) f[k].value = r[k] ?? '';
      if (r.state && ![...f.state.options].some(o => o.value === r.state)) f.state.add(new Option(r.state, r.state)); f.state.value = r.state || '';
      if (r.item && ![...f.item.options].some(o => o.value === r.item)) f.item.insertAdjacentHTML('beforeend', `<option>${esc(r.item)}</option>`);
      if (r.hsn && ![...f.hsn.options].some(o => o.value === r.hsn)) f.hsn.insertAdjacentHTML('beforeend', `<option>${esc(r.hsn)}</option>`);
      f.hsn.value = r.hsn || ''; f.item.value = r.item || ''; $('#spsave', box).textContent = 'Update'; $('#spcancel', box).hidden = false; f.name.focus(); }
    if (rm && confirm('Remove this supplier? Old vouchers keep the name.')) { await guard(() => DEL('/api/m/suppliers/' + rm.dataset.rm)); supplierList(box, def, lists); }
  };
}

async function specialList(box, key, def, lists) {
  const isPl = key === 'plants';
  const rows = await GET(isPl ? '/api/m/plants' : '/api/factory-fixed');
  const plants = isPl ? rows : await GET('/api/m/plants');
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${k === key ? rows.length : (lists[k] || []).length || ''}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="sf" class="row" style="margin-bottom:14px" autocomplete="off">
        ${isPl ? `<label style="width:170px">Plant short name<input name="name" placeholder="e.g. PPI PLANT"></label><label style="flex:1">Name<input name="full_name"></label><label style="flex:2">Address<input name="address"></label>`
        : `<label style="width:170px">Plant<select name="plant">${plants.map(p => `<option>${esc(p.name)}</option>`).join('')}</select></label>
           <label style="flex:2">Expense name<input name="name" placeholder="e.g. ELECTRICITY, MUNSHI SALARY"></label><label style="width:180px">Amount ₹ per month<input name="amount" type="number" step="0.01"></label>`}
        <button type="submit" id="ssave">Add</button><button type="button" class="sec" id="scancel" hidden>Cancel</button></form>
      <table class="t"><thead><tr>${isPl ? '<th>Plant</th><th>Name</th><th>Address</th>' : '<th>Plant</th><th>Expense</th><th class="num">Amount / month</th>'}<th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr>${isPl ? `<td><b>${esc(r.name)}</b></td><td>${esc(r.full_name)}</td><td>${esc(r.address)}</td>` : `<td>${esc(r.plant)}</td><td><b>${esc(r.name)}</b></td><td class="num">${money(r.amount)}</td>`}
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button>${isPl ? '' : ` <button class="small sec" data-rm="${r.id}">Remove</button>`}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Nothing here yet.</td></tr>'}
      </tbody></table>
      ${isPl ? '<p class="hint">The short name is what invoices use, so it cannot be changed once the plant is in use.</p>' : '<p class="hint">These amounts are added every month to the plant in Factory Wages. A month you have saved keeps its own amounts.</p>'}</div></div>`;
  const f = $('#sf', box); let editing = null;
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f);
    await guard(() => isPl ? (editing ? PUT('/api/m/plants/' + editing, d) : POST('/api/m/plants', d)) : (editing ? PUT('/api/factory-fixed/' + editing, d) : POST('/api/factory-fixed', d)));
    toast(editing ? 'Updated' : 'Added'); if (isPl) S.meta = await GET('/api/meta'); specialList(box, key, def, lists);
  };
  $('#scancel', box).onclick = () => specialList(box, key, def, lists);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id;
      for (const k of ['name', 'full_name', 'address', 'plant', 'amount']) if (f[k]) f[k].value = r[k] ?? '';
      if (isPl) f.name.readOnly = true; $('#ssave', box).textContent = 'Update'; $('#scancel', box).hidden = false; }
    if (rm && confirm('Remove this fixed expense? Months already saved keep it.')) { await guard(() => DEL('/api/factory-fixed/' + rm.dataset.rm)); specialList(box, key, def, lists); }
  };
}

// ---------- Stock IN: all material received (P.P. Enterprise + Parakh Marketing inward vouchers + stock-in entries, always Parakh Marketing) ----------
TITLES.stock = 'Stock IN';
PAGES.stock = async (el, editId) => {
  const st = S.stk = S.stk || { fy: S.fy || S.meta.current_fy, month: '', supplier: '', item: '' };
  await loadLists();
  const [d, suppliers] = await Promise.all([GET(`/api/stock?fy=${encodeURIComponent(st.fy)}&month=${st.month}&supplier=${encodeURIComponent(st.supplier)}&item=${encodeURIComponent(st.item)}`), GET('/api/m/suppliers')]);
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  const mNo = i => String((i + 3) % 12 + 1).padStart(2, '0');          // April = 04 … March = 03
  const cur = editId ? d.entries.find(x => String(x.id) === String(editId)) : null, v = cur || { date: today() };
  const tot = list => list.reduce((s, x) => ({ n: s.n + x.lorries, r: s.r + x.rawana, a: s.a + x.actual }), { n: 0, r: 0, a: 0 });
  const from = x => [['PPE', 'P.P.E. vouchers'], ['PM', 'P.M. vouchers'], ['ST', 'Stock IN']].filter(([k]) => x[k].rawana || x[k].actual)
    .map(([k, n]) => `${n}: ${qty(x[k].rawana)} / ${qty(x[k].actual)}`).join(' · ');
  const ti = tot(d.items);
  el.innerHTML = `<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:10px">
      <label>F.Y.<select id="sfy">${fys.map(x => `<option ${x === st.fy ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
      <label>Month<select id="smo"><option value="">All months</option>${MONTHS.map((m, i) => `<option value="${mNo(i)}" ${st.month === mNo(i) ? 'selected' : ''}>${m}</option>`).join('')}</select></label>
      <label style="min-width:260px">Supplier<select id="ssu"><option value="">All suppliers</option>${d.supplier_list.map(s => `<option ${s === st.supplier ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select></label>
      <label style="min-width:220px">Raw material<select id="sit"><option value="">All raw materials</option>${d.item_list.map(s => `<option ${s === st.item ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select></label>
      <span class="spacer"></span><button class="sec" id="sxp">Export</button></div>
    <div class="grid" style="grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);align-items:start;margin-top:6px">
      <div><h3 style="margin:6px 0">Total stock in — by raw material</h3>
        <div class="tablewrap" style="max-height:46vh"><table class="t"><thead><tr><th>Raw material</th><th class="num">Lorries</th><th class="num">Rawana qty (MT)</th><th class="num">Actual qty (MT)</th></tr></thead><tbody>
        ${d.items.map(x => `<tr><td><b>${esc(x.key)}</b><br><span class="hint">${from(x)}</span></td><td class="num">${x.lorries}</td><td class="num">${qty(x.rawana)}</td><td class="num"><b>${qty(x.actual)}</b></td></tr>`).join('')
          || '<tr><td colspan="4" class="muted">Nothing received in this period.</td></tr>'}
        ${d.items.length ? `<tr class="tot"><td>Total</td><td class="num">${ti.n}</td><td class="num"><b>${qty(ti.r)}</b></td><td class="num"><b>${qty(ti.a)}</b></td></tr>` : ''}</tbody></table></div>
        <p class="hint">Counts the inward vouchers of P.P. Enterprise and Parakh Marketing and the Stock IN entries below. Hint under each item: rawana / actual from each.</p></div>
      <div><h3 style="margin:6px 0">Received from — by supplier</h3>
        <div class="tablewrap" style="max-height:46vh"><table class="t"><thead><tr><th>Supplier</th><th>Raw material</th><th class="num">Lorries</th><th class="num">Rawana qty</th><th class="num">Actual qty</th></tr></thead><tbody>
        ${d.suppliers.map(x => `<tr><td><b>${esc(x.supplier)}</b></td><td>${esc(x.item)}</td><td class="num">${x.lorries}</td><td class="num">${qty(x.rawana)}</td><td class="num">${qty(x.actual)}</td></tr>`).join('')
          || '<tr><td colspan="5" class="muted">—</td></tr>'}</tbody></table></div></div></div></div>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.8fr);align-items:start">
    <form id="sif" class="card" autocomplete="off"><h3>${cur ? 'Change stock in ' + esc(cur.st_no) : 'New stock in'} <span class="hint">— Parakh Marketing</span></h3>${cur ? '' : rawanaBox('srq')}
      <div class="grid g2">
        ${field({ name: 'st_no', label: 'Stock-in no.' }, cur ? cur.st_no : d.next_no)}
        ${field({ name: 'date', label: 'Date', type: 'date' }, v.date)}
        ${field({ name: 'supplier', label: 'Supplier', type: 'select', options: [['', '— choose —'], ...suppliers.map(s => s.name)] }, v.supplier || '')}
        ${field({ name: 'item', label: 'Raw material', type: 'select', options: [['', '— choose —'], ...lv('raw_material')] }, v.item || '')}
        ${field({ name: 'rawana_no', label: 'Rawana no.' }, v.rawana_no)}
        <span></span>
        ${field({ name: 'rawana_wt', label: 'Rawana qty (MT)', type: 'number', step: '0.001' }, v.rawana_wt)}
        ${field({ name: 'actual_wt', label: 'Actual qty (MT)', type: 'number', step: '0.001' }, v.actual_wt)}
        ${field({ name: 'freight_rate', label: 'Freight per MT (₹)', type: 'number', step: '0.01' }, v.freight_rate)}
        <label>Total freight (₹)<input id="sitot" readonly tabindex="-1"></label>
        ${field({ name: 'rate', label: 'Purchase rate per MT (₹)', type: 'number', step: '0.01' }, v.rate)}
        ${field({ name: 'amount', label: 'Purchase amount (₹, before GST — blank = rate × qty)', type: 'number', step: '0.01' }, v.amount)}
        ${field({ name: 'remarks', label: 'Remarks', span: 2 }, v.remarks)}</div>
      <p class="hint">Total freight = actual qty × freight per MT (rawana qty when there is no actual qty).</p>
      <div class="row" style="margin-top:10px"><button type="submit">${cur ? 'Save changes' : 'Add stock in'}</button>${cur ? '<button type="button" class="sec" id="sicancel">Cancel</button>' : ''}</div></form>
    <div class="card"><h3>Stock IN entries · ${esc(st.fy)} <span class="hint">${d.entries.length}</span></h3>
      <div class="tablewrap" style="max-height:52vh"><table class="t"><thead><tr><th>No.</th><th>Date</th><th>Supplier / item</th><th>Rawana no.</th><th class="num">Rawana qty</th><th class="num">Actual qty</th><th class="num">Freight / MT</th><th class="num">Total freight</th><th></th></tr></thead><tbody>
      ${d.entries.map(x => `<tr><td><b>${esc(x.st_no)}</b></td><td>${dmy(x.date)}</td><td>${esc(x.supplier || '')}<br><span class="hint">${esc(x.item || '')}</span></td><td>${esc(x.rawana_no || '')}</td>
        <td class="num">${qty(x.rawana_wt)}</td><td class="num">${qty(x.actual_wt)}</td><td class="num">${x.freight_rate ? money(x.freight_rate) : ''}</td><td class="num">${x.freight_total ? money(x.freight_total) : ''}</td>
        <td style="white-space:nowrap;text-align:right"><button class="small sec" data-sed="${x.id}">Edit</button> <button class="small sec" data-sdel="${x.id}">✕</button></td></tr>`).join('')
        || '<tr><td colspan="9" class="muted">No stock-in entries yet.</td></tr>'}</tbody></table></div></div></div>`;
  const re = () => PAGES.stock(el);
  $('#sfy').onchange = e => { S.stkKeepFocus = true; st.fy = e.target.value; st.supplier = st.item = ''; re(); };
  $('#smo').onchange = e => { S.stkKeepFocus = true; st.month = e.target.value; re(); };
  $('#ssu').onchange = e => { S.stkKeepFocus = true; st.supplier = e.target.value; re(); };
  $('#sit').onchange = e => { S.stkKeepFocus = true; st.item = e.target.value; re(); };
  $('#sxp').onclick = () => downloadCsv(`stock_in_${st.fy}.csv`, d.suppliers.map(x => ({ supplier: x.supplier, item: x.item, lorries: x.lorries, rawana_qty: x.rawana.toFixed(3), actual_qty: x.actual.toFixed(3),
    ppe_vouchers_actual: x.PPE.actual.toFixed(3), pm_vouchers_actual: x.PM.actual.toFixed(3), stock_in_actual: x.ST.actual.toFixed(3) })));
  const f = $('#sif');
  const calc = () => { const q = Number(f.actual_wt.value) || Number(f.rawana_wt.value) || 0, r = Number(f.freight_rate.value) || 0; $('#sitot').value = r ? money(Math.round(q * r * 100) / 100) : ''; };
  f.addEventListener('input', calc); calc();
  if (!cur) { const nextNo = async () => { if (f.date.value) f.st_no.value = (await GET('/api/stock-in/next?date=' + f.date.value)).st_no; }; f.date.addEventListener('change', nextNo); nextNo(); }
  f.supplier.onchange = () => { const s = suppliers.find(x => x.name === f.supplier.value); if (s) { if (s.item) f.item.value = s.item; if (!f.freight_rate.value && s.freight_rate) f.freight_rate.value = s.freight_rate; calc(); } };
  const ca = $('#sicancel'); if (ca) ca.onclick = () => go('#/stock');
  if (!cur && !S.stkKeepFocus) setTimeout(() => { const q = $('#srq'); if (q) { q.focus(); q.scrollIntoView({ block: 'center' }); } }, 50);
  S.stkKeepFocus = false;
  if (!cur) hookRawana(el, 'srq', r => { let n = 0; if (r.rawana_no) { f.rawana_no.value = r.rawana_no; n++; } if (r.rawana_wt != null) { f.rawana_wt.value = q3(r.rawana_wt); n++; }
      if (r.supplier && [...f.supplier.options].some(o => o.value === r.supplier)) { f.supplier.value = r.supplier; f.supplier.onchange(); n++; }
      if (r.item && [...f.item.options].some(o => o.value === r.item)) { f.item.value = r.item; n++; }
      calc(); return n; },
    s => { suppliers.push(s); f.supplier.insertAdjacentHTML('beforeend', `<option>${esc(s.name)}</option>`); f.supplier.value = s.name; f.supplier.onchange(); });
  f.onsubmit = async e => {
    e.preventDefault(); const b = formData(f);
    if (cur) { const pw = await askEditPassword('change this stock-in entry'); if (!pw) return; b.edit_password = pw; }
    const r = await guard(() => cur ? PUT('/api/stock-in/' + cur.id, b) : POST('/api/stock-in', b));
    toast(`${r.st_no} saved`); if (cur) go('#/stock'); else re();
  };
  el.onclick = async e => {
    const ed = e.target.closest('[data-sed]'), dl = e.target.closest('[data-sdel]');
    if (ed) go('#/stock/' + ed.dataset.sed);
    if (dl) { const x = d.entries.find(y => String(y.id) === dl.dataset.sdel); if (!confirm(`Delete stock in ${x.st_no}?`)) return;
      const pw = await askEditPassword('delete this stock-in entry'); if (!pw) return;
      await guard(() => DEL(`/api/stock-in/${x.id}?pw=${encodeURIComponent(pw)}`)); toast('Deleted'); re(); }
  };
};

// ---------- Fuel: barrels used at the factory; fuel cost per MT of the items made with fuel (from Oct 2026) ----------
TITLES.fuel = 'Fuel';
PAGES.fuel = async (el, editId) => {
  const st = S.fuel = S.fuel || { fy: S.fy || S.meta.current_fy, month: '' };
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse(), y0 = Number(st.fy.slice(0, 4));
  const months = MONTHS.map((n, i) => { const y = i < 9 ? y0 : y0 + 1, m = ((i + 3) % 12) + 1; return [`${y}-${String(m).padStart(2, '0')}`, `${n} ${y}`]; });
  const [d, df] = await Promise.all([GET(`/api/fuel?fy=${encodeURIComponent(st.fy)}&month=${st.month}`), GET('/api/fuel/defaults')]);
  const cur = editId ? d.entries.find(x => String(x.id) === String(editId)) : null, v = cur || { date: today(), ltr_per_barrel: df.ltr_per_barrel, rate: df.rate };
  const mName = m => { const x = months.find(z => z[0] === m); return x ? x[1] : m; };
  const before = d.to < d.fuel_from;
  el.innerHTML = `<div class="toolbar"><label>F.Y.<select id="ffy">${fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label>Month<select id="fmo"><option value="">Whole year</option>${months.map(([k, n]) => `<option value="${k}" ${k === st.month ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <span class="hint" style="align-self:end">Cost per MT is worked out from <b>1 October 2026</b>.</span></div>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);align-items:start">
    <div class="card"><h3>⛽ Average fuel cost of production</h3>
      ${before ? '<p class="muted">This period is before October 2026 — not worked out.</p>' : `
      ${d.fuel_forms.length ? '' : '<p class="badge amber" style="display:block;padding:8px 10px">No item form is marked “Uses fuel” yet — tick it in <a href="#/itemlists/form">Item lists → Item form</a>.</p>'}
      <div class="stats" style="grid-template-columns:repeat(2,1fr);margin:6px 0 12px">
        <div class="stat amber"><div class="k">Fuel cost per MT</div><div class="v">${d.per_mt != null ? '₹ ' + money(d.per_mt) : '—'}</div><div class="s">${d.per_litre_mt != null ? qty(d.per_litre_mt) + ' litres per MT' : ''}</div></div>
        <div class="stat"><div class="k">${esc(st.month ? mName(st.month) : st.fy)}${d.calc_from > d.from ? ' (from ' + dmy(d.calc_from) + ')' : ''}</div><div class="v">₹ ${money(d.amount)}</div><div class="s">${qty(d.litres)} litres · ${qty(d.mt)} MT made with fuel</div></div></div>
      <h4 style="margin:8px 0 4px">By month</h4>
      <table class="t"><thead><tr><th>Month</th><th class="num">Fuel ₹</th><th class="num">Litres</th><th class="num">MT</th><th class="num">₹ / MT</th></tr></thead><tbody>
      ${d.months.map(m => `<tr><td>${esc(mName(m.month))}</td><td class="num">${money(m.amount)}</td><td class="num">${qty(m.litres)}</td><td class="num">${qty(m.mt)}</td><td class="num"><b>${m.per_mt != null ? money(m.per_mt) : '—'}</b></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No fuel or dispatch yet.</td></tr>'}</tbody></table>
      <h4 style="margin:14px 0 4px">Items made with fuel <span class="hint">(${esc(d.fuel_forms.join(', ') || '—')})</span></h4>
      <div class="tablewrap" style="max-height:40vh"><table class="t"><thead><tr><th>Item</th><th>Form</th><th class="num">MT</th><th class="num">Fuel cost ₹</th></tr></thead><tbody>
      ${d.items.map(i => `<tr><td>${esc(i.item)}</td><td>${esc(i.form)}</td><td class="num">${qty(i.mt)}</td><td class="num">${i.cost != null ? money(i.cost) : '—'}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No Parakh Marketing dispatch of these items.</td></tr>'}</tbody></table></div>
      <p class="hint">Fuel cost per MT = fuel amount ÷ MT of Parakh Marketing invoices whose item form uses fuel.</p>`}</div>
    <div>
      <form id="fef" class="card" autocomplete="off"><h3>${cur ? 'Change fuel entry' : 'Add fuel'}</h3>
        <div class="grid g3">
          ${field({ name: 'date', label: 'Date', type: 'date' }, v.date)}
          ${field({ name: 'barrels', label: 'No. of barrels', type: 'number', step: '0.01' }, v.barrels)}
          ${field({ name: 'ltr_per_barrel', label: 'Litres in a barrel', type: 'number', step: '0.01' }, v.ltr_per_barrel)}
          ${field({ name: 'rate', label: 'Rate per litre (₹)', type: 'number', step: '0.01' }, v.rate)}
          <label>Litres<input id="felt" readonly tabindex="-1"></label><label>Net amount (₹)<input id="feamt" readonly tabindex="-1"></label>
          ${field({ name: 'notes', label: 'Note', span: 3 }, v.notes)}</div>
        <div class="row" style="margin-top:10px"><button type="submit">${cur ? 'Save changes' : 'Add'}</button>${cur ? '<button type="button" class="sec" id="fecancel">Cancel</button>' : ''}</div></form>
      <div class="card"><h3>Fuel entries <span class="hint">${esc(st.month ? mName(st.month) : st.fy)} · ${d.entries.length}</span></h3>
        <div class="tablewrap" style="max-height:50vh"><table class="t"><thead><tr><th>Date</th><th class="num">Barrels</th><th class="num">Ltr / barrel</th><th class="num">Rate / ltr</th><th class="num">Net amount</th><th></th></tr></thead><tbody>
        ${d.entries.map(x => `<tr><td>${dmy(x.date)}${x.date < d.fuel_from ? ' <span class="badge grey" title="Before October 2026 — not in the cost per MT">not counted</span>' : ''}${x.notes ? `<br><span class="hint">${esc(x.notes)}</span>` : ''}</td><td class="num">${x.barrels}</td><td class="num">${x.ltr_per_barrel}</td><td class="num">${money(x.rate)}</td><td class="num"><b>${money(x.amount)}</b></td>
          <td style="white-space:nowrap;text-align:right"><button class="small sec" data-fed="${x.id}">Edit</button> <button class="small sec" data-fdel="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="6" class="muted">No fuel entries.</td></tr>'}
        ${d.entries.length ? `<tr class="tot"><td>Total</td><td class="num">${r2(d.entries.reduce((s, x) => s + x.barrels, 0))}</td><td></td><td></td><td class="num"><b>${money(d.entries.reduce((s, x) => s + x.amount, 0))}</b></td><td></td></tr>` : ''}</tbody></table></div></div></div></div>`;
  $('#ffy').onchange = e => { st.fy = e.target.value; st.month = ''; PAGES.fuel(el); };
  $('#fmo').onchange = e => { st.month = e.target.value; PAGES.fuel(el); };
  const f = $('#fef');
  const calc = () => { const l = (+f.barrels.value || 0) * (+f.ltr_per_barrel.value || 0); $('#felt').value = l ? qty(l) : ''; $('#feamt').value = l && +f.rate.value ? money(r2(l * +f.rate.value)) : ''; };
  f.addEventListener('input', calc); calc();
  const ca = $('#fecancel'); if (ca) ca.onclick = () => go('#/fuel');
  f.onsubmit = async e => {
    e.preventDefault(); const b = formData(f);
    if (cur) { const pw = await askEditPassword('change this fuel entry'); if (!pw) return; b.edit_password = pw; }
    await guard(() => cur ? PUT('/api/fuel/' + cur.id, b) : POST('/api/fuel', b)); toast('Fuel saved'); cur ? go('#/fuel') : PAGES.fuel(el);
  };
  el.onclick = async e => {
    const ed = e.target.closest('[data-fed]'), dl = e.target.closest('[data-fdel]');
    if (ed) go('#/fuel/' + ed.dataset.fed);
    if (dl && confirm('Delete this fuel entry?')) { const pw = await askEditPassword('delete this fuel entry'); if (!pw) return;
      await guard(() => DEL(`/api/fuel/${dl.dataset.fdel}?pw=${encodeURIComponent(pw)}`)); toast('Deleted'); PAGES.fuel(el); }
  };
};

// ---------- Factory wages: Parakh Marketing invoices only ----------
TITLES.wages = 'Factory Wages';
const MONTHS = ['April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March'];
PAGES.wages = async (el) => {
  const st = S.wg = S.wg || {};
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  st.fy = st.fy || S.fy || S.meta.current_fy;
  const y0 = Number(st.fy.slice(0, 4));
  const months = MONTHS.map((n, i) => { const y = i < 9 ? y0 : y0 + 1, m = ((i + 3) % 12) + 1; return [`${y}-${String(m).padStart(2, '0')}`, `${n} ${y}`]; });
  if (!st.month || !months.some(m => m[0] === st.month)) { const now = new Date().toISOString().slice(0, 7); st.month = months.some(m => m[0] === now) ? now : months[0][0]; }
  const d = await guard(() => GET('/api/wages?month=' + st.month));
  const rows = [];   // editable expense rows of both plants
  d.plants.forEach(p => { p.fixed.forEach(x => rows.push({ ...x, plant: p.plant, kind: 'FIXED' })); p.extra.forEach(x => rows.push({ ...x, plant: p.plant, kind: 'EXTRA' })); });
  const plantNames = d.plants.map(p => p.plant);
  const render = () => {
    const tot = p => {
      const mine = rows.filter(r => r.plant === p.plant);
      const fx = mine.filter(r => r.kind === 'FIXED').reduce((s, r) => s + (+r.amount || 0), 0), ex = mine.filter(r => r.kind === 'EXTRA').reduce((s, r) => s + (+r.amount || 0), 0);
      return { fx: r2(fx), ex: r2(ex), all: r2(p.wages + fx + ex) };
    };
    const rowHtml = (r, i) => `<tr data-i="${i}"><td>${r.kind === 'FIXED' ? '<span class="badge slate">fixed</span>' : ''}<input data-k="description" value="${esc(r.description || '')}" style="min-width:150px"></td>
      <td><input data-k="qty" type="number" step="0.001" value="${q3(r.qty)}" style="width:80px"></td><td><input data-k="rate" type="number" step="0.01" value="${r.rate ?? ''}" style="width:90px"></td>
      <td><input data-k="amount" type="number" step="0.01" value="${r.amount ?? ''}" style="width:110px"></td><td><button type="button" class="small sec" data-del="${i}">✕</button></td></tr>`;
    el.innerHTML = `
    <div class="toolbar"><label>F.Y.<select id="wfy">${fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label>Month<select id="wmo">${months.map(([v, t]) => `<option value="${v}" ${v === st.month ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <span class="hint" style="align-self:end">Only <b>Parakh Marketing</b> invoices · ${d.saved ? 'saved' + (d.saved_at ? ' ' + esc(d.saved_at) : '') : '<b>not saved yet</b>'}</span>
      <span class="spacer"></span><button class="sec" id="wold">📂 Saved vouchers</button><button class="sec" id="wexp">Export</button>
      <button class="sec" id="wprint" ${d.saved ? '' : 'disabled title="Save the month first"'}>🖨 Print voucher</button><button id="wsave">💾 Save</button></div>
    ${d.forms_without_rate.length ? `<div class="firmbox" style="margin-bottom:12px">No wage rate yet for: <b>${d.forms_without_rate.map(esc).join(', ')}</b> — set it in <a href="#/itemlists/form">Item lists → Item form</a>.</div>` : ''}
    ${d.no_plant_qty ? `<div class="firmbox" style="margin-bottom:12px">${qty(d.no_plant_qty)} MT of Parakh Marketing invoices in this month have no dispatch plant and are not counted.</div>` : ''}
    <div class="grid g2" style="align-items:start">${d.plants.map(p => { const t = tot(p); return `<div class="card"><h3>${esc(p.plant)} <span class="hint">${esc(p.full_name || '')}</span></h3>
      <table class="t"><thead><tr><th>Grade</th><th>Form</th><th class="num">Dispatched MT</th><th class="num">Wages / MT</th><th class="num">Amount</th></tr></thead><tbody>
      ${p.dispatch.map(g => `<tr><td><b>${esc(g.grade)}</b></td><td>${esc(g.form)}</td><td class="num">${qty(g.qty)}</td><td class="num">${g.rate ? money(g.rate) : '<span class="badge amber">no rate</span>'}</td><td class="num">${money(g.amount)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">No dispatch in this month.</td></tr>'}
      <tr class="tot"><td colspan="2">Total dispatch & wages</td><td class="num"><b>${qty(p.qty)}</b></td><td></td><td class="num"><b>${money(p.wages)}</b></td></tr></tbody></table>
      <h4 style="margin:14px 0 6px">Fixed & other expenses</h4>
      <table class="t wrows" data-plant="${esc(p.plant)}"><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th><th></th></tr></thead><tbody>
      ${rows.map((r, i) => r.plant === p.plant ? rowHtml(r, i) : '').join('') || '<tr><td colspan="5" class="muted">No expenses.</td></tr>'}</tbody></table>
      <div class="totals" style="margin-top:10px"><div><span>Wages on dispatch</span><b>₹ ${money(p.wages)}</b></div><div><span>Fixed expenses</span><b>₹ ${money(t.fx)}</b></div>
        <div><span>Other expenses</span><b>₹ ${money(t.ex)}</b></div><div class="grand"><span>Total ${esc(p.plant)}</span><b>₹ ${money(t.all)}</b></div></div></div>`; }).join('')}</div>
    <div class="card"><h3>Add expense</h3><form id="wadd" class="row" autocomplete="off">
      <label>Plant<select name="plant">${plantNames.map(n => `<option>${esc(n)}</option>`).join('')}</select></label>
      <label style="flex:2">Description<input name="description"></label><label>Qty<input name="qty" type="number" step="0.001"></label>
      <label>Rate<input name="rate" type="number" step="0.01"></label><label>Amount<input name="amount" type="number" step="0.01"></label>
      <button type="submit">Add</button></form><p class="hint">Qty × rate fills the amount. Press <b>💾 Save</b> to keep the expenses of this month. Dispatch always comes from the invoices and cannot be changed here.</p></div>
    <div class="card" style="text-align:center"><span class="hint">Both plants — ${esc(months.find(m => m[0] === st.month)[1])}</span>
      <div style="font-size:24px;font-weight:800">₹ ${money(d.plants.reduce((s, p) => s + tot(p).all, 0))}</div>
      <span class="hint">${qty(d.plants.reduce((s, p) => s + p.qty, 0))} MT dispatched</span></div>`;
    $('#wfy').onchange = () => { if (S.dirty && !confirm('Leave without saving?')) return; st.fy = $('#wfy').value; st.month = null; S.dirty = false; PAGES.wages(el); };
    $('#wmo').onchange = () => { if (S.dirty && !confirm('Leave without saving?')) return; st.month = $('#wmo').value; S.dirty = false; PAGES.wages(el); };
    $('#wsave').onclick = async () => { await guard(() => PUT('/api/wages', { month: st.month, rows })); S.dirty = false; toast('Saved — you can print the voucher now'); PAGES.wages(el); };
    $('#wprint').onclick = () => { if (S.dirty) return toast('Press 💾 Save first — the voucher prints what is saved.', true); window.open('/print/wages/' + st.month, '_blank'); };
    $('#wold').onclick = () => wagesSaved(m => { if (S.dirty && !confirm('Leave without saving?')) return; S.dirty = false; st.month = m;
      const y = Number(m.slice(0, 4)), mm = Number(m.slice(5)); st.fy = mm >= 4 ? `${y}-${String(y + 1).slice(2)}` : `${y - 1}-${String(y).slice(2)}`; PAGES.wages(el); });
    $('#wexp').onclick = () => downloadCsv(`factory_wages_${st.month}.csv`, [
      ...d.plants.flatMap(p => p.dispatch.map(g => ({ plant: p.plant, type: 'DISPATCH', description: g.grade + ' (' + g.form + ')', qty: g.qty, rate: g.rate, amount: g.amount }))),
      ...rows.map(r => ({ plant: r.plant, type: r.kind, description: r.description, qty: r.qty, rate: r.rate, amount: r.amount }))]);
    const fa = $('#wadd');
    const fill = () => { if (fa.qty.value && fa.rate.value) fa.amount.value = r2(+fa.qty.value * +fa.rate.value); };
    fa.qty.oninput = fill; fa.rate.oninput = fill;
    fa.onsubmit = e => { e.preventDefault(); const v = formData(fa); if (!v.description) return toast('Enter the description.', true);
      if (!v.amount && v.qty && v.rate) v.amount = r2(+v.qty * +v.rate); if (!(+v.amount)) return toast('Enter the amount (or qty and rate).', true);
      rows.push({ ...v, kind: 'EXTRA' }); S.dirty = true; render(); };
  };
  render();
  el.oninput = e => {
    const tr = e.target.closest('.wrows tr[data-i]'); if (!tr) return;
    const r = rows[+tr.dataset.i], k = e.target.dataset.k; r[k] = e.target.value; S.dirty = true;
    if ((k === 'qty' || k === 'rate') && r.qty !== '' && r.qty != null && r.rate !== '' && r.rate != null) { r.amount = r2(+r.qty * +r.rate); $('[data-k=amount]', tr).value = r.amount; }
    if (k === 'amount') r.amount_typed = 1;
  };
  el.onchange = e => { if (e.target.closest('.wrows')) render(); };
  el.onclick = e => { const b = e.target.closest('[data-del]'); if (b) { rows.splice(+b.dataset.del, 1); S.dirty = true; render(); } };
};

// every saved Factory wages month (its voucher): open or print
async function wagesSaved(open) {
  const list = await guard(() => GET('/api/wages/saved'));
  const mName = m => new Date(Number(m.slice(0, 4)), Number(m.slice(5)) - 1, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  modal('Saved factory wages vouchers', `<div class="tablewrap" style="max-height:65vh"><table class="t"><thead><tr><th>Month</th>${(list[0] ? list[0].plants : []).map(p => `<th class="num">${esc(p.plant)}</th>`).join('')}<th class="num">Total ₹</th><th class="num">MT</th><th>Saved on</th><th></th></tr></thead><tbody>
    ${list.map(r => `<tr><td><b>${esc(mName(r.month))}</b></td>${r.plants.map(p => `<td class="num">${money(p.total)}</td>`).join('')}<td class="num"><b>${money(r.total)}</b></td><td class="num">${qty(r.qty)}</td><td class="hint">${esc(r.saved_at || '')}</td>
      <td style="white-space:nowrap;text-align:right"><button class="small sec" data-wopen="${r.month}">Open</button> <button class="small" data-wpr="${r.month}">🖨 Print</button></td></tr>`).join('')
      || '<tr><td colspan="6" class="muted">No month saved yet. Open a month in Factory Wages and press 💾 Save.</td></tr>'}</tbody></table></div>`, root => {
    root.onclick = e => { const o = e.target.closest('[data-wopen]'), pr = e.target.closest('[data-wpr]');
      if (o) { closeModal(); open(o.dataset.wopen); } if (pr) window.open('/print/wages/' + pr.dataset.wpr, '_blank'); };
  });
}

// Master menu pages that use the list screens without the Item list side bar
const LIST_DEF = { suppliers: ['suppliers', 'Suppliers', 'Who sends us material — IBM no., GSTIN, raw material (inward vouchers, Stock IN)'],
  local_freight: ['local_freight', 'Local freight', 'Tempo drivers — name, tempo no., mobile (Local Freight Letter)'],
  fixed_expense: ['fixed_expense', 'Factory fixed expenses', 'Monthly fixed expenses of each plant (Factory wages)'] };
const barePage = fn => async el => { el.innerHTML = '<div class="barelist" id="blst"></div>'; const lists = await loadLists(true); return fn($('#blst'), lists); };
TITLES.suppliers = 'Suppliers'; TITLES.localfreight = 'Local Freight'; TITLES.fixedexp = 'Factory Fixed Expenses';
PAGES.suppliers = barePage((box, lists) => supplierList(box, LIST_DEF.suppliers, lists));
PAGES.localfreight = barePage((box, lists) => localDriverList(box, LIST_DEF.local_freight, lists));
PAGES.fixedexp = barePage((box, lists) => specialList(box, 'fixed_expense', LIST_DEF.fixed_expense, lists));

// ---------- Master → Logistics → Postage & Couriers: courier name, website and tracking link ----------
TITLES.couriers = 'Postage & Couriers';
PAGES.couriers = async (el, editId) => {
  const { couriers, general } = await GET('/api/couriers');
  const cur = couriers.find(c => String(c.id) === String(editId)) || null;
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.5fr);align-items:start">
    <form id="cf" class="card" autocomplete="off"><h3>${cur ? 'Edit courier' : 'Add a courier'}</h3>
      <label>Courier company name<input name="name" value="${esc(cur ? cur.name : '')}" placeholder="e.g. BLUE DART"></label>
      <label style="margin-top:8px">Website address<input name="website" value="${esc(cur ? cur.website || '' : '')}" placeholder="e.g. www.bluedart.com"></label>
      <div class="row" style="margin-top:8px"><button type="button" class="sec" id="cfind">🔍 Find the tracking link on the website</button></div>
      <p class="hint" id="cfmsg" style="margin:6px 0 0"></p>
      <label style="margin-top:8px">Tracking link<input name="tracking_url" value="${esc(cur ? cur.tracking_url || '' : '')}" placeholder="https://…{tracking_no}…"></label>
      <p class="hint" style="margin:4px 0 0">Put <b>{tracking_no}</b> where the number goes — the software fills in the tracking number. Left blank: the general link is used (${esc(general)}).</p>
      <div class="row" style="margin-top:8px;gap:6px"><input id="ctno" placeholder="A tracking number to test" style="max-width:220px"><button type="button" class="sec small" id="ctest">Open the link</button></div>
      <div class="row" style="margin-top:12px"><button type="submit">${cur ? 'Save changes' : 'Add courier'}</button>${cur ? '<button type="button" class="sec" id="cnew">+ New courier</button>' : ''}</div>
      <p class="hint">The couriers here are the “Sent by” list of Marketing dispatches. The tracking link goes in the sample dispatch email ({Tracking link}) and the WhatsApp messages.</p></form>
    <div class="card"><h3>Couriers · ${couriers.length}</h3><table class="t"><thead><tr><th>Courier</th><th>Website</th><th>Tracking link</th><th></th></tr></thead><tbody>
      ${couriers.map(c => `<tr><td><b>${esc(c.name)}</b></td><td>${c.website ? `<a href="${esc(c.website)}" target="_blank" rel="noopener">${esc(c.website.replace(/^https?:\/\//, ''))}</a>` : ''}</td>
        <td style="word-break:break-all;font-size:12px">${c.tracking_url ? esc(c.tracking_url) : '<span class="hint">general link</span>'}</td>
        <td style="white-space:nowrap"><button class="small sec" data-ced="${c.id}">Edit</button> <button class="small sec" data-cdel="${c.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">No couriers yet.</td></tr>'}</tbody></table></div></div>`;
  const f = $('#cf', el), msg = $('#cfmsg', el);
  $('#cfind', el).onclick = async e => {
    const b = e.target; b.disabled = true; b.textContent = 'Looking on the website…'; msg.textContent = '';
    try { const r = await POST('/api/couriers/find-link', { website: f.website.value });
      msg.innerHTML = (r.found ? '✅ ' : '⚠ ') + esc(r.message); if (r.found) f.tracking_url.value = r.tracking_url; else if (!f.tracking_url.value) f.tracking_url.value = ''; }
    catch (err) { msg.textContent = '⚠ ' + err.message; }
    b.disabled = false; b.textContent = '🔍 Find the tracking link on the website';
  };
  $('#ctest', el).onclick = () => { const n = $('#ctno', el).value.trim(), u = f.tracking_url.value.trim() || general;
    if (!n) return toast('Type a tracking number to test.', true); window.open(u.split('{tracking_no}').join(encodeURIComponent(n)), '_blank'); };
  f.onsubmit = async e => { e.preventDefault(); const d = formData(f);
    await guard(() => cur ? PUT('/api/couriers/' + cur.id, d) : POST('/api/couriers', d)); toast('Courier saved'); PAGES.couriers(el); };
  const nw = $('#cnew', el); if (nw) nw.onclick = () => PAGES.couriers(el);
  el.onclick = async e => {
    const ed = e.target.closest('[data-ced]'), dl = e.target.closest('[data-cdel]');
    if (ed) PAGES.couriers(el, ed.dataset.ced);
    if (dl && confirm('Remove this courier from the list? Old dispatches keep their courier name.')) { await guard(() => DEL('/api/couriers/' + dl.dataset.cdel)); toast('Courier removed'); PAGES.couriers(el); }
  };
};

PAGES.itemlists = async (el, key) => { await loadLists(true); return listsPage(el, key || 'product'); };

PAGES.buyers = el => masterTable(el, 'parties', `<div class="tabs"><button data-firm="" class="on">All</button><button data-firm="PM">Parakh Marketing</button><button data-firm="PF">Parakh Fertilizer</button><button data-firm="NONE">Firm not set</button></div>`);
PAGES.masters = async (el, tab) => {
  tab = tab || 'lorries';
  if (tab.startsWith('lists')) return go('#/itemlists/' + (tab.split(':')[1] || ''));
  if (tab === 'suppliers') return go('#/suppliers');
  if (tab === 'plants') return go('#/itemlists/plants');
  const tabs = [['lorries', 'Lorries & owners'], ['transporters', 'Transporters']];
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px">${tabs.map(([k, t]) => `<button class="${k === tab.split(':')[0] ? 'on' : ''}" onclick="go('#/masters/${k}')">${t}</button>`).join('')}</div><div id="mt"></div>`;
  await loadLists(true);
  await masterTable($('#mt'), tab);
};

// ---------- reports ----------
PAGES.reports = async (el, tab) => {
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px"><button class="${!tab ? 'on' : ''}" onclick="go('#/reports')">Sales & inward</button>
    <button class="${tab === 'tds' ? 'on' : ''}" onclick="go('#/reports/tds')">Transporter TDS</button>
    <button class="${tab === 'payments' ? 'on' : ''}" onclick="go('#/reports/payments')">Payment reminder</button>
    <button class="${tab === 'emails' ? 'on' : ''}" onclick="go('#/reports/emails')">Email log</button></div><div id="rp"></div>`;
  if (tab === 'payments') return paymentReport($('#rp'));
  if (tab === 'tds') return tdsReport($('#rp'));
  if (tab === 'emails') return emailLog($('#rp'));
  return salesReport($('#rp'));
};

// ---------- Reports → Payment reminder: PM and PF invoices; click Due → Received, double-click Received → Due ----------
async function paymentReport(el) {
  const st = S.pay = S.pay || { fy: S.fy || S.meta.current_fy, buyer: '', show: '', firm: '' };
  const d = await GET('/api/payments?fy=' + encodeURIComponent(st.fy));
  const rows0 = d.rows; d.rows = rows0.filter(r => !st.firm || r.firm_code === st.firm);
  const fys = [...new Set([S.meta.current_fy, ...d.fys])].sort().reverse();
  let buyers = [];
  const firmName = c => (S.meta.firms.find(f => f.code === c) || {}).name || c;
  const money = n => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const sel = new Set();
  const draw = () => {
    buyers = [...new Map(d.rows.map(r => [r.buyer_key, r.party_name])).entries()].sort((a, b) => String(a[1]).localeCompare(String(b[1])));
    if (st.buyer && !buyers.some(b => b[0] === st.buyer)) st.buyer = '';
    const list = d.rows.filter(r => (!st.buyer || r.buyer_key === st.buyer) && (!st.show || (st.show === 'due' ? !r.paid : r.paid)));
    const due = list.filter(r => !r.paid), rec = list.filter(r => r.paid), sum = a => a.reduce((s, r) => s + (Number(r.total) || 0), 0);
    const pick = !!st.buyer, tw = el.querySelector('.tablewrap'), scroll = tw ? tw.scrollTop : 0;
    el.innerHTML = `<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:10px">
        <div class="tabs" style="align-self:end">${[['', 'Both'], ['PM', 'PM'], ['PF', 'PF']].map(([k, n]) => `<button type="button" class="${st.firm === k ? 'on' : ''}" data-firm="${k}" title="${k ? esc(firmName(k)) : 'Parakh Marketing and Parakh Fertilizer'}">${n}</button>`).join('')}</div>
        <label>F.Y.<select id="pfy">${fys.map(x => `<option ${x === st.fy ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
        <label style="min-width:320px">Buyer<select id="pby"><option value="">— all buyers (${buyers.length}) —</option>${buyers.map(([k, n]) => `<option value="${esc(k)}" ${k === st.buyer ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
        <label>Show<select id="psh"><option value="">All</option><option value="due" ${st.show === 'due' ? 'selected' : ''}>Due only</option><option value="rec" ${st.show === 'rec' ? 'selected' : ''}>Received only</option></select></label>
        <span class="spacer"></span><button class="sec" id="pxp">Export</button></div>
      <div class="tablewrap" style="max-height:62vh"><table class="t"><thead><tr>${pick ? '<th style="width:30px"><input type="checkbox" id="pall" style="width:auto" title="Select all due"></th>' : ''}
        <th>Seller</th><th>Date</th><th>Invoice no.</th>${pick ? '' : '<th>Buyer</th>'}<th class="num">Qty (MT)</th><th class="num">Amount (₹)</th><th>Payment status</th><th></th></tr></thead><tbody>
      ${list.map(r => `<tr data-id="${r.id}"${sel.has(r.id) ? ' style="background:#eef6ff"' : ''}>${pick ? `<td><input type="checkbox" data-sel="${r.id}" style="width:auto" ${sel.has(r.id) ? 'checked' : ''}></td>` : ''}
        <td>${r.firm_code === 'PF' ? 'PF' : 'PM'}</td><td>${dmy(r.date)}</td><td><b>${r.inv_no}</b></td>${pick ? '' : `<td>${esc(r.party_name)}</td>`}
        <td class="num">${qty(r.qty)}</td><td class="num">${money(r.total)}</td>
        <td>${r.paid ? `Received${r.paid_at ? ' <span class="hint">' + dmy(r.paid_at) + '</span>' : ''}` : `Due <span class="hint">${r.date ? Math.max(0, Math.round((Date.now() - new Date(r.date)) / 864e5)) + ' days' : ''}</span>`}
          ${r.reminder_at ? `<br><span class="hint">reminder sent ${esc(r.reminder_at)}</span>` : ''}</td>
        <td><button class="small ${r.paid ? 'sec' : ''}" data-pay="${r.id}" style="min-width:86px;${r.paid ? 'background:#e7f6ec;color:#146c2e;border-color:#9bd3ae' : 'background:#fdecec;color:#b42318;border-color:#f3b4b4'}"
          title="${r.paid ? 'Double-click to mark it Due again' : 'Click when the payment is received'}">${r.paid ? '✔ Received' : 'Due'}</button></td></tr>`).join('')
        || `<tr><td colspan="9" class="muted">No Parakh Marketing or Parakh Fertilizer invoices in ${esc(st.fy)}.</td></tr>`}
      </tbody></table></div>
      <div class="row" style="justify-content:space-between;margin-top:12px;flex-wrap:wrap;gap:10px">
        <span>Invoices <b>${list.length}</b> · Due <b style="color:#b42318">₹${money(sum(due))}</b> (${due.length}) · Received <b style="color:#146c2e">₹${money(sum(rec))}</b> (${rec.length})</span>
        ${pick ? `<span class="row" style="gap:10px"><span class="hint" id="pcount">${sel.size ? `${sel.size} selected · ₹${money(sum(d.rows.filter(r => sel.has(r.id))))}` : 'Tick the invoices to put in the reminder'}</span>
          <button id="prem" ${sel.size ? '' : 'disabled'}>✉ Send reminder email</button> <button class="sec" id="prwa" ${sel.size ? '' : 'disabled'}>💬 WhatsApp reminder</button></span>` : '<span class="hint">Choose a buyer to select invoices and send a payment reminder.</span>'}</div></div>`;
    el.querySelector('.tablewrap').scrollTop = scroll;
    $('#pfy').onchange = e => { st.fy = e.target.value; paymentReport(el); };
    $('#pby').onchange = e => { st.buyer = e.target.value; sel.clear(); draw(); };
    $('#psh').onchange = e => { st.show = e.target.value; draw(); };
    $('#pxp').onclick = () => downloadCsv(`payments_${st.fy}.csv`, list.map(r => ({ seller: firmName(r.firm_code), date: dmy(r.date), invoice: r.inv_no, buyer: r.party_name, qty: r.qty, amount: r.total, status: r.paid ? 'Received' : 'Due', received_on: r.paid_at ? dmy(r.paid_at) : '' })));
    const all = $('#pall'); if (all) { all.checked = due.length > 0 && due.every(r => sel.has(r.id)); all.onchange = () => { due.forEach(r => all.checked ? sel.add(r.id) : sel.delete(r.id)); draw(); }; }
    const rem = $('#prem'); if (rem) rem.onclick = () => reminderEmail([...sel], () => paymentReport(el));
    const rwa = $('#prwa'); if (rwa) rwa.onclick = () => waFor('REMINDER', { ids: [...sel] });
  };
  const setPaid = async (id, paid) => {
    const r = d.rows.find(x => x.id === id); if (!r || !!r.paid === paid) return;
    const x = await guard(() => PUT(`/api/invoices/${id}/paid`, { paid: paid ? 1 : 0 }));
    r.paid = x.paid; r.paid_at = x.paid_at; r.changed = Date.now(); if (paid) sel.delete(id); draw();
  };
  el.onclick = e => {
    const fb = e.target.closest('[data-firm]'); if (fb) { st.firm = fb.dataset.firm; d.rows = rows0.filter(r => !st.firm || r.firm_code === st.firm); sel.clear(); return draw(); }
    const c = e.target.closest('[data-sel]'); if (c) { const id = Number(c.dataset.sel); c.checked ? sel.add(id) : sel.delete(id); return draw(); }
    const b = e.target.closest('[data-pay]'); if (b) { const r = d.rows.find(x => x.id === Number(b.dataset.pay)); if (r && !r.paid) setPaid(r.id, true); return; }
    // Clicking a row (not a button) of a chosen buyer ticks it too
    const tr = e.target.closest('tr[data-id]'); if (tr && st.buyer && !e.target.closest('button,input')) { const id = Number(tr.dataset.id); sel.has(id) ? sel.delete(id) : sel.add(id); draw(); }
  };
  el.ondblclick = e => { const b = e.target.closest('[data-pay]'); if (b) { const r = d.rows.find(x => x.id === Number(b.dataset.pay)); if (r && r.paid && Date.now() - (r.changed || 0) > 800) setPaid(r.id, false); } };
  draw();
}
async function reminderEmail(ids, after) {
  let d = await guard(() => POST('/api/payment-reminder/draft', { ids }));
  const firms = d.mails.length;
  modal(`Payment reminder to ${d.buyer}`, `<form id="prf">
    ${firms > 1 ? '<p class="badge amber" style="display:block;padding:8px 10px">These invoices are from two sellers — one email is sent from each.</p>' : ''}
    <div class="grid g2">
      ${d.templates.length ? `<label class="span2">Email template<select id="prtpl">${d.templates.map(x => `<option value="${x.id}">${esc(x.name)}${x.is_default ? ' (default)' : ''}</option>`).join('')}</select></label>` : ''}
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}</div>
    <div class="row" style="margin-top:8px;gap:18px"><b>Attach</b><label style="display:flex;gap:6px;align-items:center;font-weight:500"><input type="checkbox" name="att_invoice" style="width:auto" checked> Invoice copies <span class="hint">(the PDFs already saved in the invoice folder)</span></label>
      <label style="display:flex;gap:6px;align-items:center;font-weight:500"><input type="checkbox" name="att_bank" style="width:auto" checked> Our bank proof</label></div>
    <div id="prm"></div>
    <div class="row" style="margin-top:10px"><button type="submit">Send email</button><span class="hint">The invoice table goes in the email as a table. Change the template in Settings → Email templates.</span></div></form>`, root => {
    const mails = () => { $('#prm', root).innerHTML = d.mails.map((m, i) => `<div class="card" style="margin:10px 0 0;padding:10px 14px;background:#f7fafb">
      ${m.ready ? '' : `<p class="badge amber">Email is not set up for ${esc(m.firm)}. Open Settings → Companies → Email sending first.</p>`}
      <div class="grid g2">${field({ name: 'subject' + i, label: `Subject (from ${m.firm}${m.from ? ' · ' + m.from : ''})`, span: 2 }, m.subject)}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text' + i, m.html || textToHtmlC(m.text), 260)}</div></div></div>`).join(''); richInit(root); };
    mails();
    const ts = $('#prtpl', root);
    if (ts) ts.onchange = async () => {
      d = await guard(() => POST('/api/payment-reminder/draft', { ids, template_id: ts.value })); mails(); };
    $('#prf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const f = e.target, tpl = ts ? ts.selectedOptions[0].text.replace(' (default)', '') : d.template_name;
      try {
        for (const [i, m] of d.mails.entries())
          await POST('/api/payment-reminder', { ids: m.ids, to: f.to.value, cc: f.cc.value, subject: f['subject' + i].value, text: f['text' + i].value, html: f['html' + i].value, template_name: tpl, attach: { invoice: f.att_invoice.checked ? 1 : 0, bank: f.att_bank.checked ? 1 : 0 } });
        toast('Reminder sent'); closeModal(); after && after();
      } catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ---------- Reports → Email log: every email sent or failed ----------
async function emailLog(el) {
  const st = S.elog = S.elog || { firm: '', status: '', from: '', to: '' };
  const rows = await GET(`/api/email-log?firm=${st.firm}&status=${st.status}&from=${st.from}&to=${st.to}`);
  el.innerHTML = `<div class="card"><div class="toolbar">
      <label>Seller<select id="elf"><option value="">All</option>${S.meta.firms.map(f => `<option value="${f.code}" ${f.code === st.firm ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>
      <label>Status<select id="els"><option value="">All</option><option ${st.status === 'SENT' ? 'selected' : ''}>SENT</option><option ${st.status === 'FAILED' ? 'selected' : ''}>FAILED</option></select></label>
      <label>From<input type="date" id="elfr" value="${st.from}"></label><label>To<input type="date" id="elto" value="${st.to}"></label>
      <span class="spacer"></span><button class="sec" id="elx">Export</button></div>
    <div class="tablewrap" style="max-height:70vh"><table class="t"><thead><tr><th>Date</th><th>Time</th><th>Seller</th><th>To (buyer / transporter)</th><th>Email template</th><th>Invoice no.</th><th>What</th><th>Status</th></tr></thead><tbody>
    ${rows.map(r => `<tr><td>${dmy(r.at.slice(0, 10))}</td><td>${esc(r.at.slice(11, 16))}</td><td>${esc(r.seller)}</td><td>${esc(r.to_name)}<br><span class="hint">${esc(r.to_addr)}</span></td>
      <td>${esc(r.template)}</td><td><b>${esc(r.doc_no)}</b></td><td>${esc(r.kind)}${r.attachments ? `<br><span class="hint">${esc(r.attachments)}</span>` : ''}</td>
      <td>${r.status === 'SENT' ? '<span class="badge slate">SENT</span>' : `<span class="badge red">FAILED</span><br><span class="hint">${esc(r.error || '')}</span>`}</td></tr>`).join('') || '<tr><td colspan="8" class="muted">No emails yet.</td></tr>'}
    </tbody></table></div></div>`;
  const re = () => emailLog(el);
  $('#elf').onchange = e => { st.firm = e.target.value; re(); }; $('#els').onchange = e => { st.status = e.target.value; re(); };
  $('#elfr').onchange = e => { st.from = e.target.value; re(); }; $('#elto').onchange = e => { st.to = e.target.value; re(); };
  $('#elx').onclick = () => downloadCsv('email_log.csv', rows.map(r => ({ date: r.at, seller: r.seller, to: r.to_name, email: r.to_addr, template: r.template, invoice: r.doc_no, what: r.kind, status: r.status, error: r.error, attachments: r.attachments })));
}

// ---------- Reports → Transporter TDS: declarations u/s 194C(6), one per F.Y., transporter and buyer ----------
async function tdsReport(el) {
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  let fy = S.tdsFy || S.fy, trId = S.tdsTr || '';
  const load = async () => {
    const rows = await GET('/api/tds?fy=' + fy);
    const trs = [...new Map(rows.map(r => [r.transporter_id, r])).values()];
    if (trId && !trs.some(t => String(t.transporter_id) === String(trId))) trId = '';
    const tr = trs.find(t => String(t.transporter_id) === String(trId));
    const list = rows.filter(r => !trId || String(r.transporter_id) === String(trId));
    el.innerHTML = `<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:10px">
        <label>F.Y.<select id="tfy">${fys.map(x => `<option ${x === fy ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
        <label style="min-width:320px">Transporter<select id="ttr"><option value="">— all transporters (${trs.length}) —</option>${trs.map(t => `<option value="${t.transporter_id}" ${String(t.transporter_id) === String(trId) ? 'selected' : ''}>${esc(t.transporter)}${t.has_pan_card ? '' : ' (no PAN card)'}</option>`).join('')}</select></label>
        <span class="spacer"></span><button class="sec" id="tmpl">✎ Email matter</button></div>
      ${tr ? `<div class="firmbox" style="margin:10px 0">${esc(tr.transporter)} · PAN <b>${esc(tr.pan || '—')}</b> · Declarant <b>${esc(tr.proprietor || '—')}</b> · Email ${esc(tr.tr_email || '—')}
        · PAN card ${tr.has_pan_card ? '<span class="badge slate">✔</span>' : '<span class="badge amber">not uploaded — Masters → Transporters</span>'}</div>` : ''}
      <div class="tablewrap"><table class="t"><thead><tr>${trId ? '' : '<th>Transporter</th>'}<th>Buyer invoiced in ${esc(fy)}</th><th class="num">Invoices</th><th>First invoice</th>
        <th>Sent to transporter</th><th>Sent to buyer</th><th></th></tr></thead><tbody>
      ${list.map(r => `<tr>${trId ? '' : `<td><b>${esc(r.transporter)}</b>${r.has_pan_card ? '' : ' <span class="badge amber">no PAN card</span>'}</td>`}
        <td><b>${esc(r.buyer)}</b><br><span class="hint">${esc([r.city, r.state].filter(Boolean).join(', '))}</span></td><td class="num">${r.invoices}</td><td>${dmy(r.first_date)}</td>
        <td>${r.sent_transporter_at ? '<span class="badge slate">' + esc(r.sent_transporter_at) + '</span>' : '<span class="muted">not sent</span>'}</td>
        <td>${r.sent_buyer_at ? '<span class="badge slate">' + esc(r.sent_buyer_at) + '</span>' : '<span class="muted">not sent</span>'}${r.last_error ? `<div class="hint" style="color:#b42318" title="${esc(r.last_error)}">⚠ ${esc(r.last_error.slice(0, 80))}</div>` : ''}</td>
        <td style="white-space:nowrap;text-align:right"><button class="small sec" data-act="print" data-t="${r.transporter_id}" data-p="${r.party_id}">🖨 Print</button>
          <button class="small sec" data-act="transporter" data-t="${r.transporter_id}" data-p="${r.party_id}">✉ Transporter</button>
          <button class="small sec" data-act="buyer" data-t="${r.transporter_id}" data-p="${r.party_id}">✉ Buyer</button></td></tr>`).join('')
        || `<tr><td colspan="7" class="muted">No invoices with a transporter from the Transporters list in ${esc(fy)}.</td></tr>`}
      </tbody></table></div>
      <p class="hint">One declaration per financial year for every buyer invoiced with the transporter. It is emailed by itself to the transporter and the buyer with the first new invoice, once the transporter's PAN card is uploaded.</p></div>`;
    $('#tfy').onchange = () => { fy = S.tdsFy = $('#tfy').value; load(); };
    $('#ttr').onchange = () => { trId = S.tdsTr = $('#ttr').value; load(); };
    $('#tmpl').onclick = tdsTemplates;
    el.onclick = e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const qs = `fy=${encodeURIComponent(fy)}&t=${b.dataset.t}&p=${b.dataset.p}`;
      if (b.dataset.act === 'print') window.open('/print/tds?' + qs, '_blank');
      else tdsEmail(fy, b.dataset.t, b.dataset.p, b.dataset.act, load);
    };
  };
  await load();
}
async function tdsEmail(fy, t, p, who, after) {
  const d = await guard(() => GET(`/api/tds/draft?fy=${encodeURIComponent(fy)}&t=${t}&p=${p}&who=${who}`));
  const blocking = d.problems.filter(x => !/email/.test(x));
  modal(`Email TDS declaration to the ${who}`, `
    ${d.problems.length ? `<p class="badge ${blocking.length ? 'red' : 'amber'}">Missing: ${esc(d.problems.join(', '))}</p>` : ''}
    ${d.from ? '' : `<p class="badge amber">Email is not set up for ${esc(d.firm)}. Settings → Companies → Email.</p>`}
    <form id="tef"><div class="grid g2">${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, '')}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text', textToHtmlC(d.text), 220)}</div></div>
      <p class="hint">The declaration PDF (with the PAN card) is attached. Sent from ${esc(d.from || '—')} (${esc(d.firm)}).</p>
      <div class="row"><button type="submit" ${blocking.length || !d.from ? 'disabled' : ''}>Send email</button>
        <button type="button" class="sec" onclick="window.open('/print/tds?fy=${encodeURIComponent(fy)}&t=${t}&p=${p}','_blank')">Preview</button></div></form>`, root => {
    richInit(root);
    $('#tef', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try { await POST('/api/tds/send', { ...formData(e.target), fy, t, p, who }); toast('Declaration sent'); closeModal(); after && after(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}
async function tdsTemplates() {
  const d = await GET('/api/tds/templates');
  modal('Email matter for the TDS declaration', `<form id="ttf">
    <p class="hint">You can use: {transporter} {pan} {proprietor} {buyer} {buyer_city} {fy} {firm}</p>
    <h3>To the transporter</h3>${field({ name: 'tds_subject_transporter', label: 'Subject' }, d.tds_subject_transporter)}
    <label>Message<textarea name="tds_body_transporter" style="min-height:170px">${esc(d.tds_body_transporter)}</textarea></label>
    <h3 style="margin-top:14px">To the buyer</h3>${field({ name: 'tds_subject_buyer', label: 'Subject' }, d.tds_subject_buyer)}
    <label>Message<textarea name="tds_body_buyer" style="min-height:170px">${esc(d.tds_body_buyer)}</textarea></label>
    <div class="row" style="margin-top:12px"><button type="submit">Save</button><button type="button" class="sec" id="ttdef">Back to the default matter</button></div></form>`, root => {
    $('#ttf', root).onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/tds/templates', formData(e.target))); toast('Email matter saved'); closeModal(); };
    $('#ttdef', root).onclick = () => { for (const k of Object.keys(d.defaults)) $('#ttf', root)[k].value = d.defaults[k]; };
  });
}

async function salesReport(el) {
  const [d, dd] = await Promise.all([GET('/api/reports/monthly?fy=' + S.fy), GET('/api/dashboard?fy=' + S.fy)]);
  const by = (arr, k) => arr.find(x => x.firm_code === k) || {};
  const months = [...new Set([...d.sales.map(r => r.ym), ...d.inward.map(r => r.ym)])].filter(Boolean).sort();
  const cell = (ym, firm, k) => { const r = d.sales.find(x => x.ym === ym && x.firm_code === firm); return r ? r[k] : null; };
  el.innerHTML = `
  <div class="stats">
    <div class="stat"><div class="k">Parakh Marketing · ${esc(dd.fy)}</div><div class="v">${rs(by(dd.sales, 'PM').total)}</div><div class="s">${by(dd.sales, 'PM').n || 0} invoices · this month ${rs(by(dd.month_sales, 'PM').total)}</div></div>
    <div class="stat slate"><div class="k">Parakh Fertilizer · ${esc(dd.fy)}</div><div class="v">${rs(by(dd.sales, 'PF').total)}</div><div class="s">${by(dd.sales, 'PF').n || 0} invoices · this month ${rs(by(dd.month_sales, 'PF').total)}</div></div>
    <div class="stat rust"><div class="k">P.P. Enterprise bills · ${esc(dd.fy)}</div><div class="v">${rs(by(dd.sales, 'PPE').total)}</div><div class="s">${by(dd.sales, 'PPE').n || 0} bills to Parakh Marketing</div></div>
    <div class="stat amber"><div class="k">Inward · ${esc(dd.fy)}</div><div class="v">${qty(dd.inward.actual)} MT</div><div class="s">${dd.inward.n} lorries · rawana ${qty(dd.inward.rawana)} MT · freight ${rs(dd.inward.freight)}</div></div>
  </div>
  <div class="card"><div class="toolbar"><h3 style="margin:0">Month-wise sales · ${esc(S.fy)}</h3><span class="spacer"></span><button class="sec" id="c1">Export</button></div>
    <div class="tablewrap"><table class="t"><thead><tr><th>Month</th>${['PM', 'PF', 'PPE'].map(f => `<th class="num">${f} qty</th><th class="num">${f} total</th>`).join('')}</tr></thead><tbody>
    ${months.map(m => `<tr><td>${monthName(m)}</td>${['PM', 'PF', 'PPE'].map(f => `<td class="num">${qty(cell(m, f, 'qty'))}</td><td class="num">${cell(m, f, 'total') == null ? '' : money(cell(m, f, 'total'))}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div></div>
  <div class="grid g2">
    <div class="card"><div class="toolbar"><h3 style="margin:0">Inward month-wise</h3><span class="spacer"></span><button class="sec" id="c2">Export</button></div>
      <table class="t"><thead><tr><th>Month</th><th class="num">Lorries</th><th class="num">Rawana MT</th><th class="num">Actual MT</th><th class="num">Freight</th></tr></thead><tbody>
      ${d.inward.map(r => `<tr><td>${monthName(r.ym)}</td><td class="num">${r.n}</td><td class="num">${qty(r.rawana)}</td><td class="num">${qty(r.actual)}</td><td class="num">${money(r.freight)}</td></tr>`).join('')}</tbody></table></div>
    <div class="card"><div class="toolbar"><h3 style="margin:0">HSN summary (for GST return)</h3><span class="spacer"></span><button class="sec" id="c3">Export</button></div>
      <table class="t"><thead><tr><th>Firm</th><th>HSN</th><th class="num">GST %</th><th class="num">Qty MT</th><th class="num">Taxable</th></tr></thead><tbody>
      ${d.hsn.map(r => `<tr><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${esc(r.hsn)}</td><td class="num">${r.gst_rate}</td><td class="num">${qty(r.qty)}</td><td class="num">${money(r.taxable)}</td></tr>`).join('')}</tbody></table></div>
  </div>`;
  $('#c1').onclick = () => downloadCsv(`sales_monthly_${S.fy}.csv`, d.sales.map(r => ({ month: monthName(r.ym), ...r })));
  $('#c2').onclick = () => downloadCsv(`inward_monthly_${S.fy}.csv`, d.inward.map(r => ({ month: monthName(r.ym), ...r })));
  $('#c3').onclick = () => downloadCsv(`hsn_${S.fy}.csv`, d.hsn);
};

// ---------- settings ----------
// Settings: "This computer" pages open straight away; the important ones (data location, security, import, about) ask for the edit password
const SET_IMPORTANT = ['data', 'security', 'import', 'about'];
PAGES.settings = async (el, arg) => {
  let [tab, ...rest] = (arg || 'printers').split(':'), sub = rest.join(':') || undefined;
  if (tab === 'computer') tab = 'printers';
  if (SET_IMPORTANT.includes(tab) && !S.impOk) {
    const s = await GET('/api/settings');
    if (s.edit_password_set) {
      el.innerHTML = '<div class="card" style="max-width:520px"><h3>🔒 Important settings</h3><p class="hint">Data location, Security, Import and About open with the edit password.</p><button id="impopen">Enter password</button></div>';
      const ask = async () => { const pw = await askEditPassword('open the important settings'); if (pw) { S.impOk = true; PAGES.settings(el, arg); } };
      $('#impopen').onclick = ask; return ask();
    }
    S.impOk = true;
  }
  el.innerHTML = `<div id="st"></div>`;
  await (SETTINGS[tab] || SETTINGS.printers)($('#st'), sub);
};

const SETTINGS = {};

// ----- Companies: one tab for each firm -----
SETTINGS.company = async (box, code) => {
  const [code0, sub] = String(code || '').split(':');
  if (sub === 'docs' || sub === 'vendor') return companyDocsPage(box, code0, sub);
  code = code0;
  const firms = await GET('/api/m/firms');
  const s = await GET('/api/settings');
  code = firms.some(f => f.code === code) ? code : 'PM';
  const f = firms.find(x => x.code === code);
  const mail = s.firms.find(x => x.code === code) || {};
  box.innerHTML = `
  <div class="tabs" style="margin-bottom:14px">${firms.map(x => `<button class="${x.code === code ? 'on' : ''}" onclick="go('#/settings/company:${x.code}')"><span class="badge ${x.code}" style="margin-right:6px">${x.code}</span>${esc(x.name)}</button>`).join('')}</div>
  ${companySubTabs(code, '')}
  <div class="grid" style="grid-template-columns:300px 1fr;align-items:start">
    <div><div class="card" style="text-align:center"><h3>Company logo</h3>
      <div id="logoprev" style="height:150px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--line);border-radius:10px;background:#fafcfc;margin-bottom:12px">
        ${f.logo ? `<img src="${f.logo}" style="max-height:130px;max-width:240px">` : '<span class="muted">No logo yet</span>'}</div>
      <input type="file" id="logofile" accept="image/png,image/jpeg,image/webp" hidden>
      <div class="row" style="justify-content:center"><button id="logoup">Upload logo</button>${f.logo ? '<button class="sec" id="logodel">Remove</button>' : ''}</div>
      <p class="hint" style="margin-top:10px">Printed at the top of this company's invoices and vouchers. PNG or JPG, square or wide.</p>
    </div>
    ${['signature', 'bank_proof'].map(k => `<div class="card" style="text-align:center;margin-top:0"><h3>${k === 'signature' ? 'Signature' : 'Bank proof'}</h3>
      <div style="height:${k === 'signature' ? 110 : 150}px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--line);border-radius:10px;background:#fafcfc;margin-bottom:12px">
        ${f[k] ? `<img src="${f[k]}" style="max-height:${k === 'signature' ? 100 : 140}px;max-width:240px">` : `<span class="muted">No ${k === 'signature' ? 'signature' : 'bank proof'} yet</span>`}</div>
      <input type="file" id="${k}file" accept="image/png,image/jpeg,image/webp" hidden>
      <div class="row" style="justify-content:center"><button type="button" data-imgup="${k}">Upload</button>${f[k] ? `<button type="button" class="sec" data-imgdel="${k}">Remove</button>` : ''}</div>
      <p class="hint" style="margin-top:10px">${k === 'signature' ? 'Sign on white paper and take a photo. The white space is cut away and the paper made see-through. Printed above “Authorised Signatory” on this company’s invoices and vouchers.' : 'Cancelled cheque or passbook page. The white border is cut away.'}</p>
    </div>`).join('')}</div>
    <div>
      <form id="cf" class="card"><h3>Company details</h3>
        <div class="grid g4">
          ${field({ name: 'name', label: 'Company name', span: 2 }, f.name)}${field({ name: 'gstin', label: 'GSTIN' }, f.gstin)}${field({ name: 'pan', label: 'PAN' }, f.pan)}
          ${field({ name: 'address', label: 'Address', span: 4 }, f.address)}
          ${field({ name: 'pincode', label: 'Pincode (fills city & state)' }, f.pincode)}${field({ name: 'city', label: 'City' }, f.city)}
          ${field({ name: 'state', label: 'State', type: 'select', options: STATES() }, f.state)}${field({ name: 'state_code', label: 'State code', ro: true }, f.state_code)}
          ${field({ name: 'phone', label: 'Phone' }, f.phone)}${field({ name: 'email', label: 'Email', span: 2 }, f.email)}<div></div>
          ${field({ name: 'owner_aadhaar', label: 'Owner Aadhaar no.' }, f.owner_aadhaar)}${field({ name: 'udyam_no', label: 'Udyam (MSME) registration no.', span: 2 }, f.udyam_no)}<div></div>
        </div>
        <h3 style="margin-top:18px">Bank & UPI <span class="hint">(printed on invoices)</span></h3>
        <div class="grid g4">
          ${field({ name: 'bank_name', label: 'Bank name' }, f.bank_name)}${field({ name: 'bank_account', label: 'Account no.' }, f.bank_account)}
          ${field({ name: 'bank_ifsc', label: 'IFSC' }, f.bank_ifsc)}${field({ name: 'bank_branch', label: 'Branch' }, f.bank_branch)}
          ${field({ name: 'upi_id', label: 'UPI id (for the QR code)', span: 2 }, f.upi_id)}
        </div>
        <h3 style="margin-top:18px">Terms of sale <span class="hint">(printed on invoices)</span></h3>
        ${field({ name: 'terms', label: '', type: 'textarea' }, f.terms)}
        <div class="row" style="margin-top:14px"><button type="submit">Save company details</button></div>
      </form>
      ${code === 'PPE' ? '' : `
      <form id="ef" class="card"><h3>Email sending <span class="hint">— invoices are emailed from this address, no Outlook needed</span></h3>
        <div class="grid g4">
          <label class="span2">Sender email<input name="smtp_user" placeholder="sender@gmail.com" value="${esc(mail.smtp_user || '')}"></label>
          <label class="span2">App password ${mail.has_pass ? '<span class="badge PF">saved</span>' : ''}<input name="smtp_pass" type="password" placeholder="${mail.has_pass ? 'leave blank to keep the saved one' : '16-letter Google app password'}"></label>
          <label class="span2">Mail server<input name="smtp_host" value="${esc(mail.smtp_host || 'smtp.gmail.com')}"></label>
          <label>Port<input name="smtp_port" value="${esc(mail.smtp_port || 465)}"></label><div></div>
        </div>
        <p class="hint">Gmail: turn on 2-Step Verification, then Google Account → Security → App passwords → create one and paste it here.</p>
        <div class="row"><button type="submit">Save email settings</button><button type="button" class="sec" id="etest">Send test email</button></div>
      </form>`}
    </div>
  </div>`;
  const cf = $('#cf', box);
  hookPincode(cf);
  cf.onsubmit = async e => { e.preventDefault(); const d = formData(cf); delete d.state_code;
    await guard(() => PUT('/api/m/firms/' + f.id, d)); toast(`${d.name} saved`); S.meta = await GET('/api/meta'); route(); };
  $$('[data-imgup]', box).forEach(b => { const k = b.dataset.imgup; b.onclick = () => $('#' + k + 'file', box).click();
    $('#' + k + 'file', box).onchange = async () => {
      const file = $('#' + k + 'file', box).files[0]; if (!file) return;
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('That file is not a picture.')); i.src = URL.createObjectURL(file); }).catch(e => { toast(e.message, true); return null; });
      if (!img) return;
      const data = k === 'signature' ? await signatureImage(img) : cropBlank(img, 1200);
      await guard(() => PUT('/api/m/firms/' + f.id, { [k]: data })); toast('Saved'); route();
    }; });
  $$('[data-imgdel]', box).forEach(b => b.onclick = async () => { if (confirm('Remove this picture?')) { await guard(() => PUT('/api/m/firms/' + f.id, { [b.dataset.imgdel]: '' })); route(); } });
  $('#logoup', box).onclick = () => $('#logofile', box).click();
  $('#logofile', box).onchange = async () => {
    const file = $('#logofile', box).files[0]; if (!file) return;
    const logo = await shrinkImage(file, 600);
    await guard(() => PUT('/api/m/firms/' + f.id, { logo })); toast('Logo saved'); route();
  };
  const ld = $('#logodel', box); if (ld) ld.onclick = async () => { if (confirm('Remove the logo?')) { await guard(() => PUT('/api/m/firms/' + f.id, { logo: '' })); route(); } };
  const ef = $('#ef', box);
  if (ef) {
    ef.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/settings/email/' + code, formData(ef))); toast('Email settings saved'); route(); };
    $('#etest', box).onclick = async () => { const b = $('#etest', box); b.disabled = true; b.textContent = 'Sending…';
      try { await POST(`/api/settings/email/${code}/test`, {}); toast('Test email sent — check the inbox'); } catch (err) { toast(err.message, true); }
      b.disabled = false; b.textContent = 'Send test email'; };
  }
};

// resize an image in the browser so the logo stays small
function shrinkImage(file, max) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('That file is not a picture.'));
    img.src = URL.createObjectURL(file);
  });
}

// ----- This computer: settings kept on this PC only (not in the shared data) -----
SETTINGS.printers = async (box) => {
  const ps = await GET('/api/pc-settings');
  box.innerHTML = `<div class="card"><h3>Printers of this computer: <span style="color:var(--rust)">${esc(ps.pc)}</span></h3>
    <p class="hint" style="margin:0 0 10px">Saved on this computer only (not in the shared data), so each computer can use its own printers.</p><div id="printbox" class="hint">Loading…</div></div>`;
  printersSection($('#printbox', box));
};
// Start when Windows starts (Settings → This computer → Updates)
function startSection(sb) {
  const showStart = s => {
    if (!s.supported) { sb.textContent = 'Only available when Mineral Saathi runs on Windows.'; return; }
    sb.innerHTML = `<label style="display:flex;gap:10px;align-items:center;font-size:15px;color:var(--text);font-weight:600">
        <input type="checkbox" id="startchk" style="width:auto;transform:scale(1.3)" ${s.enabled ? 'checked' : ''}>
        Start Mineral Saathi automatically when <b>${esc(s.pc)}</b> starts</label>
      <p class="hint" style="margin:8px 0 0">Keep this <b>on</b> for the office PC. Turn it <b>off</b> on the home PC and laptop, so the data is opened there only when you open it yourself.</p>`;
    $('#startchk', sb).onchange = async () => showStart(await guard(() => PUT('/api/startup', { enabled: $('#startchk', sb).checked })));
  };
  GET('/api/startup').then(showStart).catch(() => { sb.textContent = 'Could not check.'; });
}
SETTINGS.computer = async (box) => {
  const ps = await GET('/api/pc-settings');
  box.innerHTML = `
  <div class="card"><h3>This computer: <span style="color:var(--rust)">${esc(ps.pc)}</span></h3>
    <p class="hint" style="margin:0">Settings on this tab belong to this computer only. They are saved in its own program folder
      (<code>${esc(ps.file)}</code>), not in the shared data, so the office PC, home PC and laptop can each be set differently. Updates never change them.</p></div>
  <div class="card"><h3>Start when Windows starts</h3><div id="startbox" class="hint">Checking…</div></div>
  <div class="card"><h3>Printers</h3><div id="printbox" class="hint">Loading…</div></div>`;
  printersSection($('#printbox', box));
  const showStart = s => {
    const sb = $('#startbox', box);
    if (!s.supported) { sb.textContent = 'Only available when Mineral Saathi runs on Windows.'; return; }
    sb.innerHTML = `<label style="display:flex;gap:10px;align-items:center;font-size:15px;color:var(--text);font-weight:600">
        <input type="checkbox" id="startchk" style="width:auto;transform:scale(1.3)" ${s.enabled ? 'checked' : ''}>
        Start Mineral Saathi automatically when <b>${esc(s.pc)}</b> starts</label>
      <p class="hint" style="margin:8px 0 0">Keep this <b>on</b> for the office PC. Turn it <b>off</b> on the home PC and laptop, so the data is opened there only when you open it yourself.
        This setting is for the computer that runs Mineral Saathi (${esc(s.pc)}).</p>`;
    $('#startchk', box).onchange = async () => showStart(await guard(() => PUT('/api/startup', { enabled: $('#startchk', box).checked })));
  };
  GET('/api/startup').then(showStart).catch(() => { $('#startbox', box).textContent = 'Could not check.'; });
};

async function printersSection(box) {
  const ps = await GET('/api/print-setup');
  const KINDS = [['invoice', 'Sales invoice — PM, PF, PPE (A4)']];   // every other paper: Settings → Page Setup
  const PAPER_NAMES = { A4: 'A4 (210 × 297)', A5: 'A5 (148 × 210)', LETTER: 'Letter', LABEL4X6: '4 × 6 inch label (101.6 × 152.4)', ENV_DL: 'Envelope DL (220 × 110)', ENV_C5: 'Envelope C5 (229 × 162)', ENV_10: 'Envelope No.10 (241 × 105)', '': 'Own size' };
  const rules = `<div class="row" style="margin:6px 0 14px"><label style="width:220px">One invoice copy from (MT)<input id="singlemt" type="number" step="0.5" value="${ps.single_copy_mt}"></label>
    <span class="hint">Invoices of ${ps.single_copy_mt} MT or more print 1 copy; smaller ones print 2 (Original + Duplicate). Same rule on every computer.</span><button class="sec small" id="savemt">Save</button></div>
    <label style="display:flex;gap:8px;align-items:center;margin:0 0 14px"><input type="checkbox" id="ewbback" style="width:auto" ${ps.ewb_back ? 'checked' : ''}> Print the e-way bill on the back of each invoice copy (both-side printing, this computer) — with the delivery location QR below it when the buyer has a location link (printed even without an e-way bill)</label>`;
  if (!ps.local) {
    const w = printWhere();
    box.innerHTML = `${rules}<p style="color:var(--text)">This computer opens Mineral Saathi from the main PC (${esc(ps.pc)}). Choose how it prints:</p>
      <label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text)"><input type="radio" name="pw" value="window" style="width:auto" ${w !== 'main' ? 'checked' : ''}> Print window on this computer (choose this computer's printer; paper size is set already)</label>
      <label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text);margin-top:6px"><input type="radio" name="pw" value="main" style="width:auto" ${w === 'main' ? 'checked' : ''}> Print straight on the main PC's printers (${esc(ps.pc)}), no print window</label>`;
    $$('[name=pw]', box).forEach(r => r.onchange = () => { try { localStorage.setItem('ms_print_where', r.value); } catch { } toast('Saved for this computer'); });
  } else if (!ps.direct) {
    box.innerHTML = rules + 'Direct printing works when Mineral Saathi runs on Windows. Here the print window is used.';
  } else {
    const pl = await GET('/api/printers');
    box.innerHTML = rules + KINDS.map(([k, title]) => {
      const s = ps.kinds[k];
      return `<form class="pform card" data-k="${k}" style="background:#f7fafb;margin:0 0 12px"><h3 style="margin-bottom:8px">${title}</h3>
        <div class="grid g4">
          <label class="span2">Printer<select name="printer"><option value="">— choose —</option>${pl.printers.map(n => `<option ${n === s.printer ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
          <label class="span2">Paper<select name="paper">${Object.keys(PAPER_NAMES).map(pk => `<option value="${pk}" ${pk === (s.paper || '') ? 'selected' : ''}>${PAPER_NAMES[pk]}</option>`).join('')}</select></label>
          <label>Width mm<input name="w" type="number" step="0.1" value="${s.w}"></label><label>Height mm<input name="h" type="number" step="0.1" value="${s.h}"></label>
          <label>Margin mm<input name="margin" type="number" step="0.5" value="${s.margin}"></label>
          <label>Size %<input name="scale" type="number" step="1" value="${s.scale}"></label>
          <label>Shift right mm<input name="ox" type="number" step="0.5" value="${s.ox}"></label><label>Shift down mm<input name="oy" type="number" step="0.5" value="${s.oy}"></label>
          <label class="span2" style="display:flex;gap:8px;align-items:center;font-size:13px;margin-top:18px"><input type="checkbox" name="landscape" style="width:auto" ${s.landscape ? 'checked' : ''}> Landscape (wide)</label>
        </div>
        <div class="row" style="margin-top:10px"><button type="submit">Save</button><button type="button" class="sec ptest">Print a test</button>
          <span class="hint pnote">${pl.default ? 'Windows default printer: ' + esc(pl.default) : ''}</span></div></form>`;
    }).join('') + `<p class="hint">Prints go straight to the chosen printer with no print window. Use "Shift" if the print sits off-centre on the paper.</p>
      <p class="hint"><b>Bag stickers, envelopes, vouchers, letters and all Marketing papers:</b> printer, paper and position are set in <a href="#/settings/pagesetup">Settings → Page Setup</a>.</p>`;
    $$('.pform', box).forEach(f => {
      const k = f.dataset.k;
      const lockSize = () => { const own = !f.paper.value; f.w.readOnly = !own; f.h.readOnly = !own; if (!own) { const [w, h] = ps.papers[f.paper.value]; f.w.value = w; f.h.value = h; } };
      f.paper.onchange = lockSize; lockSize();
      f.onsubmit = async e => { e.preventDefault(); const d = formData(f); d.landscape = f.landscape.checked;
        ps.kinds[k] = await guard(() => PUT('/api/print-setup/' + k, d)); toast('Printer settings saved for this computer'); };
      $('.ptest', f).onclick = async () => { const d = formData(f); d.landscape = f.landscape.checked;
        await guard(() => PUT('/api/print-setup/' + k, d)); toast('Printing a test…');
        const r = await guard(() => POST('/api/print/test/' + k)); toast('Test sent to ' + r.printer); };
    });
  }
  $('#ewbback', box).onchange = async e => { await guard(() => PUT('/api/pc-settings', { print_ewb_back: e.target.checked })); toast(e.target.checked ? 'E-way bill prints on the back' : 'Invoice prints without the e-way bill'); };
  $('#savemt', box).onclick = async () => { await guard(() => PUT('/api/print-rules', { single_copy_mt: $('#singlemt', box).value })); toast('Saved'); printersSection(box); };
}

// ----- Data location: office PC, home PC, laptop — one at a time -----
SETTINGS.data = async (box) => {
  const d = await GET('/api/data-location');
  const lk = d.lock || {};
  box.innerHTML = `
  <div class="card"><h3>Where the data is</h3>
    <div class="grid g3">
      <div class="firmbox"><span class="hint">This computer</span><br><b style="font-size:17px">${esc(d.pc)}</b></div>
      <div class="firmbox"><span class="hint">Data folder</span><br><b>${esc(d.data_folder)}</b><br><span class="hint">${(d.db_size / 1048576).toFixed(1)} MB</span></div>
      <div class="firmbox"><span class="hint">Mode</span><br><b>${d.shared ? 'Shared folder — office, home or laptop, one at a time' : 'Only on this computer'}</b></div>
    </div>
    ${d.shared ? `<div class="row" style="margin-top:14px"><button class="rust" id="closeday">⏻ Close for today</button>
      <span class="hint">Press this before you leave, so the data can be opened on your home PC or laptop. Mineral Saathi stops on this computer.</span></div>` : ''}
  </div>
  ${d.shared ? `
  <div class="card"><h3>Use it at home or on the laptop</h3><ol style="line-height:1.8;margin:0;padding-left:20px">
    <li>On the office PC press <b>Close for today</b> (above). Wait a minute for Google Drive to sync.</li>
    <li>First time only on the home PC / laptop: install Google Drive for desktop (same Google account) and Node.js LTS, unzip the MineralSaathi program and open <b>Open-Mineral-Saathi.bat</b>.
      It asks <b>“Where is your data?”</b> — choose this folder:<br><b>${esc(d.data_folder)}</b> <span class="hint">(the drive letter may be different there)</span></li>
    <li>Open <b>Mineral Saathi</b> from the desktop. It waits until Google Drive has brought the latest data.</li>
    <li>When you finish there, press <b>Close for today</b> on that computer too. Next morning the office PC opens the data by itself.</li>
  </ol><p class="hint">If you forget to close, the other computer will not open the data and tells you where it is open. If that computer is off, use <code>windows\\Take-Over-Data.bat</code>.</p></div>` : ''}
  <div class="card"><h3>${d.shared ? 'Move the data to another folder' : 'Move the data to Google Drive (to use it at home / on the laptop)'}</h3>
    <p class="hint">Use a folder inside Google Drive, e.g. <code>G:\\My Drive\\Mineral Saathi Data</code>. In Google Drive, set this folder to <b>Available offline</b>.
      A backup is taken first; the server restarts by itself in a few seconds.</p>
    <div class="row"><label style="flex:1">New data folder<input id="newdir" placeholder="G:\\My Drive\\Mineral Saathi Data"></label>
      <label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" id="repl" style="width:auto"> replace data already in that folder</label>
      <button id="movego">Move data</button></div>
    ${d.shared ? '<p style="margin-top:12px"><button class="sec" id="moveback">Move the data back to this computer only</button></p>' : ''}
  </div>
  ${d.local ? `<div class="card"><h3>Use data from another folder</h3>
    <p class="hint">Link this computer to Mineral Saathi data that is already somewhere else (Google Drive, another disk, a pen drive). Nothing is copied or moved —
      Mineral Saathi restarts and shows <b>“Where is your data?”</b> to choose the folder.</p>
    <button class="sec" id="choosedata">Choose the data folder…</button></div>` : ''}`;
  const ch = $('#choosedata', box); if (ch) ch.onclick = async () => {
    if (S.dirty && !confirm('You have unsaved changes. Continue anyway?')) return;
    if (!confirm('Mineral Saathi restarts and asks where the data is. Continue?')) return;
    await guard(() => POST('/api/data-choose')); S.dirty = false;
    document.body.innerHTML = '<div style="margin:auto;text-align:center;font-family:Segoe UI,Arial;color:#2F4F5A"><h2>Restarting…</h2><p>The “Where is your data?” page opens in a few seconds.</p></div>';
    for (let i = 0; i < 40; i++) { await new Promise(r => setTimeout(r, 1500)); try { const v = await (await fetch('/api/version')).json(); if (v.setup) { location.href = '/'; return; } } catch {} }
  };
  const cd = $('#closeday', box); if (cd) cd.onclick = closeForToday;

  const mv = async folder => {
    if (!confirm(folder ? `Move the data to\n${folder}\n\nAll PCs will reconnect after a few seconds.` : 'Move the data back to this computer only?')) return;
    const r = await guard(() => POST('/api/data-location', { folder, replace: $('#repl', box).checked }));
    toast(`Data moved to ${r.folder} — restarting…`); setTimeout(() => location.reload(), 9000);
  };
  $('#movego', box).onclick = () => { const f = $('#newdir', box).value.trim(); if (!f) return toast('Type the folder first.', true); mv(f); };
  const mb = $('#moveback', box); if (mb) mb.onclick = () => mv('');
};

async function closeForToday() {
  if (S.dirty && !confirm('You have unsaved changes. Close anyway?')) return;
  if (!confirm('Close Mineral Saathi for today on this computer?\nThe data becomes free for your home PC or laptop.')) return;
  const r = await guard(() => POST('/api/close'));
  S.dirty = false;
  document.body.innerHTML = `<div style="margin:auto;text-align:center;font-family:Segoe UI,Arial;color:#2F4F5A">
    <img src="logo-icon.png" style="width:110px;border-radius:20px"><h1>Closed for today</h1>
    <p>Mineral Saathi has stopped on <b>${esc(r.pc)}</b>. The data is free to open on your home PC or laptop.</p>
    <p style="color:#63757b">Wait about a minute for Google Drive to finish syncing. You can close this window (Alt+F4).</p></div>`;
}

// ---------- Commission (private, own password) ----------
TITLES.commission = 'Commission';
PAGES.commission = async (el) => {
  if (!S.commPw) {
    el.innerHTML = `<div class="card" style="max-width:460px"><h3>🔒 Commission</h3><form id="cpf" autocomplete="off">
      <label>Commission password<input name="pw" type="password"></label>
      <div class="row" style="margin-top:12px"><button type="submit">Open</button><span class="hint">Set it in Settings → Security.</span></div></form></div>`;
    const f = $('#cpf'); f.pw.focus();
    f.onsubmit = async e => {
      e.preventDefault(); S.commPw = f.pw.value;
      try { await POST('/api/commission/check'); PAGES.commission(el); }
      catch (err) { S.commPw = null; toast(err.message, true); f.pw.select(); }
    };
    return;
  }
  const st = S.comm = S.comm || { fy: '', party: '', agent: '' };
  const d = await guard(() => GET(`/api/commission?fy=${encodeURIComponent(st.fy)}&party=${st.party}&agent=${encodeURIComponent(st.agent)}`));
  const buyer = d.buyers.find(b => String(b.id) === String(st.party));
  const buyers = st.agent ? d.buyers.filter(b => b.agents.includes(st.agent)) : d.buyers;
  const who = [st.agent && 'Agent ' + st.agent, buyer && buyer.name].filter(Boolean).join(' · ');
  el.innerHTML = `
  <div class="toolbar"><label>F.Y.<select id="cfy"><option value="">All years</option>${d.fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${esc(y)}</option>`).join('')}</select></label>
    <label>Agent<select id="cag"><option value="">— all agents —</option>${d.agents.map(a => `<option ${a === st.agent ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
    <label style="min-width:320px">Buyer <span class="hint">(only buyers with a commission rate)</span><select id="cpb"><option value="">— all buyers —</option>${buyers.map(b => `<option value="${b.id}" ${String(b.id) === String(st.party) ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></label>
    <label style="align-self:end"><button type="button" id="cxadd">+ Expense</button></label>
    <span class="spacer"></span><button class="sec" id="cimp">⬆ Import old payments</button><button class="sec" id="cexp">Export</button><button class="sec" id="clock">🔒 Lock</button></div>
  ${!d.buyers.length ? '<div class="card"><p>No buyer has a commission rate yet. Add it in Buyers → the buyer → items → <b>Commission ₹ / MT</b>.</p></div>' : `
  <div class="grid comm" style="grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);align-items:start">
    <style>.comm .t { font-size: 12.5px; } .comm .t td, .comm .t th { padding: 6px 8px; } .comm .tablewrap { overflow: auto; }</style>
    <div class="card"><h3>Commission on invoices <span class="hint">${d.lines.length} lines · ${qty(d.qty)} MT</span></h3>
      <div class="tablewrap" style="max-height:58vh"><table class="t"><thead><tr><th>Date</th><th>Invoice</th>${st.party ? '' : '<th>Buyer</th>'}<th>Item</th>${st.agent ? '' : '<th>Agent</th>'}<th class="num">Qty MT</th><th class="num">Rate / MT</th><th class="num">Commission</th></tr></thead><tbody>
      ${[...d.lines.map(l => ({ ...l, _k: 'L' })), ...d.extras.map(x => ({ ...x, _k: 'X' }))].sort((a, b) => (a.date || '').localeCompare(b.date || '')).map(l => l._k === 'L'
        ? `<tr><td>${dmy(l.date)}</td><td><span class="badge ${l.firm_code}">${l.firm_code}</span> <b>${esc(l.inv_no)}</b></td>${st.party ? '' : `<td>${esc(l.buyer)}</td>`}
        <td>${esc(l.item)}</td>${st.agent ? '' : `<td>${esc(l.agent)}</td>`}<td class="num">${qty(l.qty)}</td><td class="num">${money(l.rate)}</td><td class="num"><b>${money(l.commission)}</b></td></tr>`
        : `<tr style="background:#fbf7f4"><td>${dmy(l.date)}</td><td><span class="badge amber">EXPENSE</span></td>${st.party ? '' : `<td>${esc(l.buyer || '')}</td>`}
        <td>${esc(l.description)} <button class="small sec" data-xdel="${l.id}" title="Remove this expense">✕</button></td>${st.agent ? '' : `<td>${esc(l.agent || '')}</td>`}<td></td><td></td><td class="num"><b>${money(l.amount)}</b></td></tr>`).join('')
        || '<tr><td colspan="8" class="muted">No invoices for this choice.</td></tr>'}
      </tbody></table></div></div>
    <div class="card"><h3>Commission paid</h3>
      <div class="tablewrap" style="max-height:40vh"><table class="t"><thead><tr><th>Date</th>${st.party ? '' : '<th>Buyer / agent</th>'}<th class="num">Amount</th><th>Sent to</th><th>Via</th><th></th></tr></thead><tbody>
      ${d.payments.map(x => `<tr><td>${dmy(x.date)}</td>${st.party ? '' : `<td>${esc([x.buyer, x.agent && 'Agent ' + x.agent].filter(Boolean).join(' · '))}</td>`}<td class="num"><b>${money(x.amount)}</b></td><td>${esc(x.sent_to)}</td>
        <td>${esc(x.sent_via)}${x.ref ? `<br><span class="hint">${esc(x.ref)}</span>` : ''}${x.notes ? `<br><span class="hint">${esc(x.notes)}</span>` : ''}</td>
        <td><button class="small sec" data-cdel="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="6" class="muted">Nothing paid yet.</td></tr>'}
      </tbody></table></div>
      ${st.party || st.agent ? `<form id="cpay" style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px" autocomplete="off"><h3 style="margin-top:0">Add commission paid — ${esc(who)}</h3>
        <div class="grid g2">
          <label>Date<input name="date" type="date" value="${today()}"></label>
          <label>Amount ₹<input name="amount" type="number" step="0.01"></label>
          <label>Sent to<input name="sent_to" placeholder="Name of the person" value="${esc(st.agent || '')}"></label>
          <label>Sent via<input name="sent_via" list="dl-cvia" placeholder="Cash, UPI, bank…"></label>
          <label>Reference / UTR<input name="ref"></label>
          <label>Note<input name="notes"></label>
        </div>${datalist('dl-cvia', ['CASH', 'UPI', 'BANK TRANSFER', 'CHEQUE'])}
        <div class="row" style="margin-top:10px"><button type="submit">Save payment</button></div></form>` : '<p class="hint" style="margin-top:12px">Choose an agent or a buyer above to add a payment.</p>'}
    </div>
  </div>`}
  <div class="card"><div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;text-align:center">
    <div><span class="hint">Commission on invoices</span><div style="font-size:20px;font-weight:700">₹ ${money(d.commission)}</div></div>
    <div><span class="hint">Expenses</span><div style="font-size:20px;font-weight:700">₹ ${money(d.extra)}</div></div>
    <div><span class="hint">Total to pay</span><div style="font-size:24px;font-weight:800">₹ ${money(d.total)}</div></div>
    <div><span class="hint">Commission paid</span><div style="font-size:24px;font-weight:800;color:#1e6b39">₹ ${money(d.paid)}</div></div>
    <div><span class="hint">Balance to pay</span><div style="font-size:24px;font-weight:800;color:${d.balance > 0 ? '#9A4A2A' : '#1e6b39'}">₹ ${money(d.balance)}</div></div>
  </div><p class="hint" style="text-align:center;margin:8px 0 0">${st.fy ? 'F.Y. ' + esc(st.fy) : 'All years'} · ${who ? esc(who) : 'all agents and buyers'}</p></div>`;
  const re = () => PAGES.commission(el);
  const fy = $('#cfy'); if (fy) fy.onchange = () => { st.fy = fy.value; re(); };
  const pb = $('#cpb'); if (pb) pb.onchange = () => { st.party = pb.value; re(); };
  const ag = $('#cag'); if (ag) ag.onchange = () => { st.agent = ag.value; if (st.party && !d.buyers.find(b => String(b.id) === String(st.party) && (!st.agent || b.agents.includes(st.agent)))) st.party = ''; re(); };
  $('#clock').onclick = () => { S.commPw = null; re(); };
  $('#cexp').onclick = () => downloadCsv(`commission_${st.fy || 'all'}.csv`, d.lines.map(l => ({ date: l.date, invoice: l.firm_code + ' ' + l.inv_no, buyer: l.buyer, agent: l.agent, item: l.item, qty: l.qty, rate: l.rate, commission: l.commission })));
  const cp = $('#cpay'); if (cp) cp.onsubmit = async e => {
    e.preventDefault(); await guard(() => POST('/api/commission/payments', { ...formData(cp), party_id: st.party, agent: st.agent })); toast('Payment saved'); re();
  };
  el.onclick = async e => {
    const b = e.target.closest('[data-cdel]'); if (b && confirm('Remove this payment entry?')) { await guard(() => DEL('/api/commission/payments/' + b.dataset.cdel)); re(); }
    const x = e.target.closest('[data-xdel]'); if (x && confirm('Remove this expense?')) { await guard(() => DEL('/api/commission/extras/' + x.dataset.xdel)); re(); }
  };
  const xa = $('#cxadd'); if (xa) xa.onclick = () => modal('Add expense', `<form id="cxf" autocomplete="off"><div class="grid g3">
      <label>Agent<select name="agent"><option value="">— none —</option>${d.agents.map(a => `<option ${a === st.agent ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
      <label class="span2">Buyer<select name="party_id"><option value="">— none —</option>${d.buyers.map(b => `<option value="${b.id}" ${String(b.id) === String(st.party) ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></label>
      <label>Date<input name="date" type="date" value="${today()}"></label>
      <label class="span2">Description<input name="description" placeholder="e.g. travel, sample, gift"></label>
      <label>Amount ₹<input name="amount" type="number" step="0.01"></label></div>
      <p class="hint">Link the expense to an agent, a buyer, or both. It is added to the amount to be paid.</p><div class="row"><button type="submit">Save expense</button></div></form>`, root => {
    const f = $('#cxf', root);
    // choosing an agent narrows the buyer list to that agent's buyers
    const fill = () => { const a = f.agent.value, cur = f.party_id.value;
      f.party_id.innerHTML = '<option value="">— none —</option>' + d.buyers.filter(b => !a || b.agents.includes(a)).map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('');
      if ([...f.party_id.options].some(o => o.value === cur)) f.party_id.value = cur; };
    f.agent.onchange = fill; fill();
    f.onsubmit = async e => {
      e.preventDefault(); const v = formData(f);
      if (!v.agent && !v.party_id) return toast('Choose the agent or the buyer for this expense.', true);
      await guard(() => POST('/api/commission/extras', v)); toast('Expense saved'); closeModal(); re();
    };
  });
  $('#cimp').onclick = () => importCommissionPayments(st, who, re);
};

// Old commission payments from an Excel (.xlsx) or CSV file: read here on the screen, checked, then saved in one go
async function importCommissionPayments(st, who, after) {
  modal('Import old commission payments', `<p>Choose an Excel (.xlsx) or CSV file. The first row should have headings such as
      <b>Date</b>, <b>Amount</b>, Sent to, Via / Mode, Ref / UTR, Note, and if the file has many agents or buyers, <b>Agent</b> or <b>Buyer</b>.</p>
    ${who ? `<p class="hint">Rows without an Agent / Buyer column are saved for: <b>${esc(who)}</b></p>` : '<p class="hint">Tip: choose the agent (or buyer) first if the file has no Agent / Buyer column.</p>'}
    <input type="file" id="cif" accept=".xlsx,.csv"><div id="cip" style="margin-top:12px"></div>`, root => {
    $('#cif', root).onchange = async e => {
      const file = e.target.files[0]; if (!file) return;
      let rows;
      try { rows = /\.csv$/i.test(file.name) ? parseCsv(await file.text()) : await readXlsx(file); }
      catch (err) { return toast('Could not read the file: ' + err.message, true); }
      const hi = rows.findIndex(r => r.some(c => /date/i.test(String(c))));
      if (hi < 0) return toast('No heading row with "Date" found in the file.', true);
      const head = rows[hi].map(c => String(c || '').trim().toLowerCase());
      const col = re => head.findIndex(h => re.test(h));
      const C = { date: col(/date/), amount: col(/amount|amt/) >= 0 ? col(/amount|amt/) : col(/^rs\b|^paid$|^₹/), agent: col(/agent/), buyer: col(/buyer|party/),
        sent_via: col(/via|mode/), ref: col(/ref|utr|chq|cheque|txn/), notes: col(/note|remark|narration|particular|detail/) };
      C.sent_to = head.findIndex((h, i) => /sent to|paid to|^to$|name|person/.test(h) && !Object.values(C).includes(i));
      if (C.amount < 0) return toast('No "Amount" column found.', true);
      const list = rows.slice(hi + 1).map(r => {
        const g = k => C[k] >= 0 ? r[C[k]] : '';
        return { date: toIsoDate(g('date')), amount: String(g('amount') ?? '').replace(/[^0-9.]/g, ''), agent: g('agent'), buyer: g('buyer'),
          sent_to: g('sent_to'), sent_via: g('sent_via'), ref: g('ref'), notes: g('notes') };
      }).filter(x => x.date || Number(x.amount));
      const bad = list.filter(x => !x.date || !(Number(x.amount) > 0)).length;
      const sum = list.filter(x => x.date && Number(x.amount) > 0).reduce((s, x) => s + (Number(x.amount) || 0), 0);
      $('#cip', root).innerHTML = `<div class="tablewrap" style="max-height:300px"><table class="t"><thead><tr><th>Date</th><th class="num">Amount</th><th>Agent / buyer</th><th>Sent to</th><th>Via</th><th>Ref</th><th>Note</th></tr></thead><tbody>
        ${list.map(x => `<tr ${!x.date || !(Number(x.amount) > 0) ? 'style="background:#fde8e8"' : ''}><td>${x.date ? dmy(x.date) : '<b>?</b>'}</td><td class="num">${money(x.amount)}</td><td>${esc(x.agent || x.buyer || who)}</td>
          <td>${esc(x.sent_to)}</td><td>${esc(x.sent_via)}</td><td>${esc(x.ref)}</td><td>${esc(x.notes)}</td></tr>`).join('')}</tbody></table></div>
        <p><b>${list.length - bad}</b> payments · total ₹ ${money(sum)}${bad ? ` · <span style="color:#b91c1c">${bad} rows without a proper date or amount will be skipped</span>` : ''}. Rows already saved (same date, amount and agent/buyer) are skipped.</p>
        <button id="cigo">Import ${list.length - bad} payments</button>`;
      $('#cigo', root).onclick = async () => {
        const r = await guard(() => POST('/api/commission/payments/bulk', { rows: list, party_id: st.party, agent: st.agent }));
        toast(`${r.added} payments added${r.skipped ? `, ${r.skipped} already there` : ''}${r.errors.length ? `, ${r.errors.length} skipped` : ''}`); closeModal(); after();
      };
    };
  });
}
function toIsoDate(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'number' || /^\d{5}(\.\d+)?$/.test(String(v))) {   // Excel date number
    const d = new Date(Date.UTC(1899, 11, 30) + Math.round(Number(v)) * 86400000); return d.toISOString().slice(0, 10);
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})$/);
  if (m) { const y = m[3].length === 2 ? '20' + m[3] : m[3]; return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
  return '';
}
function parseCsv(text) {
  return text.replace(/\r/g, '').split('\n').filter(l => l.trim()).map(line => {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') q = false; else cur += ch; }
      else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch;
    }
    out.push(cur); return out;
  });
}
// first sheet of an .xlsx file as rows of cells (no extra library: unzip with the browser, read the XML)
async function readXlsx(file) {
  const buf = new Uint8Array(await file.arrayBuffer()), dv = new DataView(buf.buffer);
  let eocd = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('not an .xlsx file');
  const n = dv.getUint16(eocd + 10, true); let p = dv.getUint32(eocd + 16, true);
  const files = {};
  for (let k = 0; k < n; k++) {
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true);
    const off = dv.getUint32(p + 42, true), name = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nl));
    files[name] = { method, csize, off }; p += 46 + nl + el + cl;
  }
  const read = async name => {
    const f = files[name]; if (!f) return null;
    const start = f.off + 30 + dv.getUint16(f.off + 26, true) + dv.getUint16(f.off + 28, true), data = buf.subarray(start, start + f.csize);
    if (f.method === 0) return new TextDecoder().decode(data);
    return await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  };
  const xml = s => new DOMParser().parseFromString(s, 'application/xml');
  const ssx = await read('xl/sharedStrings.xml');
  const shared = ssx ? [...xml(ssx).getElementsByTagName('si')].map(si => [...si.getElementsByTagName('t')].map(t => t.textContent).join('')) : [];
  const sheetName = Object.keys(files).filter(f => /^xl\/worksheets\/sheet\d+\.xml$/.test(f)).sort((a, b) => parseInt(a.match(/\d+/)) - parseInt(b.match(/\d+/)))[0];
  if (!sheetName) throw new Error('no sheet found');
  const doc = xml(await read(sheetName));
  const colIdx = ref => { let c = 0; for (const ch of ref.replace(/\d/g, '')) c = c * 26 + ch.charCodeAt(0) - 64; return c - 1; };
  return [...doc.getElementsByTagName('row')].map(row => {
    const out = [];
    for (const c of row.getElementsByTagName('c')) {
      const t = c.getAttribute('t'), v = c.getElementsByTagName('v')[0];
      let val = t === 'inlineStr' ? [...c.getElementsByTagName('t')].map(x => x.textContent).join('') : v ? v.textContent : '';
      if (t === 's') val = shared[Number(val)] ?? ''; else if (!t || t === 'n') val = val === '' ? '' : Number(val);
      out[colIdx(c.getAttribute('r'))] = val;
    }
    return out;
  });
}

// ----- Security: password to change or cancel saved invoices -----
SETTINGS.security = async (box) => {
  const s = await GET('/api/settings');
  box.innerHTML = `<div class="card" style="max-width:640px"><h3>Invoice edit password</h3>
    <p class="hint">A saved invoice is locked. To change or cancel it (sales invoices and P.P. Enterprise bills), this password is asked.
      ${s.edit_password_set ? '<b style="color:#1e6b39">A password is set.</b>' : '<b style="color:#b45309">No password set yet — saved invoices cannot be changed until you set one.</b>'}</p>
    <form id="pwf" autocomplete="off"><div class="grid g3">
      ${s.edit_password_set ? '<label>Current password<input name="old" type="password"></label>' : ''}
      <label>New password<input name="password" type="password"></label>
      <label>New password again<input name="again" type="password"></label></div>
      <div class="row" style="margin-top:12px"><button type="submit">${s.edit_password_set ? 'Change password' : 'Set password'}</button></div></form></div>`;
  box.insertAdjacentHTML('beforeend', `<div class="card" style="max-width:640px"><h3>🔒 Commission password</h3>
    <p class="hint">Opens the Commission screen. Keep it different from the edit password.
      ${s.comm_password_set ? '<b style="color:#1e6b39">A password is set.</b>' : '<b style="color:#b45309">No password set yet — the Commission screen cannot be opened until you set one.</b>'}</p>
    <form id="cwf" autocomplete="off"><div class="grid g3">
      ${s.comm_password_set ? '<label>Current password<input name="old" type="password"></label>' : ''}
      <label>New password<input name="password" type="password"></label>
      <label>New password again<input name="again" type="password"></label></div>
      <div class="row" style="margin-top:12px"><button type="submit">${s.comm_password_set ? 'Change password' : 'Set password'}</button></div></form></div>`);
  $('#cwf', box).onsubmit = async e => {
    e.preventDefault(); const d = formData(e.target);
    if (d.password !== d.again) return toast('The two new passwords are not the same.', true);
    await guard(() => PUT('/api/comm-password', d)); toast('Commission password saved'); SETTINGS.security(box);
  };
  $('#pwf', box).onsubmit = async e => {
    e.preventDefault(); const d = formData(e.target);
    if (d.password !== d.again) return toast('The two new passwords are not the same.', true);
    await guard(() => PUT('/api/edit-password', d)); toast('Password saved'); SETTINGS.security(box);
  };
};

// ----- Email templates: message bodies for sales invoice, proforma invoice, invoice copy to transporter -----
const TPL_FOR = [['SALE', 'Sales invoice (to buyer)'], ['PROFORMA', 'Proforma invoice'], ['TRANSPORTER', 'Invoice copy to transporter'], ['REMINDER', 'Payment reminder'], ['SAMPLE', 'Sample dispatch (Marketing)'], ['EXP_LATE', 'Order expected — gentle reminder (late)'], ['EXP_SOON', 'Order expected — reminder before the date'], ['COMPANY', 'Company details (to a buyer)']];
const REMINDER_SAMPLE = 'Dear Sir / Madam,\n\nThis is a gentle reminder that the payment for the following invoice(s) is still due:\n\n{Invoice table}\n\nTotal due: {Total due}\n\nKindly arrange the payment at the earliest. Our bank details: {Seller bank details}\nIf you have already paid, please share the payment details and ignore this reminder.\n\nRegards,\n{Seller name}';
SETTINGS.templates = async (box, editId) => {
  const { templates, vars, reminder_vars, sample_vars, exp_vars, company_vars, sample_auto } = await GET('/api/email-templates');
  const cur = templates.find(x => String(x.id) === String(editId)) || null;
  const sample = 'Dear Sir / Madam,\n\nPlease find attached our invoice {Invoice No.} dated {Invoice date} for {Item name} ({Item qty}).\nLorry No.: {Lorry no.}   Driver: {Driver number}\nTransporter: {Transporter name}\n\nRegards,\n{Seller name}';
  const [es, ae] = await Promise.all([GET('/api/email-style'), GET('/api/auto-email')]);
  box.innerHTML = `<div class="card" style="border-left:4px solid ${ae.on ? '#2e9e5b' : '#c9d3d6'}"><h3 style="margin-bottom:6px">⚡ Automatic invoice email</h3>
    <label style="display:flex;gap:10px;align-items:center;font-size:15px;font-weight:600"><input type="checkbox" id="aeon" style="width:auto;transform:scale(1.3)" ${ae.on ? 'checked' : ''}> Send the invoice email by itself when the L.R. copy is attached</label>
    <p class="hint" style="margin:8px 0 0">The email goes to the buyer's email about 10 minutes after the L.R. copy is attached (so all its pages go together), with the default <b>Sales invoice</b> template.
      It carries everything in one email: invoice + e-way bill, L.R. copy, and the transporter's TDS declaration and bank proof when they are due.
      <b>No L.R. copy → no email.</b> Nothing else is ever sent by itself.${ae.on && ae.since ? ` On since ${esc(ae.since)} — only invoices made after that.` : ''}
      Sending by hand (Email to buyer) works as before.</p></div>
  <form id="esf" class="card" autocomplete="off"><h3>✉ Email look <span class="hint">— how every email looks (invoice, proforma, reminder, TDS …)</span></h3>
    <div class="row" style="flex-wrap:wrap;gap:10px;align-items:end">
      <label>Font<select name="font">${RICH_FONTS.map(([v, n]) => `<option value='${v}' ${v === es.font ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label style="width:110px">Text size<select name="size">${[12, 13, 14, 15, 16, 18].map(n => `<option ${n === es.size ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label style="width:110px">Text colour<input type="color" name="color" value="${esc(es.color)}" style="height:36px;padding:2px"></label>
      <label style="width:150px">Logo height (px)<input type="number" name="logo_h" min="24" max="160" value="${es.logo_h}"></label>
      <label style="width:140px">Logo<select name="logo_align"><option value="left" ${es.logo_align !== 'center' ? 'selected' : ''}>Left</option><option value="center" ${es.logo_align === 'center' ? 'selected' : ''}>Centre</option></select></label>
      <label style="display:flex;gap:6px;align-items:center;padding-bottom:8px"><input type="checkbox" name="footer" style="width:auto" ${es.footer ? 'checked' : ''}> Firm address, phone and GSTIN at the bottom</label>
      <button type="submit">Save look</button><button type="button" class="sec" id="esprev">👁 Preview</button></div>
    <p class="hint">Emails go as proper HTML: a white page with your logo at a fixed size, the message in your font, and your firm details at the bottom. A plain-text copy goes along for old mail programs.</p></form>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.4fr);align-items:start">
    <div class="card"><h3>Email templates</h3>
      ${TPL_FOR.map(([k, t]) => `<h4 style="margin:12px 0 4px">${t}</h4>${templates.filter(x => x.purpose === k).map(x => `<div class="row" style="justify-content:space-between;border-bottom:1px solid var(--line);padding:6px 0">
        <span><b>${esc(x.name)}</b>${x.is_default ? ' <span class="badge slate">default</span>' : ''}${x.purpose === 'TRANSPORTER' && x.is_default ? (ae.transporter ? ' <span class="badge amber">⚡ sent by itself</span>' : ' <span class="badge grey">by hand</span>') : ''}${x.purpose === 'SAMPLE' && x.is_default ? (sample_auto ? ' <span class="badge amber">⚡ sent by itself</span>' : ' <span class="badge grey">by hand</span>') : ''}</span>
        <span><button class="small sec" data-ted="${x.id}">Edit</button></span></div>`).join('') || '<p class="hint">None yet — the standard message is used.</p>'}`).join('')}
      <p class="hint" style="margin-top:12px">The proforma invoice template is kept ready for when proforma invoices are added.</p></div>
    <form id="tf" class="card" autocomplete="off"><h3>${cur ? 'Edit template' : 'New template'}</h3>
      <div class="grid g3">
        <label class="span2">Template name<input name="name" value="${esc(cur ? cur.name : '')}"></label>
        <label>Used for<select name="purpose">${TPL_FOR.map(([k, t]) => `<option value="${k}" ${cur && cur.purpose === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      </div>
      <p class="hint" style="margin:10px 0 4px">Click a field to put it in the message where the cursor is:</p>
      <div class="row" id="tvars" style="gap:6px;flex-wrap:wrap"></div>
      <div style="margin-top:10px"><span class="lbl" style="font-weight:600">Message</span> <span class="hint">— set the font, size, bold, colour, paragraphs and lists; the {fields} are filled in when the email is made</span>
        ${richArea('body', cur ? (cur.html || textToHtmlC(cur.body)) : textToHtmlC(sample), 300)}</div>
      <div class="row" style="margin-top:8px"><button type="button" class="sec small" id="tprev">👁 Preview the email</button></div>
      <div id="trauto" class="firmbox" style="margin-top:10px" hidden><label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="traon" style="width:auto" ${ae.transporter ? 'checked' : ''}>
        ⚡ Send the invoice copy to the transporter by itself</label>
        <p class="hint" style="margin:6px 0 0">Off: the transporter gets the invoice copy only when you press “Email to transporter”. On: it goes by itself about 10 minutes after an invoice is saved with all its dispatch details, to the transporter's email (Master → Logistics → Transporters), using the default transporter template. Only invoices made after you switch it on.</p></div>
      <div id="rmauto" class="firmbox" style="margin-top:10px" hidden></div>
      <div id="exauto" class="firmbox" style="margin-top:10px" hidden></div>
      <div id="smauto" class="firmbox" style="margin-top:10px" hidden><label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="smon" style="width:auto" ${sample_auto ? 'checked' : ''}>
        ⚡ Send the sample dispatch email by itself when the tracking number is entered</label>
        <p class="hint" style="margin:6px 0 0">Off: the customer gets it only when you press “✉ Email” on the dispatch (Marketing → Enquiries). On: when a dispatch is saved with a new tracking number (or the number is changed), the email goes to the customer's email about 5 minutes later — so a typing mistake can still be corrected — once for each number, with the default sample template.
        The tracking link comes from Master → Logistics → Postage &amp; Couriers (else the general link in Settings → Marketing). No customer email → nothing is sent.</p>
        <label style="display:flex;gap:8px;align-items:center;font-weight:600;margin-top:10px"><input type="checkbox" name="with_anrep" style="width:auto" ${cur && cur.with_anrep ? 'checked' : ''}> 🧪 Also send the Analysis report with this email</label>
        <p class="hint" style="margin:4px 0 0">The report of each grade sent is chosen by itself from Master → Analysis Reports (only reports not linked to a buyer or group, matched by Item, Colour, Form and Mesh) and attached as a PDF on the sender firm's letter head.
          With this template the “Send analysis report” box of the email is ticked; the automatic email sends it too.</p></div>
      <label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" name="is_default" style="width:auto" ${!cur || cur.is_default ? 'checked' : ''}> Use this template by default</label>

      <div class="row" style="margin-top:12px"><button type="submit">${cur ? 'Save changes' : 'Add template'}</button>${cur ? '<button type="button" class="sec" id="tnew">+ New template</button>' : ''}</div>
      <p class="hint">Item name shows every item (Item1, Item2). Item qty is the total quantity of the invoice. Bank details come as one line: bank – account no. – IFSC.</p></form></div>`;
  $('#aeon', box).onchange = async e => { const r = await guard(() => PUT('/api/auto-email', { on: e.target.checked ? 1 : 0 }));
    toast(r.on ? 'Automatic invoice email is on (only with the L.R. copy)' : 'Automatic invoice email is off'); SETTINGS.templates(box, editId); };
  const ef = $('#esf', box);
  ef.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/email-style', formData(ef))); toast('Email look saved'); };
  $('#esprev', box).onclick = async () => { await guard(() => PUT('/api/email-style', formData(ef))); emailPreview({}); };
  const f = $('#tf', box);
  const showVars = () => { const list = f.purpose.value === 'REMINDER' ? reminder_vars : f.purpose.value === 'SAMPLE' ? sample_vars : /^EXP_/.test(f.purpose.value) ? exp_vars : f.purpose.value === 'COMPANY' ? company_vars : vars;
    $('#tvars', box).innerHTML = list.map(v => `<button type="button" class="small sec" data-var="${esc(v)}">${esc(v)}</button>`).join(''); };
  const trRow = () => { $('#trauto', box).hidden = f.purpose.value !== 'TRANSPORTER'; $('#smauto', box).hidden = f.purpose.value !== 'SAMPLE'; $('#rmauto', box).hidden = f.purpose.value !== 'REMINDER'; if (f.purpose.value === 'REMINDER') reminderAutoBox($('#rmauto', box));
    $('#exauto', box).hidden = !/^EXP_/.test(f.purpose.value); if (/^EXP_/.test(f.purpose.value)) expAutoBox($('#exauto', box), f.purpose.value); };
  showVars(); trRow(); f.purpose.onchange = () => { showVars(); trRow();
    const smDef = templates.find(x => x.purpose === 'SAMPLE' && x.is_default) || templates.find(x => x.purpose === 'SAMPLE');   // a new sample template starts from the cover-letter words
    if (!cur && f.purpose.value === 'SAMPLE' && smDef) richSet(box, 'body', smDef.html || textToHtmlC(smDef.body)); };
  $('#traon', box).onchange = async e => { const r = await guard(() => PUT('/api/auto-email/transporter', { on: e.target.checked ? 1 : 0 }));
    toast(r.transporter ? 'Invoice copy goes to the transporter by itself' : 'Invoice copy to the transporter only by hand'); };
  $('#smon', box).onchange = async e => { const r = await guard(() => PUT('/api/auto-email/sample', { on: e.target.checked ? 1 : 0 }));
    toast(r.on ? 'Sample dispatch email goes by itself when the tracking number is entered' : 'Sample dispatch email only by hand'); };
  richInit(box);
  if (!cur && f.purpose.value === 'REMINDER') richSet(box, 'body', textToHtmlC(REMINDER_SAMPLE));
  $('#tprev', box).onclick = () => emailPreview({ html: f.html.value });
  box.onclick = async e => {
    const v = e.target.closest('[data-var]');
    if (v) richInsert(box, 'body', '{' + v.dataset.var + '}');
    const ed = e.target.closest('[data-ted]'); if (ed) SETTINGS.templates(box, ed.dataset.ted);
  };
  const nw = $('#tnew', box); if (nw) nw.onclick = () => SETTINGS.templates(box);
  f.onsubmit = async e => {
    e.preventDefault(); const d = formData(f);
    await guard(() => cur ? PUT('/api/email-templates/' + cur.id, d) : POST('/api/email-templates', d));
    toast('Template saved'); SETTINGS.templates(box);
  };
};

// the automatic payment reminder switch (inside the Payment reminder template)
async function expAutoBox(el, kind) {
  const r = await GET('/api/exp-mail-settings'), late = kind === 'EXP_LATE', k = late ? 'late' : 'soon';
  el.innerHTML = `<label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="exon" style="width:auto" ${r[k + '_auto'] ? 'checked' : ''}>
      ⚡ Send this reminder by itself</label>
    <div class="row" style="margin-top:6px;gap:8px;align-items:end"><label style="width:auto">${late ? 'Days after the expected date' : 'Days before the expected date'}
      <input type="number" id="exdays" min="0" max="60" style="width:90px" value="${r[k + '_days']}"></label><button type="button" class="sec small" id="exsave">Save days</button></div>
    <p class="hint" style="margin:6px 0 0">The expected date is the one in Reports → Expected Orders (from each buyer's past orders, seasonal buyers included).
      ${late ? `When a buyer's order has <b>not come ${r.late_days} days after</b> the expected date, the buyer gets this gentle reminder (within 30 days after that — a buyer late for longer is reminded only by hand, so switching this on does not email buyers who are months late).` : `<b>${r.soon_days} days before</b> a buyer's expected date, the buyer gets this reminder.`}
      Sent once for each expected date, between 10 am and 7 pm, from the buyer's firm email, with the default template of this kind.
      Not sent to: a buyer with an order already in the Orders Book, a buyer who has stopped buying, our own firms, ONLINE SALE, or a buyer with no email.
      You can also send it by hand: Reports → Expected Orders → “✉ Remind”.</p>`;
  $('#exon', el).onchange = async e => { await guard(() => PUT('/api/exp-mail-settings', { [k + '_auto']: e.target.checked ? 1 : 0 }));
    toast(e.target.checked ? 'This reminder now goes by itself' : 'This reminder only by hand'); expAutoBox(el, kind); };
  $('#exsave', el).onclick = async () => { await guard(() => PUT('/api/exp-mail-settings', { [k + '_days']: $('#exdays', el).value })); toast('Days saved'); expAutoBox(el, kind); };
}
async function reminderAutoBox(el) {
  const r = await GET('/api/auto-email/reminder');
  const money = n => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  el.innerHTML = `<p style="margin:0 0 8px"><b>{Invoice table}</b> <span class="hint">— click this field above to place the table of due invoices anywhere in the message: Sl, invoice date, invoice no., qty, amount, due on and days overdue, with the total.
      One email per buyer lists every due invoice; the invoice PDFs already saved in the invoice folder are attached (an invoice without a saved PDF is still in the table).</span></p>
    <label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="rmon" style="width:auto" ${r.on ? 'checked' : ''}>
      ⚡ Send payment reminders by themselves</label>
    <p class="hint" style="margin:6px 0 0">Set each buyer in Master → Buyer B2B: <b>Payment by</b> (1–45 days) and <b>Send payment reminder = YES</b> (NO = never).
      When an unpaid invoice passes its date (invoice date + those days), the buyer gets one email with all its overdue unpaid invoices — invoice date, number, qty and amount (the {Invoice table}) —
      with our bank proof and the invoice copies attached, using the default Payment reminder template. While it is still not marked received, it is sent again every ${r.every} days.
      Mark payments received in Reports → Payment reminder (click Due) to stop it. ${r.buyers} buyer${r.buyers === 1 ? '' : 's'} set to YES.</p>
    <div class="row" style="margin-top:6px;gap:8px;align-items:end"><label style="width:auto">Only invoices dated from<input type="date" id="rmsince" value="${esc(r.since || '')}"></label>
      <button type="button" class="sec small" id="rmsave">Save date</button></div>
    ${r.on ? `<h4 style="margin:10px 0 4px">Overdue now</h4>${r.plan.length ? `<table class="t"><thead><tr><th>Buyer</th><th>Firm</th><th>Invoices</th><th class="num">Amount</th><th>Next reminder</th></tr></thead><tbody>
      ${r.plan.map(x => `<tr><td>${esc(x.buyer)}${x.email ? '' : ' <span class="badge amber">no email</span>'}</td><td>${esc(x.firm)}</td><td>${esc(x.invoices)}</td><td class="num">${money(x.total)}</td>
        <td>${x.next === 'now' ? '<span class="badge amber">within 10 minutes</span>' : dmy(x.next)}</td></tr>`).join('')}</tbody></table>` : '<p class="hint">No overdue invoice of a buyer set to YES.</p>'}` : ''}`;
  $('#rmon', el).onchange = async e => { const x = await guard(() => PUT('/api/auto-email/reminder', { on: e.target.checked ? 1 : 0 }));
    toast(x.on ? 'Payment reminders go by themselves (invoices from ' + dmy(x.since) + ')' : 'Payment reminders only by hand'); reminderAutoBox(el); };
  $('#rmsave', el).onclick = async () => { await guard(() => PUT('/api/auto-email/reminder', { on: $('#rmon', el).checked ? 1 : 0, since: $('#rmsince', el).value })); toast('Date saved'); reminderAutoBox(el); };
}

// how an email will look (sample firm: Parakh Marketing)
async function emailPreview({ html }) {
  const r = await guard(() => GET('/api/email-style/preview' + (html != null ? '' : '')));
  let page = r.html;
  if (html != null) page = page.replace(/(<tr><td style="padding:16px 28px 22px[^>]*>)[\s\S]*?(<\/td><\/tr>)/, (m, a, b) => a + html + b);
  const w = window.open('', '_blank', 'width=760,height=820'); if (!w) return toast('Allow pop-up windows to see the preview.', true);
  w.document.open(); w.document.write(page); w.document.close();
}

// ----- Universal rules: apply everywhere in the program -----
SETTINGS.rules = async (box) => {
  const r = await GET('/api/rules');
  box.innerHTML = `<form id="rf" class="card" style="max-width:720px" autocomplete="off"><h3>Universal rules</h3>
    <h4 style="margin:6px 0">E-way bill limit</h4>
    <p class="hint">An invoice above this amount cannot be saved without the e-way bill number, lorry no., transporter, L.R. no., freight and plant.</p>
    <div class="grid g2">
      <label>1. Within the state (₹)<input name="ewb_intra" type="number" value="${r.ewb_intra}"></label>
      <label>2. Outside the state (₹)<input name="ewb_inter" type="number" value="${r.ewb_inter}"></label></div>
    <h4 style="margin:16px 0 6px">Mobile number</h4>
    <div class="grid g2"><label>Number of digits<input name="mobile_digits" type="number" value="${r.mobile_digits}"></label>
      <p class="hint" style="align-self:end">Checked in every mobile and driver-phone box (buyers, lorries, transporters, invoices, inward). A leading 0 or 91 is removed.</p></div>
    <div class="row" style="margin-top:14px"><button type="submit">Save rules</button></div></form>`;
  $('#rf', box).onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/rules', formData(e.target))); S.meta = await GET('/api/meta'); toast('Rules saved'); };
};

// ----- Backup & files -----
SETTINGS.backup = async (box) => {
  const s = await GET('/api/settings');
  box.innerHTML = `
  <div class="card"><h3>Backup folder</h3>
    <p class="hint">A full copy of the data is saved here after every new or changed invoice, and every hour. A Google Drive folder on the main PC works well, e.g. <code>G:\\My Drive\\Mineral Saathi Backup</code>.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="bf" value="${esc(s.backup_folder)}"></label><button id="savebf">Save folder</button><button class="sec" id="bnow">Backup now</button></div>
    <p>Last backup: <b>${s.last_backup ? new Date(s.last_backup).toLocaleString('en-IN') : 'not yet'}</b> ${s.last_backup_file ? `<span class="hint">${esc(s.last_backup_file)}</span>` : ''}</p>
    ${s.last_backup_error ? `<p class="badge red">Last error: ${esc(s.last_backup_error)}</p>` : ''}
    <details><summary>Latest backup files (${s.backups.length})</summary><ul>${s.backups.map(b => `<li>${esc(b.name)} <span class="hint">${(b.size / 1048576).toFixed(1)} MB</span></li>`).join('')}</ul></details>
  </div>
  <div class="card"><h3>E-way bill folder <span class="hint">(this computer)</span></h3>
    <p class="hint">The ⬇ JSON button on the invoice saves <b>ewaybill.json</b> here (a copy of every file goes into the <b>old</b> folder inside it). Upload it on the e-way bill portal.</p>
    <div class="row"><label style="flex:1">Folder<input id="ef" value="${esc(s.ewb_folder)}"></label><button id="saveef">Save folder</button></div>
  </div>
  <div class="card"><h3>Invoice PDF folder</h3>
    <p class="hint">A PDF of every invoice is saved here after it is saved (by financial year), named Invoice no_Buyer_to_City_of_Item_by_Firm.pdf, with the e-way bill on the next page.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="pf" value="${esc(s.pdf_folder)}"></label><button id="savepf">Save folder</button></div>
  </div>`;
  $('#savebf').onclick = async () => { await guard(() => PUT('/api/settings', { backup_folder: $('#bf').value })); toast('Backup folder saved'); route(); };
  $('#bnow').onclick = async () => { await guard(() => POST('/api/backup')); toast('Backup saved'); route(); };
  $('#saveef').onclick = async () => { await guard(() => PUT('/api/settings', { ewb_folder: $('#ef').value })); toast('E-way bill folder saved'); };
  $('#savepf').onclick = async () => { await guard(() => PUT('/api/settings', { pdf_folder: $('#pf').value })); toast('PDF folder saved'); };
};

// ----- Import -----
SETTINGS.import = async (box) => {
  box.innerHTML = `<div class="card"><h3>Import data from an old Excel file</h3>
    <p class="hint">Choose a data file prepared from an old billing workbook (for example <b>parakh-fertilizer-data.json</b> or <b>buyer-items-and-rates.json</b>).
      New buyers are added, empty details of existing buyers are filled in, and old invoices are added as view-only. Running it twice does not make duplicates.</p>
    <div class="row"><input type="file" id="impf" accept=".json" style="max-width:420px"><button id="impgo">Import</button></div>
    <div id="imprep" style="margin-top:12px"></div></div>`;
  $('#impgo').onclick = async () => {
    const file = $('#impf').files[0]; if (!file) return toast('Choose the data file first.', true);
    let data; try { data = JSON.parse(await file.text()); } catch { return toast('That file is not a Mineral Saathi data file.', true); }
    const isItems = data.kind === 'mineral-saathi-buyer-items';
    if (!confirm(isItems ? `Import items & rates for ${data.buyers?.length || 0} buyers?` : `Import ${data.buyers?.length || 0} buyers and ${data.invoices?.length || 0} invoices for ${FIRM_NAME[data.firm_code] || '?'}?`)) return;
    const b = $('#impgo'); b.disabled = true; b.textContent = 'Importing…';
    try {
      const r = await POST('/api/import', data); S.parties = null;
      const list = (title, arr) => arr.length ? `<p><b>${title} (${arr.length})</b><br>${arr.map(esc).join('<br>')}</p>` : '';
      if (r.kind === 'items') {
        $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.items_added} items added to ${r.buyers_touched} buyers${r.items_existing ? `, ${r.items_existing} were already there` : ''}.</p>
          ${list('Buyers in the file that are not in Buyers (not added)', r.buyers_not_found)}</div>`;
      } else {
        $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.invoices_added} invoices added${r.invoices_existing ? `, ${r.invoices_existing} were already imported` : ''}.
          ${r.buyers_added.length} new buyers added, ${r.buyers_filled} existing buyers had empty details filled in.</p>
          ${list('New buyers added (billing firm: ' + FIRM_NAME[data.firm_code] + ')', r.buyers_added)}
          ${list('Already in Buyers but linked to the other firm — check in Buyers', r.buyers_other_firm)}
          ${list('Already in Buyers with no firm set — set it in Buyers', r.buyers_no_firm)}
          ${list('Invoice numbers NOT imported because a new invoice with that number already exists', r.invoices_skipped)}</div>`;
      }
      toast('Import finished');
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = 'Import';
  };
};

// ----- Updates -----
SETTINGS.updates = async (box, sub) => {
  box.innerHTML = `<div class="card"><h3>Automatic updates</h3><div id="upd"></div></div>
    <div class="card" id="startcard"><h3>Start when Windows starts</h3><div id="startbox" class="hint">Checking…</div></div>`;
  startSection($('#startbox', box));
  if (sub === 'start') setTimeout(() => $('#startcard', box).scrollIntoView({ block: 'start' }), 100);
  const showUpd = u => {
    $('#upd').innerHTML = `<p>Installed version <b>${esc(u.current)}</b>${u.latest ? ` · newest available <b>${esc(u.latest)}</b>` : ''}
      ${u.last_check ? `<span class="hint"> · last checked ${new Date(u.last_check).toLocaleString('en-IN')}</span>` : ''}</p>
      ${u.message ? `<p class="firmbox">${esc(u.message)}</p>` : ''}
      <p class="hint">The main PC checks for a new version every 30 minutes and installs it by itself when nobody has saved anything for 5 minutes.
        It takes a backup first and never touches your data. All PCs switch to the new version automatically.</p>
      <div class="row"><label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text)"><input type="checkbox" id="updauto" style="width:auto" ${u.auto ? 'checked' : ''}> Install updates automatically</label>
        <span class="spacer"></span><button class="sec" id="updcheck">Check now</button><button id="updnow">Install update now</button></div>`;
    $('#updauto').onchange = async () => showUpd(await guard(() => PUT('/api/update/settings', { auto: $('#updauto').checked })));
    $('#updcheck').onclick = async () => { $('#updcheck').textContent = 'Checking…'; showUpd(await guard(() => POST('/api/update/check', { install: false }))); };
    $('#updnow').onclick = async () => {
      $('#updnow').textContent = 'Installing…'; $('#updnow').disabled = true;
      const r = await guard(() => POST('/api/update/check', { install: true }));
      if (r.installing) { toast(`Installing version ${r.installing} — the app will reload in a few seconds`); setTimeout(() => location.reload(), 9000); }
      else showUpd(r);
    };
  };
  showUpd(await GET('/api/update'));
};

// ----- About -----
SETTINGS.about = async (box) => {
  box.innerHTML = `<div class="card" style="display:flex;gap:20px;align-items:center"><img src="logo-icon.png" style="width:96px;border-radius:18px">
    <div><h3 style="margin:0 0 6px">Mineral Saathi</h3><p style="margin:0">Version <b>${esc(S.meta.version)}</b> · billing for P.P. Enterprise, Parakh Marketing and Parakh Fertilizer.</p>
    <p class="hint">Every PC loads the screens from the main PC (${esc(S.meta.host)}), so updating the main PC updates all PCs automatically.</p></div></div>`;
};

// ---------- misc ----------
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key.toLowerCase() === 'n' && $('#modal').hidden) {
    e.preventDefault();
    if (location.hash.startsWith('#/inward')) $('#newin')?.click(); else go('#/newinvoice');
  }
});

$('#fsbtn').onclick = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => {});
// backup state under the clock: green "Backup done" / red "Error in backup" — a click opens Backup settings
async function backupState() {
  const b = $('#bkst'); if (!b) return;
  try { const r = await GET('/api/backup-status');
    b.textContent = r.error ? 'Error in backup' : r.last ? 'Backup done' : 'No backup yet'; b.style.color = r.error || !r.last ? 'var(--bad)' : 'var(--ok)';
    b.title = r.error ? r.error : r.last ? 'Last backup: ' + new Date(r.last).toLocaleString('en-IN') : ''; } catch { /* offline */ }
}
setTimeout(backupState, 1500); setInterval(backupState, 120e3);
setInterval(() => { if (!$('#clock')) return; $('#clock').textContent = new Date().toLocaleString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); }, 1000);

// Auto-update: when the main PC gets a new version, every PC reloads it.
async function checkVersion() {
  if (!$('#sidefoot')) return;          // closed for today
  try {
    const { version } = await GET('/api/version');
    if (S.version && version !== S.version) {
      if (!S.dirty && $('#modal').hidden) location.reload();
      else { const b = $('#banner'); b.hidden = false; b.innerHTML = `New version ${esc(version)} is installed. Save your work, then <button class="sec small" onclick="location.reload()">Reload now</button>`; }
    }
    const u = await GET('/api/update').catch(() => null);
    versionLine(version, u);
  } catch { const sf = $('#sidefoot'); sf.textContent = '⚠ Main PC not reachable'; sf.style.color = ''; sf.style.fontWeight = ''; }
}
// bottom-left version line: green = newest installed, red = a new version is out. Double-click = check and install now.
const verNewer = (a, b) => { const x = String(a || '').split('.').map(Number), y = String(b || '').split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
function versionLine(version, u) {
  const sf = $('#sidefoot'); if (!sf) return;
  const out = u && u.latest && verNewer(u.latest, version), known = u && u.latest;
  sf.innerHTML = out ? `Version ${esc(version)} · <b>update ${esc(u.latest)} available</b>` : `Version ${esc(version)} · ${known ? 'latest' : 'connected'}`;
  sf.style.color = out ? '#ff7b7b' : known ? '#5fe08a' : ''; sf.style.fontWeight = known ? '700' : '';
  sf.style.cursor = 'pointer'; sf.style.userSelect = 'none';
  sf.title = (out ? `Version ${u.latest} is out — ` : known ? 'This is the newest version — ' : '') + 'double-click to check for an update and install it'
    + (u && u.last_check ? `\nLast checked: ${new Date(u.last_check).toLocaleString('en-IN')}` : '');
  if (sf.dataset.hooked) return; sf.dataset.hooked = '1';
  sf.ondblclick = async () => {
    if (sf.dataset.busy) return; sf.dataset.busy = '1';
    sf.textContent = 'Checking for update…'; sf.style.color = '';
    try {
      const r = await POST('/api/update/check', { install: true });
      if (r.installing) { sf.textContent = `Installing version ${r.installing}…`; sf.style.color = '#5fe08a'; toast(`Installing version ${r.installing} — the app will reload in a few seconds`); setTimeout(() => location.reload(), 9000); return; }
      toast(r.message || 'Checked', /Update:|missing/.test(r.message || ''));
      versionLine(r.current, r);
    } catch (e) { toast(e.message, true); checkVersion(); }
    finally { delete sf.dataset.busy; }
  };
}

(async function start() {
  try {
    S.meta = await GET('/api/meta');
  } catch (e) {
    $('#page').innerHTML = `<div class="card"><h3>Cannot reach the main PC</h3><p>${esc(e.message)}</p><button onclick="location.reload()">Try again</button></div>`; return;
  }
  S.version = S.meta.version;
  // closing this window on the main PC (data in Google Drive) = "Close for today"
  S.pageId = Math.random().toString(36).slice(2);
  POST('/api/hello', { page: S.pageId }).catch(() => {});
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/bye?page=' + S.pageId, JSON.stringify({ page: S.pageId })); } catch { } });
  if (S.meta.shared) {
    const b = document.createElement('button'); b.className = 'ghost'; b.textContent = '⏻ Close for today';
    b.style.cssText = 'color:#f3c9a8;font-size:13px;margin:6px 10px;text-align:left'; b.onclick = closeForToday;
    $('#side').insertBefore(b, $('#sidefoot'));
  }
  S.fy = localStorage.getItem('ms_fy') && S.meta.fys.includes(localStorage.getItem('ms_fy')) ? localStorage.getItem('ms_fy') : S.meta.current_fy;
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  $('#fy').innerHTML = fys.map(f => `<option ${f === S.fy ? 'selected' : ''}>${f}</option>`).join('');
  $('#fy').onchange = () => { S.fy = $('#fy').value; try { localStorage.setItem('ms_fy', S.fy); } catch { } route(); };
  checkVersion(); setInterval(checkVersion, 60000);
  route();
})();
