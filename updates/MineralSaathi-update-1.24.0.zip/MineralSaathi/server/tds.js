'use strict';
// Transporter TDS declaration (section 194C(6)): made on behalf of the transporter, once every financial
// year for every buyer that got an invoice carried by that transporter. Sent to the transporter and to the buyer.
const { all, get, run, setting } = require('./db');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dmy = iso => iso ? iso.split('-').reverse().join('/') : '';

const DEFAULTS = {
  tds_subject_transporter: 'TDS declaration u/s 194C(6) — {transporter} to {buyer} — F.Y. {fy}',
  tds_body_transporter: `Dear Sir,

Please find attached the declaration under section 194C(6) of the Income Tax Act for non-deduction of tax at source, for F.Y. {fy}, made on your behalf for our buyer:

{buyer}, {buyer_city}

A copy of your PAN card is attached with the declaration. The same declaration has been sent to the buyer.

Regards,
{firm}`,
  tds_subject_buyer: 'TDS declaration u/s 194C(6) of transporter {transporter} (PAN {pan}) — F.Y. {fy}',
  tds_body_buyer: `Dear Sir / Madam,

Our goods to you are carried by the transporter {transporter} (PAN {pan}).
Please find attached the transporter's declaration under section 194C(6) of the Income Tax Act for non-deduction of tax at source on freight, for F.Y. {fy}, with a copy of the PAN card.

Kindly do not deduct TDS on the freight paid to this transporter for F.Y. {fy}.

Regards,
{firm}`
};
const template = k => setting(k) || DEFAULTS[k];
function templates() { return Object.fromEntries(Object.keys(DEFAULTS).map(k => [k, template(k)])); }

const findTransporter = name => name ? get('SELECT * FROM transporters WHERE upper(trim(name)) = upper(trim(?))', name) : null;

// the certificate of (F.Y., transporter, buyer); made from the first invoice of that year if it is not there yet
function ensure(fy, trId, partyId) {
  let c = get('SELECT * FROM tds_certs WHERE fy = ? AND transporter_id = ? AND party_id = ?', fy, trId, partyId);
  if (c) return c;
  const tr = get('SELECT name FROM transporters WHERE id = ?', trId);
  const first = tr && get(`SELECT id, date, firm_code FROM invoices WHERE fy = ? AND party_id = ? AND cancelled = 0 AND kind = 'SALE'
                           AND upper(trim(transporter)) = upper(trim(?)) ORDER BY date, id LIMIT 1`, fy, partyId, tr.name);
  if (!first) return null;
  run('INSERT INTO tds_certs(fy, transporter_id, party_id, cert_date, first_invoice_id, firm_code) VALUES(?,?,?,?,?,?)', fy, trId, partyId, first.date, first.id, first.firm_code);
  return get('SELECT * FROM tds_certs WHERE fy = ? AND transporter_id = ? AND party_id = ?', fy, trId, partyId);
}

function data(certId) {
  const c = get('SELECT * FROM tds_certs WHERE id = ?', certId);
  if (!c) return null;
  const tr = get('SELECT * FROM transporters WHERE id = ?', c.transporter_id);
  const party = get('SELECT * FROM parties WHERE id = ?', c.party_id);
  const last = get(`SELECT firm_code FROM invoices WHERE fy = ? AND party_id = ? AND cancelled = 0 AND upper(trim(transporter)) = upper(trim(?)) ORDER BY date DESC, id DESC LIMIT 1`, c.fy, c.party_id, tr ? tr.name : '');
  const firm = get('SELECT * FROM firms WHERE code = ?', (last && last.firm_code) || c.firm_code || party.firm_code || 'PM');
  return { c, tr, party, firm };
}

function fill(text, d) {
  const v = {
    transporter: d.tr.name, pan: d.tr.pan || '', proprietor: d.tr.proprietor || d.tr.contact || '', fy: d.c.fy, buyer: d.party.name,
    buyer_city: [d.party.city, d.party.state].filter(Boolean).join(', '), firm: d.firm ? d.firm.name : ''
  };
  return String(text || '').replace(/\{(\w+)\}/g, (m, k) => (k in v ? v[k] : m));
}

// what is missing to make or send the certificate
function problems(d, who) {
  const p = [];
  if (!d.tr.pan_card) p.push('PAN card of the transporter (Masters → Transporters)');
  if (!d.tr.pan) p.push('PAN of the transporter');
  if (!d.tr.proprietor && !d.tr.contact) p.push("name of the transporter's proprietor / partner (declarant)");
  if (who === 'transporter' && !d.tr.email) p.push("transporter's email");
  if (who === 'buyer' && !d.party.email) p.push("buyer's email");
  return p;
}

// ---- the printable declaration (A4), laid out like the transporter's own declaration ----
function html(d, opts = {}) {
  const { c, tr, party } = d;
  const date = dmy(c.cert_date);
  const place = (tr.district || tr.state || 'JODHPUR').toUpperCase();
  const name = esc(tr.name.toUpperCase());
  const who = esc((tr.proprietor || tr.contact || '____________________').toUpperCase());   // declarant: proprietor, else the contact person
  const pan = esc(tr.pan || '__________');
  const trAddr = [tr.address, tr.district, tr.state].filter(Boolean).join(', ').toUpperCase();
  const phones = [tr.mobile, tr.phone].filter(Boolean).join(',');
  const buyerAddr = esc(party.address || '').replace(/\n/g, '<br>');
  const buyerPlace = [party.city, party.state].filter(Boolean).join(', ').toUpperCase();
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(tr.name)} to ${esc(party.name)} TDS ${esc(c.fy)}</title><style>
@page { size: A4; margin: 0; }
* { box-sizing: border-box; }
body { margin: 0; font-family: Calibri, "Segoe UI", Arial, sans-serif; color: #000; font-size: 14.5px; line-height: 1.42; }
.sheet { width: 210mm; height: 297mm; padding: 11mm 14mm 10mm 15mm; position: relative; background: #fff; overflow: hidden; display: flex; flex-direction: column; }
.top { font-weight: 700; font-size: 13.5px; line-height: 1.3; }
.top span { display: inline-block; width: 62px; text-align: right; margin-right: 4px; }
.nm { text-align: center; font-size: 30px; font-weight: 800; margin: 4px 0 0; letter-spacing: .3px; }
.ad { text-align: center; font-weight: 700; font-size: 12.5px; } .ph { text-align: center; font-size: 12.5px; }
.date { text-align: right; margin-top: 10px; font-weight: 700; } .date i { display: inline-block; min-width: 150px; border-bottom: 1px solid #000; text-align: center; margin-left: 20px; }
.ttl { text-align: center; font-weight: 700; margin: 6px 0 10px; }
.to b.big { font-size: 20px; display: block; margin-top: 4px; } .to .a { font-weight: 700; font-size: 13px; }
.dh { text-align: center; font-weight: 700; font-size: 19px; text-decoration: underline; margin: 6px 0 4px; }
ol { margin: 6px 0 8px; padding-left: 52px; } ol li { margin: 3px 0; } ol li::marker { font-weight: 700; }
.pd { display: grid; grid-template-columns: 70px 1fr auto; font-weight: 700; margin: 2px 0 0 10px; }
.vh { text-align: center; font-weight: 700; font-size: 16px; margin-top: 8px; }
.foot { margin: 8px 0 0 10px; }
.panw { flex: 1 1 auto; min-height: 0; display: flex; justify-content: flex-end; align-items: flex-end; padding-top: 4mm; }
.pan { max-width: 92mm; max-height: 100%; border: 1px solid #ccc; }
.no-print { background: #1A3E4A; padding: 10px; text-align: center; } .no-print button { font-size: 14px; padding: 8px 16px; background: #1A9BB5; color: #fff; border: 0; border-radius: 6px; margin: 0 4px; cursor: pointer; }
@media screen { body { background: #e7edef; } .sheet { margin: 10px auto; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
@media print { .no-print { display: none; } }
${opts.shot ? 'html, body { background: #fff !important; } .sheet { margin: 0 !important; box-shadow: none !important; } .no-print { display: none !important; }' : ''}
</style></head><body>
${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
<div class="sheet">
  <div class="top"><div><span>PAN</span>${pan}</div>${tr.gstin ? `<div><span>GST NO</span>${esc(tr.gstin)}</div>` : ''}</div>
  <div class="nm">${name}</div>
  <div class="ad">${esc(trAddr)}</div>
  ${phones ? `<div class="ph">PH-${esc(phones)}</div>` : ''}
  <div class="date">Date <i>${date}</i></div>
  <div class="ttl">Declaration under section 194C (6) for Non-deduction of tax at source</div>
  <div class="to"><b>To</b><b class="big">${esc(party.name.toUpperCase())}</b><div class="a">${buyerAddr}${buyerPlace ? '<br>' + esc(buyerPlace) : ''}</div></div>
  <div class="dh">Declaration</div>
  <div>I, ${who} Proprietor / partner / Director of ${name} (name and address of payee) [hereinafter “the contractor”] do hereby makes the following declaration as required by sub section (6) of section 194C of the Income tax Act, 1961 for receiving payment from the payer without deduction of tax at source. under Sec 393(4)(a)</div>
  <ol>
    <li>That I/We am/are authorized to make this declaration in the capacity as proprietor / partner / director</li>
    <li>That the contractor is engaged by the payer for plying, hiring or leasing of goods carriage for its business</li>
    <li>That the contractor does not own more than 10 goods carriage as on date.</li>
    <li>That if the number of goods carriage * owned by the contractor exceeds ten at any time during this year ${esc(c.fy)} ( i.e..,APRIL TO MARCH) or after furnishing this declaration , the contractor shall forthwith , in writing intimate the payer of this fact.</li>
    <li>That the income tax Permanent Account Number (PAN) of the contractor is ${pan}. A self-attested photocopy of the PAN is furnished to the payer along with this declaration.</li>
  </ol>
  <div class="pd"><span>PLACE</span><span>${esc(place)}</span><span></span></div>
  <div class="pd"><span>DATE</span><span>${date}</span><span>Declarant</span></div>
  <div class="vh">VERIFICATION</div>
  <div>I, the above named declared do hereby verify that the contents of the above paragraphs one to five are true to the best of my knowledge and belief, and no part of it is false and nothing material has been declared concealed in it</div>
  <div class="pd" style="margin-top:4px"><span>PLACE</span><span>${esc(place)}</span><span></span></div>
  <div class="pd"><span>DATE</span><span>${date}</span><span>Name of Declarant</span></div>
  <div class="foot">*Goods carriage means any motor vehicle constructed or adapted for use solely for the carriage of goods , or any motor vehicle not so constructed or adapted when used for the carriage [Explanation (a) to subsection (7) of section 44AE read with explanation (ii) of section 194C and section 2 of the Motor Vehicle Act , 1988]</div>
  <div class="panw">${tr.pan_card ? `<img class="pan" src="${tr.pan_card}" alt="PAN card">` : ''}</div>
</div>${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

// list for Reports → Transporter TDS: every transporter + buyer pair with invoices in the year
function list(fy) {
  return all(`SELECT t.id AS transporter_id, t.name AS transporter, t.pan, t.email AS tr_email, COALESCE(NULLIF(t.proprietor,''), t.contact) AS proprietor,
      CASE WHEN COALESCE(t.pan_card,'') = '' THEN 0 ELSE 1 END AS has_pan_card,
      p.id AS party_id, p.name AS buyer, p.city, p.state, p.email AS buyer_email,
      COUNT(i.id) AS invoices, MIN(i.date) AS first_date, MAX(i.date) AS last_date, ROUND(SUM(i.total)) AS total,
      c.id AS cert_id, c.cert_date, c.sent_transporter_at, c.sent_buyer_at, c.last_error
    FROM invoices i
    JOIN transporters t ON upper(trim(t.name)) = upper(trim(i.transporter))
    JOIN parties p ON p.id = i.party_id
    LEFT JOIN tds_certs c ON c.fy = i.fy AND c.transporter_id = t.id AND c.party_id = p.id
    WHERE i.fy = ? AND i.cancelled = 0 AND i.kind = 'SALE'
    GROUP BY t.id, p.id ORDER BY t.name, p.name`, fy);
}

module.exports = { DEFAULTS, templates, template, ensure, data, fill, problems, html, list, findTransporter };
