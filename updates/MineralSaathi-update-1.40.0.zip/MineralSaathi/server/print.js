'use strict';
// Printable pages (A4). The app opens these to print or save as PDF; email uses them to make the PDF.
const { get } = require('./db');
const { inWords, freightFigures, freightRate, r2, bankUpi } = require('./logic');
const qr = require('./qr');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const qty = n => { const v = Math.round((Number(n) || 0) * 1000) / 1000; return v.toLocaleString('en-IN', Number.isInteger(v) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 3, maximumFractionDigits: 3 }); };   // 35 or 21.500
const dmy = iso => iso ? iso.split('-').reverse().join('.') : '';
const nl = s => esc(s).replace(/\n/g, '<br>');

const BASE_CSS = `
* { box-sizing: border-box; }
body { font-family: "Segoe UI", Arial, sans-serif; font-size: 11.5px; color: #1d2b31; margin: 0; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #2F4F5A; padding: 4px 6px; vertical-align: top; }
th { background: #e8f1f3; font-weight: 600; text-align: left; }
.r { text-align: right; } .c { text-align: center; }
.head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #9A4A2A; padding-bottom: 6px; margin-bottom: 6px; }
.firm { font-size: 24px; font-weight: 800; color: #2F4F5A; letter-spacing: .5px; }
.muted { color: #5b6b70; }
.title { font-size: 15px; font-weight: 700; color: #9A4A2A; text-align: right; }
.box { border: 1px solid #2F4F5A; padding: 6px 8px; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 6px; }
.lbl { color: #5b6b70; font-size: 10px; text-transform: uppercase; letter-spacing: .4px; }
.big { font-size: 13px; font-weight: 700; }
.tot td { font-weight: 700; background: #f4ece7; white-space: nowrap; }
.sign { height: 60px; }
.no-print { background: #1A3E4A; padding: 10px; margin-bottom: 14px; text-align: center; }
.no-print button { font-size: 14px; padding: 8px 16px; background: #1A9BB5; color: #fff; border: 0; border-radius: 6px; cursor: pointer; margin-left: 6px; }
@media print { .no-print { display: none; } }
/* A4 invoice: bigger type, spread over the whole page */
.invp { display: flex; flex-direction: column; font-size: 13.5px; line-height: 1.38; }
.invp td, .invp th { padding: 5px 8px; }
.invp .firm { font-size: 31px; } .invp .title { font-size: 20px; } .invp .big { font-size: 16px; }
.invp .lbl { font-size: 11px; } .invp .copyl { font-size: 11px; font-weight: 700; letter-spacing: .6px; color: #5b6b70; }
.invp .head { padding-bottom: 8px; margin-bottom: 8px; }
.invp .grid2 { gap: 8px; margin-bottom: 8px; }
.invp .box { padding: 8px 10px; }
.invp .kv td { border: 0; padding: 3px 6px; } .invp .kv td:nth-child(odd) { white-space: nowrap; color: #44575d; } .invp .kv td:nth-child(2) { white-space: nowrap; }
.invp .head > div:last-child { white-space: nowrap; padding-left: 12px; }
.invp .grow { flex: 1 1 auto; display: flex; min-height: 0; }
.invp .items { height: 100%; }
.invp .items tbody tr:not(.fill) { height: 1px; }
.invp .items td { border-top-color: #c9d6da; border-bottom-color: #c9d6da; }
.invp .items .fx td { border-top-color: #2F4F5A; }
.invp .words, .invp .hsn, .invp .freight, .invp .foot, .invp .bankbox { margin-top: 8px; }
.invp .bankd { margin-top: 8px; padding-top: 6px; border-top: 1px dashed #9aa; font-size: 12.5px; }
.invp .freight { font-size: 14px; background: #fbf7f4; }
.invp .foot { display: grid; grid-template-columns: 1.5fr 1fr; gap: 8px; }
.invp .foot.withqr { grid-template-columns: 1.35fr 150px 1fr; }
.invp .qrbox { text-align: center; padding: 6px; overflow-wrap: anywhere; } .invp .qrbox svg { display: block; margin: 2px auto; }
.invp .terms { font-size: 12px; } .invp .sigbox { display: flex; flex-direction: column; justify-content: space-between; } .invp .sign { height: 70px; }
`;

// the firm's signature (Settings → Companies), on its invoices and vouchers
const signTag = f => f.signature && /^data:image\/(png|jpeg|webp);base64,/.test(f.signature) ? `<img src="${f.signature}" style="max-height:62px;max-width:180px">` : '';
const logoTag = f => f.logo && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo) ? `<img src="${f.logo}" style="max-height:62px;max-width:150px">` : '';

// ---- page setup: paper size, margin, nudge and scale (Settings > This computer > Printers) ----
const PAPERS = {
  A4: [210, 297], A5: [148, 210], LETTER: [215.9, 279.4], LABEL4X6: [101.6, 152.4],
  ENV_DL: [220, 110], ENV_C5: [229, 162], ENV_10: [241, 105]
};
const DEFAULT_SETUP = {
  invoice: { paper: 'A4', w: 210, h: 297, margin: 10, ox: 0, oy: 0, scale: 100 },
  label: { paper: 'LABEL4X6', w: 101.6, h: 152.4, margin: 3, ox: 0, oy: 0, scale: 100 },
  envelope: { paper: 'ENV_DL', w: 220, h: 110, margin: 8, ox: 0, oy: 0, scale: 100 }
};
function setupFor(kind, s) {
  const d = { ...DEFAULT_SETUP[kind], ...(s || {}) };
  if (d.paper && PAPERS[d.paper]) { const [w, h] = PAPERS[d.paper]; d.w = w; d.h = h; }
  if (d.landscape) { const a = Math.max(d.w, d.h), b = Math.min(d.w, d.h); d.w = a; d.h = b; }
  for (const k of ['w', 'h', 'margin', 'ox', 'oy', 'scale']) d[k] = Number(d[k]) || (k === 'scale' ? 100 : 0);
  return d;
}
function sheetCss(s, shot) {
  const sc = (s.scale || 100) / 100;
  return `@page { size: ${s.w}mm ${s.h}mm; margin: 0; }
.sheet { width: ${s.w}mm; height: ${s.h}mm; padding: ${s.margin}mm; overflow: hidden; position: relative; background: #fff; break-after: page; page-break-after: always; }
.sheet:last-of-type { break-after: auto; page-break-after: auto; }
.inner { width: ${(s.w - 2 * s.margin) / sc}mm; transform: translate(${s.ox}mm, ${s.oy}mm) scale(${sc}); transform-origin: top left; }
@media screen { body { background: #e7edef; } .sheet { margin: 10px auto; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
${shot ? 'html, body { background: #fff !important; } .sheet { margin: 0 !important; box-shadow: none !important; } .no-print { display: none !important; }' : ''}`;
}

function shell(title, sheets, opts = {}) {
  const s = opts.setup;
  const pages = (Array.isArray(sheets) ? sheets : [sheets]).map(b => `<div class="sheet"><div class="inner">${b}</div></div>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${BASE_CSS}${sheetCss(s, opts.shot)}</style></head>
<body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
${pages}${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

// Copies: one copy when the invoice is 9 MT or more, otherwise two (original + duplicate).
function invoiceCopies(inv, singleFromMt = 9) {
  if (inv.pf_source_id) return ['ORIGINAL FOR RECIPIENT', 'DUPLICATE FOR TRANSPORTER'];   // Parakh Marketing → Parakh Fertilizer: always 2
  const total = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);
  return total >= singleFromMt ? ['ORIGINAL FOR RECIPIENT'] : ['ORIGINAL FOR RECIPIENT', 'DUPLICATE FOR TRANSPORTER'];
}

// "Ship to" block: shown when the goods go to a delivery address (godown) other than the registered address
function shipTo(inv) {
  if (!inv.ship_address && !inv.ship_name) return '';
  const place = [inv.ship_city, inv.ship_pincode].filter(Boolean).join(' - ');
  const st = inv.ship_state ? esc(inv.ship_state) + (inv.ship_state_code ? ' (Code ' + esc(inv.ship_state_code) + ')' : '') : '';
  return `<div style="margin-top:5px;padding-top:4px;border-top:1px dashed #9aa"><span class="lbl">Ship to / Delivery at</span>
    ${inv.ship_name ? `<div><b>${esc(inv.ship_name)}</b></div>` : ''}${nl(inv.ship_address || '')}${place ? '<br>' + esc(place) : ''}${st ? (place ? ', ' : '<br>') + st : ''}
    ${Number(inv.trans_type) === 2 || Number(inv.trans_type) === 4 ? '<div class="muted" style="font-size:9px">E-way bill: Bill To - Ship To</div>' : ''}</div>`;
}

function invoiceHtml(inv, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const setup = setupFor('invoice', opts.setup);
  const f = inv.firm;
  const intra = !(inv.igst > 0);
  const isPpe = inv.kind === 'PPE_BILL';
  const rows = inv.items.map(it => {
    const desc = [`<b>${esc(it.item_name)}</b>`];
    if (it.grade) desc.push(esc(it.grade));
    if (isPpe) desc.push(`Lorry ${esc(it.lorry_no || '')}${it.rawana_no ? ' · Rawana ' + esc(it.rawana_no) : ''}${it.challan_no ? ' · Challan ' + esc(it.challan_no) : ''}`);
    const pack = [
      (it.bags || it.pack_size) ? `${it.bags ? esc(it.bags) + ' bags' : ''}${it.pack_size ? ' × ' + esc(it.pack_size) + ' kg' : ''}` : '',
      it.bag_type ? esc(it.bag_type) : '',
      it.packing_type ? esc(it.packing_type) : '',
      it.liner === 1 ? 'with liner' : it.liner === 0 ? 'without liner' : '',
      it.bag_supply === 'BUYER' ? "in buyer's own bags" : ''
    ].filter(Boolean).join(' · ');
    if (pack) desc.push(pack);
    if (it.lot_no) desc.push(`Lot No.: <b>${esc(it.lot_no)}</b>`);
    const pl = it.plant || (!isPpe && inv.plant);           // for our own use only: very small
    if (pl && !isPpe) desc.push(`<span style="font-size:7.5px;color:#8a979b;letter-spacing:.3px">${esc(pl)}</span>`);
    return `<tr><td class="c">${it.sl}</td><td>${desc.join('<br>')}</td><td class="c">${esc(it.hsn)}</td><td class="r">${qty(it.qty)}</td>
      <td class="c">${esc(it.unit)}</td><td class="r">${money(it.rate)}</td><td class="c">${it.gst_rate}%</td><td class="r">${money(it.amount)}</td></tr>`;
  }).join('');
  const totalQty = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);

  // HSN summary
  const hsn = {};
  for (const it of inv.items) {
    const k = it.hsn + '|' + it.gst_rate;
    hsn[k] = hsn[k] || { hsn: it.hsn, rate: it.gst_rate, taxable: 0 };
    hsn[k].taxable += it.amount;
  }
  const hsnRows = Object.values(hsn).map(h => {
    const tax = r2(h.taxable * h.rate / 100);
    return `<tr><td>${esc(h.hsn)}</td><td class="r">${money(h.taxable)}</td>
      ${intra ? `<td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td><td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td>`
        : `<td class="r">${h.rate}%</td><td class="r">${money(tax)}</td>`}<td class="r">${money(tax)}</td></tr>`;
  }).join('');

  const bank = [f.bank_name && `Bank: ${esc(f.bank_name)}`, f.bank_account && `A/c: ${esc(f.bank_account)}`, f.bank_ifsc && `IFSC: ${esc(f.bank_ifsc)}`, f.upi_id && `UPI: ${esc(f.upi_id)}`].filter(Boolean).join(' · ');

  // freight line: "Freight Rs.2600 per Metric Ton · Total Freight Approx Rs.(rate × qty)"
  const freightLine = (() => {
    const n = String(inv.freight_note || '').trim(), mode = String(inv.freight_mode || '').trim();
    if (!n && !mode) return '';
    const rate = freightRate(n);
    const modeTxt = mode ? ` &nbsp;·&nbsp; Freight: <b>${esc(mode)}</b>` : '';
    if (!(rate > 0) || isPpe) return n && !/^(paid|to\s*pay)$/i.test(n) ? `<b>Freight:</b> ${esc(n)}${modeTxt}` : `<b>Freight:</b> ${esc(mode || n.toUpperCase())}`;
    const total = inv.freight_total > 0 ? inv.freight_total : rate * totalQty;
    return `<b>Freight Rs.${esc(rate.toLocaleString('en-IN'))} per Metric Ton</b> &nbsp;·&nbsp; Total Freight Approx <b>Rs.${money(total)}</b>${modeTxt}`;
  })();

  const payUpi = String(f.upi_id || '').trim() || bankUpi(f.bank_account, f.bank_ifsc) || '';
  // UPI QR: pay this invoice's exact amount; the transaction note has the invoice no. and the firm
  const upiQr = (() => {
    if (isPpe || inv.cancelled || !payUpi || !(inv.total > 0)) return '';
    const firmTag = String(f.name || '').replace(/[^A-Za-z]/g, '');
    const note = inv.is_proforma ? `PI ${inv.pi_no} ${firmTag}` : `Inv ${inv.inv_no} ${firmTag}`;
    const url = `upi://pay?pa=${encodeURIComponent(payUpi).replace(/%40/g, "@")}&pn=${encodeURIComponent(f.name)}&am=${Number(inv.total).toFixed(2)}&cu=INR&tn=${encodeURIComponent(note)}`;
    return `<div class="box qrbox"><div class="lbl">Scan &amp; pay by UPI</div>${qr.svg(url, 120)}
      <div><b>₹ ${money(inv.total)}</b></div><div class="muted" style="font-size:10px">${esc(payUpi)}<br>${esc(note)}</div></div>`;
  })();

  const H = (setup.h - 2 * setup.margin) / ((setup.scale || 100) / 100);
  const page = copyLabel => `<div class="invp" style="height:${H}mm">
  <div class="head"><div style="display:flex;gap:14px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div>
    <div class="muted">${esc(f.address)}, ${esc(f.city)} - ${esc(f.pincode)} (${esc(f.state)})<br>Ph: ${esc(f.phone)} · ${esc(f.email)}</div></div></div>
    <div>${copyLabel ? `<div class="r copyl">${esc(copyLabel)}</div>` : ''}<div class="title">${inv.is_proforma ? 'PROFORMA INVOICE' : 'TAX INVOICE'}${inv.cancelled ? ' — CANCELLED' : ''}</div>
    <div class="r">GSTIN: <b>${esc(f.gstin)}</b><br>PAN: ${esc(f.pan)}</div></div></div>

  <div class="grid2">
    <div class="box"><div class="lbl">Bill to</div><div class="big">${esc(inv.party_name)}</div>
      ${nl(inv.party_address)}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}, ${esc(inv.party_state || '')}
      ${inv.party_state_code ? ' (Code ' + esc(inv.party_state_code) + ')' : ''}<br>
      ${inv.party_gstin ? 'GSTIN: <b>' + esc(inv.party_gstin) + '</b>' : 'Unregistered (B2C)'}${inv.party_pan ? ' · PAN: ' + esc(inv.party_pan) : ''}
      ${shipTo(inv)}</div>
    <div class="box"><table class="kv"><tbody>
      <tr><td>${inv.is_proforma ? 'Proforma No.' : 'Invoice No.'}</td><td class="big">${esc(inv.is_proforma ? inv.pi_no : inv.inv_no)}</td><td>Date</td><td class="big">${dmy(inv.date)}</td></tr>
      <tr><td>F.Y.</td><td>${esc(inv.fy)}</td><td>Lorry No.</td><td><b>${esc(isPpe ? '' : inv.lorry_no || '')}</b></td></tr>
      <tr><td>Transporter</td><td colspan="3">${esc(inv.transporter || '')}${inv.transporter_gstin ? '<br>GSTIN <b>' + esc(inv.transporter_gstin) + '</b>' : ''}</td></tr>
      <tr><td>L.R. No.</td><td>${esc(inv.lr_no || '')}</td><td>E-way bill</td><td><b>${esc(inv.ewb_no || '')}</b></td></tr>
      ${inv.driver_phone ? `<tr><td>Driver Ph.</td><td colspan="3">${esc(inv.driver_phone)}</td></tr>` : ''}
    </tbody></table></div>
  </div>

  <div class="grow"><table class="items"><thead><tr><th class="c" style="width:32px">#</th><th>Description of goods</th><th class="c">HSN</th><th class="r">Qty</th><th class="c">Unit</th><th class="r">Rate</th><th class="c">GST</th><th class="r">Amount</th></tr></thead>
  <tbody>${rows}
  <tr class="fill"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
  <tr class="fx"><td></td><td class="r"><b>Total quantity</b></td><td></td><td class="r"><b>${qty(totalQty)}</b></td><td class="c">MT</td><td></td><td class="r">Taxable</td><td class="r"><b>${money(inv.taxable)}</b></td></tr>
  ${intra ? `<tr class="fx"><td colspan="7" class="r">CGST</td><td class="r">${money(inv.cgst)}</td></tr><tr class="fx"><td colspan="7" class="r">SGST</td><td class="r">${money(inv.sgst)}</td></tr>`
           : `<tr class="fx"><td colspan="7" class="r">IGST</td><td class="r">${money(inv.igst)}</td></tr>`}
  ${inv.round_off ? `<tr class="fx"><td colspan="7" class="r">Round off</td><td class="r">${money(inv.round_off)}</td></tr>` : ''}
  <tr class="tot fx"><td colspan="7" class="r">Grand total</td><td class="r">₹ ${money(inv.total)}</td></tr>
  </tbody></table></div>
  <div class="box words"><span class="lbl">Amount in words</span><br><b>${esc(inWords(inv.total))}</b></div>

  <table class="hsn"><thead><tr><th>HSN</th><th class="r">Taxable</th>${intra ? '<th class="r">CGST %</th><th class="r">CGST</th><th class="r">SGST %</th><th class="r">SGST</th>' : '<th class="r">IGST %</th><th class="r">IGST</th>'}<th class="r">Total tax</th></tr></thead>
  <tbody>${hsnRows}</tbody></table>

  ${freightLine || inv.notes ? `<div class="box freight">${freightLine}${freightLine && inv.notes ? '<br>' : ''}${inv.notes ? esc(inv.notes) : ''}</div>` : ''}

  <div class="foot ${upiQr ? 'withqr' : ''}">
    <div class="box"><div class="lbl">Terms of sale</div><div class="terms">${nl(f.terms || '')}</div>
      ${f.bank_name || f.bank_account ? `<div class="bankd"><div class="lbl">Bank details</div>A/c Name: <b>${esc(f.name.toUpperCase())}</b><br>
        ${f.bank_name ? `Bank: <b>${esc(f.bank_name)}</b>${f.bank_branch ? ', ' + esc(f.bank_branch) : ''}<br>` : ''}
        ${f.bank_account ? `A/c No.: <b>${esc(f.bank_account)}</b>` : ''}${f.bank_ifsc ? ` &nbsp; IFSC: <b>${esc(f.bank_ifsc)}</b>` : ''}
        ${payUpi ? `<br>UPI: ${esc(payUpi)}` : ''}</div>` : ''}</div>
    ${upiQr}
    <div class="box r sigbox"><div>For <b>${esc(f.name.toUpperCase())}</b></div><div class="sign">${signTag(f)}</div><div>Authorised Signatory</div></div>
  </div>
  <div class="c muted" style="margin-top:4px;font-size:10.5px">${inv.is_proforma ? 'This is a proforma invoice, not a tax invoice. The tax invoice is made at the time of dispatch.' : 'This is a computer generated invoice.'}</div>
</div>`;
  let copies = opts.copies || (isPpe || inv.is_proforma ? [''] : invoiceCopies(inv, opts.singleFromMt));
  if (opts.copy != null) copies = [copies[Number(opts.copy)] ?? copies[0]];
  return shell(`${f.name} Invoice ${inv.inv_no}`, copies.map(page), { ...opts, setup });
}

function voucherHtml(w, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const isPpe = /^PPE/i.test(w.voucher_no);
  const f = get('SELECT * FROM firms WHERE code = ?', isPpe ? 'PPE' : 'PM');
  const { amount, shownRate } = freightFigures(w);
  const adv = Number(w.advance) || 0;
  const net = r2(amount - adv);
  // UPI QR for the lorry owner: net freight, note = voucher no. + lorry no.
  const payQr = (() => {
    const l = get('SELECT * FROM lorries WHERE lorry_no = ?', String(w.lorry_no || '').toUpperCase().replace(/[^A-Z0-9]/g, '')) || {};
    const upi = String(w.upi || l.upi || bankUpi(l.bank_account, l.bank_ifsc) || '').trim();
    if (!upi || !/^[^@\s]+@[^@\s]+$/.test(upi) || !(net > 0)) return null;
    const name = w.owner_name || l.holder || l.owner || '';
    const note = `${w.voucher_no} ${w.lorry_no}`;
    const url = `upi://pay?pa=${encodeURIComponent(upi).replace(/%40/g, '@')}${name ? '&pn=' + encodeURIComponent(name) : ''}&am=${net.toFixed(2)}&cu=INR&tn=${encodeURIComponent(note)}`;
    return { svg: qr.svg(url, 130), upi, name, note };
  })();
  const body = `<div>
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div><div class="muted">${esc(f.address)}, ${esc(f.city)}</div></div></div>
  <div class="title">FREIGHT PAYMENT VOUCHER</div></div>
  <table><tbody>
    <tr><td>Voucher No.</td><td class="big">${esc(w.voucher_no)}</td><td>Voucher date</td><td>${dmy(w.voucher_date)}</td></tr>
    <tr><td>Plant</td><td>${esc(w.plant || '')}</td><td>Received on</td><td>${dmy(w.date)}</td></tr>
    <tr><td>Lorry No.</td><td class="big">${esc(w.lorry_no)}</td><td>Challan No.</td><td>${esc(w.challan_no || '')}</td></tr>
    <tr><td>Rawana No.</td><td>${esc(w.rawana_no || '')}</td><td>From → To</td><td><b>${esc(w.supplier || '')}</b> → <b>${esc(w.to_party || 'PARAKH MARKETING')}</b>${w.mines ? '<br>Mines: ' + esc(w.mines) : ''}</td></tr>
    <tr><td>Grade</td><td>${esc(w.grade || '')} ${esc(w.condition || '')}</td><td>Owner</td><td>${esc(w.owner_name || '')}${w.pan ? ' · PAN ' + esc(w.pan) : ''}</td></tr>
    <tr><td>Driver</td><td>${esc(w.driver_name || '')} ${esc(w.driver_phone || '')}</td><td>UPI</td><td>${esc(w.upi || (payQr && payQr.upi) || '')}</td></tr>
  </tbody></table>
  <table style="margin-top:8px"><thead><tr><th>Particulars</th><th class="r">Weight (MT)</th><th class="r">Rate / MT</th><th class="r">Amount</th></tr></thead>
  <tbody><tr><td>Freight for ${esc(w.lorry_no)}</td><td class="r">${qty(w.rawana_wt)}</td><td class="r">${money(shownRate)}</td><td class="r">${money(amount)}</td></tr>
  ${adv ? `<tr><td colspan="3" class="r">Less advance</td><td class="r">${money(adv)}</td></tr>` : ''}
  <tr class="tot"><td colspan="3" class="r">Net payable</td><td class="r">₹ ${money(net)}</td></tr>
  <tr><td colspan="4">Paid: Cash ₹ ${money(w.cash_amt)} · Bank ₹ ${money(w.bank_amt)}${w.pay_mode ? ' (' + esc(w.pay_mode) + ')' : ''}${w.chq_no ? ' · Ref ' + esc(w.chq_no) : ''}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(net))}</b></div>
  <div class="box" style="margin-top:8px;display:flex;gap:16px;align-items:stretch">
    ${payQr ? `${payQr.svg}<div style="align-self:center"><div class="lbl">Scan &amp; pay net freight by UPI</div><div style="font-size:18px;font-weight:800;margin:3px 0">₹ ${money(net)}</div>
    <div>To: <b>${esc(payQr.name || '')}</b><br>UPI: ${esc(payQr.upi)}<br>Note: ${esc(payQr.note)}</div></div>` : ''}
    <div style="margin-left:auto;display:flex;flex-direction:column;justify-content:space-between;text-align:right;min-height:120px;min-width:220px">
      <div>For <b>${esc(f.name.toUpperCase())}</b></div><div style="text-align:right">${signTag(f)}</div><div>Authorised Signatory</div></div>
  </div>
</div>`;
  return shell(`Voucher ${w.voucher_no}`, body, { ...opts, setup: setupFor('invoice', opts.setup) });
}

// ---- 4 x 6 bag / parcel sticker: To, Bag No. n / N, From ----
function labelHtml(inv, opts = {}) {
  const s = setupFor('label', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const of = Math.max(1, Number(opts.of) || 1);
  const from = Math.max(1, Number(opts.from) || 1), to = Math.min(of, Math.max(from, Number(opts.to) || of));
  const phone = p.mobile || p.phone || '';
  const items = inv.items.map(it => [it.item_name, it.grade].filter(Boolean).join(' ') + (it.pack_size ? ` · ${it.pack_size} kg bag` : '')).join('<br>');
  // two halves: upper = buyer (TO), lower = sender (FROM) with invoice and bag no. No logo.
  const one = n => `<div class="lbl4x6">
    <div class="half to"><div class="k">TO</div>
      <div class="nm">${esc(inv.party_name)}</div>
      ${inv.ship_address ? `${inv.ship_name ? `<div class="ad"><b>${esc(inv.ship_name)}</b></div>` : ''}<div class="ad">${nl(inv.ship_address)}<br>${esc(inv.ship_city || '')}${inv.ship_pincode ? ' - <b>' + esc(inv.ship_pincode) + '</b>' : ''}<br>${esc(inv.ship_state || '')}</div>`
        : `<div class="ad">${nl(inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - <b>' + esc(inv.party_pincode) + '</b>' : ''}<br>${esc(inv.party_state || '')}</div>`}
      ${phone ? `<div class="ph">Ph: <b>${esc(phone)}</b></div>` : ''}${inv.party_gstin ? `<div class="ph">GSTIN: <b>${esc(inv.party_gstin)}</b></div>` : ''}</div>
    <div class="half from"><div class="k">FROM</div>
      <div class="nm2">${esc(f.name.toUpperCase())}</div>
      <div class="ad2">${esc(f.address)}<br>${esc(f.city)}${f.pincode ? ' - ' + esc(f.pincode) : ''} · ${esc(f.state)}<br>Ph: ${esc(f.phone)}${f.gstin ? '<br>GSTIN ' + esc(f.gstin) : ''}</div>
      <div class="foot"><div class="info">Invoice <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>${items}${inv.transporter ? '<br>By ' + esc(inv.transporter) : ''}</div>
        <div class="bag"><span>BAG NO.</span><div><b>${n}</b> / <b>${of}</b></div></div></div></div>
  </div>`;
  const pages = []; for (let n = from; n <= to; n++) pages.push(one(n));
  const css = `<style>
    .lbl4x6 { height: ${s.h - 2 * s.margin}mm; display: flex; flex-direction: column; color: #000; }
    .lbl4x6 .half { flex: 1 1 0; min-height: 0; overflow: hidden; padding: 2.5mm; border: 2px solid #000; display: flex; flex-direction: column; }
    .lbl4x6 .to { border-bottom: 0; }
    .lbl4x6 .from { border-top: 2px dashed #000; }
    .lbl4x6 .k { font-size: 10px; font-weight: 800; letter-spacing: 1px; border-bottom: 1px solid #000; margin-bottom: 1.5mm; }
    .lbl4x6 .nm { font-size: 24px; font-weight: 800; line-height: 1.15; }
    .lbl4x6 .ad { font-size: 16px; line-height: 1.35; margin-top: 1mm; }
    .lbl4x6 .ph { font-size: 16px; margin-top: 1mm; }
    .lbl4x6 .nm2 { font-size: 16px; font-weight: 800; line-height: 1.15; }
    .lbl4x6 .ad2 { font-size: 12px; line-height: 1.35; margin-top: 1mm; }
    .lbl4x6 .foot { margin-top: auto; display: flex; gap: 2mm; align-items: flex-end; }
    .lbl4x6 .info { flex: 1; font-size: 11px; line-height: 1.3; }
    .lbl4x6 .bag { border: 2px solid #000; padding: 1mm 2.5mm; text-align: center; white-space: nowrap; }
    .lbl4x6 .bag span { font-size: 10px; font-weight: 700; display: block; } .lbl4x6 .bag b { font-size: 26px; }
  </style>`;
  pages[0] = css + pages[0];
  return shell(`Bag stickers ${inv.inv_no}`, pages, { ...opts, setup: s });
}

// ---- envelope: invoice, lorry, transporter, e-way bill, To M/s … ----
function envelopeHtml(inv, opts = {}) {
  const s = setupFor('envelope', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const phone = p.mobile || p.phone || '';
  const body = `<style>
    .env { height: ${s.h - 2 * s.margin}mm; display: grid; grid-template-columns: 1fr 1.25fr; gap: 6mm; font-size: 12px; color: #000; }
    .env .left { font-size: 11px; line-height: 1.45; }
    .env .left .firm2 { font-size: 15px; font-weight: 800; }
    .env .ref { margin-top: 3mm; border: 1px solid #000; padding: 2mm; line-height: 1.6; }
    .env .right { align-self: center; border-left: 2px solid #000; padding-left: 5mm; }
    .env .right .k { font-size: 11px; font-weight: 700; letter-spacing: 1px; }
    .env .right .nm { font-size: 17px; font-weight: 800; margin: 1mm 0; }
    .env .right .ad { font-size: 13px; line-height: 1.4; }
  </style><div class="env">
    <div class="left">${logoTag(f)}<div class="firm2">${esc(f.name.toUpperCase())}</div>${esc(f.address)}<br>${esc(f.city)} - ${esc(f.pincode)}, ${esc(f.state)}<br>Ph: ${esc(f.phone)}
      <div class="ref">Invoice No. <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}<br>Lorry No. <b>${esc(inv.lorry_no || '')}</b><br>${esc(inv.transporter || '')}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>E-Way Bill No. <b>${esc(inv.ewb_no || '')}</b></div></div>
    <div class="right"><div class="k">TO</div><div class="nm">M/s. ${esc(inv.party_name)}</div>
      <div class="ad">${nl(inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}<br>${esc(inv.party_state || '')}${phone ? '<br>Ph. ' + esc(phone) : ''}</div></div>
  </div>`;
  return shell(`Envelope ${inv.inv_no}`, body, { ...opts, setup: s });
}

// Transporter invoice (freight bill from the transporter to the buyer): No. = L.R. no., amount = total freight
function trInvoiceHtml(inv, tr, opts = {}) {
  const title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const pan = tr.pan || (tr.gstin && tr.gstin.length >= 12 ? tr.gstin.slice(2, 12) : '');
  const phones = [tr.mobile, tr.phone].filter(Boolean).join(',');
  const qtyT = inv.items.reduce((s, i) => s + (Number(i.qty) || 0), 0), amt = Number(inv.freight_total) || 0;
  const destCity = inv.ship_city || inv.party_city, destState = inv.ship_state || inv.party_state;
  const party = inv.party || {}, ph = [party.mobile, party.phone].filter(Boolean)[0];
  const words = inWords(Math.round(amt)).replace(/^Rupees\s*/i, '').replace(/\s*only\.?$/i, '');
  const body = `<style>.trinv td, .trinv th { border: 0; padding: 0; background: none; }</style><div class="trinv" style="font-family:Calibri,Carlito,'Segoe UI',Arial,sans-serif;font-size:13.5px;color:#000;padding:6mm 4mm">
    <table style="width:100%;font-weight:bold;font-size:12.5px"><tr><td style="width:50%"><div style="padding-left:28px">GST NO</div>${esc(tr.gstin || '')}</td>
      <td style="text-align:right"><div style="padding-right:36px">PAN</div>${esc(pan)}</td></tr></table>
    <div style="text-align:center;margin-top:18px"><div style="font-size:27px;font-weight:bold;letter-spacing:.3px">${esc(String(tr.name || '').toUpperCase())}</div>
      <div style="font-size:11px;font-weight:bold">${esc(String([tr.address, tr.district, tr.state].filter(Boolean).join(', ')).toUpperCase())}</div>
      ${phones ? `<div style="font-size:11px">PH-${esc(phones)}</div>` : ''}</div>
    <table style="width:100%;margin-top:26px;font-weight:bold;font-size:14px"><tr><td style="width:70px">No.</td><td>${esc(inv.lr_no || '')}</td>
      <td style="text-align:right"><i style="border-bottom:1px solid #000;padding:0 2px 3px 20px">${esc(dmy(inv.date).replace(/\./g, '/'))}</i></td></tr></table>
    <div style="margin-top:34px">To</div>
    <div style="font-size:17px;font-weight:bold">${esc(inv.party_name)}</div>
    <div style="font-weight:bold">${esc([inv.party_address, ph ? 'Ph.' + ph : ''].filter(Boolean).join(' , '))}</div>
    <div style="font-weight:bold">${esc([inv.party_city, inv.party_state].filter(Boolean).join(',').toUpperCase())}</div>
    <table style="width:100%;border-collapse:collapse;margin-top:34px;border:1.5px solid #000">
      <tr style="font-weight:bold;font-size:14px;text-align:center"><td style="border:1px solid #000;width:13%;padding:3px">SL</td><td style="border:1px solid #000;padding:3px">Details</td>
        <td style="border:1px solid #000;width:12%;padding:3px">Qty</td><td style="border:1px solid #000;width:16%;padding:3px">Amount</td></tr>
      <tr style="vertical-align:top;height:100px"><td style="border:1px solid #000;text-align:center;vertical-align:middle">1</td>
        <td style="border:1px solid #000;padding:2px 4px;line-height:1.35">${esc(title(inv.firm.city || tr.district || ''))} To ${esc([destCity, destState].filter(Boolean).join(',').toUpperCase())}<br><br>
          Goods Sent By ${esc(inv.firm.name)}<br>Invoice No.${esc(inv.inv_no)}<br>Lorry No.${esc(inv.lorry_no || '')}</td>
        <td style="border:1px solid #000;padding:2px 4px">${qty(qtyT)}</td><td style="border:1px solid #000;padding:2px 4px;text-align:right;font-weight:bold">${money(amt)}</td></tr>
      <tr style="font-weight:bold"><td></td><td style="text-align:right;padding:2px 4px;border-right:1px solid #000;border-top:1px solid #000">TOTAL</td>
        <td style="border:1px solid #000;padding:2px 4px">${qty(qtyT)}</td><td style="border:1px solid #000;padding:2px 4px;text-align:right">${money(amt)}</td></tr></table>
    <div style="margin-top:20px;font-weight:bold;font-size:14px">Total Rs.&nbsp;&nbsp;&nbsp;&nbsp;${esc(words)} Only.</div>
    <div style="margin-left:96px;font-size:12px"><i>(Amount in Words)</i></div>
    <div style="margin-top:38px;font-size:15px">Kindly transfer the above amount to the bank account details mentioned below.</div>
    <div style="margin-top:24px;font-weight:bold;font-size:14px">Bank Details</div>
    <table style="font-size:12px;line-height:1.35"><tr><td style="width:90px">Name:</td><td>${esc(String(tr.name || '').toUpperCase())}</td></tr>
      <tr><td>Bank:</td><td>${esc(String(tr.bank_name || '').toUpperCase())}</td></tr><tr><td>Account No:</td><td>${esc(tr.bank_account || '')}</td></tr><tr><td>IFSC</td><td>${esc(tr.bank_ifsc || '')}</td></tr></table>
    <div style="margin-top:22px;font-size:12px">Thank You</div>
    <div style="margin-top:22px;font-size:12px">${esc(String(tr.proprietor || '').toUpperCase())}</div>
    <div style="font-size:12px;font-weight:bold"><i>${esc(String(tr.name || '').toUpperCase())}</i></div>
    <div style="font-size:12px;font-weight:bold"><i>${esc(title(tr.district || ''))}</i></div>
    <div style="margin-top:40px;text-align:center;font-weight:bold;font-size:12px"><i>( This is a computer generated Document )</i></div></div>`;
  return shell(`Transporter invoice ${inv.lr_no || ''}`, body, opts);
}

// Local freight letter: Parakh Marketing asks the transporter to pay the tempo that brings the goods to its godown
function localFreightHtml(inv, lf, tr, opts = {}) {
  const f = inv.firm, title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const d = new Date(), today = d.toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  const words = inWords(Math.round(lf.amount)).replace(/^Rupees\s*/i, '').replace(/\s*only\.?$/i, '');
  const groups = new Map();
  for (const it of inv.items) { const k = Number(it.pack_size) || 0; groups.set(k, (groups.get(k) || 0) + (Number(it.bags) || 0)); }
  const bagLine = [...groups].filter(([, b]) => b).map(([kg, b]) => `${b} Bags of ${qty(kg)} Kg`).join(' + ');
  const totalKg = [...groups].reduce((s, [kg, b]) => s + kg * b, 0);
  const place = [inv.ship_city || inv.party_city, inv.ship_pincode || inv.party_pincode].filter(Boolean).join('-');
  const row = (k, v) => `<tr><td style="width:86px;padding:5px 0">${k}</td><td style="padding:5px 0"><b><i>${v}</i></b></td></tr>`;
  const body = `<style>.lfl td { border: 0; padding: 0; background: none; }</style>
  <div class="lfl" style="font-family:'Bookman Old Style','Book Antiqua',Georgia,serif;font-size:13px;color:#000;padding:4mm 3mm;height:260mm;position:relative">
    <div style="font-family:'Old English Text MT','Engravers MT',Georgia,serif;font-size:22px;font-weight:bold;letter-spacing:.5px">${esc(String(f.name).toUpperCase())}</div>
    <div style="font-size:11px;margin-top:14px">${esc(today)}</div>
    <div style="margin-top:22px">To<br>The Manager<br><b>${esc(String(tr.name || '').toUpperCase())}</b><br>${esc(title(tr.district || ''))}</div>
    <div style="margin-top:34px">Dear Sir ,</div>
    <table style="margin-top:8px;border-collapse:collapse">
      <tr><td style="width:86px;padding:5px 0">Kindly pay</td><td style="padding:5px 0">Rs.${money(lf.amount)} ( ${esc(words)} Only.)</td></tr>
      ${row('Name', esc(lf.driver))}${lf.mobile ? row('Mobile No.', esc(lf.mobile)) : ''}${row('Taxi No.', esc(lf.tempo_no))}</table>
    <div style="margin-top:6px">For the delivery of goods from our factory (${esc(lf.from_place || 'Mandore Industrial Area')}) to</div>
    <div style="margin-top:14px"><b><i>${esc(String(tr.name || '').toUpperCase())}</i></b></div>
    <div style="margin-top:12px">${esc(title(tr.district || ''))}</div>
    <div style="margin-top:42px"><b><i>${esc(bagLine)}&nbsp;&nbsp;&nbsp;Total&nbsp;&nbsp;&nbsp;&nbsp;${qty(totalKg)} Kg.</i></b></div>
    <div style="margin-top:12px">for</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-size:17px;font-weight:bold">M/s. ${esc(inv.party_name)}</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-weight:bold">${esc(String(place).toUpperCase())}</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-weight:bold">${esc(String(inv.ship_state || inv.party_state || '').toUpperCase())}</div>
    <div style="margin-top:42px">Invoice No.&nbsp;&nbsp;&nbsp;<b><i style="display:inline-block;min-width:46px;text-align:center;border-bottom:1px solid #000;padding-bottom:4px">${esc(inv.inv_no)}</i></b>&nbsp;&nbsp;Dated&nbsp;&nbsp;<b><i style="display:inline-block;min-width:140px;text-align:center;border-bottom:1px solid #000;padding-bottom:4px">${esc(dmy(inv.date).replace(/\./g, '/'))}</i></b></div>
    <div style="margin-top:38px">Thank you</div>
    <div style="margin-top:20px">${esc(lf.signer || '')}</div>
    <div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:9.5px;font-weight:bold">${esc(f.address)}<br>${esc(title(f.city))} ${esc(f.pincode || '')} ${esc(title(f.state))}</div></div>`;
  return shell(`Local freight letter ${inv.inv_no}`, body, opts);
}

module.exports = { localFreightHtml, trInvoiceHtml, invoiceHtml, voucherHtml, labelHtml, envelopeHtml, setupFor, invoiceCopies, PAPERS, DEFAULT_SETUP };
