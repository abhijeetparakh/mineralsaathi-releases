-- Mineral Saathi database schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- Billing firms: P.P.Enterprise, Parakh Marketing, Parakh Fertilizer
CREATE TABLE IF NOT EXISTS firms (
  id INTEGER PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,          -- PPE / PM / PF
  name TEXT NOT NULL,
  gstin TEXT, pan TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  phone TEXT, email TEXT,
  bank_name TEXT, bank_account TEXT, bank_ifsc TEXT, upi_id TEXT,
  smtp_host TEXT, smtp_port INTEGER, smtp_user TEXT, smtp_pass TEXT,
  terms TEXT
);

-- Plants where material is received / ground / dispatched
CREATE TABLE IF NOT EXISTS plants (
  id INTEGER PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,           -- PPI PLANT, KI PLANT
  full_name TEXT, address TEXT
);

CREATE TABLE IF NOT EXISTS parties (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  firm_code TEXT,                      -- which firm usually bills this party (PM / PF)
  gstin TEXT, pan TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  ship_address TEXT,
  email TEXT, mobile TEXT, phone TEXT,
  transporter TEXT, km INTEGER,
  group_name TEXT, payment_terms TEXT, notes TEXT,
  is_b2c INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_parties_name ON parties(name);

CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,                  -- DIATOMACEOUS EARTH
  grade TEXT,                          -- Y300 MESH
  hsn TEXT DEFAULT '2512',
  gst_rate REAL DEFAULT 5,
  unit TEXT DEFAULT 'MT',
  bag_type TEXT, pack_size REAL,
  rate REAL,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS transporters (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT, mobile TEXT, address TEXT, district TEXT, state TEXT,
  gstin TEXT, pan TEXT, email TEXT, contact TEXT,
  bank_name TEXT, bank_account TEXT, bank_ifsc TEXT
);

CREATE TABLE IF NOT EXISTS lorries (
  id INTEGER PRIMARY KEY,
  lorry_no TEXT UNIQUE NOT NULL,
  owner TEXT, pan TEXT, mobile TEXT, address TEXT,
  driver_name TEXT, driver_phone TEXT,
  bank_name TEXT, holder TEXT, bank_ifsc TEXT, bank_account TEXT, upi TEXT,
  tds_declaration TEXT
);

CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  grade TEXT, rate REAL, freight_rate REAL,
  type TEXT DEFAULT 'REG'              -- REG / URD
);

-- Inward challan + freight voucher
-- rawana_wt  = weight on the rawana (from mines)  -> printed on voucher, used for PPE bill
-- actual_wt  = weight actually received at plant -> freight is calculated on this
CREATE TABLE IF NOT EXISTS inwards (
  id INTEGER PRIMARY KEY,
  fy TEXT NOT NULL,
  voucher_no TEXT NOT NULL,
  date TEXT,                           -- ISO yyyy-mm-dd (date received)
  voucher_date TEXT,
  supplier TEXT, mines TEXT,
  lorry_no TEXT, grade TEXT, condition TEXT, plant TEXT,
  rawana_no TEXT, challan_no TEXT,
  rawana_wt REAL, actual_wt REAL,
  freight_rate REAL,                   -- rate per MT on actual weight
  freight_amt REAL,                    -- actual_wt * freight_rate
  advance REAL DEFAULT 0,
  pay_mode TEXT, cash_amt REAL DEFAULT 0, bank_amt REAL DEFAULT 0, chq_no TEXT,
  owner_name TEXT, pan TEXT, driver_name TEXT, driver_phone TEXT, upi TEXT,
  transporter TEXT, lr_no TEXT,
  royalty REAL, dmft REAL, nmet REAL,
  ppe_invoice_id INTEGER,              -- set when billed by P.P.Enterprise to Parakh Marketing
  remarks TEXT,
  legacy INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(fy, voucher_no)
);
CREATE INDEX IF NOT EXISTS ix_inwards_fy ON inwards(fy);
CREATE INDEX IF NOT EXISTS ix_inwards_lorry ON inwards(lorry_no);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY,
  firm_code TEXT NOT NULL,             -- seller: PPE / PM / PF
  fy TEXT NOT NULL,
  inv_no INTEGER NOT NULL,
  date TEXT,
  kind TEXT DEFAULT 'SALE',            -- SALE / PPE_BILL
  party_id INTEGER,
  party_name TEXT, party_gstin TEXT, party_pan TEXT,
  party_address TEXT, party_city TEXT, party_state TEXT, party_state_code TEXT, party_pincode TEXT,
  ship_address TEXT,
  supply_type TEXT DEFAULT 'B2B',      -- B2B / B2C
  lorry_no TEXT, transporter TEXT, lr_no TEXT, driver_phone TEXT,
  plant TEXT, ewb_no TEXT, freight_note TEXT, advance_freight REAL,
  taxable REAL, cgst REAL, sgst REAL, igst REAL, round_off REAL, total REAL,
  email_sent_at TEXT, notes TEXT,
  legacy INTEGER DEFAULT 0,
  cancelled INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(firm_code, fy, inv_no)
);
CREATE INDEX IF NOT EXISTS ix_invoices_fy ON invoices(firm_code, fy);

CREATE TABLE IF NOT EXISTS invoice_items (
  id INTEGER PRIMARY KEY,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  sl INTEGER,
  item_name TEXT, grade TEXT, hsn TEXT,
  qty REAL, unit TEXT DEFAULT 'MT', rate REAL, amount REAL, gst_rate REAL,
  bags INTEGER, pack_size REAL, bag_type TEXT,
  inward_id INTEGER,                   -- PPE bill line -> inward lorry
  lorry_no TEXT, rawana_no TEXT, challan_no TEXT
);
CREATE INDEX IF NOT EXISTS ix_items_inv ON invoice_items(invoice_id);

-- Items, rates and packing agreed with each buyer
CREATE TABLE IF NOT EXISTS party_items (
  id INTEGER PRIMARY KEY,
  party_id INTEGER NOT NULL REFERENCES parties(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL, grade TEXT,
  hsn TEXT, gst_rate REAL DEFAULT 5,
  rate REAL,                           -- rate per MT
  pack_size REAL,                      -- kg per bag
  bag_type TEXT,                       -- PLAIN, DEE-E, YELLOW DEE-E, PRINTED LAMINATED ...
  bag_supply TEXT,                     -- OUR = we supply bags, BUYER = buyer sends own bags
  liner INTEGER,                       -- 1 with liner, 0 without
  notes TEXT,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_party_items ON party_items(party_id);

-- Pick-lists used across the app (item colour, mesh, bag type, HSN ...)
CREATE TABLE IF NOT EXISTS lists (
  id INTEGER PRIMARY KEY,
  list_key TEXT NOT NULL,
  value TEXT NOT NULL,
  note TEXT,                           -- e.g. HSN description
  num REAL,                            -- e.g. GST % for an HSN, kg for a bag weight
  sort INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1,
  UNIQUE(list_key, value)
);

-- Delivery addresses (godowns / plants) of a buyer, each with its own pincode
-- commission paid on goods sold (private: only the password-protected Commission screen)
-- paid for a buyer, or to an agent who gets commission on several buyers
CREATE TABLE IF NOT EXISTS commission_pay (
  id INTEGER PRIMARY KEY,
  party_id INTEGER REFERENCES parties(id),
  agent TEXT,
  date TEXT NOT NULL, fy TEXT,
  amount REAL NOT NULL,
  sent_to TEXT, sent_via TEXT, ref TEXT, notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_comm_pay2 ON commission_pay(party_id);
-- other amounts owed to an agent / for a buyer (expenses), added to the commission
CREATE TABLE IF NOT EXISTS commission_extra (
  id INTEGER PRIMARY KEY,
  party_id INTEGER REFERENCES parties(id),
  agent TEXT,
  date TEXT NOT NULL, fy TEXT,
  description TEXT,
  amount REAL NOT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- (old table of version 1.21.0, copied into commission_pay once)
CREATE TABLE IF NOT EXISTS commission_payments (
  id INTEGER PRIMARY KEY,
  party_id INTEGER NOT NULL REFERENCES parties(id),
  date TEXT NOT NULL, fy TEXT,
  amount REAL NOT NULL,
  sent_to TEXT, sent_via TEXT, ref TEXT, notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_comm_pay ON commission_payments(party_id);

CREATE TABLE IF NOT EXISTS party_addresses (
  id INTEGER PRIMARY KEY,
  party_id INTEGER NOT NULL REFERENCES parties(id) ON DELETE CASCADE,
  godown_name TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  contact TEXT, phone TEXT, km INTEGER,
  is_default INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_party_addresses ON party_addresses(party_id);

-- transporter TDS declarations u/s 194C(6): one per financial year, transporter and buyer
CREATE TABLE IF NOT EXISTS tds_certs (
  id INTEGER PRIMARY KEY,
  fy TEXT NOT NULL,
  transporter_id INTEGER NOT NULL REFERENCES transporters(id),
  party_id INTEGER NOT NULL REFERENCES parties(id),
  cert_date TEXT,
  first_invoice_id INTEGER,
  firm_code TEXT,
  sent_transporter_at TEXT, sent_buyer_at TEXT,
  last_error TEXT,
  UNIQUE(fy, transporter_id, party_id)
);

-- email templates (message body) for: SALE invoice to buyer, PROFORMA invoice, invoice copy to TRANSPORTER
CREATE TABLE IF NOT EXISTS email_templates (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  purpose TEXT NOT NULL,                            -- SALE, PROFORMA, TRANSPORTER
  body TEXT,
  is_default INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);

-- documents of one invoice: test report, L.R. copy, transporter's invoice (files in the data folder)
CREATE TABLE IF NOT EXISTS invoice_docs (
  id INTEGER PRIMARY KEY,
  invoice_id INTEGER NOT NULL,
  kind TEXT NOT NULL,                               -- TEST_REPORT, LR, TR_INVOICE
  file TEXT NOT NULL,                               -- path inside the data folder
  name TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_invoice_docs ON invoice_docs(invoice_id);
-- documents already sent to a buyer once (transporter bank proof)
CREATE TABLE IF NOT EXISTS sent_docs (
  party_id INTEGER, transporter_id INTEGER, kind TEXT, at TEXT,
  UNIQUE(party_id, transporter_id, kind)
);
-- every email sent or failed
CREATE TABLE IF NOT EXISTS email_log (
  id INTEGER PRIMARY KEY,
  at TEXT DEFAULT (datetime('now','localtime')),
  firm_code TEXT, seller TEXT, to_name TEXT, to_addr TEXT, template TEXT, doc_no TEXT, kind TEXT,
  status TEXT, error TEXT, attachments TEXT
);

-- Orders book: coming orders to plan production (removed when the sales invoice is saved and printed)
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY,
  firm_code TEXT NOT NULL,
  party_id INTEGER NOT NULL,
  dispatch_by TEXT,
  notes TEXT,
  proforma_id INTEGER,                              -- made from a proforma invoice
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  party_item_id INTEGER, item_name TEXT, grade TEXT, qty REAL
);

-- Factory wages (Parakh Marketing dispatches only)
CREATE TABLE IF NOT EXISTS factory_fixed (          -- fixed monthly expenses of a plant (Item lists)
  id INTEGER PRIMARY KEY,
  plant TEXT NOT NULL, name TEXT NOT NULL, amount REAL,
  active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS wage_entries (           -- saved expense rows of one month and plant
  id INTEGER PRIMARY KEY,
  month TEXT NOT NULL,                              -- YYYY-MM
  plant TEXT NOT NULL,
  kind TEXT NOT NULL,                               -- FIXED or EXTRA
  description TEXT, qty REAL, rate REAL, amount REAL,
  saved_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_wage_month ON wage_entries(month);

-- Stock IN: material received by Parakh Marketing entered by hand (no freight voucher). No. PMST01, PMST02 … per F.Y.
CREATE TABLE IF NOT EXISTS stock_in (
  id INTEGER PRIMARY KEY,
  fy TEXT NOT NULL,
  st_no TEXT NOT NULL,
  date TEXT,
  supplier TEXT, item TEXT,
  rawana_no TEXT, rawana_wt REAL, actual_wt REAL,
  freight_rate REAL,                   -- freight per MT
  freight_total REAL,                  -- actual qty x freight per MT
  remarks TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(fy, st_no)
);

-- Local freight: tempo drivers who take small loads (under 200 bags) to the transporter's godown
CREATE TABLE IF NOT EXISTS local_drivers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL, tempo_no TEXT, mobile TEXT
);
-- Local freight letters printed for an invoice
CREATE TABLE IF NOT EXISTS local_freight (
  id INTEGER PRIMARY KEY,
  invoice_id INTEGER NOT NULL,
  driver TEXT, tempo_no TEXT, mobile TEXT, amount REAL, from_place TEXT, signer TEXT,
  at TEXT DEFAULT (datetime('now','localtime'))
);
