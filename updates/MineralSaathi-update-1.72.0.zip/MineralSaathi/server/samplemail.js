'use strict';
// Sample dispatch email (Marketing) and Master → Logistics → Postage & Couriers.
// - Couriers: name, website and tracking link ({tracking_no} is replaced by the number). The link can be looked up
//   on the courier's website; if none is found it stays blank and the general tracking link (Settings → Marketing) is used.
// - Email template "Sample dispatch" (purpose SAMPLE): same words as the cover letter, plus the tracking number.
// - Automatic: one switch (inside the SAMPLE template). When a dispatch gets a tracking number (or it changes),
//   the email goes to the customer by itself after 5 minutes (so a typing mistake can still be corrected), once per number.
const { all, get, run, setting, setSetting } = require('./db');
const mailer = require('./mailer');

run(`CREATE TABLE IF NOT EXISTS couriers (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, website TEXT, tracking_url TEXT, active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime')))`);
run(`CREATE TABLE IF NOT EXISTS sample_mails (
  id INTEGER PRIMARY KEY, dispatch_id INTEGER NOT NULL, tracking_no TEXT, status TEXT NOT NULL, due_at TEXT, tries INTEGER DEFAULT 0,
  to_addr TEXT, error TEXT, sent_at TEXT, auto INTEGER DEFAULT 1, created_at TEXT DEFAULT (datetime('now','localtime')))`);

const M = () => require('./marketing/db');
const mkt = () => { try { return M().isOpen() ? M() : null; } catch { return null; } };
const stamp = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19).replace('T', ' ');
const up = v => String(v ?? '').trim().replace(/\s+/g, ' ').toUpperCase();
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- couriers ----------
// the couriers already typed in Marketing → Lists come into the master once; new couriers go both ways
function seedCouriers() {
  const m = mkt(); if (!m) return;
  for (const r of m.all("SELECT value FROM mkt_lists WHERE list_key = 'courier'")) run('INSERT OR IGNORE INTO couriers(name) VALUES(?)', up(r.value));
}
try { seedCouriers(); } catch (e) { console.error('Couriers:', e.message); }
function toMktList(name) {
  const m = mkt(); if (!m) return;
  try { if (!m.get("SELECT 1 FROM mkt_lists WHERE list_key = 'courier' AND upper(value) = upper(?)", name))
    m.run("INSERT INTO mkt_lists(list_key, value, sort) VALUES('courier', ?, 0)", name); } catch (e) { console.error('Courier list:', e.message); }
}
function generalLink() { return setting('mkt.tracking_url') || 'https://t.17track.net/en#nums={tracking_no}'; }
// the tracking link for this courier and number: the courier's own link, else the general one
function trackLink(courier, no) {
  if (!no) return '';
  const c = courier ? get('SELECT tracking_url FROM couriers WHERE upper(name) = upper(?)', String(courier).trim()) : null;
  const tpl = (c && c.tracking_url) || generalLink();
  return tpl.split('{tracking_no}').join(encodeURIComponent(no));
}
const okUrl = u => /^https?:\/\/[^\s]+$/i.test(u);
function cleanCourier(b) {
  const o = { name: up(b.name), website: String(b.website || '').trim(), tracking_url: String(b.tracking_url || '').trim() };
  if (!o.name) throw new UserErr('Enter the courier company name.');
  if (o.website && !/^https?:\/\//i.test(o.website)) o.website = 'https://' + o.website;
  if (o.website && !okUrl(o.website)) throw new UserErr('The website address does not look right.');
  if (o.tracking_url && (!okUrl(o.tracking_url) || !o.tracking_url.includes('{tracking_no}')))
    throw new UserErr('The tracking link must start with http and have {tracking_no} where the number goes.');
  return o;
}
class UserErr extends Error { constructor(m) { super(m); this.status = 400; } }

// ---- find the tracking link on the courier's website ----
// Reads the home page (and the tracking page it links to) and looks for a tracking form or a link with the number in it.
const NUM_PARAM = /^(awb|awbno|awb_no|awbnumber|track|trackno|track_no|tracking|trackingno|tracking_no|trackingnumber|tracking-id|trackingid|trackfor|tracknumber|trknbr|trk|cn|cnno|cn_no|consignment|consignmentno|consignment_no|docket|docketno|docket_no|waybill|waybillno|shipment|shipmentno|ref|refno|reference|nums?|number|id|q|query|search|article|articleno|itemno|item_no|lrno|lr_no|grno)$/i;
async function fetchPage(url) {
  const r = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(12000), headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36', Accept: 'text/html,*/*' } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return { url: r.url || url, html: (await r.text()).slice(0, 1500000) };
}
const attr = (tag, a) => { const m = tag.match(new RegExp('\\b' + a + '\\s*=\\s*("([^"]*)"|\'([^\']*)\'|([^\\s>]+))', 'i')); return m ? (m[2] ?? m[3] ?? m[4] ?? '') : null; };
const unent = s => String(s || '').replace(/&amp;/g, '&').replace(/&#x2F;/gi, '/').replace(/&#47;/g, '/');
const abs = (u, base) => { try { return new URL(unent(u), base).href; } catch { return null; } };
const sameSite = (a, b) => { try { const h = x => new URL(x).hostname.replace(/^www\d?\./, '').split('.').slice(-2).join('.'); return h(a) === h(b); } catch { return false; } };
// a link that already carries a number parameter → that parameter becomes {tracking_no}
function fromLink(u) {
  try {
    const x = new URL(u);
    for (const [k] of x.searchParams) if (NUM_PARAM.test(k)) { x.searchParams.set(k, '__NO__'); return x.href.replace('__NO__', '{tracking_no}'); }
    const h = x.hash.match(/^#(.*?)(nums?|awb|tracking(?:no|number|id)?|trackno|id)=([^&]*)/i);
    if (h) return x.href.replace(/(#.*?(?:nums?|awb|tracking(?:no|number|id)?|trackno|id)=)[^&]*/i, '$1{tracking_no}');
  } catch { /* not a link */ }
  return null;
}
// a GET form with one text box for the number → action?box={tracking_no}
function fromForms(html, base) {
  const out = [];
  for (const m of html.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)) {
    const tag = m[1], inner = m[2], text = (tag + inner).toLowerCase();
    if (!/track|trace|awb|consign|docket|waybill|shipment/.test(text)) continue;
    if ((attr('<x ' + tag, 'method') || 'get').toLowerCase() !== 'get') continue;
    const inputs = [...inner.matchAll(/<input\b[^>]*>/gi)].map(i => i[0]);
    const box = inputs.find(i => { const t = (attr(i, 'type') || 'text').toLowerCase(), n = attr(i, 'name') || '';
      return ['text', 'search', 'number', 'tel'].includes(t) && n && (NUM_PARAM.test(n) || /track|awb|consign|docket|waybill|shipment|number/i.test(n + ' ' + (attr(i, 'placeholder') || '') + ' ' + (attr(i, 'id') || ''))); });
    if (!box) continue;
    const action = abs(attr('<x ' + tag, 'action') || base, base); if (!action) continue;
    const x = new URL(action);
    for (const h of inputs) { const t = (attr(h, 'type') || '').toLowerCase(), n = attr(h, 'name'); if (t === 'hidden' && n) x.searchParams.set(n, attr(h, 'value') || ''); }
    x.searchParams.set(attr(box, 'name'), '__NO__');
    out.push(x.href.replace('__NO__', '{tracking_no}'));
  }
  return out;
}
async function findTrackingUrl(website) {
  if (!website) throw new UserErr('Enter the website address first.');
  const start = /^https?:\/\//i.test(website) ? website : 'https://' + website;
  let home;
  try { home = await fetchPage(start); }
  catch (e) { return { found: false, message: `Could not open ${start}: ${e.name === 'TimeoutError' ? 'no answer in 12 seconds' : e.message}. Check the address and the internet connection.` }; }
  const look = page => {
    const forms = fromForms(page.html, page.url);
    if (forms.length) return forms[0];
    for (const m of page.html.matchAll(/<a\b[^>]*href\s*=\s*["']([^"'#][^"']*)["'][^>]*>/gi)) {
      const u = abs(m[1], page.url); const t = u && fromLink(u);
      if (t && /track|trace|awb|consign|docket|waybill|shipment/i.test(t)) return t;
    }
    return null;
  };
  let hit = look(home);
  if (!hit) {           // open the tracking page the home page links to (at most 4)
    const pages = [...new Set([...home.html.matchAll(/<a\b([^>]*)>([\s\S]{0,200}?)<\/a>/gi)]
      .filter(m => /track|trace/i.test((attr('<a ' + m[1], 'href') || '') + ' ' + m[2].replace(/<[^>]+>/g, '')))
      .map(m => abs(attr('<a ' + m[1], 'href') || '', home.url)).filter(u => u && /^https?:/.test(u) && sameSite(u, home.url)))].slice(0, 4);
    for (const p of pages) {
      const t = fromLink(p); if (t) { hit = t; break; }
      try { hit = look(await fetchPage(p)); } catch { /* next one */ }
      if (hit) break;
    }
  }
  return hit ? { found: true, tracking_url: hit, message: 'Tracking link found on the website. Check it once with a real number.' }
    : { found: false, tracking_url: '', message: 'No tracking link with the number could be found on the website (many courier sites use a captcha or an app). It is left blank — the general tracking link (17track) is used for this courier.' };
}

// ---------- the email ----------
const SAMPLE_VARS = ['Addressed to', 'Buyer name', 'Company', 'City', 'Ref No.', 'Dispatch date', 'Samples', 'Items', 'Courier', 'Tracking no.', 'Tracking link',
  'Sample table', 'Rates', 'Delivery time', 'Payment terms', 'Packing note', 'Signer', 'Seller name', 'Today'];
const SAMPLE_STD = 'To,\n{Addressed to}\n\nDear Sir / Madam,\n\nThank you for your enquiry. We are pleased to send {Samples} of {Items} by {Courier} and offer the following:\n\n{Sample table}\n\n'
  + 'Rates: {Rates}\nFreight: To pay (not included in the above price)\nDelivery time: {Delivery time}\nPayment terms: {Payment terms}\n\n'
  + 'Tracking no.: {Tracking no.} ({Courier})\nTrack your parcel: {Tracking link}\nYour Ref. No.: {Ref No.}\n\n'
  + '{Packing note}We look forward to your confirmation and are happy to assist with dispatch and logistics. Please feel free to reach out for any clarification or customization.\n\nThank you,\n{Signer}\n{Seller name}';
// the default template (made once; it can be edited, not deleted)
if (!get("SELECT 1 FROM email_templates WHERE purpose = 'SAMPLE'")) {
  const html = mailer.textToHtml(SAMPLE_STD);
  run('INSERT INTO email_templates(name, purpose, body, html, is_default, auto_send) VALUES(?,?,?,?,1,0)', 'Sample dispatch (cover letter)', 'SAMPLE', SAMPLE_STD, html);
}

function dispatchData(id) {
  const m = mkt(); if (!m) throw new UserErr('Marketing data is not open.');
  const d = require('./marketing/print').dispatchFull(id);
  if (!d) throw new UserErr('This dispatch is not there any more.');
  return d;
}
const titleCase = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
const money = n => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const kgs = n => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 });
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
function sampleTable(d) {
  const cols = ['#', 'Grade', 'Item', 'Colour', 'Mesh', 'Sample', 'Bulk packing', 'Rate', 'Minimum order'];
  const rows = d.lines.map((l, i) => [String(i + 1), l.grade || '', titleCase(l.item_name), l.colour || '', l.mesh || '', l.sample_size || '',
    [l.bag_weight ? kgs(l.bag_weight) + ' KG BAG' : '', l.bag_type, l.packing_type, l.liner === 1 ? 'WITH LINER' : l.liner === 0 ? 'WITHOUT LINER' : ''].filter(Boolean).join(' · '),
    l.rate != null ? `Rs.${money(l.rate)} per ${l.unit || ''}`.trim() : '', l.unit === 'KG' ? d.s.min_order_kg : l.unit === 'MT' ? d.s.min_order_mt : '']);
  const keep = cols.map((c, j) => j < 3 || rows.some(r => r[j]));            // leave out empty columns
  const C = cols.filter((c, j) => keep[j]), R = rows.map(r => r.filter((c, j) => keep[j]));
  const td = 'border:1px solid #c9d3d6;padding:5px 8px;font-size:13px;vertical-align:top';
  return {
    text: R.map(r => r.filter(Boolean).join(' | ')).join('\n'),
    html: `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin:0 0 14px;width:100%"><thead><tr>${C.map(c => `<th style="${td};background:#eef3f4;text-align:left">${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${R.map(r => `<tr>${r.map((c, j) => `<td style="${td}${C[j] === 'Grade' || C[j] === 'Rate' ? ';font-weight:bold' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`
  };
}
function sampleValues(d) {
  const L = d.lead || {}, n = d.lines.length, no = d.dispatch.tracking_no || '';
  const items = [...new Set(d.lines.map(l => titleCase(l.item_name)).filter(Boolean))].join(', ') || 'Natural mineral';
  return {
    'addressed to': [L.buyer_name ? 'Shri ' + L.buyer_name : '', L.company ? 'M/s. ' + L.company : '', [L.city, L.state].filter(Boolean).join(', ')].filter(Boolean).join('\n'),
    'buyer name': L.buyer_name || '', company: L.company || '', city: [L.city, L.state].filter(Boolean).join(', '), 'ref no.': String(L.ref_no ?? ''),
    'dispatch date': dmy(d.dispatch.date), samples: n === 1 ? 'a sample' : `samples of ${n} grades`, items, courier: d.dispatch.courier || '',
    'tracking no.': no, 'tracking link': trackLink(d.dispatch.courier, no), rates: d.s.gst_note || '', 'delivery time': d.s.delivery_time || '',
    'payment terms': d.s.payment_terms || '', 'packing note': d.lines.some(l => l.unit === 'KG') ? 'All consignments sent via transport that do not meet a full truckload will be packed in double HDPE bags to ensure product safety during transit. ' : '',
    signer: d.s.signer || '', 'seller name': d.firm.name || '', today: dmy(stamp())
  };
}
function fillSample(tpl, d) {
  const v = sampleValues(d), table = sampleTable(d);
  const key = k => k.trim().toLowerCase();
  const empty = k => { const kk = key(k); return kk !== 'sample table' && kk in v && !v[kk]; };
  tpl = { body: String(tpl.body || SAMPLE_STD).split('\n').filter(l => !(/^\s*\{([^{}]+)\}\s*$/.test(l) && empty(l.trim().slice(1, -1)))).join('\n'),
    html: tpl.html ? String(tpl.html).replace(/(<br\s*\/?>)?\s*\{([^{}<>]+)\}\s*(<br\s*\/?>)?/gi, (m, a, k, b) => empty(k) && (a || b) ? (a && b ? a : '') : m) : null };
  const text = String(tpl.body || SAMPLE_STD).replace(/\{([^{}]+)\}/g, (m, k) => key(k) === 'sample table' ? table.text : v[key(k)] ?? m)
    .replace(/^.*\(\)\s*$/gm, s => s.replace(/ \(\)/, '')).replace(/\n{3,}/g, '\n\n');
  let html = String(tpl.html || mailer.textToHtml(tpl.body || SAMPLE_STD));
  html = html.replace(/<p[^>]*>\s*\{\s*sample table\s*\}\s*<\/p>/gi, table.html)
    .replace(/\{([^{}<>]+)\}/g, (m, k) => {
      const kk = key(k);
      if (kk === 'sample table') return table.html;
      if (kk === 'tracking link') return v[kk] ? `<a href="${esc(v[kk])}" style="color:#1a6fb0">${esc(v[kk])}</a>` : '';
      return v[kk] != null ? esc(v[kk]).replace(/\n/g, '<br>') : m;
    });
  return { text, html };
}
function sampleDraft(id, tid) {
  const d = dispatchData(id);
  const tpl = tid ? get('SELECT name, body, html, with_anrep FROM email_templates WHERE id = ?', tid)
    : get("SELECT name, body, html, with_anrep FROM email_templates WHERE purpose = 'SAMPLE' AND active = 1 ORDER BY is_default DESC, id LIMIT 1");
  const m = fillSample(tpl || { body: SAMPLE_STD }, d);
  const to = mailer.splitAddr(d.lead && d.lead.email || '');
  const f = get('SELECT * FROM firms WHERE code = ?', d.firm.code) || d.firm;
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: sampleSubject(d), text: m.text, html: m.html,
    template_name: tpl ? tpl.name : 'Standard message', firm_code: f.code, firm: f.name, from: f.smtp_user || f.email || '', ready: !!(f.smtp_user && f.smtp_pass),
    anreps: require('./anreport').reportsForLines(d.lines).map(r => ({ id: r.id, name: require('./anreport').printName(r) })), with_anrep: tpl ? !!tpl.with_anrep : false, dispatch_id: id,
    tracking_no: d.dispatch.tracking_no || '', company: (d.lead && (d.lead.company || d.lead.buyer_name)) || '',
    templates: all("SELECT id, name, is_default FROM email_templates WHERE purpose = 'SAMPLE' AND active = 1 ORDER BY is_default DESC, name") };
}
function sampleSubject(d) {
  const no = d.dispatch.tracking_no;
  return `Sample dispatched${d.dispatch.courier ? ' by ' + d.dispatch.courier : ''}${no ? ' — tracking no. ' + no : ''} — your Ref. ${d.lead ? d.lead.ref_no : ''} — ${d.firm.name || ''}`;
}

module.exports = function register(route, { smtpSend, brandLogo, port, pdfFolder }) {
  async function sendSample(id, body, auto) {
    const d = dispatchData(id), f = get('SELECT * FROM firms WHERE code = ?', d.firm.code) || d.firm;
    const to = mailer.splitAddr(body.to), cc = mailer.splitAddr(body.cc);
    const L = d.lead || {};
    const log = (status, error) => run(`INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)`,
      f.code, f.name, L.company || L.buyer_name || '', String(body.to || ''), body.template_name || 'Standard message', 'Ref ' + (L.ref_no ?? '') + (d.dispatch.tracking_no ? ' · ' + d.dispatch.tracking_no : ''),
      auto ? 'Sample dispatch (automatic)' : 'Sample dispatch', status, error || null, status === 'SENT' && atts.length ? 'Analysis report (' + atts.map(a => a.name).join(', ') + ')' : null);
    let atts = [];
    try {
      if (!f.smtp_user || !f.smtp_pass) throw new UserErr(`Email is not set up for ${f.name}. Open Settings → Companies → Email.`);
      if (!to.length) throw new UserErr('Enter the customer email address.');
      // analysis reports of the grades sent (Master → Analysis Reports), on the sender firm's letter head
      if (body.anrep === undefined ? !!(get("SELECT with_anrep FROM email_templates WHERE purpose = 'SAMPLE' AND active = 1 ORDER BY is_default DESC, id LIMIT 1") || {}).with_anrep : Number(body.anrep)) atts = await require('./anreport').attachFor(d.lines, null, f.code, { port, pdfFolder }, { dispatch: id });
      await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
        { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || sampleSubject(d), text: body.text ? String(body.text) : mailer.htmlToText(body.html), html: body.html ? String(body.html) : undefined, attachments: atts.map(a => ({ path: a.path, filename: a.filename })) });
      log('SENT');
      return { sent: true, at: new Date().toLocaleString('en-IN'), to: to.join(', ') };
    } catch (e) { log('FAILED', e.message); throw e; }
  }

  // ---- automatic: queue on a new tracking number, send after 5 minutes ----
  function onTracking(id, oldNo, newNo) {
    try {
      newNo = String(newNo || '').trim();
      if (!newNo || newNo === String(oldNo || '').trim()) return;
      if (setting('auto_sample_email', '0') !== '1') return;
      if (get("SELECT 1 FROM sample_mails WHERE dispatch_id = ? AND tracking_no = ? AND status = 'SENT'", id, newNo)) return;
      run("UPDATE sample_mails SET status = 'REPLACED' WHERE dispatch_id = ? AND status IN ('WAIT', 'FAILED')", id);
      run("INSERT INTO sample_mails(dispatch_id, tracking_no, status, due_at) VALUES(?, ?, 'WAIT', ?)", id, newNo, stamp(new Date(Date.now() + 5 * 60e3)));
    } catch (e) { console.error('Sample email queue:', e.message); }
  }
  require('./hooks').on('tracking', onTracking);
  let busy = false;
  async function worker() {
    if (busy || !mkt()) return; busy = true;
    try {
      const due = all(`SELECT * FROM sample_mails WHERE (status = 'WAIT' AND due_at <= ?) OR (status = 'FAILED' AND tries < 5 AND due_at <= ?) ORDER BY id LIMIT 10`, stamp(), stamp());
      for (const q of due) {
        const disp = M().get('SELECT tracking_no FROM dispatches WHERE id = ?', q.dispatch_id);
        if (!disp || String(disp.tracking_no || '') !== q.tracking_no) { run("UPDATE sample_mails SET status = 'REPLACED' WHERE id = ?", q.id); continue; }
        if (setting('auto_sample_email', '0') !== '1') { run("UPDATE sample_mails SET status = 'OFF' WHERE id = ?", q.id); continue; }
        let dr; try { dr = sampleDraft(q.dispatch_id); } catch (e) { run("UPDATE sample_mails SET status = 'FAILED', tries = 9, error = ? WHERE id = ?", e.message, q.id); continue; }
        if (!dr.to) { run("UPDATE sample_mails SET status = 'NO EMAIL', error = 'The customer has no email address.' WHERE id = ?", q.id); continue; }
        try {
          await sendSample(q.dispatch_id, { to: dr.to, cc: dr.cc, subject: dr.subject, text: dr.text, html: dr.html, template_name: dr.template_name }, true);
          run("UPDATE sample_mails SET status = 'SENT', sent_at = ?, to_addr = ?, error = NULL WHERE id = ?", stamp(), dr.to, q.id);
          console.log(`  Sample dispatch email (Ref ${dr.company}, ${q.tracking_no}) sent to ${dr.to} (automatic).`);
        } catch (e) {
          run("UPDATE sample_mails SET status = 'FAILED', tries = tries + 1, error = ?, due_at = ? WHERE id = ?", String(e.message).slice(0, 300), stamp(new Date(Date.now() + 3600e3)), q.id);
        }
      }
    } finally { busy = false; }
  }
  setInterval(() => worker().catch(e => console.error('Sample email:', e.message)), 60e3).unref();

  // ---- routes ----
  route('GET', '/api/couriers', () => ({ couriers: all('SELECT * FROM couriers WHERE active = 1 ORDER BY name'), general: generalLink() }));
  route('POST', '/api/couriers', ({ body }) => {
    const o = cleanCourier(body);
    if (get('SELECT 1 FROM couriers WHERE upper(name) = ? AND active = 1', o.name)) throw new UserErr(`${o.name} is already in the list.`);
    const old = get('SELECT id FROM couriers WHERE upper(name) = ?', o.name);
    if (old) run('UPDATE couriers SET website = ?, tracking_url = ?, active = 1 WHERE id = ?', o.website || null, o.tracking_url || null, old.id);
    else run('INSERT INTO couriers(name, website, tracking_url) VALUES(?,?,?)', o.name, o.website || null, o.tracking_url || null);
    toMktList(o.name);
    return { ok: true };
  });
  route('PUT', '/api/couriers/:id', ({ p, body }) => {
    const o = cleanCourier(body), cur = get('SELECT * FROM couriers WHERE id = ?', p.id);
    if (!cur) throw new UserErr('This courier is not there any more.');
    if (get('SELECT 1 FROM couriers WHERE upper(name) = ? AND id <> ?', o.name, p.id)) throw new UserErr(`${o.name} is already in the list.`);
    run('UPDATE couriers SET name = ?, website = ?, tracking_url = ? WHERE id = ?', o.name, o.website || null, o.tracking_url || null, p.id);
    if (cur.name !== o.name) { const m = mkt(); if (m) try { m.run("UPDATE mkt_lists SET value = ? WHERE list_key = 'courier' AND upper(value) = upper(?)", o.name, cur.name); } catch { toMktList(o.name); } }
    else toMktList(o.name);
    return { ok: true };
  });
  route('DELETE', '/api/couriers/:id', ({ p }) => { run('UPDATE couriers SET active = 0 WHERE id = ?', p.id); return { ok: true }; });
  route('POST', '/api/couriers/find-link', ({ body }) => findTrackingUrl(String((body && body.website) || '').trim()));

  route('GET', '/api/auto-email/sample', () => ({ on: setting('auto_sample_email', '0') === '1' }));
  route('PUT', '/api/auto-email/sample', ({ body }) => { setSetting('auto_sample_email', Number(body.on) ? '1' : '0'); return { on: Number(body.on) === 1 }; });
  route('GET', '/api/sample-mail/vars', () => ({ vars: SAMPLE_VARS }));
  route('GET', '/api/sample-mail/:id', ({ p, q }) => sampleDraft(Number(p.id), q.tid ? Number(q.tid) : null));
  route('POST', '/api/sample-mail/:id', async ({ p, body }) => {
    const r = await sendSample(Number(p.id), body || {}, false);
    const disp = M().get('SELECT tracking_no FROM dispatches WHERE id = ?', p.id);
    run("UPDATE sample_mails SET status = 'REPLACED' WHERE dispatch_id = ? AND status IN ('WAIT', 'FAILED')", p.id);
    run("INSERT INTO sample_mails(dispatch_id, tracking_no, status, sent_at, to_addr, auto) VALUES(?, ?, 'SENT', ?, ?, 0)", p.id, disp ? disp.tracking_no : null, stamp(), r.to);
    return r;
  });
  // last email state of these dispatches (shown on the enquiry page)
  route('GET', '/api/sample-mail-status', ({ q }) => {
    const ids = String(q.ids || '').split(',').map(Number).filter(Boolean).slice(0, 500);
    if (!ids.length) return {};
    const o = {};
    for (const r of all(`SELECT * FROM sample_mails WHERE dispatch_id IN (${ids.map(() => '?').join(',')}) AND status <> 'REPLACED' ORDER BY id`, ...ids))
      o[r.dispatch_id] = { status: r.status, at: r.sent_at || r.due_at, error: r.error, to: r.to_addr, tracking_no: r.tracking_no };
    return o;
  });
};
module.exports.trackLink = trackLink;
module.exports.SAMPLE_VARS = SAMPLE_VARS;
module.exports.findTrackingUrl = findTrackingUrl;
