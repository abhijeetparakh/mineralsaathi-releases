'use strict';
/* Reports → Buyer Chart, Sales Analysis, Expected Orders.
   All sales of all years come once from /api/analysis; the screens add them up here.
   Charts are drawn as SVG by hand (no outside library): thin marks, one axis, hover tooltips. */

// categorical colours, always in this order (validated palette); grey for "last year" / reference
const AN_COL = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'];
const AN_GREY = '#b4bcbf';
const AN_MON = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
const AN_MONTH_FULL = ['APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER', 'JANUARY', 'FEBRUARY', 'MARCH'];
const anMi = ym => (Number(ym.slice(5, 7)) + 8) % 12;                     // 2026-04 → 0 (April) … 2027-03 → 11
const anFyOf = iso => { const y = Number(iso.slice(0, 4)), m = Number(iso.slice(5, 7)); const a = m >= 4 ? y : y - 1; return `${a}-${String(a + 1).slice(2)}`; };
const anPrevFy = fy => { const a = Number(fy.slice(0, 4)) - 1; return `${a}-${String(a + 1).slice(2)}`; };
const anYmOf = (fy, i) => { const a = Number(fy.slice(0, 4)), m = (i + 3) % 12 + 1; return `${i < 9 ? a : a + 1}-${String(m).padStart(2, '0')}`; };
const anAddDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + Math.round(n)); return d.toISOString().slice(0, 10); };
const anDays = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 864e5);
// ₹ in lakh / crore for axes and tiles; full rupees in tooltips
const anRsShort = n => { const v = Math.abs(n); return v >= 1e7 ? '₹' + (n / 1e7).toFixed(v >= 1e8 ? 0 : 1) + ' Cr' : v >= 1e5 ? '₹' + (n / 1e5).toFixed(v >= 1e6 ? 0 : 1) + ' L' : '₹' + Math.round(n).toLocaleString('en-IN'); };
const anFmt = (m, n, long) => m === 'amt' ? (long ? rs(n) : anRsShort(n)) : (long ? qty(n) + ' MT' : Number(n).toLocaleString('en-IN', { maximumFractionDigits: n >= 100 ? 0 : 1 }) + (long ? ' MT' : ''));

let AN = null, ANat = 0;
async function anData(fresh) {
  if (!AN || fresh || Date.now() - ANat > 120e3) { AN = await GET('/api/analysis'); ANat = Date.now(); AN.partyList = Object.entries(AN.parties).map(([k, p]) => ({ pk: k, ...p })).sort((a, b) => a.name.localeCompare(b.name)); }
  return AN;
}
// the sales lines left after the filters: firm, own firms, buyer, item
function anRows(d, f) {
  return d.lines.filter(r => (!f.firm || r[2] === f.firm) && (f.own || !d.parties[r[3]].own) && (!f.pk || r[3] === f.pk) && (!f.item || r[4] === f.item));
}
const anVal = (r, m) => m === 'amt' ? r[7] : r[6];

// ---------- the tooltip (one for all charts) ----------
function anTip() {
  let t = $('#antip');
  if (!t) { t = document.createElement('div'); t.id = 'antip';
    t.style.cssText = 'position:fixed;z-index:80;pointer-events:none;background:#fff;border:1px solid var(--line);border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.14);padding:8px 10px;font-size:12.5px;line-height:1.45;max-width:320px;display:none';
    document.body.appendChild(t); }
  return t;
}
function anHover(root) {
  const t = anTip();
  root.addEventListener('mousemove', e => {
    const h = e.target.closest('[data-tip]'); if (!h || !root.contains(h)) { t.style.display = 'none'; return; }
    t.innerHTML = h.dataset.tip; t.style.display = 'block';
    const x = Math.min(e.clientX + 14, innerWidth - t.offsetWidth - 8), y = Math.min(e.clientY + 14, innerHeight - t.offsetHeight - 8);
    t.style.left = x + 'px'; t.style.top = y + 'px';
    if (root.dataset.cross != null) { const c = $('.ancross', root); const col = h.dataset.col; if (c && col != null) { c.setAttribute('x1', h.dataset.cx); c.setAttribute('x2', h.dataset.cx); c.style.display = ''; } }
  });
  root.addEventListener('mouseleave', () => { t.style.display = 'none'; const c = $('.ancross', root); if (c) c.style.display = 'none'; });
}
const anNice = v => { if (!(v > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; };
const anLegend = items => `<div class="row" style="gap:14px;flex-wrap:wrap;margin:0 0 6px;font-size:12.5px;color:var(--muted)">${items.map(([n, c, dash]) =>
  `<span style="display:inline-flex;align-items:center;gap:6px"><svg width="18" height="10"><line x1="1" y1="5" x2="17" y2="5" stroke="${c}" stroke-width="${dash ? 2 : 3}" ${dash ? 'stroke-dasharray="4 3"' : ''} stroke-linecap="round"/></svg>${esc(n)}</span>`).join('')}</div>`;

// vertical bars: labels[], values[], optional colours[] and click keys
function anBars(box, { labels, values, colors, keys, fmt, tip, height = 240, onClick, group = 1 }) {
  const W = Math.max(320, box.clientWidth || 600), H = height, L = 64, R = 10, T = 12, B = 30;
  const max = anNice(Math.max(...values, 0) * 1.08), n = labels.length, slot = (W - L - R) / n, bw = Math.max(6, Math.min(48, slot * 0.62));
  const y = v => T + (H - T - B) * (1 - v / max);
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = max * i / 4, yy = y(v); g += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" stroke="#e8eef0"/><text x="${L - 8}" y="${yy + 4}" text-anchor="end" font-size="11" fill="#63757b">${esc(fmt(v))}</text>`; }
  const bars = values.map((v, i) => { const x = L + slot * i + (slot - bw) / 2, yy = y(v), h = Math.max(0, H - B - yy), r = Math.min(4, h, bw / 2);
    const path = h > 0 ? `M${x},${H - B} L${x},${yy + r} Q${x},${yy} ${x + r},${yy} L${x + bw - r},${yy} Q${x + bw},${yy} ${x + bw},${yy + r} L${x + bw},${H - B} Z` : '';
    return `<g data-tip="${esc(tip ? tip(i) : `<b>${esc(labels[i])}</b><br>${esc(fmt(v, true))}`)}" ${keys ? `data-k="${esc(keys[i])}" style="cursor:pointer"` : ''}>
      <rect x="${L + slot * i}" y="${T}" width="${slot}" height="${H - T - B}" fill="transparent"/><path d="${path}" fill="${(colors && colors[i]) || AN_COL[0]}"/></g>`; }).join('');
  const every = group > 1 ? group : Math.ceil(n / Math.max(1, Math.floor((W - L - R) / 62)));
  // group > 1: one label under each group of bars (e.g. last year + expected)
  const xl = labels.map((l, i) => i % every ? '' : `<text x="${L + slot * i + slot * (group > 1 ? group : 1) / 2}" y="${H - 10}" text-anchor="middle" font-size="11.5" fill="#63757b">${esc(l)}</text>`).join('');
  box.innerHTML = `<svg width="${W}" height="${H}" style="display:block">${g}<line x1="${L}" x2="${W - R}" y1="${H - B}" y2="${H - B}" stroke="#c9d3d6"/>${bars}${xl}</svg>`;
  anHover(box);
  if (onClick) box.onclick = e => { const k = e.target.closest('[data-k]'); if (k) onClick(k.dataset.k); };
}
// lines over the 12 months of the financial year; series: [{ name, color, values[12] (null = not yet), dash }]
function anLines(box, { series, fmt, height = 280 }) {
  const W = Math.max(360, box.clientWidth || 700), H = height, L = 64, R = 14, T = 12, B = 28;
  const all = series.flatMap(s => s.values.filter(v => v != null));
  const max = anNice(Math.max(...all, 0) * 1.08), slot = (W - L - R) / 12;
  const x = i => L + slot * i + slot / 2, y = v => T + (H - T - B) * (1 - v / max);
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = max * i / 4, yy = y(v); g += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" stroke="#e8eef0"/><text x="${L - 8}" y="${yy + 4}" text-anchor="end" font-size="11" fill="#63757b">${esc(fmt(v))}</text>`; }
  const paths = series.map(s => { const pts = s.values.map((v, i) => v == null ? null : [x(i), y(v)]);
    let d = '', on = false; pts.forEach(p => { if (!p) { on = false; return; } d += (on ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1); on = true; });
    return `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" ${s.dash ? 'stroke-dasharray="5 4"' : ''}/>`
      + pts.map(p => p ? `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="${s.color}" stroke="#fff" stroke-width="2"/>` : '').join(''); }).join('');
  const cols = AN_MON.map((m, i) => `<rect x="${L + slot * i}" y="${T}" width="${slot}" height="${H - T - B}" fill="transparent" data-col="${i}" data-cx="${x(i)}"
    data-tip="${esc(`<b>${AN_MON[i]}</b><br>` + series.map(s => `<span style="color:${s.color}">●</span> ${esc(s.name)}: <b>${s.values[i] == null ? '—' : esc(fmt(s.values[i], true))}</b>`).join('<br>'))}"/>`).join('');
  const xl = AN_MON.map((m, i) => `<text x="${x(i)}" y="${H - 9}" text-anchor="middle" font-size="11.5" fill="#63757b">${m}</text>`).join('');
  box.dataset.cross = '1';
  box.innerHTML = anLegend(series.map(s => [s.name, s.color, s.dash])) + `<svg width="${W}" height="${H}" style="display:block">${g}<line x1="${L}" x2="${W - R}" y1="${H - B}" y2="${H - B}" stroke="#c9d3d6"/>
    <line class="ancross" x1="0" x2="0" y1="${T}" y2="${H - B}" stroke="#9aa8ad" stroke-dasharray="3 3" style="display:none"/>${paths}${cols}${xl}</svg>`;
  anHover(box);
}
// horizontal bars: rows [{ label, value, prev, key, sub }] — prev is drawn as a thin grey mark (last year)
function anHBars(box, { rows, fmt, onClick, color = AN_COL[0], prevName = 'Last year' }) {
  const max = Math.max(...rows.map(r => Math.max(r.value, r.prev || 0)), 1);
  box.innerHTML = rows.map(r => `<div data-tip="${esc(`<b>${esc(r.label)}</b><br>${esc(fmt(r.value, true))}${r.prev != null ? `<br>${esc(prevName)}: ${esc(fmt(r.prev, true))}` : ''}${r.sub ? '<br>' + esc(r.sub) : ''}`)}" ${r.key ? `data-k="${esc(r.key)}"` : ''}
      style="display:grid;grid-template-columns:minmax(120px,38%) 1fr 92px;gap:10px;align-items:center;padding:4px 0;${r.key && onClick ? 'cursor:pointer' : ''}">
      <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px">${esc(r.label)}</div>
      <div style="position:relative;height:16px"><div style="position:absolute;left:0;top:2px;height:12px;width:${(r.value / max * 100).toFixed(2)}%;background:${color};border-radius:0 4px 4px 0"></div>
        ${r.prev != null ? `<div style="position:absolute;top:0;height:16px;width:2px;background:#5d6b70;left:calc(${(r.prev / max * 100).toFixed(2)}% - 1px)" title=""></div>` : ''}</div>
      <div style="text-align:right;font-size:12.5px;font-variant-numeric:tabular-nums">${esc(fmt(r.value))}</div></div>`).join('') || '<p class="muted">No sales.</p>';
  anHover(box);
  if (onClick) box.onclick = e => { const k = e.target.closest('[data-k]'); if (k) onClick(k.dataset.k); };
}

// ---------- shared filter bar ----------
function anFilters(st, d, { fy = true, item = true, buyer = false, measure = true } = {}) {
  const items = [...new Set(d.lines.map(r => r[4]))].sort();
  return `<div class="card" style="padding:10px 14px"><div class="row" style="gap:10px;flex-wrap:wrap;align-items:end">
    ${fy ? `<label style="width:120px">F.Y.<select data-f="fy">${[...d.fys].reverse().map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>` : ''}
    <label style="width:170px">Firm<select data-f="firm"><option value="">All firms</option>${['PM', 'PF', 'PPE'].map(k => `<option value="${k}" ${st.firm === k ? 'selected' : ''}>${FIRM_NAME[k]}</option>`).join('')}</select></label>
    ${measure ? `<label style="width:150px">Show<select data-f="m"><option value="qty" ${st.m === 'qty' ? 'selected' : ''}>Quantity (MT)</option><option value="amt" ${st.m === 'amt' ? 'selected' : ''}>Amount (₹, before GST)</option></select></label>` : ''}
    ${item ? `<label style="width:220px">Item<select data-f="item"><option value="">All items</option>${items.map(i => `<option ${st.item === i ? 'selected' : ''}>${esc(i)}</option>`).join('')}</select></label>` : ''}
    ${buyer ? `<label style="width:260px">Buyer<input data-f="buyer" list="dl-anb" placeholder="All buyers — type to choose" value="${esc(st.pk && d.parties[st.pk] ? d.parties[st.pk].name : '')}"><datalist id="dl-anb">${d.partyList.filter(p => st.own || !p.own).map(p => `<option value="${esc(p.name)}${p.city ? ' — ' + esc(p.city) : ''}">`).join('')}</datalist></label>` : ''}
    <label style="display:flex;gap:6px;align-items:center;padding-bottom:8px"><input type="checkbox" data-f="own" style="width:auto" ${st.own ? 'checked' : ''}> Include sales between our own firms</label>
  </div></div>`;
}
function anHookFilters(el, st, d, redraw) {
  $$('[data-f]', el).forEach(c => c.onchange = () => {
    const k = c.dataset.f;
    if (k === 'own') st.own = c.checked;
    else if (k === 'buyer') { const v = c.value.trim(); st.pk = v ? (d.partyList.find(p => `${p.name}${p.city ? ' — ' + p.city : ''}` === v || p.name === v) || {}).pk || st.pk : ''; }
    else st[k] = c.value;
    redraw();
  });
}

// ---------- Buyer Chart: buyers × months of one financial year ----------
TITLES.buyerchart = 'Buyer Chart';
PAGES.buyerchart = async el => {
  el.innerHTML = '<div class="empty">Adding up the sales of all years…</div>';
  const d = await anData();
  const st = S.anb = S.anb || { fy: S.fy || d.fys[d.fys.length - 1], firm: '', m: 'qty', item: '', own: false, q: '', sort: 'name' };
  if (!d.fys.includes(st.fy)) st.fy = d.fys[d.fys.length - 1];
  const draw = () => {
    const rows = anRows(d, st), prevFy = anPrevFy(st.fy);
    const map = new Map();
    for (const r of rows) {
      if (r[0] !== st.fy && r[0] !== prevFy) continue;
      const x = map.get(r[3]) || { pk: r[3], m: Array(12).fill(0), tot: 0, prev: 0 };
      if (r[0] === st.fy) { x.m[anMi(r[1])] += anVal(r, st.m); x.tot += anVal(r, st.m); } else x.prev += anVal(r, st.m);
      map.set(r[3], x);
    }
    let list = [...map.values()].filter(x => x.tot > 0 || x.prev > 0).map(x => ({ ...x, name: d.parties[x.pk].name, city: d.parties[x.pk].city }));
    const q = st.q.trim().toUpperCase(); if (q) list = list.filter(x => x.name.toUpperCase().includes(q) || String(x.city || '').toUpperCase().includes(q));
    const ch = x => x.prev > 0 ? (x.tot - x.prev) / x.prev * 100 : null;
    list.sort(st.sort === 'total' ? (a, b) => b.tot - a.tot : st.sort === 'change' ? (a, b) => (ch(b) ?? 1e9) - (ch(a) ?? 1e9) : (a, b) => a.name.localeCompare(b.name));
    const colTot = Array(12).fill(0); list.forEach(x => x.m.forEach((v, i) => colTot[i] += v));
    const max = Math.max(...list.flatMap(x => x.m), 1), grand = list.reduce((s, x) => s + x.tot, 0), grandPrev = list.reduce((s, x) => s + x.prev, 0);
    const f = v => v ? (st.m === 'amt' ? Math.round(v).toLocaleString('en-IN') : qty(v)) : '';
    const heat = v => v ? `background:rgba(42,120,214,${(0.08 + 0.5 * v / max).toFixed(3)})` : '';
    const ongoing = st.fy === anFyOf(d.today);
    const chg = x => { const c = ch(x); return x.prev > 0 && !x.tot ? (ongoing ? '<span class="badge grey">none yet</span>' : '<span class="badge red">stopped</span>') : c == null ? (x.tot ? '<span class="badge PM">new</span>' : '')
      : `<span style="color:${c >= 0 ? 'var(--ok)' : 'var(--bad)'};font-weight:600">${c >= 0 ? '▲' : '▼'} ${Math.abs(c) > 999 ? '>999' : Math.abs(c).toFixed(0)}%</span>`; };
    $('#anbody', el).innerHTML = `<div class="card" style="padding:0">
      <div class="toolbar" style="padding:10px 14px"><h3 style="margin:0">Buyer chart · ${esc(st.fy)} <span class="hint">${list.length} buyers · ${st.m === 'amt' ? '₹ before GST' : 'MT'} · darker = more</span></h3><span class="spacer"></span>
        <input type="search" id="anbq" placeholder="Search buyer / city" value="${esc(st.q)}" style="width:200px">
        <select id="anbs" style="width:auto"><option value="name" ${st.sort === 'name' ? 'selected' : ''}>A → Z</option><option value="total" ${st.sort === 'total' ? 'selected' : ''}>Biggest first</option><option value="change" ${st.sort === 'change' ? 'selected' : ''}>Most growth first</option></select>
        <button class="sec" id="anbx">Export</button></div>
      <style>.anb td, .anb th { padding:5px 6px !important; } .anb td:first-child { max-width:230px; }</style>
      <div class="tablewrap" style="max-height:68vh"><table class="t anb" style="font-size:12.5px"><thead><tr><th>Party</th>${AN_MONTH_FULL.map(m => `<th class="num">${m.slice(0, 3)}</th>`).join('')}<th class="num">Total</th><th class="num">${esc(prevFy)}</th><th class="num">Change</th></tr></thead><tbody>
      ${list.map(x => `<tr class="click" data-pk="${esc(x.pk)}"><td><b>${esc(x.name)}</b> <span class="hint">${esc(x.city || '')}</span></td>${x.m.map(v => `<td class="num" style="${heat(v)}">${f(v)}</td>`).join('')}
        <td class="num"><b>${f(x.tot)}</b></td><td class="num" style="color:var(--muted)">${f(x.prev)}</td><td class="num">${chg(x)}</td></tr>`).join('') || '<tr><td colspan="16" class="muted">No sales.</td></tr>'}
      <tr style="font-weight:700;background:#f4f7f8"><td>Total</td>${colTot.map(v => `<td class="num">${f(v)}</td>`).join('')}<td class="num">${f(grand)}</td><td class="num">${f(grandPrev)}</td>
        <td class="num">${grandPrev ? `<span style="color:${grand >= grandPrev ? 'var(--ok)' : 'var(--bad)'}">${grand >= grandPrev ? '▲' : '▼'} ${Math.abs((grand - grandPrev) / grandPrev * 100).toFixed(0)}%</span>` : ''}</td></tr></tbody></table></div>
      <p class="hint" style="padding:6px 14px 10px;margin:0">Click a buyer to see all its years, items and orders. ${st.fy === S.meta.current_fy ? `The ${esc(prevFy)} column is the whole of last year.` : ''}</p></div>`;
    let tm; $('#anbq', el).oninput = e => { clearTimeout(tm); tm = setTimeout(() => { st.q = e.target.value; draw(); const s = $('#anbq', el); s.focus(); s.setSelectionRange(s.value.length, s.value.length); }, 250); };
    $('#anbs', el).onchange = e => { st.sort = e.target.value; draw(); };
    $('#anbx', el).onclick = () => downloadCsv(`buyer_chart_${st.fy}.csv`, list.map(x => ({ party: x.name, city: x.city, ...Object.fromEntries(AN_MONTH_FULL.map((m, i) => [m, x.m[i] ? r2(x.m[i]) : ''])), total: r2(x.tot), [prevFy]: r2(x.prev) })));
  };
  el.innerHTML = anFilters(st, d) + '<div id="anbody"></div>';
  anHookFilters(el, st, d, draw);
  el.onclick = e => { const tr = e.target.closest('tr[data-pk]'); if (tr) anParty(tr.dataset.pk, st); };
  draw();
};

// ---------- Sales Analysis: year by year, month by month, buyers, items ----------
TITLES.analysis = 'Sales Analysis';
PAGES.analysis = async el => {
  el.innerHTML = '<div class="empty">Adding up the sales of all years…</div>';
  const d = await anData();
  const cur = d.fys[d.fys.length - 1];
  const st = S.ana = S.ana || { fy: S.fy || cur, firm: '', m: 'qty', item: '', own: false, pk: '', years: d.fys.slice(-3) };
  if (!d.fys.includes(st.fy)) st.fy = cur;
  const draw = () => {
    const rows = anRows(d, st), fy = st.fy, prevFy = anPrevFy(fy), todayIso = d.today, ongoing = fy === anFyOf(todayIso);
    // same period last year: April up to this month
    const inPeriod = ym => !ongoing || anMi(ym) <= anMi(todayIso.slice(0, 7));
    const sum = (f, filt = () => true) => rows.filter(r => r[0] === f && filt(r)).reduce((s, r) => s + anVal(r, st.m), 0);
    const thisV = sum(fy), prevAll = sum(prevFy);
    // same period last year, to the same day (invoice dates); with an item chosen, to the same month
    const lyDay = String(Number(todayIso.slice(0, 4)) - 1) + todayIso.slice(4);
    const prevSame = !ongoing ? prevAll : st.item ? sum(prevFy, r => inPeriod(r[1]))
      : d.orders.filter(o => anFyOf(o[1]) === prevFy && o[1] <= lyDay && (!st.firm || o[2] === st.firm) && (st.own || !d.parties[o[0]].own) && (!st.pk || o[0] === st.pk)).reduce((s, o) => s + (st.m === 'amt' ? o[4] : o[3]), 0);
    const buyers = f => new Set(rows.filter(r => r[0] === f && (r[6] || r[7])).map(r => r[3]));
    const bNow = buyers(fy), bPrev = buyers(prevFy);
    const invN = f => d.counts.filter(c => c[0] === f && (!st.firm || c[2] === st.firm) && (st.own || !d.parties[c[3]].own) && (!st.pk || c[3] === st.pk)).reduce((s, c) => s + c[4], 0);
    const g = (a, b) => b ? ((a - b) / b * 100) : null;
    const tile = (k, v, sub, gr) => `<div class="stat"><div class="k">${k}</div><div class="v">${v}</div><div class="hint">${sub}${gr != null ? ` <b style="color:${gr >= 0 ? 'var(--ok)' : 'var(--bad)'}">${gr >= 0 ? '▲' : '▼'} ${Math.abs(gr).toFixed(0)}%</b>` : ''}</div></div>`;
    const newB = [...bNow].filter(k => !bPrev.has(k)), lostB = [...bPrev].filter(k => !bNow.has(k));
    $('#anbody', el).innerHTML = `
      <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
        ${tile(`Sales ${esc(fy)}${ongoing ? ' so far' : ''}`, esc(anFmt(st.m, thisV, true)), ongoing ? `${st.item ? `Apr–${AN_MON[anMi(todayIso.slice(0, 7))]}` : 'till ' + dmy(lyDay)} of ${esc(prevFy)}: ${esc(anFmt(st.m, prevSame, true))}` : `${esc(prevFy)}: ${esc(anFmt(st.m, prevAll, true))}`, g(thisV, ongoing ? prevSame : prevAll))}
        ${tile('Buyers', bNow.size, `${esc(prevFy)}: ${bPrev.size} · new ${newB.length} · not bought ${lostB.length}`, null)}
        ${tile('Invoices', invN(fy), `${esc(prevFy)}: ${invN(prevFy)}`, null)}
        ${tile('Whole of ' + esc(prevFy), esc(anFmt(st.m, prevAll, true)), `${esc(anPrevFy(prevFy))}: ${esc(anFmt(st.m, sum(anPrevFy(prevFy)), true))}`, g(prevAll, sum(anPrevFy(prevFy))))}
      </div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Year by year <span class="hint">— click a year to look at it</span></h3><span class="hint">${ongoing ? esc(fy) + ' is till today' : ''}</span></div><div id="ch1" style="margin-top:8px"></div></div>
      <div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h3 style="margin:0">Month by month — year against year</h3>
        <div class="row" style="gap:10px;flex-wrap:wrap">${[...d.fys].reverse().slice(0, 8).map(y => `<label style="display:flex;gap:4px;align-items:center;font-weight:500"><input type="checkbox" data-yr="${y}" style="width:auto" ${st.years.includes(y) ? 'checked' : ''}> ${y}</label>`).join('')}</div></div>
        <div id="ch2" style="margin-top:8px"></div><p class="hint" style="margin:4px 0 0">Up to 8 years at a time. A line stops at the last month with sales.</p></div>
      <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start">
        <div class="card"><h3>Top buyers · ${esc(fy)} <span class="hint">— grey mark = ${esc(prevFy)} · click to open</span></h3><div id="ch3"></div></div>
        <div class="card"><h3>Items · ${esc(fy)} <span class="hint">— click an item to see only it</span></h3><div id="ch4"></div>
          <h3 style="margin-top:16px">Firms · ${esc(fy)}</h3><div id="ch5"></div></div></div>
      <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start">
        <div class="card"><h3>New buyers in ${esc(fy)} <span class="hint">${newB.length} · nothing in ${esc(prevFy)}</span></h3>${anList(d, rows, newB, fy, st.m)}</div>
        <div class="card"><h3>Bought in ${esc(prevFy)}, not yet in ${esc(fy)} <span class="hint">${lostB.length} · worth a call</span></h3>${anList(d, rows, lostB, prevFy, st.m)}</div></div>`;
    // 1. year by year (current year in blue, others grey)
    const ys = d.fys.filter(y => sum(y) > 0 || y === fy);
    anBars($('#ch1', el), { labels: ys, values: ys.map(y => sum(y)), keys: ys, colors: ys.map(y => y === fy ? AN_COL[0] : AN_GREY), fmt: (v, l) => anFmt(st.m, v, l),
      tip: i => `<b>${ys[i]}</b><br>${esc(anFmt(st.m, sum(ys[i]), true))}${i ? `<br>vs ${ys[i - 1]}: ${(() => { const p = sum(ys[i - 1]); return p ? ((sum(ys[i]) - p) / p * 100 >= 0 ? '▲ ' : '▼ ') + Math.abs((sum(ys[i]) - p) / p * 100).toFixed(0) + '%' : '—'; })()}` : ''}`,
      onClick: y => { st.fy = y; if (!st.years.includes(y)) st.years = [...st.years, y].slice(-8); draw(); $('[data-f=fy]', el).value = y; } });
    // 2. month by month, a line for each chosen year (newest = slot 1)
    const yrs = [...st.years].filter(y => d.fys.includes(y)).sort().reverse();
    anLines($('#ch2', el), { fmt: (v, l) => anFmt(st.m, v, l), series: yrs.map((y, i) => {
      const v = Array(12).fill(0); rows.filter(r => r[0] === y).forEach(r => v[anMi(r[1])] += anVal(r, st.m));
      const last = y === anFyOf(todayIso) ? anMi(todayIso.slice(0, 7)) : 11;
      return { name: y, color: AN_COL[i % 8], values: v.map((x, j) => j > last ? null : x) }; }) });
    // 3. top buyers
    const by = new Map(); rows.forEach(r => { if (r[0] !== fy && r[0] !== prevFy) return; const x = by.get(r[3]) || { v: 0, p: 0 }; r[0] === fy ? x.v += anVal(r, st.m) : x.p += anVal(r, st.m); by.set(r[3], x); });
    const top = [...by.entries()].filter(([, x]) => x.v > 0).sort((a, b) => b[1].v - a[1].v).slice(0, 15);
    anHBars($('#ch3', el), { rows: top.map(([k, x]) => ({ label: d.parties[k].name, value: x.v, prev: x.p, key: k, sub: d.parties[k].city })), fmt: (v, l) => anFmt(st.m, v, l), prevName: prevFy, onClick: k => anParty(k, st) });
    // 4. items, with share
    const it = new Map(); rows.filter(r => r[0] === fy).forEach(r => it.set(r[4], (it.get(r[4]) || 0) + anVal(r, st.m)));
    const itp = new Map(); rows.filter(r => r[0] === prevFy).forEach(r => itp.set(r[4], (itp.get(r[4]) || 0) + anVal(r, st.m)));
    const itT = [...it.values()].reduce((s, v) => s + v, 0) || 1;
    anHBars($('#ch4', el), { rows: [...it.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => ({ label: `${k} · ${(v / itT * 100).toFixed(0)}%`, value: v, prev: itp.get(k) || 0, key: k })),
      fmt: (v, l) => anFmt(st.m, v, l), prevName: prevFy, color: AN_COL[2], onClick: k => { st.item = k; $('[data-f=item]', el).value = k; draw(); } });
    // 5. firms
    const fm = ['PM', 'PF', 'PPE'].map(k => ({ label: FIRM_NAME[k], value: rows.filter(r => r[0] === fy && r[2] === k).reduce((s, r) => s + anVal(r, st.m), 0), prev: rows.filter(r => r[0] === prevFy && r[2] === k).reduce((s, r) => s + anVal(r, st.m), 0) })).filter(x => x.value || x.prev);
    anHBars($('#ch5', el), { rows: fm, fmt: (v, l) => anFmt(st.m, v, l), prevName: prevFy, color: AN_COL[6] });
    $$('[data-yr]', el).forEach(c => c.onchange = () => { st.years = $$('[data-yr]', el).filter(x => x.checked).map(x => x.dataset.yr); draw(); });
  };
  el.innerHTML = anFilters(st, d, { buyer: true }) + '<div id="anbody"></div>';
  anHookFilters(el, st, d, draw);
  el.addEventListener('click', e => { const a = e.target.closest('[data-pk]'); if (a) anParty(a.dataset.pk, st); });
  draw();
};
function anList(d, rows, keys, fy, m) {
  const v = k => rows.filter(r => r[3] === k && r[0] === fy).reduce((s, r) => s + anVal(r, m), 0);
  const list = keys.map(k => ({ k, v: v(k) })).sort((a, b) => b.v - a.v);
  return list.length ? `<div class="tablewrap" style="max-height:300px"><table class="t"><tbody>${list.map(x => `<tr class="click" data-pk="${esc(x.k)}"><td><b>${esc(d.parties[x.k].name)}</b> <span class="hint">${esc(d.parties[x.k].city || '')}</span></td>
    <td class="num">${esc(anFmt(m, x.v, true))} <span class="hint">in ${esc(fy)}</span></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">None.</p>';
}

// ---------- one buyer: years, months, items, last orders ----------
async function anParty(pk, st0) {
  const d = await anData(), p = d.parties[pk]; if (!p) return;
  const st = { m: (st0 && st0.m) || 'qty', firm: st0 && st0.firm || '', own: true, pk, item: '' };
  const rows = anRows(d, st), ys = d.fys.filter(y => rows.some(r => r[0] === y));
  const sum = y => rows.filter(r => r[0] === y).reduce((s, r) => s + anVal(r, st.m), 0);
  const orders = d.orders.filter(o => o[0] === pk && (!st.firm || o[2] === st.firm)).sort((a, b) => b[1].localeCompare(a[1]));
  const pred = anPredict(d, { firm: st.firm, own: true }).find(x => x.pk === pk);
  const items = new Map(); rows.filter(r => ys.slice(-3).includes(r[0])).forEach(r => { const k = r[4] + (r[5] ? ' ' + r[5] : ''); const x = items.get(k) || {}; x[r[0]] = (x[r[0]] || 0) + anVal(r, st.m); items.set(k, x); });
  const last3 = ys.slice(-3);
  modal(`${p.name}${p.city ? ' · ' + p.city : ''}`, `
    <div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:6px">${p.mobile ? `<a class="badge slate" href="tel:${esc(p.mobile)}">📞 ${esc(p.mobile)}</a> <a class="badge PM" target="_blank" href="https://wa.me/91${esc(String(p.mobile).replace(/\D/g, '').slice(-10))}">WhatsApp</a>` : ''}
      ${p.email ? `<span class="badge grey">${esc(p.email)}</span>` : ''}${pred ? ` <span class="badge ${pred.status === 'overdue' ? 'amber' : pred.status === 'lost' ? 'red' : 'grey'}">Next order expected ${dmy(pred.next)} · ~${qty(pred.qty)} MT</span>` : ''}</div>
    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);align-items:start">
      <div><h4 style="margin:6px 0">Year by year (${st.m === 'amt' ? '₹ before GST' : 'MT'})</h4><div id="pp1"></div></div>
      <div><h4 style="margin:6px 0">Month by month</h4><div id="pp2"></div></div></div>
    <div class="grid" style="grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);align-items:start;margin-top:8px">
      <div><h4 style="margin:6px 0">Items</h4><table class="t"><thead><tr><th>Item</th>${last3.map(y => `<th class="num">${y}</th>`).join('')}</tr></thead><tbody>
        ${[...items.entries()].sort((a, b) => (b[1][last3[last3.length - 1]] || 0) - (a[1][last3[last3.length - 1]] || 0)).map(([k, x]) => `<tr><td>${esc(k)}</td>${last3.map(y => `<td class="num">${x[y] ? esc(anFmt(st.m, x[y], true)) : ''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <div><h4 style="margin:6px 0">Last orders <span class="hint">${orders.length} in all</span></h4><div class="tablewrap" style="max-height:300px"><table class="t"><tbody>
        ${orders.slice(0, 25).map(o => `<tr><td style="white-space:nowrap">${dmy(o[1])}</td><td><span class="badge ${o[2]}">${o[2]}</span></td><td class="num">${qty(o[3])} MT</td><td class="num">${rs(o[4])}</td><td class="hint">${esc(o[5])}</td></tr>`).join('')}</tbody></table></div></div></div>`, root => {
    anBars($('#pp1', root), { labels: ys, values: ys.map(sum), height: 200, fmt: (v, l) => anFmt(st.m, v, l), colors: ys.map((y, i) => i === ys.length - 1 ? AN_COL[0] : AN_GREY) });
    anLines($('#pp2', root), { height: 200, fmt: (v, l) => anFmt(st.m, v, l), series: ys.slice(-3).reverse().map((y, i) => { const v = Array(12).fill(0); rows.filter(r => r[0] === y).forEach(r => v[anMi(r[1])] += anVal(r, st.m));
      const last = y === anFyOf(d.today) ? anMi(d.today.slice(0, 7)) : 11; return { name: y, color: AN_COL[i], values: v.map((x, j) => j > last ? null : x) }; }) });
  });
}

// ---------- Expected Orders ----------
// For every buyer: its orders (invoices within 3 days count as one order), the usual gap between orders (median of the
// last 8 gaps in the last 4 years), the usual quantity (median of the last 5 orders) and the usual items.
// Next order ≈ last order + usual gap. Regular buyers (similar gaps) get High confidence.
// Months ahead: the same month of the last 3 years × the trend (last 12 months against the 12 before).
function anPredict(d, f) {
  const med = a => { const s = [...a].sort((x, y) => x - y), n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : 0; };
  const by = new Map();
  for (const o of d.orders) {
    if (f.firm && o[2] !== f.firm) continue;
    const p = d.parties[o[0]]; if (!p || (!f.own && p.own) || /ONLINE SALE/i.test(p.name)) continue;
    (by.get(o[0]) || by.set(o[0], []).get(o[0])).push(o);
  }
  const today = d.today, from4 = anAddDays(today, -4 * 365), out = [];
  for (const [pk, os] of by) {
    os.sort((a, b) => a[1].localeCompare(b[1]));
    const ord = []; for (const o of os) { const l = ord[ord.length - 1]; if (l && anDays(l.date, o[1]) <= 3) { l.qty += o[3]; l.amt += o[4]; o[5].split(', ').forEach(x => l.items.add(x)); } else ord.push({ date: o[1], qty: o[3], amt: o[4], items: new Set(o[5].split(', ')) }); }
    if (ord.length < 3) continue;
    const recent = ord.filter(o => o.date >= from4);
    const use = recent.length >= 3 ? recent : ord.slice(-6);
    const gaps = []; for (let i = 1; i < use.length; i++) gaps.push(anDays(use[i - 1].date, use[i].date));
    const g = gaps.slice(-8), gap = Math.max(7, med(g));
    const mean = g.reduce((s, x) => s + x, 0) / g.length, sd = Math.sqrt(g.reduce((s, x) => s + (x - mean) ** 2, 0) / g.length), cv = mean ? sd / mean : 9;
    const last = ord[ord.length - 1], next = anAddDays(last.date, gap), late = anDays(next, today);
    const q = med(ord.slice(-5).map(o => o.qty)), amt = med(ord.slice(-5).map(o => o.amt));
    const cnt = new Map(); ord.slice(-5).forEach(o => o.items.forEach(i => cnt.set(i, (cnt.get(i) || 0) + 1)));
    const items = [...cnt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]).join(', ');
    const months = new Map(); ord.slice(-12).forEach(o => months.set(anMi(o.date.slice(0, 7)), (months.get(anMi(o.date.slice(0, 7))) || 0) + 1));
    const since = anDays(last.date, today);
    // stopped: late by more than a whole usual gap (at least 6 months), or nothing for 2 years
    const status = late > Math.max(gap, 180) || since > 730 ? 'lost' : late > Math.max(10, gap * 0.25) ? 'overdue' : late > -31 ? 'due' : 'later';
    const conf = g.length >= 5 && cv < 0.45 ? 'High' : g.length >= 3 && cv < 0.8 ? 'Medium' : 'Low';
    const seasonal = months.size && ord.length >= 6 && months.size <= 4 ? [...months.keys()].sort((a, b) => a - b) : null;
    let x = { pk, name: d.parties[pk].name, city: d.parties[pk].city, mobile: d.parties[pk].mobile, orders: ord.length, last: last.date, lastQty: last.qty, gap: Math.round(gap), next, late, since, qty: q, amt, items, status, conf,
      season: seasonal ? seasonal.map(i => AN_MON[i]).join(', ') : '' };
    // a seasonal buyer (orders only in a few months of the year): late → the next order is expected at the start of its next season month
    if (seasonal && status !== 'due' && status !== 'later' && since <= 730) {
      const cm = anMi(today.slice(0, 7)); let k = 1; while (k <= 12 && !seasonal.includes((cm + k) % 12)) k++;
      const t = Number(today.slice(0, 4)) * 12 + Number(today.slice(5, 7)) - 1 + k, nx = `${Math.floor(t / 12)}-${String(t % 12 + 1).padStart(2, '0')}-01`;
      const l2 = anDays(nx, today); x = { ...x, next: nx, late: l2, status: l2 > -31 ? 'due' : 'later' };
    }
    out.push(x);
  }
  return out.sort((a, b) => a.next.localeCompare(b.next));
}
TITLES.expected = 'Expected Orders';
PAGES.expected = async el => {
  el.innerHTML = '<div class="empty">Studying the orders of past years…</div>';
  const d = await anData();
  const st = S.anx = S.anx || { firm: '', own: false, m: 'qty', show: 'soon', item: '' };
  const draw = () => {
    const today = d.today, curYm = today.slice(0, 7), rows = anRows(d, st);
    // month totals (all years)
    const mt = new Map(); rows.forEach(r => mt.set(r[1], (mt.get(r[1]) || 0) + anVal(r, st.m)));
    const ymAdd = (ym, n) => { const t = Number(ym.slice(0, 4)) * 12 + Number(ym.slice(5)) - 1 + n; return `${Math.floor(t / 12)}-${String(t % 12 + 1).padStart(2, '0')}`; };
    const last12 = [...Array(12)].reduce((s, x, i) => s + (mt.get(ymAdd(curYm, -1 - i)) || 0), 0), prev12 = [...Array(12)].reduce((s, x, i) => s + (mt.get(ymAdd(curYm, -13 - i)) || 0), 0);
    const trend = prev12 ? Math.min(1.4, Math.max(0.7, last12 / prev12)) : 1;
    const fc = ym => { const v = [1, 2, 3].map(k => mt.get(ymAdd(ym, -12 * k))).filter(x => x != null); return v.length ? v.reduce((s, x) => s + x, 0) / v.length * trend : 0; };
    const ahead = [...Array(6)].map((x, i) => ymAdd(curYm, i));
    // items for the next 3 months
    const itemMonth = new Map(); rows.forEach(r => { const k = r[4] + '\u0001' + r[1]; itemMonth.set(k, (itemMonth.get(k) || 0) + anVal(r, st.m)); });
    const itemNames = [...new Set(rows.filter(r => r[1] >= ymAdd(curYm, -36)).map(r => r[4]))];
    const itemFc = itemNames.map(it => ({ it, v: ahead.slice(0, 3).map(ym => { const v = [1, 2, 3].map(k => itemMonth.get(it + '\u0001' + ymAdd(ym, -12 * k)) || 0); return v.reduce((s, x) => s + x, 0) / 3 * trend; }),
      ly: ahead.slice(0, 3).map(ym => itemMonth.get(it + '\u0001' + ymAdd(ym, -12)) || 0) })).filter(x => x.v.some(v => v > 0.0001)).sort((a, b) => b.v[0] + b.v[1] + b.v[2] - a.v[0] - a.v[1] - a.v[2]);
    const pred = anPredict(d, st).filter(x => !st.item || x.items.includes(st.item));
    const show = { soon: x => x.status === 'overdue' || x.status === 'due', overdue: x => x.status === 'overdue', later: x => x.status === 'later', lost: x => x.status === 'lost', all: () => true }[st.show];
    const list = pred.filter(show).sort(st.show === 'lost' ? (a, b) => b.amt - a.amt : (a, b) => a.next.localeCompare(b.next));
    const n = s => pred.filter(x => s === 'soon' ? x.status === 'overdue' || x.status === 'due' : x.status === s).length;
    const stBadge = x => x.status === 'overdue' ? `<span class="badge amber">${x.late} days late</span>` : x.status === 'due' ? `<span class="badge PM">${x.late >= 0 ? 'due now' : 'in ' + -x.late + ' days'}</span>`
      : x.status === 'lost' ? `<span class="badge red">no order for ${Math.round(x.since / 30)} months</span>` : `<span class="badge grey">in ${-x.late} days</span>`;
    const soonTot = pred.filter(x => x.status === 'overdue' || x.status === 'due').reduce((s, x) => s + x.qty, 0);
    $('#anbody', el).innerHTML = `
      <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
        <div class="stat"><div class="k">${esc(monthName(curYm))} expected</div><div class="v">${esc(anFmt(st.m, fc(curYm), true))}</div><div class="hint">so far: ${esc(anFmt(st.m, mt.get(curYm) || 0, true))}</div></div>
        <div class="stat"><div class="k">Next 3 months expected</div><div class="v">${esc(anFmt(st.m, ahead.slice(0, 3).reduce((s, ym) => s + fc(ym), 0), true))}</div><div class="hint">same months last year: ${esc(anFmt(st.m, ahead.slice(0, 3).reduce((s, ym) => s + (mt.get(ymAdd(ym, -12)) || 0), 0), true))}</div></div>
        <div class="stat"><div class="k">Orders due now / overdue</div><div class="v">${n('soon')}</div><div class="hint">about ${qty(soonTot)} MT from these buyers</div></div>
        <div class="stat"><div class="k">Trend</div><div class="v" style="color:${trend >= 1 ? 'var(--ok)' : 'var(--bad)'}">${trend >= 1 ? '▲' : '▼'} ${Math.abs((trend - 1) * 100).toFixed(0)}%</div><div class="hint">last 12 months against the 12 before</div></div></div>
      <div class="grid" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);align-items:start">
        <div class="card"><h3>Next 6 months</h3>${anLegend([['Same month last year', AN_GREY], ['Expected', AN_COL[0]]])}<div id="xc1"></div></div>
        <div class="card"><h3>Items expected <span class="hint">${st.m === 'amt' ? '₹' : 'MT'} · last year in brackets</span></h3><div class="tablewrap" style="max-height:300px"><table class="t"><thead><tr><th>Item</th>${ahead.slice(0, 3).map(ym => `<th class="num">${esc(monthName(ym).slice(0, 3))}</th>`).join('')}</tr></thead><tbody>
          ${itemFc.slice(0, 15).map(x => `<tr><td>${esc(x.it)}</td>${x.v.map((v, i) => `<td class="num"><b>${esc(anFmt(st.m, v))}</b> <span class="hint">(${esc(anFmt(st.m, x.ly[i]))})</span></td>`).join('')}</tr>`).join('') || '<tr><td class="muted">Not enough history.</td></tr>'}</tbody></table></div></div></div>
      <div class="card"><div class="toolbar"><h3 style="margin:0">Buyers — when the next order is expected</h3><span class="spacer"></span>
        <div class="tabs">${[['soon', `Due now & late · ${n('soon')}`], ['overdue', `Late · ${n('overdue')}`], ['later', `Later · ${n('later')}`], ['lost', `Stopped buying · ${n('lost')}`], ['all', `All · ${pred.length}`]].map(([k, t]) => `<button data-show="${k}" class="${st.show === k ? 'on' : ''}">${t}</button>`).join('')}</div>
        <button class="sec" id="anxx">Export</button></div>
        <div class="tablewrap" style="max-height:60vh"><table class="t"><thead><tr><th>Buyer</th><th>Usual items</th><th>Last order</th><th class="num">Usual gap</th><th>Next order expected</th><th class="num">Usual qty</th><th>Sure?</th><th></th></tr></thead><tbody>
        ${list.map(x => `<tr class="click" data-pk="${esc(x.pk)}"><td><b>${esc(x.name)}</b> <span class="hint">${esc(x.city || '')}</span>${x.season ? `<br><span class="hint">usually orders in ${esc(x.season)}</span>` : ''}</td>
          <td class="hint">${esc(x.items)}</td><td style="white-space:nowrap">${dmy(x.last)}<br><span class="hint">${qty(x.lastQty)} MT</span></td><td class="num">${x.gap} days<br><span class="hint">${x.orders} orders</span></td>
          <td style="white-space:nowrap"><b>${dmy(x.next)}</b><br>${stBadge(x)}</td><td class="num"><b>${qty(x.qty)} MT</b><br><span class="hint">${esc(anRsShort(x.amt))}</span></td>
          <td><span class="badge ${x.conf === 'High' ? 'PM' : x.conf === 'Medium' ? 'slate' : 'grey'}">${x.conf}</span></td>
          <td style="white-space:nowrap">${x.mobile ? `<a class="small" href="https://wa.me/91${esc(String(x.mobile).replace(/\D/g, '').slice(-10))}" target="_blank" onclick="event.stopPropagation()">WhatsApp</a>` : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="muted">None.</td></tr>'}</tbody></table></div>
        <p class="hint" style="margin:8px 0 0">How it is worked out: from each buyer's past orders (3 or more), the usual gap between orders and the usual quantity of its last 5 orders. Next order = last order + usual gap.
          <b>High</b> = the buyer orders at regular gaps; <b>Low</b> = irregular. Months ahead = the same month of the last 3 years × the trend. ONLINE SALE (B2C) is not in the buyer list. This is a guide, not a promise — use it to plan production and to call buyers in time.</p></div>`;
    anBars($('#xc1', el), { labels: ahead.flatMap(ym => [monthName(ym).slice(0, 3) + ' ' + ym.slice(0, 4), '']), height: 250, group: 2,
      values: ahead.flatMap(ym => [mt.get(ymAdd(ym, -12)) || 0, fc(ym)]), colors: ahead.flatMap(() => [AN_GREY, AN_COL[0]]), fmt: (v, l) => anFmt(st.m, v, l),
      tip: i => { const ym = ahead[Math.floor(i / 2)]; return `<b>${esc(monthName(ym))}</b><br>Expected: <b>${esc(anFmt(st.m, fc(ym), true))}</b><br>Same month last year: ${esc(anFmt(st.m, mt.get(ymAdd(ym, -12)) || 0, true))}${ym === curYm ? `<br>So far this month: ${esc(anFmt(st.m, mt.get(ym) || 0, true))}` : ''}`; } });
    $$('[data-show]', el).forEach(b => b.onclick = () => { st.show = b.dataset.show; draw(); });
    $('#anxx', el).onclick = () => downloadCsv('expected_orders.csv', list.map(x => ({ buyer: x.name, city: x.city, mobile: x.mobile, items: x.items, last_order: dmy(x.last), usual_gap_days: x.gap, next_expected: dmy(x.next), usual_qty_mt: r2(x.qty), sure: x.conf, status: x.status })));
  };
  el.innerHTML = anFilters(st, d, { fy: false }) + '<div id="anbody"></div>';
  anHookFilters(el, st, d, draw);
  el.addEventListener('click', e => { const a = e.target.closest('tr[data-pk]'); if (a) anParty(a.dataset.pk, st); });
  draw();
};

// ---------- B2C Sales: online / unregistered customers, all years ----------
// rows: [fy, ym, firm, customer key, name, state, medium, item, qty, amount, invoice ids]
TITLES.b2csales = 'B2C Sales';
PAGES.b2csales = async el => {
  el.innerHTML = '<div class="empty">Adding up the B2C sales of all years…</div>';
  const d = await anData();
  const fys = [...new Set(d.b2c.map(r => r[0]))].sort();
  if (!fys.length) { el.innerHTML = '<div class="card">No B2C sales yet.</div>'; return; }
  const cur = anFyOf(d.today);
  const st = S.anc = S.anc || { fy: fys.includes(cur) ? cur : fys[fys.length - 1], m: 'amt', item: '' };
  const items = [...new Set(d.b2c.map(r => r[7]))].sort();
  const draw = () => {
    const rows = d.b2c.filter(r => !st.item || r[7] === st.item), fy = st.fy, prevFy = anPrevFy(fy), ongoing = fy === cur;
    const v = r => st.m === 'amt' ? r[9] : r[8];
    const sum = (f, filt = () => true) => rows.filter(r => r[0] === f && filt(r)).reduce((s, r) => s + v(r), 0);
    const inPeriod = ym => !ongoing || anMi(ym) <= anMi(d.today.slice(0, 7));
    const bills = (f, filt = () => true) => new Set(rows.filter(r => r[0] === f && filt(r)).flatMap(r => r[10].split(','))).size;
    const custs = f => new Set(rows.filter(r => r[0] === f).map(r => r[3]));
    const now = sum(fy), prevSame = sum(prevFy, r => inPeriod(r[1])), bN = bills(fy), amtN = rows.filter(r => r[0] === fy).reduce((s, r) => s + r[9], 0);
    const gr = (a, b) => b ? (a - b) / b * 100 : null;
    const tile = (k, val, sub, g) => `<div class="stat"><div class="k">${k}</div><div class="v">${val}</div><div class="hint">${sub}${g != null ? ` <b style="color:${g >= 0 ? 'var(--ok)' : 'var(--bad)'}">${g >= 0 ? '▲' : '▼'} ${Math.abs(g).toFixed(0)}%</b>` : ''}</div></div>`;
    // repeat customers (all years)
    const all = new Map(); d.b2c.forEach(r => { const x = all.get(r[3]) || { name: r[4], state: r[5], bills: new Set(), amt: 0, last: '' }; r[10].split(',').forEach(b => x.bills.add(b)); x.amt += r[9]; if (r[1] > x.last) x.last = r[1]; all.set(r[3], x); });
    const repeat = [...all.values()].filter(x => x.bills.size > 1).sort((a, b) => b.bills.size - a.bills.size || b.amt - a.amt);
    $('#anbody', el).innerHTML = `
      <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
        ${tile(`B2C sales ${esc(fy)}${ongoing ? ' so far' : ''}`, esc(anFmt(st.m, now, true)), `${ongoing ? 'Apr–' + AN_MON[anMi(d.today.slice(0, 7))] + ' of ' : ''}${esc(prevFy)}: ${esc(anFmt(st.m, prevSame, true))}`, gr(now, prevSame))}
        ${tile('Customers', custs(fy).size, `${esc(prevFy)}: ${custs(prevFy).size}`, null)}
        ${tile('Bills', bN, `${esc(prevFy)}: ${bills(prevFy)}`, null)}
        ${tile('Average bill', esc(rs(bN ? amtN / bN : 0)), 'before GST', null)}</div>
      <div class="card"><h3>B2C year by year <span class="hint">— every complete year${ongoing ? `; ${esc(fy)} till today` : ''} · click a year</span></h3><div id="cc1"></div></div>
      <div class="card"><h3>Month by month — year against year</h3><div id="cc2"></div></div>
      <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start">
        <div class="card"><h3>Medium of sale · ${esc(fy)} <span class="hint">— grey mark = ${esc(prevFy)}</span></h3><div id="cc3"></div>
          <h3 style="margin-top:16px">States · ${esc(fy)}</h3><div id="cc5"></div></div>
        <div class="card"><h3>Items · ${esc(fy)}</h3><div id="cc4"></div>
          <h3 style="margin-top:16px">Top customers · ${esc(fy)}</h3><div id="cc6"></div></div></div>
      <div class="card"><h3>Customers who bought again <span class="hint">${repeat.length} · all years</span></h3>
        <div class="tablewrap" style="max-height:320px"><table class="t"><thead><tr><th>Customer</th><th>State</th><th class="num">Bills</th><th class="num">Amount (before GST)</th><th>Last bought</th></tr></thead><tbody>
        ${repeat.map(x => `<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.state)}</td><td class="num">${x.bills.size}</td><td class="num">${rs(x.amt)}</td><td>${esc(monthName(x.last))}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">None yet.</td></tr>'}</tbody></table></div></div>`;
    const f = (x, l) => anFmt(st.m, x, l);
    const ys = fys;
    anBars($('#cc1', el), { labels: ys, values: ys.map(y => sum(y)), keys: ys, colors: ys.map(y => y === fy ? AN_COL[0] : AN_GREY), fmt: f, onClick: y => { st.fy = y; $('[data-c=fy]', el).value = y; draw(); } });
    anLines($('#cc2', el), { fmt: f, series: ys.slice(-3).reverse().map((y, i) => { const m = Array(12).fill(0); rows.filter(r => r[0] === y).forEach(r => m[anMi(r[1])] += v(r));
      const last = y === cur ? anMi(d.today.slice(0, 7)) : 11; return { name: y, color: AN_COL[i], values: m.map((x, j) => j > last ? null : x) }; }) });
    const by = (col, f0) => { const a = new Map(), p = new Map(); rows.forEach(r => { if (r[0] === fy) a.set(r[col], (a.get(r[col]) || 0) + v(r)); if (r[0] === prevFy) p.set(r[col], (p.get(r[col]) || 0) + v(r)); });
      return [...a.entries()].sort((x, y) => y[1] - x[1]).map(([k, val]) => ({ label: f0 ? f0(k) : k || '—', value: val, prev: p.get(k) || 0, key: k })); };
    anHBars($('#cc3', el), { rows: by(6), fmt: f, prevName: prevFy, color: AN_COL[6] });
    anHBars($('#cc4', el), { rows: by(7).slice(0, 10), fmt: f, prevName: prevFy, color: AN_COL[2], onClick: k => { st.item = k; $('[data-c=item]', el).value = k; draw(); } });
    anHBars($('#cc5', el), { rows: by(5).slice(0, 10), fmt: f, prevName: prevFy, color: AN_COL[1] });
    const names = new Map(rows.map(r => [r[3], r[4]]));
    anHBars($('#cc6', el), { rows: by(3, k => names.get(k)).slice(0, 12), fmt: f, prevName: prevFy });
  };
  el.innerHTML = `<div class="card" style="padding:10px 14px"><div class="row" style="gap:10px;flex-wrap:wrap;align-items:end">
      <label style="width:120px">F.Y.<select data-c="fy">${[...fys].reverse().map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label style="width:170px">Show<select data-c="m"><option value="amt" ${st.m === 'amt' ? 'selected' : ''}>Amount (₹, before GST)</option><option value="qty" ${st.m === 'qty' ? 'selected' : ''}>Quantity (MT)</option></select></label>
      <label style="width:220px">Item<select data-c="item"><option value="">All items</option>${items.map(i => `<option ${st.item === i ? 'selected' : ''}>${esc(i)}</option>`).join('')}</select></label></div>
      <p class="hint" style="margin:6px 0 0">B2C = ONLINE SALE invoices and the older online buyers without GSTIN (ONLINE SELF / ONLINE WEBSITE …).</p></div><div id="anbody"></div>`;
  $$('[data-c]', el).forEach(c => c.onchange = () => { st[c.dataset.c] = c.value; draw(); });
  draw();
};

// ---------- Group Sales: buyers of one group of companies (Buyers → Group of companies) together ----------
TITLES.groupsales = 'Group Sales';
PAGES.groupsales = async el => {
  el.innerHTML = '<div class="empty">Adding up the sales of the groups…</div>';
  const d = await anData();
  const skip = new Set(['', 'SINGLE', 'ONLINE']);
  const grpOf = pk => { const g = String(d.parties[pk].group || '').trim().toUpperCase(); return skip.has(g) ? null : g; };
  const st = S.ang = S.ang || { fy: anFyOf(d.today), firm: '', m: 'qty', item: '', own: false, g: '' };
  if (!d.fys.includes(st.fy)) st.fy = d.fys[d.fys.length - 1];
  const draw = () => {
    const rows = anRows(d, st).filter(r => grpOf(r[3])), fy = st.fy, prevFy = anPrevFy(fy);
    const yrs = [anPrevFy(anPrevFy(anPrevFy(fy))), anPrevFy(anPrevFy(fy)), prevFy, fy];
    const groups = new Map();
    const ongoing = fy === anFyOf(d.today), cm = anMi(d.today.slice(0, 7));
    rows.forEach(r => { const g = grpOf(r[3]); const x = groups.get(g) || { g, members: new Set(), y: {}, ps: 0 }; x.members.add(r[3]); x.y[r[0]] = (x.y[r[0]] || 0) + anVal(r, st.m);
      if (r[0] === prevFy && (!ongoing || anMi(r[1]) <= cm)) x.ps += anVal(r, st.m); groups.set(g, x); });
    // members of each group from Buyers, even without sales
    Object.entries(d.parties).forEach(([pk]) => { const g = grpOf(pk); if (g && groups.has(g)) groups.get(g).members.add(pk); });
    const list = [...groups.values()].filter(x => st.single || x.members.size >= 2).sort((a, b) => (b.y[fy] || 0) - (a.y[fy] || 0) || (b.y[prevFy] || 0) - (a.y[prevFy] || 0));
    const totalFy = anRows(d, st).filter(r => r[0] === fy).reduce((s, r) => s + anVal(r, st.m), 0), grpFy = list.reduce((s, x) => s + (x.y[fy] || 0), 0);
    const f = (x, l) => anFmt(st.m, x, l), cell = x => x ? esc(st.m === 'amt' ? Math.round(x).toLocaleString('en-IN') : qty(x)) : '';
    // change against the same months of last year (this year is not over yet)
    const chg = x => { const a = x.y[fy] || 0, b = x.ps || 0; return !b ? (a ? '<span class="badge PM">new</span>' : '') : `<span style="color:${a >= b ? 'var(--ok)' : 'var(--bad)'};font-weight:600">${a >= b ? '▲' : '▼'} ${Math.abs((a - b) / b * 100).toFixed(0)}%</span>`; };
    const sel = st.g && groups.get(st.g);
    $('#anbody', el).innerHTML = `
      <div class="grid" style="grid-template-columns:repeat(3,minmax(0,1fr));gap:12px">
        <div class="stat"><div class="k">Groups</div><div class="v">${list.length}</div><div class="hint">set in Buyers → Group of companies</div></div>
        <div class="stat"><div class="k">Group sales ${esc(fy)}</div><div class="v">${esc(f(grpFy, true))}</div><div class="hint">${totalFy ? (grpFy / totalFy * 100).toFixed(0) : 0}% of all sales</div></div>
        <div class="stat"><div class="k">${esc(prevFy)}</div><div class="v">${esc(f(list.reduce((s, x) => s + (x.y[prevFy] || 0), 0), true))}</div><div class="hint">whole year</div></div></div>
      <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.2fr);align-items:start">
        <div class="card"><h3>Groups · ${esc(fy)} <span class="hint">— grey mark = ${esc(prevFy)} · click a group</span></h3><div id="gc1"></div></div>
        <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Groups year by year <span class="hint">${st.m === 'amt' ? '₹' : 'MT'}</span></h3>
          <label style="display:flex;gap:6px;align-items:center;font-weight:500"><input type="checkbox" id="gsingle" style="width:auto" ${st.single ? 'checked' : ''}> Show groups with one buyer</label></div><div class="tablewrap" style="max-height:420px"><table class="t"><thead><tr><th>Group</th><th class="num">Buyers</th>${yrs.map(y => `<th class="num">${y}</th>`).join('')}<th class="num" title="${ongoing ? 'Against April–' + AN_MON[cm] + ' of ' + prevFy : 'Against ' + prevFy}">Change${ongoing ? ' *' : ''}</th></tr></thead><tbody>
          ${list.map(x => `<tr class="click" data-g="${esc(x.g)}" style="${x.g === st.g ? 'background:#e6f3f7' : ''}"><td><b>${esc(x.g)}</b></td><td class="num">${x.members.size}</td>${yrs.map(y => `<td class="num">${cell(x.y[y])}</td>`).join('')}<td class="num">${chg(x)}</td></tr>`).join('') || '<tr><td colspan="7" class="muted">No group sales. Put the buyers of one group under the same Group of companies in Buyers.</td></tr>'}</tbody></table></div>${ongoing ? `<p class="hint" style="margin:6px 0 0">* Change = ${esc(fy)} so far against April–${AN_MON[cm]} of ${esc(prevFy)}.</p>` : ''}</div></div>
      ${sel ? `<div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">${esc(sel.g)} <span class="hint">${sel.members.size} buyers</span></h3><button class="sec small" id="gclose">✕ Close</button></div>
        <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);align-items:start;margin-top:8px"><div><h4 style="margin:4px 0">Year by year</h4><div id="gc2"></div></div><div><h4 style="margin:4px 0">Month by month</h4><div id="gc3"></div></div></div>
        <h4 style="margin:12px 0 4px">Buyers of the group</h4><table class="t"><thead><tr><th>Buyer</th>${yrs.map(y => `<th class="num">${y}</th>`).join('')}</tr></thead><tbody>
        ${[...sel.members].map(pk => ({ pk, y: Object.fromEntries(yrs.map(y => [y, rows.filter(r => r[3] === pk && r[0] === y).reduce((s, r) => s + anVal(r, st.m), 0)])) })).sort((a, b) => (b.y[fy] || 0) - (a.y[fy] || 0) || (b.y[prevFy] || 0) - (a.y[prevFy] || 0))
          .map(m => `<tr class="click" data-pk="${esc(m.pk)}"><td><b>${esc(d.parties[m.pk].name)}</b> <span class="hint">${esc(d.parties[m.pk].city || '')}</span></td>${yrs.map(y => `<td class="num">${cell(m.y[y])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : ''}`;
    $('#gsingle', el).onchange = e => { st.single = e.target.checked; draw(); };
    anHBars($('#gc1', el), { rows: list.filter(x => x.y[fy] || x.y[prevFy]).slice(0, 15).map(x => ({ label: x.g, value: x.y[fy] || 0, prev: x.y[prevFy] || 0, key: x.g, sub: x.members.size + ' buyers' })), fmt: f, prevName: prevFy,
      onClick: g => { st.g = g; draw(); } });
    if (sel) {
      const gr = rows.filter(r => grpOf(r[3]) === sel.g), ys = d.fys.filter(y => gr.some(r => r[0] === y));
      anBars($('#gc2', el), { labels: ys, values: ys.map(y => gr.filter(r => r[0] === y).reduce((s, r) => s + anVal(r, st.m), 0)), height: 220, fmt: f, colors: ys.map(y => y === fy ? AN_COL[0] : AN_GREY) });
      anLines($('#gc3', el), { height: 220, fmt: f, series: ys.slice(-3).reverse().map((y, i) => { const m = Array(12).fill(0); gr.filter(r => r[0] === y).forEach(r => m[anMi(r[1])] += anVal(r, st.m));
        const last = y === anFyOf(d.today) ? anMi(d.today.slice(0, 7)) : 11; return { name: y, color: AN_COL[i], values: m.map((x, j) => j > last ? null : x) }; }) });
      $('#gclose', el).onclick = () => { st.g = ''; draw(); };
    }
  };
  el.innerHTML = anFilters(st, d) + '<div id="anbody"></div>';
  anHookFilters(el, st, d, draw);
  el.addEventListener('click', e => { const g = e.target.closest('tr[data-g]'); if (g) { st.g = g.dataset.g; draw(); return; } const p = e.target.closest('tr[data-pk]'); if (p) anParty(p.dataset.pk, st); });
  draw();
};

// ---------- IBM Return: Parakh Marketing only — opening, inward, sales, closing; buyer-wise details to copy into the IBM form ----------
TITLES.ibm = 'IBM Return';
// copy text to the clipboard (works on the main PC and on other PCs over the network)
function ibmCopy(text) {
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).catch(() => ibmCopyOld(text));
  ibmCopyOld(text); return Promise.resolve();
}
function ibmCopyOld(text) { const t = document.createElement('textarea'); t.value = text; t.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch { /* old */ } t.remove(); }
PAGES.ibm = async el => {
  const st = S.ibm = S.ibm || { fy: '', month: '' };
  const d = await GET(`/api/ibm?fy=${st.fy}&month=${st.month}`);
  st.fy = d.fy; st.month = d.month;
  const q = n => n == null ? '' : (Math.round((Number(n) || 0) * 1000) / 1000).toFixed(3), a = n => (Math.round(Number(n) || 0)).toString();
  const ra = n => n == null ? '' : (Math.round((Number(n) || 0) * 100) / 100).toFixed(2);
  const cp = (val, shown, cls = 'num') => val === '' || val == null ? `<td class="${cls}"></td>` : `<td data-copy="${esc(val)}" class="ibmc ${cls}" title="Click to copy">${shown ?? esc(val)}</td>`;
  const M = d.rows, sum = f => M.reduce((t, r) => t + (f(r) || 0), 0), mname = ym => AN_MONTH_FULL[anMi(ym)];
  const big = 'font-size:18px';
  el.innerHTML = `<style>.ibmt td.ibmc { cursor:copy; border-radius:4px; } .ibmt td.ibmc:hover { background:#eef6f8; }
      .ibmt tr.ibmrow td { background:#fff8e1; } .ibmt td.ibmc.copied { background:#ffe08a !important; outline:2px solid #e0a800; font-weight:700; }
      .ibmb td, .ibmb th { ${big}; padding:10px 12px !important; } .ibmt th, .ibmt td { border:1px solid #dfe6e8; } .ibmt thead th { text-align:center; }
      .ibmt tr.fut td { color:#a5b1b5; } .ibmt:not(.ibmb) td, .ibmt:not(.ibmb) th { padding:5px 8px !important; }</style>
    <div class="card" style="padding:10px 14px"><div class="row" style="gap:12px;flex-wrap:wrap;align-items:end">
      <label style="width:130px">Year<select id="ibmy">${[...d.fys].reverse().map(y => `<option ${y === d.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label style="width:250px">Opening balance as on ${dmy(d.opening_date)} (MT)<input id="ibmo" type="number" step="0.001" value="${q(d.opening_balance)}"></label>
      <button class="sec" id="ibms">Save</button></div>
      <p class="hint" style="margin:6px 0 0">Parakh Marketing only. Input = P.P. Enterprise bills to Parakh Marketing + Stock IN (its own purchases, on the rawana weight; rate and amount from the Stock IN entry). Output = Parakh Marketing sales invoices. Amounts before GST. IBM no. from Master → Suppliers. Click any figure to copy it.</p></div>
    <div class="grid" style="grid-template-columns:minmax(0,1.35fr) minmax(470px,1fr);align-items:start">
      <div class="card" style="overflow:auto"><h3>Input · ${esc(d.fy)}</h3>
        <table class="t ibmt"><thead><tr><th></th><th colspan="2"></th>${d.suppliers.map(s => `<th colspan="3">${esc(s.ibm_no || '— IBM no. not set —')}</th>`).join('')}</tr>
          <tr><th rowspan="2">Month</th><th colspan="2">INPUT TOTAL</th>${d.suppliers.map(s => `<th colspan="3">${esc(s.name)}</th>`).join('')}</tr>
          <tr><th>Qty</th><th>Amount</th>${d.suppliers.map(() => '<th>Qty</th><th>Rate</th><th>Amount</th>').join('')}</tr></thead><tbody>
        ${M.map((r, i) => `<tr data-r="i${i}" class="${r.future ? 'fut' : ''}"><td><b>${mname(r.month)}</b></td>${cp(q(r.input))}${cp(a(r.input_amount))}
          ${d.suppliers.map(s => { const x = r.by_sup[s.name] || {}; return x.qty ? cp(q(x.qty)) + cp(ra(x.rate)) + cp(a(x.amount)) : '<td></td><td></td><td></td>'; }).join('')}</tr>`).join('')}
        <tr style="font-weight:700;background:#f4f7f8"><td>TOTAL</td>${cp(q(sum(r => r.input)))}${cp(a(sum(r => r.input_amount)))}
          ${d.suppliers.map(s => { const qq = sum(r => (r.by_sup[s.name] || {}).qty), am = sum(r => (r.by_sup[s.name] || {}).amount); return qq ? cp(q(qq)) + cp(ra(am / qq)) + cp(a(am)) : '<td></td><td></td><td></td>'; }).join('')}</tr></tbody></table></div>
      <div class="card" style="overflow:auto"><h3 style="text-align:center;font-size:20px">PARAKH MARKETING · ${esc(d.fy)}</h3>
        <table class="t ibmt"><thead><tr><th>Month</th><th>Opening Qty</th><th>Input Qty</th><th>Output Qty</th><th>Closing Balance</th></tr></thead><tbody>
        ${M.map((r, i) => `<tr data-r="p${i}" class="${r.future ? 'fut' : ''}"><td><b>${mname(r.month)}</b></td>${cp(q(r.opening))}${cp(q(r.input))}${cp(q(r.output))}${cp(q(r.closing))}</tr>`).join('')}
        <tr style="font-weight:700;background:#f4f7f8"><td>TOTAL</td><td></td>${cp(q(sum(r => r.input)))}${cp(q(sum(r => r.output)))}<td></td></tr></tbody></table></div></div>
    <div class="card"><div class="toolbar"><h3 style="margin:0">Buyer-wise details</h3>
        <label style="width:200px">Month<select id="ibmm">${M.map(r => `<option value="${r.month}" ${r.month === d.month ? 'selected' : ''}>${esc(monthName(r.month))}</option>`).join('')}</select></label>
        <span class="hint">amount before GST · click a value to copy it</span><span class="spacer"></span><button class="sec" id="ibmx">Export</button></div>
      <table class="t ibmt ibmb"><thead><tr><th style="text-align:left">Company Name</th><th style="text-align:left">GSTIN</th><th class="num">Qty</th><th class="num">Amount</th></tr></thead><tbody>
      ${d.buyers.map((b, i) => `<tr data-r="b${i}">${cp(b.name, `<b>${esc(b.name)}</b>`, '')}${cp(b.gstin || 'UN-REGIS-DEALER', null, '')}${cp(q(b.qty))}${cp(a(b.amount))}</tr>`).join('')
        || '<tr><td colspan="4" class="muted">No Parakh Marketing sales in this month.</td></tr>'}</tbody>
      <tfoot><tr style="background:#1A3E4A;color:#fff;font-weight:700"><td colspan="2" style="color:#fff">Total Qty. <span class="ibmc" data-copy="${q(d.buyers_qty)}" style="cursor:copy">${q(d.buyers_qty)}</span> MT</td>
        <td colspan="2" class="num" style="color:#fff">Total Amount Rs. <span class="ibmc" data-copy="${a(d.buyers_amount)}" style="cursor:copy">${a(d.buyers_amount)}</span></td></tr></tfoot></table></div>`;
  $('#ibmy', el).onchange = e => { st.fy = e.target.value; st.month = ''; PAGES.ibm(el); };
  $('#ibmm', el).onchange = e => { st.month = e.target.value; PAGES.ibm(el); };
  $('#ibms', el).onclick = async () => { await guard(() => PUT('/api/ibm/settings', { opening: $('#ibmo', el).value })); toast('Saved'); PAGES.ibm(el); };
  $('#ibmx', el).onclick = () => downloadCsv(`ibm_buyers_${d.month}.csv`, d.buyers.map(b => ({ company_name: b.name, gstin: b.gstin || 'UN-REGIS-DEALER', qty: q(b.qty), amount: a(b.amount) })));
  // click a value: copy it; the values clicked in a row stay marked until a value of another row is clicked
  el.onclick = async e => {
    const c = e.target.closest('[data-copy]'); if (!c) return;
    const tr = c.closest('tr');
    if (!tr || !tr.classList.contains('ibmrow')) { $$('.ibmrow', el).forEach(r => r.classList.remove('ibmrow')); $$('.copied', el).forEach(x => x.classList.remove('copied')); }
    if (tr && tr.dataset.r != null) tr.classList.add('ibmrow');
    c.classList.add('copied');
    await ibmCopy(c.dataset.copy); toast('Copied: ' + c.dataset.copy);
  };
};

// ---------- Firm Wise: Parakh Marketing / Parakh Fertilizer sales of a year or a month, totals and the invoices ----------
TITLES.firmwise = 'Firm Wise';
PAGES.firmwise = async el => {
  const st = S.fw = S.fw || { fy: S.fy || S.meta.current_fy, month: '', firm: '' };
  const fys = [...new Set([S.meta.current_fy, ...(S.meta.fys || [])])].sort().reverse();
  const rows0 = await GET(`/api/invoices?fy=${encodeURIComponent(st.fy)}&kind=SALE`);
  const months = anFyMonths(st.fy);
  const rows = rows0.filter(r => ['PM', 'PF'].includes(r.firm_code) && (!st.firm || r.firm_code === st.firm) && (!st.month || String(r.date).slice(0, 7) === st.month));
  const live = rows.filter(r => !r.cancelled), tot = f => live.reduce((s, r) => s + (Number(f(r)) || 0), 0);
  const firmTot = k => { const x = live.filter(r => r.firm_code === k); return { n: x.length, q: x.reduce((s, r) => s + (Number(r.qty) || 0), 0), t: x.reduce((s, r) => s + (Number(r.taxable) || 0), 0), a: x.reduce((s, r) => s + (Number(r.total) || 0), 0) }; };
  const btn = (k, t) => `<button data-fw="${k}" class="${st.firm === k ? 'on' : ''}">${t}</button>`;
  el.innerHTML = `<div class="card" style="padding:10px 14px"><div class="row" style="gap:12px;flex-wrap:wrap;align-items:end">
      <label style="width:130px">F.Y.<select id="fwy">${fys.map(y => `<option ${y === st.fy ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
      <label style="width:190px">Month<select id="fwm"><option value="">Whole year</option>${months.map(m => `<option value="${m}" ${m === st.month ? 'selected' : ''}>${esc(monthName(m))}</option>`).join('')}</select></label>
      <div class="tabs" style="margin-bottom:2px">${btn('PM', 'Parakh Marketing')}${btn('PF', 'Parakh Fertilizer')}${btn('', 'Both')}</div>
      <span class="spacer"></span><button class="sec" id="fwx">Export</button></div></div>
    <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
      <div class="stat"><div class="k">Total quantity</div><div class="v">${qty(tot(r => r.qty))} MT</div><div class="hint">${live.length} invoices${rows.length > live.length ? ` · ${rows.length - live.length} cancelled not counted` : ''}</div></div>
      <div class="stat"><div class="k">Taxable amount</div><div class="v">${rs(tot(r => r.taxable))}</div><div class="hint">before GST</div></div>
      <div class="stat"><div class="k">GST</div><div class="v">${rs(tot(r => r.cgst + r.sgst + r.igst))}</div><div class="hint">CGST + SGST + IGST</div></div>
      <div class="stat"><div class="k">Total amount</div><div class="v">${rs(tot(r => r.total))}</div><div class="hint">${esc(st.month ? monthName(st.month) : st.fy)} · ${st.firm ? FIRM_NAME[st.firm] : 'PM + PF'}</div></div></div>
    ${!st.firm ? `<div class="card"><table class="t"><thead><tr><th>Firm</th><th class="num">Invoices</th><th class="num">Qty (MT)</th><th class="num">Taxable</th><th class="num">Total amount</th></tr></thead><tbody>
      ${['PM', 'PF'].map(k => { const x = firmTot(k); return `<tr><td><span class="badge ${k}">${k}</span> ${FIRM_NAME[k]}</td><td class="num">${x.n}</td><td class="num">${qty(x.q)}</td><td class="num">${money(x.t)}</td><td class="num"><b>${money(x.a)}</b></td></tr>`; }).join('')}</tbody></table></div>` : ''}
    <div class="card" style="padding:0"><div class="tablewrap" id="fwl" style="max-height:62vh">${rows.length ? `<table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th>Type</th><th>Lorry</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">GST</th><th class="num">Total</th><th>E-way bill</th><th>Email</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td><b>${r.inv_no}</b>${r.cancelled ? ' <span class="badge red">cancelled</span>' : ''}${r.legacy ? ' <span class="badge grey">Excel</span>' : ''}</td>
        <td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td>${r.supply_type || ''}</td><td>${esc(r.lorry_no || '')}</td><td class="num">${qty(r.qty)}${r.lines > 1 ? ` <span class="muted">(${r.lines} items)</span>` : ''}</td>
        <td class="num">${money(r.taxable)}</td><td class="num">${money(r.cgst + r.sgst + r.igst)}</td><td class="num"><b>${money(r.total)}</b></td><td>${esc(r.ewb_no || '')}</td><td>${r.email_sent_at ? '✓' : ''}</td></tr>`).join('')}
      <tr style="font-weight:700;background:#f4f7f8"><td colspan="6">Total (without cancelled)</td><td class="num">${qty(tot(r => r.qty))}</td><td class="num">${money(tot(r => r.taxable))}</td><td class="num">${money(tot(r => r.cgst + r.sgst + r.igst))}</td><td class="num">${money(tot(r => r.total))}</td><td colspan="2"></td></tr></tbody></table>` : '<div class="empty">No invoices.</div>'}</div></div>`;
  $('#fwy', el).onchange = e => { st.fy = e.target.value; st.month = ''; PAGES.firmwise(el); };
  $('#fwm', el).onchange = e => { st.month = e.target.value; PAGES.firmwise(el); };
  $$('[data-fw]', el).forEach(b => b.onclick = () => { st.firm = b.dataset.fw; PAGES.firmwise(el); });
  $('#fwl', el).onclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) go('#/invoice/' + tr.dataset.id); };
  $('#fwx', el).onclick = () => downloadCsv(`firm_wise_${st.firm || 'PM_PF'}_${st.month || st.fy}.csv`, rows.map(r => ({ firm: r.firm_code, inv_no: r.inv_no, date: r.date, party: r.party_name, type: r.supply_type, lorry: r.lorry_no, qty: r.qty, taxable: r.taxable, gst: r2(r.cgst + r.sgst + r.igst), total: r.total, ewb: r.ewb_no, cancelled: r.cancelled ? 'yes' : '' })));
};
const anFyMonths = fy => { const a = Number(fy.slice(0, 4)); return [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3].map(m => `${m >= 4 ? a : a + 1}-${String(m).padStart(2, '0')}`); };
