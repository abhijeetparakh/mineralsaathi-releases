'use strict';
// Reports → IBM Return: Parakh Marketing only — its inward (inward vouchers to Parakh Marketing + Stock IN) and its sales.
// Opening balance as on 1 April 2026 (setting); the opening of any later month = that + inward − sales of the months before.
const { all, setting, setSetting } = require('./db');
class E extends Error { constructor(m) { super(m); this.status = 400; } }
const r3 = n => Math.round((Number(n) || 0) * 1000) / 1000, r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const PM_NAME = "upper(trim(COALESCE(to_party, ''))) IN ('PARAKH MARKETING', 'PM')";

function inward(from, to, by) {        // by: 'actual' or 'rawana'
  const w = by === 'rawana' ? 'rawana_wt' : 'actual_wt';
  const a = all(`SELECT date, supplier, COALESCE(${w}, 0) AS qty, rawana_wt, actual_wt FROM inwards WHERE ${PM_NAME} AND date >= ? AND date < ?`, from, to);
  const b = all(`SELECT date, supplier, COALESCE(${w}, 0) AS qty, rawana_wt, actual_wt FROM stock_in WHERE date >= ? AND date < ?`, from, to);
  return [...a, ...b];
}
function sales(from, to) {
  return all(`SELECT i.id, i.date, i.party_id, COALESCE(i.b2c_name, i.party_name) AS name, i.party_gstin, i.b2c_id,
      (SELECT SUM(qty) FROM invoice_items WHERE invoice_id = i.id) AS qty, i.taxable
    FROM invoices i WHERE i.firm_code = 'PM' AND COALESCE(i.kind, 'SALE') = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND i.date >= ? AND i.date < ?`, from, to);
}
const nextMonth = ym => { const y = Number(ym.slice(0, 4)), m = Number(ym.slice(5)); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; };

module.exports = function register(route) {
  route('GET', '/api/ibm', ({ q }) => {
    const openDate = setting('ibm_opening_date', '2026-04-01'), opening0 = Number(setting('ibm_opening', '1025.990')) || 0, by = setting('ibm_inward_by', 'actual');
    const month = /^\d{4}-\d{2}$/.test(q.month || '') ? q.month : new Date().toISOString().slice(0, 7);
    const from = month + '-01', to = nextMonth(month) + '-01';
    if (from < openDate) throw new E(`The opening balance is from ${openDate.split('-').reverse().join('.')}. Choose that month or a later one.`);
    // opening of this month = opening balance + inward − sales from the opening date to the month before
    const inBefore = inward(openDate, from, by).reduce((s, r) => s + r.qty, 0), outBefore = sales(openDate, from).reduce((s, r) => s + (Number(r.qty) || 0), 0);
    const opening = r3(opening0 + inBefore - outBefore);
    const ins = inward(from, to, by), outs = sales(from, to);
    const sup = new Map(all('SELECT * FROM suppliers').map(s => [String(s.name || '').trim().toUpperCase(), s]));
    const supRows = new Map();
    for (const r of ins) { const k = String(r.supplier || '—').trim().toUpperCase(); const x = supRows.get(k) || { name: r.supplier || '—', ibm_no: (sup.get(k) || {}).ibm_no || '', gstin: (sup.get(k) || {}).gstin || '', lorries: 0, qty: 0, rawana: 0, actual: 0 };
      x.lorries++; x.qty += r.qty; x.rawana += Number(r.rawana_wt) || 0; x.actual += Number(r.actual_wt) || 0; supRows.set(k, x); }
    const parties = new Map(all('SELECT id, name, gstin FROM parties').map(p => [p.id, p]));
    const buyers = new Map();
    for (const s of outs) {
      const p = s.party_id ? parties.get(s.party_id) : null;
      const gst = s.b2c_id ? '' : String(s.party_gstin || (p && p.gstin) || '').toUpperCase();
      const name = s.b2c_id ? s.name : (p && p.name) || s.name;
      const k = (gst || 'N' + String(name).toUpperCase());
      const x = buyers.get(k) || { name, gstin: gst, invoices: 0, qty: 0, amount: 0 }; x.invoices++; x.qty += Number(s.qty) || 0; x.amount += Number(s.taxable) || 0; buyers.set(k, x);
    }
    const received = r3(ins.reduce((s, r) => s + r.qty, 0)), sold = r3(outs.reduce((s, r) => s + (Number(r.qty) || 0), 0));
    return { month, opening_date: openDate, opening_balance: opening0, inward_by: by, opening, received, sold, closing: r3(opening + received - sold),
      sales_amount: r2(outs.reduce((s, r) => s + (Number(r.taxable) || 0), 0)),
      suppliers: [...supRows.values()].map(x => ({ ...x, qty: r3(x.qty), rawana: r3(x.rawana), actual: r3(x.actual) })).sort((a, b) => b.qty - a.qty),
      buyers: [...buyers.values()].map(x => ({ ...x, qty: r3(x.qty), amount: r2(x.amount) })).sort((a, b) => a.name.localeCompare(b.name)) };
  });
  route('PUT', '/api/ibm/settings', ({ body }) => {
    if (body.opening !== undefined) { const n = Number(body.opening); if (!(n >= 0)) throw new E('Enter the opening balance in MT.'); setSetting('ibm_opening', String(r3(n))); }
    if (body.opening_date !== undefined) { if (!/^\d{4}-\d{2}-01$/.test(String(body.opening_date))) throw new E('The opening date is the 1st of a month.'); setSetting('ibm_opening_date', body.opening_date); }
    if (body.inward_by !== undefined) setSetting('ibm_inward_by', body.inward_by === 'rawana' ? 'rawana' : 'actual');
    return { ok: true };
  });
};
