'use strict';
// Master → Analysis Reports: test report templates (Sl No. · Content · Observed Value in % · Protocol Adopted),
// linked to Item + Colour + Form + Mesh, printed / emailed as a PDF on the firm's letter head.
TITLES.anreports = 'Analysis Reports';

PAGES.anreports = async (el, editId) => {
  await loadLists();
  const [list, fr] = await Promise.all([GET('/api/anreports'), GET('/api/anreports-firms')]);
  const isNew = editId === 'new';
  const cur = isNew ? { name: '', heading: 'Chemical & Physical Properties', product: '', colour: '', form: '', mesh: '', rows: [['', '', ''], ['', '', ''], ['', '', '']], note: '' }
    : list.find(r => String(r.id) === String(editId)) || list[0] || null;
  S.anrFirm = S.anrFirm || 'PM';
  const opt = (key, v) => `<option value="">— any —</option>${[...new Set([...lv(key), ...(v ? [v] : [])])].map(x => `<option ${x === v ? 'selected' : ''}>${esc(x)}</option>`).join('')}`;
  const link = r => [r.product, r.colour, r.form, r.mesh ? r.mesh + ' MESH' : ''].filter(Boolean).join(' · ') || '<span class="badge amber">not linked</span>';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,2.2fr);align-items:start">
    <div class="card"><div class="toolbar"><h3 style="margin:0">Reports</h3><span class="spacer"></span><button class="small" onclick="go('#/anreports/new')">+ New report</button></div>
      ${list.map(r => `<a class="listhead ${cur && r.id === cur.id && !isNew ? 'on' : ''}" style="display:block;padding:8px 10px;border-bottom:1px solid var(--line);cursor:pointer" onclick="go('#/anreports/${r.id}')">
        <b>${esc(r.name)}</b><br><span class="hint">${link(r)}</span></a>`).join('') || '<p class="hint">No report yet.</p>'}
      <p class="hint" style="margin-top:10px">Each report is linked to an Item, Colour, Form and Mesh (from Master → Item List; “any” = not checked).
        When you email an invoice or a sample dispatch with “Analysis report” ticked, the report of the same combination as the item sent goes with it as a PDF, on that firm's letter head.
        If two reports fit, the one with more fields filled in is used.</p></div>
    ${cur ? `<form id="arf" class="card" autocomplete="off">
      <div class="toolbar"><h3 style="margin:0">${isNew ? 'New analysis report' : 'Edit report'}</h3><span class="spacer"></span>
        ${isNew ? '' : `<button type="button" class="sec small" id="arcopy">⧉ Duplicate</button><button type="button" class="sec small" id="ardel">Delete</button>`}</div>
      <div class="grid g2">
        <label>Heading (first line)<input name="heading" value="${esc(cur.heading || '')}" placeholder="Chemical & Physical Properties"></label>
        <label>Report name (second line)<input name="name" value="${esc(cur.name)}" placeholder="Diatomaceous Earth Light Yellow"></label></div>
      ${cur.print_name && cur.print_name !== cur.name ? `<p class="hint" style="margin:4px 0 0">Printed as: <b>${esc(cur.print_name)}</b> — “Diatomaceous Earth” is replaced by the Item linked below.</p>` : ''}
      <div class="firmbox" style="margin-top:10px"><b>Linked to</b> <span class="hint">— sent with invoices / sample dispatches of this item</span>
        <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:6px">
          <label>Item<select name="product">${opt('product', cur.product)}</select></label>
          <label>Colour<select name="colour">${opt('colour', cur.colour)}</select></label>
          <label>Form<select name="form">${opt('form', cur.form)}</select></label>
          <label>Mesh<select name="mesh">${opt('mesh', cur.mesh)}</select></label></div></div>
      <table class="t" style="margin-top:12px" id="artab"><thead><tr><th style="width:60px">Sl No.</th><th>Content</th><th style="width:150px">Observed Value in %</th><th>Protocol Adopted</th><th style="width:76px"></th></tr></thead><tbody></tbody></table>
      <div class="row" style="margin-top:6px"><button type="button" class="sec small" id="aradd">+ Add row</button></div>
      <label style="margin-top:10px">Note (printed after the table)<textarea name="note" rows="3" placeholder="e.g. The above values are typical and may vary slightly from lot to lot.">${esc(cur.note || '')}</textarea></label>
      <div class="row" style="margin-top:12px;gap:8px;align-items:end;flex-wrap:wrap"><button type="submit">${isNew ? 'Add report' : 'Save'}</button>
        <span class="spacer"></span>
        <label style="width:auto">Firm (letter head)<select id="arfirm">${fr.firms.map(f => `<option value="${esc(f.code)}" ${f.code === S.anrFirm ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>
        <button type="button" class="sec" id="arprint">🖨 Print</button><button type="button" class="sec" id="armail">✉ Email PDF</button></div>
      <p class="hint">Print and Email use the saved report — press Save first after a change.</p></form>` : '<div class="card"><p>Add the first report with “+ New report”.</p></div>'}</div>`;
  if (!cur) return;
  const f = $('#arf', el), tb = $('#artab tbody', el);
  let rows = cur.rows.map(r => [...r]);
  const read = () => { rows = $$('tr', tb).map(tr => $$('input', tr).map(i => i.value)); };
  const draw = () => {
    tb.innerHTML = rows.map((r, i) => `<tr><td class="c"><b>${i + 1}.</b></td>${r.map((v, j) => `<td><input value="${esc(v)}" ${j === 1 ? 'style="text-align:center"' : ''}></td>`).join('')}
      <td style="white-space:nowrap"><button type="button" class="small sec" data-up="${i}" title="Move up" ${i ? '' : 'disabled'}>↑</button><button type="button" class="small sec" data-rm="${i}" title="Remove the row">✕</button></td></tr>`).join('');
  };
  draw();
  tb.onclick = e => {
    const u = e.target.closest('[data-up]'), x = e.target.closest('[data-rm]'); if (!u && !x) return; read();
    if (u) { const i = +u.dataset.up; [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; } else rows.splice(+x.dataset.rm, 1);
    draw();
  };
  $('#aradd', el).onclick = () => { read(); rows.push(['', '', '']); draw(); $$('tr:last-child input', tb)[0].focus(); };
  const save = async () => { read(); const v = formData(f); v.rows = rows;
    return isNew ? (await POST('/api/anreports', v)).id : (await PUT('/api/anreports/' + cur.id, v)).id; };
  f.onsubmit = async e => { e.preventDefault(); const id = await guard(save); toast('Report saved'); go('#/anreports/' + id); if (!isNew) PAGES.anreports(el, id); };
  $('#arfirm', el).onchange = e => { S.anrFirm = e.target.value; };
  $('#arprint', el).onclick = async () => { if (isNew) { const id = await guard(save); go('#/anreports/' + id); return; } window.open(`/print/anreport/${cur.id}?firm=${encodeURIComponent($('#arfirm', el).value)}`, '_blank'); };
  $('#armail', el).onclick = () => { if (isNew) return toast('Save the report first', true); anrEmail(cur, $('#arfirm', el).value, fr.firms); };
  if (!isNew) {
    $('#arcopy', el).onclick = async () => { const r = await guard(() => POST(`/api/anreports/${cur.id}/copy`, {})); toast('Copy made — change its name and link'); go('#/anreports/' + r.id); };
    $('#ardel', el).onclick = async () => { if (!confirm(`Delete the report “${cur.name}”?`)) return; await guard(() => DEL('/api/anreports/' + cur.id)); toast('Deleted'); go('#/anreports'); };
  }
};

function anrEmail(rep, firmCode, firms) {
  const fm = firms.find(x => x.code === firmCode) || {};
  modal(`Email analysis report · ${rep.print_name || rep.name}`, `${fm.email ? '' : `<p class="badge amber">Email is not set up for ${esc(fm.name || firmCode)}. Open Settings → Companies → Email sending first.</p>`}
    <form id="aem"><div class="grid g2">
      ${field({ name: 'to', label: 'To (more than one: comma between)' }, '')}${field({ name: 'cc', label: 'CC' }, '')}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, `Analysis report — ${rep.print_name || rep.name} — ${fm.name || ''}`)}
      ${field({ name: 'text', label: 'Message', type: 'textarea', span: 2 }, `Dear Sir / Madam,\n\nPlease find attached the analysis report of ${rep.print_name || rep.name}.\n\nRegards,\n${fm.name || ''}`)}</div>
      <div class="row" style="margin-top:8px"><button type="submit" ${fm.email ? '' : 'disabled'}>Send email</button><span class="hint">The report goes as a PDF on the letter head of ${esc(fm.name || '')}.</span></div></form>`, root => {
    const t = $('#aem [name=text]', root); if (t) t.rows = 7;
    $('#aem', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Making the PDF and sending…';
      try { await POST(`/api/anreports/${rep.id}/email`, { ...formData(e.target), firm_code: firmCode }); toast('Analysis report sent'); closeModal(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}
