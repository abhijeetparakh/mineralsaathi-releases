'use strict';
// Database access. Only the server process on the main PC touches the database file,
// so several PCs can work at the same time without clashes.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.MS_DATA_DIR || path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'mineral.db');

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---- upgrades for databases made by older versions ----
function addColumn(table, col, type) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`);
}
addColumn('invoice_items', 'bag_supply', 'TEXT');
addColumn('invoice_items', 'liner', 'INTEGER');
addColumn('inwards', 'to_party', 'TEXT');
addColumn('firms', 'logo', 'TEXT');
// P.P. Enterprise vouchers: goods go FROM P.P. Enterprise TO Parakh Marketing
db.exec(`UPDATE inwards SET supplier = 'P.P.ENTERPRISE', to_party = 'PARAKH MARKETING'
         WHERE voucher_no LIKE 'PPE-V%' AND (to_party IS NULL OR supplier IS NOT 'P.P.ENTERPRISE')`);
// buyers without a usual transporter get the one from their latest invoice
db.exec(`UPDATE parties SET transporter = (SELECT i.transporter FROM invoices i WHERE i.party_id = parties.id AND COALESCE(i.transporter,'') <> ''
           ORDER BY i.date DESC, i.id DESC LIMIT 1) WHERE COALESCE(transporter,'') = ''`);
// e-mail addresses are always kept in small letters
db.exec(`UPDATE parties SET email = lower(email) WHERE email <> lower(email);
         UPDATE firms SET email = lower(email), smtp_user = lower(smtp_user) WHERE email <> lower(email) OR smtp_user <> lower(smtp_user);
         UPDATE transporters SET email = lower(email) WHERE email <> lower(email);`);

const fix = p => p.map(v => v === undefined ? null : (typeof v === 'boolean' ? (v ? 1 : 0) : v));
const all = (sql, ...p) => db.prepare(sql).all(...fix(p)).map(r => ({ ...r }));
const get = (sql, ...p) => { const r = db.prepare(sql).get(...fix(p)); return r ? { ...r } : null; };
const run = (sql, ...p) => db.prepare(sql).run(...fix(p));

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}

const colCache = {};
function columns(table) {
  if (!colCache[table]) colCache[table] = all(`PRAGMA table_info(${table})`).map(c => c.name);
  return colCache[table];
}

function setting(key, fallback = null) {
  const r = get('SELECT value FROM settings WHERE key = ?', key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value == null ? null : String(value));
}

module.exports = { db, all, get, run, tx, columns, setting, setSetting, DB_FILE, DATA_DIR, ROOT };
