'use strict';
const hooks = require('../hooks');
// Marketing: enquiries (leads) and the dispatches sent to them. A dispatch holds one or more samples,
// like an invoice holds items. Saving a dispatch also plans the first follow-up call ("Did the sample arrive?").
const M = require('./db');
const { all: mAll } = require('../db');

const up = v => { const s = String(v ?? '').trim().replace(/\s+/g, ' '); return s ? s.toUpperCase() : null; };
const txt = v => { const s = String(v ?? '').trim(); return s || null; };
const digits = v => String(v ?? '').replace(/\D/g, '');
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const isoDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null;
function today() { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); }
function addDays(iso, n) { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }

function cleanLead(b, forSample) {
  const o = {
    buyer_name: up(b.buyer_name), company: up(b.company ?? b.name), address: txt(b.address), city: up(b.city), state: up(b.state),
    pincode: digits(b.pincode) || null, digipin: up(b.digipin), mobile1: digits(b.mobile1) || null, mobile2: digits(b.mobile2) || null,
    gst: up(b.gst), email: txt(b.email) ? String(b.email).trim().toLowerCase() : null, note: txt(b.note)
  };
  for (const k of ['mobile1', 'mobile2']) if (o[k] && o[k].length > 10 && o[k].startsWith('91')) o[k] = o[k].slice(-10);   // +91 98…
  if (!o.company && !o.buyer_name) throw new M.MktError('Enter the company or the buyer name.');
  if (!o.mobile1 || o.mobile1.length !== 10) throw new M.MktError('Check the mobile number: 10 digits.');
  if (o.mobile2 && o.mobile2.length !== 10) throw new M.MktError('Check the second mobile number: 10 digits, or leave it blank.');
  if (o.pincode && o.pincode.length !== 6) throw new M.MktError('Check the pincode: 6 digits.');
  if (forSample && !o.pincode) throw new M.MktError('Enter the pincode (6 digits) — the sample goes by post or courier.');
  if (forSample && !o.address) throw new M.MktError('Enter the address — the sample goes by post or courier.');
  if (o.gst && !/^[0-9A-Z]{15}$/.test(o.gst)) throw new M.MktError('Check the GST number: 15 letters and digits, or leave it blank.');
  if (o.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(o.email)) throw new M.MktError('Check the email address.');
  return o;
}

// one sample line of a dispatch (one sample sticker each)
function cleanLine(b, i) {
  const n = `Sample ${i + 1}: `;
  const o = {
    item_name: up(b.item_name), grade: up(b.grade), mesh: up(b.mesh), colour: up(b.colour), form: up(b.form),
    sample_size: up(b.sample_size), rate: num(b.rate), unit: up(b.unit), bag_type: up(b.bag_type), packing_type: up(b.packing_type),
    liner: b.liner === '' || b.liner == null ? null : (Number(b.liner) ? 1 : 0), bag_weight: num(b.bag_weight), note: txt(b.note)
  };
  if (!o.item_name) throw new M.MktError(n + 'choose the item (Master → Item List).');
  if (!o.grade) throw new M.MktError(n + 'enter the grade — choose colour and mesh, or type it.');
  if (!o.sample_size) throw new M.MktError(n + 'choose the sample size.');
  if (o.rate != null && o.rate < 0) throw new M.MktError(n + 'the rate cannot be negative.');
  if (o.rate != null && !o.unit) throw new M.MktError(n + 'choose the unit of the rate (KG or MT).');
  if (o.bag_weight != null && o.bag_weight < 0) throw new M.MktError(n + 'the bag weight cannot be negative.');
  return o;
}
function cleanDispatch(b, s) {
  const o = {
    date: isoDate(b.date) || today(), firm_code: txt(b.firm_code) || s.default_firm,
    courier: up(b.courier), tracking_no: up(b.tracking_no) ? up(b.tracking_no).replace(/\s/g, '') : null,
    freight_to_pay: Number(b.freight_to_pay) ? 1 : 0, parcels: num(b.parcels) == null ? null : Math.round(num(b.parcels)),
    total_weight: num(b.total_weight), delivered_on: isoDate(b.delivered_on), note: txt(b.note)
  };
  if (!o.courier) throw new M.MktError('Choose the courier (sent by).');
  if ((o.parcels != null && o.parcels < 0) || (o.total_weight != null && o.total_weight < 0)) throw new M.MktError('Parcels and weight cannot be negative.');
  const firms = mAll('SELECT code FROM firms');
  if (firms.length && !firms.some(f => f.code === o.firm_code)) throw new M.MktError('Choose the sender company.');
  return o;
}
function cleanLines(lines) {
  const ls = (Array.isArray(lines) ? lines : []).filter(l => l && Object.entries(l).some(([k, v]) => k !== 'unit' && v !== '' && v != null));
  if (!ls.length) throw new M.MktError('Add at least one sample.');
  if (ls.length > 30) throw new M.MktError('A dispatch can hold up to 30 samples.');
  return ls.map(cleanLine);
}

function nextRef(s) {
  const max = M.get('SELECT MAX(ref_no) m FROM leads').m || 0;
  return Math.max(max + 1, s.next_ref || 1);
}

// another enquiry with the same mobile number (to avoid two records for one customer)
function sameMobile(mobile, exceptId) {
  if (!mobile) return null;
  return M.get('SELECT id, ref_no, company, buyer_name FROM leads WHERE (mobile1 = ? OR mobile2 = ?) AND id <> ? LIMIT 1', mobile, mobile, exceptId || 0);
}

function insertLead(o, s) {
  const ref = nextRef(s), keys = Object.keys(o);
  const id = Number(M.run(`INSERT INTO leads(ref_no, ${keys.join(',')}) VALUES(?, ${keys.map(() => '?').join(',')})`, ref, ...keys.map(k => o[k])).lastInsertRowid);
  return { id, ref_no: ref };
}
function updateLead(id, o) {
  const keys = Object.keys(o);
  M.run(`UPDATE leads SET ${keys.map(k => k + ' = ?').join(', ')}, updated_at = datetime('now','localtime') WHERE id = ?`, ...keys.map(k => o[k]), id);
}

function leadFull(id) {
  const lead = M.get('SELECT * FROM leads WHERE id = ?', id);
  if (!lead) throw new M.MktError('This enquiry is not there any more.');
  return {
    lead,
    dispatches: M.all('SELECT * FROM dispatches WHERE lead_id = ? ORDER BY date DESC, id DESC', id)
      .map(d => ({ ...d, lines: M.all('SELECT * FROM samples WHERE dispatch_id = ? ORDER BY id', d.id) })),
    follow_ups: M.all('SELECT * FROM follow_ups WHERE lead_id = ? ORDER BY due_date DESC, id DESC', id),
    communications: M.all('SELECT * FROM communications WHERE lead_id = ? ORDER BY date DESC, id DESC', id)
  };
}

module.exports = function register(route, settings) {
  route('GET', '/api/mkt/next-ref', () => ({ ref_no: nextRef(settings()) }));

  // quick search for the "Find enquiry" box: Ref No., mobile, company or name
  route('GET', '/api/mkt/find', ({ q }) => {
    const t = String(q.q || '').trim();
    if (!t) return [];
    const d = digits(t), like = '%' + t.toUpperCase() + '%';
    return M.all(`SELECT id, ref_no, company, buyer_name, city, state, mobile1 FROM leads
      WHERE ${/^\d{1,6}$/.test(t) ? 'ref_no = ? OR ' : ''}${d.length >= 4 ? "mobile1 LIKE ? OR mobile2 LIKE ? OR " : ''}company LIKE ? OR buyer_name LIKE ?
      ORDER BY ${/^\d{1,6}$/.test(t) ? 'ref_no = ? DESC, ' : ''}ref_no DESC LIMIT 12`,
      ...(/^\d{1,6}$/.test(t) ? [Number(t)] : []), ...(d.length >= 4 ? ['%' + d + '%', '%' + d + '%'] : []), like, like, ...(/^\d{1,6}$/.test(t) ? [Number(t)] : []));
  });

  // enquiries list with their samples and next call
  route('GET', '/api/mkt/leads', ({ q }) => {
    const t = String(q.q || '').trim(), args = [];
    let where = '';
    if (t) {
      const like = '%' + t.toUpperCase() + '%', d = digits(t);
      where = `WHERE l.company LIKE ? OR l.buyer_name LIKE ? OR l.city LIKE ? OR l.state LIKE ?${d.length >= 3 ? ' OR l.mobile1 LIKE ? OR l.mobile2 LIKE ?' : ''}${/^\d+$/.test(t) ? ' OR l.ref_no = ?' : ''}`;
      args.push(like, like, like, like);
      if (d.length >= 3) args.push('%' + d + '%', '%' + d + '%');
      if (/^\d+$/.test(t)) args.push(Number(t));
    }
    const limit = Math.min(Number(q.limit) || 300, 5000);
    return M.all(`SELECT l.id, l.ref_no, l.company, l.buyer_name, l.city, l.state, l.mobile1, l.became_buyer_id,
        (SELECT COUNT(*) FROM samples s WHERE s.lead_id = l.id) AS samples,
        (SELECT COALESCE(d.date, '') || ' · ' || COALESCE((SELECT group_concat(COALESCE(s.grade, s.item_name), ', ') FROM samples s WHERE s.dispatch_id = d.id), '')
           FROM dispatches d WHERE d.lead_id = l.id ORDER BY d.date DESC, d.id DESC LIMIT 1) AS last_sample,
        (SELECT MIN(f.due_date) FROM follow_ups f WHERE f.lead_id = l.id AND f.status = 'PENDING') AS next_call
      FROM leads l ${where} ORDER BY l.ref_no DESC LIMIT ${limit}`, ...args);
  });

  route('GET', '/api/mkt/leads/:id', ({ p }) => leadFull(Number(p.id)));

  // enquiry only (no sample yet)
  route('POST', '/api/mkt/leads', ({ body }) => {
    const o = cleanLead(body.lead || body, false);
    const dup = !body.allow_duplicate && sameMobile(o.mobile1);
    if (dup) throw new M.MktError(`Mobile ${o.mobile1} is already Ref ${dup.ref_no} — ${dup.company || dup.buyer_name}. Open that enquiry instead.`);
    return M.tx(() => insertLead(o, settings()));
  });
  route('PUT', '/api/mkt/leads/:id', ({ p, body }) => {
    const id = Number(p.id);
    if (!M.get('SELECT 1 FROM leads WHERE id = ?', id)) throw new M.MktError('This enquiry is not there any more.');
    const o = cleanLead(body.lead || body, false);
    const dup = !body.allow_duplicate && sameMobile(o.mobile1, id);
    if (dup) throw new M.MktError(`Mobile ${o.mobile1} is already Ref ${dup.ref_no} — ${dup.company || dup.buyer_name}.`);
    updateLead(id, o);
    return { id };
  });
  route('DELETE', '/api/mkt/leads/:id', ({ p }) => {
    const id = Number(p.id);
    if (M.get('SELECT 1 FROM dispatches WHERE lead_id = ? UNION ALL SELECT 1 FROM communications WHERE lead_id = ? LIMIT 1', id, id))
      throw new M.MktError('This enquiry has dispatches or calls, so it is kept. Delete its dispatches first.');
    M.tx(() => { M.run('DELETE FROM follow_ups WHERE lead_id = ?', id); M.run('DELETE FROM leads WHERE id = ?', id); });
    return { deleted: true };
  });

  // new dispatch: for an existing enquiry (lead_id) or a new one (lead), its sample lines, and the first follow-up call
  const insertLines = (did, leadId, date, lines) => {
    const keys = Object.keys(lines[0]);
    for (const ln of lines) M.run(`INSERT INTO samples(dispatch_id, lead_id, date, ${keys.join(',')}) VALUES(?, ?, ?, ${keys.map(() => '?').join(',')})`, did, leadId, date, ...keys.map(k => ln[k]));
  };
  route('POST', '/api/mkt/dispatches', ({ body }) => {
    const s = settings();
    const lead = cleanLead(body.lead || {}, true), disp = cleanDispatch(body.dispatch || {}, s), lines = cleanLines(body.lines);
    const leadId = Number(body.lead_id) || null;
    if (leadId && !M.get('SELECT 1 FROM leads WHERE id = ?', leadId)) throw new M.MktError('This enquiry is not there any more.');
    const dup = !body.allow_duplicate && sameMobile(lead.mobile1, leadId);
    if (dup) throw new M.MktError(`Mobile ${lead.mobile1} is already Ref ${dup.ref_no} — ${dup.company || dup.buyer_name}. Find that enquiry and add the dispatch there.`);
    return M.tx(() => {
      let L;
      if (leadId) { updateLead(leadId, lead); L = { id: leadId, ref_no: M.get('SELECT ref_no FROM leads WHERE id = ?', leadId).ref_no }; }
      else L = insertLead(lead, s);
      const dk = Object.keys(disp);
      const did = Number(M.run(`INSERT INTO dispatches(lead_id, ${dk.join(',')}) VALUES(?, ${dk.map(() => '?').join(',')})`, L.id, ...dk.map(k => disp[k])).lastInsertRowid);
      insertLines(did, L.id, disp.date, lines);
      let follow_up = null;
      if (s.followup_auto) {        // Settings → Marketing: "Did the sample arrive?" call — on/off and after how many days
        const reasons = M.all("SELECT value FROM mkt_lists WHERE list_key = 'followup_reason' AND active = 1 ORDER BY sort, value").map(r => r.value);
        const reason = reasons.find(r => /SAMPLE RECEIVED|SAMPLE RECIVED/.test(r)) || reasons[0] || 'CHECK IF SAMPLE RECEIVED';
        const due = addDays(disp.date, s.followup_days);
        const fid = Number(M.run('INSERT INTO follow_ups(lead_id, dispatch_id, due_date, reason, calendar_status) VALUES(?, ?, ?, ?, ?)', L.id, did, due, reason, s.calendar_url ? 'QUEUED' : null).lastInsertRowid);
        if (s.calendar_url) setImmediate(() => hooks.emit('followup', fid));   // to Google Calendar now (the 10-minute worker retries)
        follow_up = { due_date: due, reason };
      }
      if (disp.tracking_no) setImmediate(() => hooks.emit('tracking', did, null, disp.tracking_no));   // sample dispatch email (if switched on)
      return { lead_id: L.id, ref_no: L.ref_no, dispatch_id: did, samples: lines.length, follow_up };
    });
  });

  route('GET', '/api/mkt/dispatches/:id', ({ p }) => {
    const dispatch = M.get('SELECT * FROM dispatches WHERE id = ?', p.id);
    if (!dispatch) throw new M.MktError('This dispatch is not there any more.');
    return { dispatch, lines: M.all('SELECT * FROM samples WHERE dispatch_id = ? ORDER BY id', dispatch.id), lead: M.get('SELECT * FROM leads WHERE id = ?', dispatch.lead_id) };
  });
  // change a saved dispatch: its details, its sample lines (replaced like invoice lines) and the enquiry's details
  route('PUT', '/api/mkt/dispatches/:id', ({ p, body }) => {
    const old = M.get('SELECT * FROM dispatches WHERE id = ?', p.id);
    if (!old) throw new M.MktError('This dispatch is not there any more.');
    const s = settings(), disp = cleanDispatch(body.dispatch || {}, s), lines = cleanLines(body.lines);
    const lead = body.lead ? cleanLead(body.lead, true) : null;
    if (lead) { const dup = !body.allow_duplicate && sameMobile(lead.mobile1, old.lead_id); if (dup) throw new M.MktError(`Mobile ${lead.mobile1} is already Ref ${dup.ref_no} — ${dup.company || dup.buyer_name}.`); }
    M.tx(() => {
      if (lead) updateLead(old.lead_id, lead);
      const dk = Object.keys(disp);
      M.run(`UPDATE dispatches SET ${dk.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...dk.map(k => disp[k]), old.id);
      M.run('DELETE FROM samples WHERE dispatch_id = ?', old.id);
      insertLines(old.id, old.lead_id, disp.date, lines);
      if (disp.date !== old.date)          // the planned first call moves with the dispatch date (and goes to the calendar again on the new day)
        M.run("UPDATE follow_ups SET due_date = ?, calendar_status = CASE WHEN ? THEN 'QUEUED' ELSE calendar_status END WHERE dispatch_id = ? AND status = 'PENDING'",
          addDays(disp.date, s.followup_days), s.calendar_url ? 1 : 0, old.id);
    });
    if ((disp.tracking_no || '') !== (old.tracking_no || '')) hooks.emit('tracking', old.id, old.tracking_no, disp.tracking_no);   // sample dispatch email (if switched on)
    return { id: old.id, lead_id: old.lead_id };
  });
  route('DELETE', '/api/mkt/dispatches/:id', ({ p }) => {
    const old = M.get('SELECT * FROM dispatches WHERE id = ?', p.id);
    if (!old) return { deleted: true };
    M.tx(() => {
      M.run("DELETE FROM follow_ups WHERE dispatch_id = ? AND status = 'PENDING'", old.id);
      M.run('DELETE FROM dispatch_freight WHERE dispatch_id = ?', old.id);
      M.run('DELETE FROM samples WHERE dispatch_id = ?', old.id);
      M.run('DELETE FROM dispatches WHERE id = ?', old.id);
    });
    return { deleted: true, lead_id: old.lead_id };
  });

  // "Make Buyer": the buyer was added to Master → Buyer B2B (a one-time copy); the enquiry remembers which one
  route('POST', '/api/mkt/leads/:id/buyer', ({ p, body }) => {
    const id = Number(p.id), pid = Number(body.party_id);
    if (!M.get('SELECT 1 FROM leads WHERE id = ?', id)) throw new M.MktError('This enquiry is not there any more.');
    if (!mAll('SELECT id FROM parties WHERE id = ?', pid).length) throw new M.MktError('That buyer is not in Master → Buyer B2B.');
    M.run("UPDATE leads SET became_buyer_id = ?, updated_at = datetime('now','localtime') WHERE id = ?", pid, id);
    return { id, became_buyer_id: pid };
  });
  route('DELETE', '/api/mkt/leads/:id/buyer', ({ p }) => { M.run('UPDATE leads SET became_buyer_id = NULL WHERE id = ?', p.id); return { ok: true }; });
  // buyers that may be this enquiry already (same GSTIN or mobile) — to link instead of adding twice
  route('GET', '/api/mkt/leads/:id/buyer-candidates', ({ p }) => {
    const l = M.get('SELECT * FROM leads WHERE id = ?', p.id);
    if (!l) throw new M.MktError('This enquiry is not there any more.');
    const out = [], m = [l.mobile1, l.mobile2].filter(Boolean);
    if (l.gst) out.push(...mAll('SELECT id, name, city, firm_code, gstin FROM parties WHERE active = 1 AND upper(gstin) = ?', l.gst));
    for (const x of m) for (const r of mAll("SELECT id, name, city, firm_code, gstin FROM parties WHERE active = 1 AND (replace(replace(COALESCE(mobile,''),' ',''),'-','') LIKE ? OR replace(replace(COALESCE(phone,''),' ',''),'-','') LIKE ?) LIMIT 5", '%' + x + '%', '%' + x + '%')) if (!out.some(o => o.id === r.id)) out.push(r);
    if (l.company) for (const r of mAll('SELECT id, name, city, firm_code, gstin FROM parties WHERE active = 1 AND upper(name) = ? LIMIT 5', l.company)) if (!out.some(o => o.id === r.id)) out.push(r);
    return out;
  });

  // read-only look into the billing buyers: "Also a buyer: …" (nothing is written there)
  route('GET', '/api/mkt/buyer-match', ({ q }) => {
    const m = digits(q.mobile).slice(-10), g = up(q.gst);
    const out = [];
    if (m.length === 10) {
      for (const r of mAll("SELECT name FROM parties WHERE active = 1 AND (replace(replace(COALESCE(mobile,''),' ',''),'-','') LIKE ? OR replace(replace(COALESCE(phone,''),' ',''),'-','') LIKE ?) LIMIT 3", '%' + m + '%', '%' + m + '%')) out.push({ name: r.name, kind: 'Buyer B2B' });
      for (const r of mAll("SELECT name FROM b2c_customers WHERE active = 1 AND replace(COALESCE(mobile,''),' ','') LIKE ? LIMIT 3", '%' + m + '%')) out.push({ name: r.name, kind: 'Buyer B2C' });
    }
    if (g && g.length === 15) for (const r of mAll('SELECT name FROM parties WHERE active = 1 AND upper(gstin) = ? LIMIT 3', g)) if (!out.some(x => x.name === r.name)) out.push({ name: r.name, kind: 'Buyer B2B (GST)' });
    return out;
  });
};
