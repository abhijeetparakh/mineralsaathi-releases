'use strict';
/* Mineral Saathi — screens. Loaded from the main PC, so every PC always runs the latest version. */

// ---------- small helpers ----------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rs = n => '₹ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');
const qty = n => n == null || n === '' ? '' : (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 });
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const FIRM_NAME = { PPE: 'P.P. Enterprise', PM: 'Parakh Marketing', PF: 'Parakh Fertilizer' };

const S = { meta: null, fy: null, dirty: false, version: null, parties: null, items: null };

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = null;
  try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) throw new Error((data && data.error) || 'Could not reach the main PC. Is the Mineral Saathi server running?');
  return data;
}
const GET = u => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b), DEL = u => api('DELETE', u);

let toastT;
function toast(msg, err) {
  const t = $('#toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, err ? 6000 : 3000);
}
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, true); throw e; } }

function modal(title, html, mount) {
  $('#mtitle').textContent = title; $('#mbody').innerHTML = html; $('#modal').hidden = false;
  if (mount) mount($('#mbody'));
  const first = $('#mbody input, #mbody select, #mbody textarea'); if (first) first.focus();
}
function closeModal() { $('#modal').hidden = true; $('#mbody').innerHTML = ''; }
$('#mclose').onclick = closeModal;
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

function formData(root) {
  const o = {};
  $$('[name]', root).forEach(el => { o[el.name] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value.trim(); });
  return o;
}
function field(f, v) {
  const val = v ?? f.def ?? '';
  const cls = f.span ? `class="span${f.span}"` : '';
  if (f.type === 'select') return `<label ${cls}>${esc(f.label)}<select name="${f.name}" ${f.disabled ? 'disabled' : ''}>${(f.options || []).map(o => {
    const [k, t] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(k)}" ${String(k) === String(val) ? 'selected' : ''}>${esc(t)}</option>`; }).join('')}</select></label>`;
  if (f.type === 'textarea') return `<label ${cls}>${esc(f.label)}<textarea name="${f.name}">${esc(val)}</textarea></label>`;
  return `<label ${cls}>${esc(f.label)}<input name="${f.name}" type="${f.type || 'text'}" value="${esc(val)}" ${f.list ? `list="${f.list}"` : ''} ${f.step ? `step="${f.step}"` : ''} ${f.ro ? 'readonly' : ''}></label>`;
}
function datalist(id, values) { return `<datalist id="${id}">${[...new Set(values.filter(Boolean))].map(v => `<option value="${esc(v)}">`).join('')}</datalist>`; }
function markDirty(root) { root.addEventListener('input', () => { S.dirty = true; }); }

function downloadCsv(name, rows) {
  if (!rows.length) return toast('Nothing to export.', true);
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(','))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = name; a.click();
}

// Saves a file. Where the browser allows it, the save window opens on the Desktop with the name filled in.
async function saveToDesktop(name, text) {
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name, startIn: 'desktop', types: [{ description: 'JSON file', accept: { 'application/json': ['.json'] } }] });
      const w = await h.createWritable(); await w.write(text); await w.close();
      toast(`Saved ${h.name} — upload it on the e-way bill portal`); return;
    } catch (e) { if (e.name === 'AbortError') return; }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; a.click();
  toast(`${name} downloaded — upload it on the e-way bill portal`);
}

async function loadParties(force) { if (!S.parties || force) S.parties = await GET('/api/m/parties?limit=2000'); return S.parties; }
async function loadItems(force) { if (!S.items || force) S.items = await GET('/api/m/items'); return S.items; }

// ---------- packing (who gives the bags, liner) ----------
const PACKING = [['', '—'], ['OUR|0', 'Our bags'], ['OUR|1', 'Our bags + liner'], ['BUYER|0', "Buyer's bags"], ['BUYER|1', "Buyer's bags + liner"]];
const BAG_TYPES = ['PLAIN', 'PLAIN LAMINATED', 'PLAIN BAGS WITH LINER', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'PRINTED LAMINATED', '4 COLOUR LAMINATED BAGS', 'ORGASIL', 'VEDANT', 'IDEAL'];
const packKey = (supply, liner) => supply ? `${supply}|${liner ? 1 : 0}` : '';
const packText = (supply, liner) => [supply === 'BUYER' ? "buyer's bags" : supply === 'OUR' ? 'our bags' : '', liner === 1 ? 'with liner' : liner === 0 && supply ? 'no liner' : ''].filter(Boolean).join(' · ');

// House rules while typing:
//  e-mail → small letters · lorry no. → capitals without spaces · pincode / phone → numbers only
//  (amounts and weights are number boxes, so they only take numbers)
const RULES = [
  ['input[name=email], input[name=to], input[name=cc], input[name=smtp_user]', v => v.toLowerCase()],
  ['input[name=lorry_no], input[data-k=lorry_no]', v => v.toUpperCase().replace(/[^A-Z0-9,]/g, '')],
  ['input[name=pincode], input[name=party_pincode]', v => v.replace(/\D/g, '').slice(0, 6)],
  ['input[name=phone], input[name=mobile], input[name=driver_phone]', v => v.replace(/[^0-9,]/g, '')],
  ['input[name=ewb_no]', v => v.replace(/\D/g, '').slice(0, 12)]
];
document.addEventListener('input', e => {
  const el = e.target;
  if (!el.matches || el.type === 'number') return;
  for (const [sel, fn] of RULES) {
    if (!el.matches(sel)) continue;
    const nv = fn(el.value);
    if (nv !== el.value) { const pos = Math.max(0, (el.selectionStart || 0) - (el.value.length - nv.length)); el.value = nv; try { el.setSelectionRange(pos, pos); } catch { } }
    break;
  }
});
document.addEventListener('focusin', e => { const el = e.target; if (el.matches && el.matches('input[name=pincode], input[name=phone], input[name=mobile], input[name=driver_phone]')) el.inputMode = 'numeric'; });

// city and state filled from the pincode
function hookPincode(root) {
  const pin = $('[name=pincode]', root), city = $('[name=city]', root), state = $('[name=state]', root);
  if (!pin || !city || !state) return;
  pin.addEventListener('input', async () => {
    const v = pin.value.replace(/\D/g, '');
    if (v.length !== 6) return;
    const r = await GET('/api/pincode/' + v).catch(() => null);
    if (!r || !r.found) { toast('Pincode not found in the list — type city and state.', true); return; }
    city.value = r.city;
    if (state.tagName === 'SELECT' && ![...state.options].some(o => o.value === r.state)) state.add(new Option(r.state, r.state));
    state.value = r.state;
    if ($('[name=state_code]', root)) $('[name=state_code]', root).value = r.state_code || '';
    toast(`${r.city}, ${r.state}`);
  });
}

// ---------- router ----------
const PAGES = {};
const TITLES = { dashboard: 'Dashboard', inward: 'Inward & Freight', ppe: 'P.P. Enterprise → Parakh Marketing Bills', invoices: 'Sales Invoices',
  newinvoice: 'New Sales Invoice', invoice: 'Sales Invoice', buyers: 'Buyers', masters: 'Masters', reports: 'Reports', settings: 'Settings & Backup' };

function go(hash) { location.hash = hash; }
async function route() {
  const [page, arg] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/');
  const fn = PAGES[page] || PAGES.dashboard;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.page === page));
  $('#title').textContent = TITLES[page] || 'Mineral Saathi';
  S.dirty = false;
  const old = $('#page'), fresh = old.cloneNode(false); old.replaceWith(fresh);   // drop listeners of the previous screen
  fresh.innerHTML = '<div class="empty">Loading…</div>';
  try { await fn($('#page'), arg); } catch (e) { $('#page').innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', route);
$$('#nav a').forEach(a => a.onclick = () => {
  if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return;
  S.dirty = false;
  if (location.hash === '#/' + a.dataset.page) route(); else go('#/' + a.dataset.page);
});
window.addEventListener('beforeunload', e => { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });

// ---------- dashboard ----------
PAGES.dashboard = async (el) => {
  const d = await GET('/api/dashboard?fy=' + S.fy);
  const by = (arr, k) => arr.find(x => x.firm_code === k) || {};
  el.innerHTML = `
  <div class="stats">
    <div class="stat"><div class="k">Parakh Marketing · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PM').total)}</div><div class="s">${by(d.sales, 'PM').n || 0} invoices · this month ${rs(by(d.month_sales, 'PM').total)}</div></div>
    <div class="stat slate"><div class="k">Parakh Fertilizer · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PF').total)}</div><div class="s">${by(d.sales, 'PF').n || 0} invoices · this month ${rs(by(d.month_sales, 'PF').total)}</div></div>
    <div class="stat rust"><div class="k">P.P. Enterprise bills · ${esc(d.fy)}</div><div class="v">${rs(by(d.sales, 'PPE').total)}</div><div class="s">${by(d.sales, 'PPE').n || 0} bills to Parakh Marketing</div></div>
    <div class="stat amber"><div class="k">Inward · ${esc(d.fy)}</div><div class="v">${qty(d.inward.actual)} MT</div><div class="s">${d.inward.n} lorries · rawana ${qty(d.inward.rawana)} MT · freight ${rs(d.inward.freight)}</div></div>
  </div>
  <div class="grid g2">
    <div class="card"><h3>Waiting for P.P. Enterprise bill</h3>
      <p><b style="font-size:22px">${d.unbilled.n}</b> lorries · ${qty(d.unbilled.qty)} MT rawana weight</p>
      <button onclick="go('#/ppe')">Make bill</button> <button class="sec" onclick="go('#/inward')">New inward</button> <button class="sec" onclick="go('#/newinvoice')">New sales invoice</button></div>
    <div class="card"><h3>Backup</h3>
      <p>Last backup: <b>${d.last_backup ? new Date(d.last_backup).toLocaleString('en-IN') : 'not yet'}</b></p>
      ${d.backup_error ? `<p class="badge red">Last error: ${esc(d.backup_error)}</p>` : ''}
      <button class="sec" onclick="go('#/settings')">Backup settings</button></div>
  </div>
  <div class="card"><h3>Latest invoices</h3><table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th class="num">Total</th></tr></thead><tbody>
    ${d.recent.map(r => `<tr class="click" onclick="openInvoice(${r.id}, '${r.kind}')"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${r.inv_no}</td><td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td class="num">${money(r.total)}</td></tr>`).join('')}
  </tbody></table></div>`;
};

function openInvoice(id, kind) {
  if (kind === 'PPE_BILL') return window.open('/print/invoice/' + id, '_blank');
  go('#/invoice/' + id);
}

// ---------- inward ----------
PAGES.inward = async (el) => {
  el.innerHTML = `<div class="toolbar"><button id="newin">+ New inward (Ctrl+N)</button>
    <input type="search" id="q" placeholder="Search lorry, voucher, rawana, supplier, owner…">
    <div class="tabs" id="st"><button data-s="" class="on">All</button><button data-s="unbilled">Not billed</button><button data-s="billed">Billed</button></div>
    <span class="spacer"></span><button class="sec" id="csv">Export</button><button class="sec small" id="togact" title="Show / hide actual weight"></button></div>
    <div class="tablewrap" id="list"></div>`;
  let status = '', rows = [];
  const showAct = () => { try { return localStorage.getItem('ms_show_actual') === '1'; } catch { return false; } };
  const setTog = () => { $('#togact').textContent = showAct() ? '👁 Hide actual wt' : '👁 Show actual wt'; };
  setTog();
  $('#togact').onclick = () => { try { localStorage.setItem('ms_show_actual', showAct() ? '0' : '1'); } catch { } setTog(); load(); };
  const load = async () => {
    rows = await GET(`/api/inwards?fy=${S.fy}&status=${status}&q=${encodeURIComponent($('#q').value)}`);
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Voucher</th><th>Received</th><th>From</th><th>To</th><th>Lorry</th><th>Grade</th><th>Plant</th><th>Rawana no.</th>
      <th class="num">Rawana wt</th>${showAct() ? '<th class="num">Actual wt</th>' : ''}<th class="num">Rate</th><th class="num">Freight</th><th>PPE bill</th><th></th></tr></thead><tbody>
      ${rows.map(w => `<tr class="click" data-id="${w.id}"><td><b>${esc(w.voucher_no)}</b></td><td>${dmy(w.date)}</td><td>${esc(w.supplier)}</td><td>${esc(w.to_party || '')}</td><td>${esc(w.lorry_no)}</td>
      <td>${esc(w.grade)}</td><td>${esc(w.plant)}</td><td>${esc(w.rawana_no)}</td><td class="num">${qty(w.rawana_wt)}</td>${showAct() ? `<td class="num">${qty(w.actual_wt)}</td>` : ''}
      <td class="num">${money(w.freight_rate)}</td><td class="num">${money(w.freight_amt)}</td>
      <td>${w.ppe_inv_no ? `<span class="badge PPE">No. ${w.ppe_inv_no}</span>` : (/ENTERPRISE/i.test(w.supplier || '') ? '<span class="badge amber">pending</span>' : '')}</td>
      <td><button class="small sec" data-print="${w.id}">Voucher</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">No inward entries.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#st button').forEach(b => b.onclick = () => { $$('#st button').forEach(x => x.classList.remove('on')); b.classList.add('on'); status = b.dataset.s; load(); });
  $('#list').onclick = e => {
    const p = e.target.closest('[data-print]'); if (p) { e.stopPropagation(); return window.open('/print/voucher/' + p.dataset.print, '_blank'); }
    const tr = e.target.closest('tr[data-id]'); if (tr) inwardForm(Number(tr.dataset.id), load);
  };
  $('#newin').onclick = () => chooseVoucherFirm(load);
  $('#csv').onclick = () => downloadCsv(`inward_${S.fy}.csv`, rows);
  await load();
};

async function chooseVoucherFirm(after) {
  const [ppe, pm] = await Promise.all([GET(`/api/inwards/next?fy=${S.fy}&firm=PPE`), GET(`/api/inwards/next?fy=${S.fy}&firm=PM`)]);
  modal('New inward — which firm makes the freight voucher?', `
    <div class="grid g2">
      <button class="rust" style="padding:22px;font-size:17px" data-f="PPE">P.P. Enterprise<br><small style="font-weight:400">Goods sent by P.P. Enterprise to Parakh Marketing · freight paid by P.P. Enterprise<br>Next voucher <b>${esc(ppe.voucher_no)}</b></small></button>
      <button style="padding:22px;font-size:17px" data-f="PM">Parakh Marketing<br><small style="font-weight:400">Parakh Marketing buys from another supplier · freight paid by Parakh Marketing<br>Next voucher <b>${esc(pm.voucher_no)}</b></small></button>
    </div>`, root => {
    root.onclick = e => { const b = e.target.closest('[data-f]'); if (b) { closeModal(); inwardForm(null, after, b.dataset.f); } };
    $('button', root).focus();
  });
}

async function inwardForm(id, after, vfirm) {
  const [w, suppliers] = await Promise.all([id ? GET('/api/inwards/' + id) : null, GET('/api/m/suppliers')]);
  const v = w || { date: today(), condition: 'RAW', mines: 'BADIARA', plant: S.meta.plants[0]?.name, supplier: vfirm === 'PPE' ? 'P.P.ENTERPRISE' : '', to_party: 'PARAKH MARKETING' };
  if (w) vfirm = /^PPE/i.test(w.voucher_no) ? 'PPE' : 'PM';
  const next = !w ? (await GET(`/api/inwards/next?fy=${S.fy}&firm=${vfirm}`)).voucher_no : null;
  const plants = S.meta.plants.map(p => p.name);
  modal(`${id ? 'Inward ' + v.voucher_no : 'New inward'} — freight voucher by ${FIRM_NAME[vfirm]}`, `
  <form id="inf" autocomplete="off">
    ${datalist('dl-sup', suppliers.map(s => s.name))}${datalist('dl-grade', ['YELLOW', 'WHITE', 'GYPSUM', 'ZEOCLAY', 'BENTONITE', 'SM', 'B-GRADE'])}
    <div class="grid g4">
      ${field({ name: 'voucher_no', label: `Voucher no. (${FIRM_NAME[vfirm]})`, ro: true }, v.voucher_no || next)}
      ${field({ name: 'date', label: 'Date received', type: 'date' }, v.date)}
      ${field({ name: 'supplier', label: vfirm === 'PPE' ? 'From' : 'From (supplier)', list: 'dl-sup', ro: vfirm === 'PPE' }, vfirm === 'PPE' ? 'P.P.ENTERPRISE' : v.supplier)}
      ${field({ name: 'to_party', label: 'To', ro: true }, v.to_party || 'PARAKH MARKETING')}
      ${field({ name: 'mines', label: 'Mines' }, v.mines)}
      ${field({ name: 'lorry_no', label: 'Lorry no.' }, v.lorry_no)}
      ${field({ name: 'grade', label: 'Grade', list: 'dl-grade' }, v.grade)}
      ${field({ name: 'condition', label: 'Condition', type: 'select', options: ['RAW', 'BROKEN', 'DRY', 'WET'] }, v.condition)}
      ${field({ name: 'plant', label: 'Plant', type: 'select', options: plants }, v.plant)}
      ${field({ name: 'rawana_no', label: 'Rawana no.' }, v.rawana_no)}
      ${field({ name: 'challan_no', label: 'Challan no.' }, v.challan_no)}
      ${field({ name: 'rawana_wt', label: 'Rawana weight (MT)', type: 'number', step: '0.001' }, v.rawana_wt)}
      ${field({ name: 'actual_wt', label: 'Actual weight received (MT)', type: 'number', step: '0.001' }, v.actual_wt)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div class="freightbox">
        <div class="grid g2">${field({ name: 'freight_rate', label: 'Freight rate per MT (on actual weight)', type: 'number', step: '0.01' }, v.freight_rate)}
          ${field({ name: 'advance', label: 'Advance paid', type: 'number', step: '0.01' }, v.advance)}</div>
        <div style="margin-top:10px">Freight to pay = actual weight × rate = <span class="big" id="famt">₹ 0</span></div>
        <div class="hint" id="fshow">Voucher will show: rawana weight × adjusted rate</div>
      </div>
      <div class="grid g3">
        ${field({ name: 'cash_amt', label: 'Paid cash', type: 'number', step: '0.01' }, v.cash_amt)}
        ${field({ name: 'bank_amt', label: 'Paid bank', type: 'number', step: '0.01' }, v.bank_amt)}
        ${field({ name: 'pay_mode', label: 'Bank / mode', list: 'dl-mode' }, v.pay_mode)}
        ${field({ name: 'chq_no', label: 'Cheque / UTR' }, v.chq_no)}
        ${field({ name: 'upi', label: 'UPI / account', span: 2 }, v.upi)}
        ${datalist('dl-mode', ['KOTAK / ONLINE', 'IDBI / ONLINE', 'BOTH / ONLINE', 'CASH'])}
      </div>
    </div>
    <div class="grid g4" style="margin-top:12px">
      ${field({ name: 'owner_name', label: 'Lorry owner' }, v.owner_name)}
      ${field({ name: 'pan', label: 'Owner PAN' }, v.pan)}
      ${field({ name: 'driver_name', label: 'Driver name' }, v.driver_name)}
      ${field({ name: 'driver_phone', label: 'Driver phone' }, v.driver_phone)}
      ${field({ name: 'royalty', label: 'Royalty', type: 'number', step: '0.01' }, v.royalty)}
      ${field({ name: 'dmft', label: 'DMFT', type: 'number', step: '0.01' }, v.dmft)}
      ${field({ name: 'nmet', label: 'NMET', type: 'number', step: '0.01' }, v.nmet)}
      ${field({ name: 'remarks', label: 'Remarks' }, v.remarks)}
    </div>
    ${v.ppe_invoice_id ? '<p class="badge PPE" style="margin-top:10px">Billed by P.P. Enterprise — rawana weight is locked</p>' : ''}
    <div class="row" style="margin-top:16px"><button type="submit">Save</button><button type="button" class="sec" id="saveprint">Save & print voucher</button>
      <span class="spacer"></span>${id && !v.ppe_invoice_id ? '<button type="button" class="sec" id="delin">Delete</button>' : ''}</div>
  </form>`, root => {
    const f = $('#inf', root);
    const calc = () => {
      const d = formData(f);
      const amt = r2((+d.actual_wt || 0) * (+d.freight_rate || 0));
      const shown = +d.rawana_wt ? r2(amt / +d.rawana_wt) : 0;
      $('#famt').textContent = '₹ ' + money(amt);
      $('#fshow').textContent = +d.rawana_wt ? `Voucher will show: ${qty(d.rawana_wt)} MT @ ₹${money(shown)} = ₹${money(amt)}` : 'Enter rawana weight to see the voucher rate';
    };
    f.addEventListener('input', calc); calc();
    if (v.ppe_invoice_id) f.rawana_wt.readOnly = true;
    f.lorry_no.addEventListener('change', async () => {
      const no = f.lorry_no.value.trim(); if (!no) return;
      const r = await GET('/api/lorry/' + encodeURIComponent(no));
      const fill = (k, val) => { if (val && !f[k].value) f[k].value = val; };
      if (r.lorry) { fill('owner_name', r.lorry.owner); fill('pan', r.lorry.pan); fill('driver_name', r.lorry.driver_name); fill('driver_phone', r.lorry.driver_phone); fill('upi', r.lorry.upi); }
      if (r.last) { [...(vfirm === 'PPE' ? [] : ['supplier']), 'mines', 'grade', 'owner_name', 'pan', 'driver_name', 'driver_phone', 'upi', 'freight_rate'].forEach(k => fill(k, r.last[k])); if (r.last.plant) f.plant.value = r.last.plant; }
      calc();
    });
    f.supplier.addEventListener('change', () => { const s = suppliers.find(x => x.name === f.supplier.value); if (s) { if (!f.grade.value) f.grade.value = s.grade || ''; if (!f.freight_rate.value && s.freight_rate) f.freight_rate.value = s.freight_rate; calc(); } });
    const save = async (print) => {
      const d = formData(f); delete d.voucher_no; d.voucher_firm = vfirm;
      const r = await guard(() => id ? PUT('/api/inwards/' + id, d) : POST('/api/inwards', d));
      toast('Inward saved'); closeModal(); if (print) window.open('/print/voucher/' + r.id + '?print=1', '_blank'); after && after();
    };
    f.onsubmit = e => { e.preventDefault(); save(false); };
    $('#saveprint', root).onclick = () => save(true);
    const del = $('#delin', root); if (del) del.onclick = async () => { if (confirm('Delete this inward entry?')) { await guard(() => DEL('/api/inwards/' + id)); closeModal(); after && after(); } };
  });
}

// ---------- P.P. Enterprise bills ----------
PAGES.ppe = async (el) => {
  const [pending, bills] = await Promise.all([
    GET(`/api/inwards?fy=${S.fy}&status=unbilled&supplier=ENTERPRISE`),
    GET(`/api/invoices?fy=${S.fy}&firm=PPE`)
  ]);
  const lastRate = bills.length ? (await GET('/api/invoices/' + bills[0].id)).items[0]?.rate : '';
  el.innerHTML = `
  <div class="card"><h3>1 · Tick the lorries received from P.P. Enterprise</h3>
    <p class="hint">The bill uses the <b>rawana weight</b>. Freight was already paid on the actual weight in the inward entry.</p>
    ${pending.length ? `<div class="tablewrap" style="max-height:340px"><table class="t"><thead><tr><th><input type="checkbox" id="all"></th><th>Voucher</th><th>Received</th><th>Lorry</th><th>Grade</th><th>Rawana no.</th><th>Challan</th><th class="num">Rawana wt</th><th class="num">Actual wt</th></tr></thead><tbody>
      ${pending.map(w => `<tr><td><input type="checkbox" class="pick" value="${w.id}" data-q="${w.rawana_wt}"></td><td>${esc(w.voucher_no)}</td><td>${dmy(w.date)}</td><td><b>${esc(w.lorry_no)}</b></td><td>${esc(w.grade)}</td><td>${esc(w.rawana_no)}</td><td>${esc(w.challan_no)}</td><td class="num">${qty(w.rawana_wt)}</td><td class="num">${qty(w.actual_wt)}</td></tr>`).join('')}
    </tbody></table></div>` : '<div class="empty">All P.P. Enterprise lorries of this year are billed.</div>'}
  </div>
  <div class="card"><h3>2 · Bill details</h3>
    <div class="row">
      <label style="width:160px">Bill date<input type="date" id="bdate" value="${today()}"></label>
      <label style="width:160px">Rate per MT<input type="number" id="brate" step="0.01" value="${esc(lastRate || '')}"></label>
      <label style="width:110px">GST %<input type="number" id="bgst" value="5"></label>
      <label style="width:280px">Item<input id="bitem" value="DIATOMACEOUS EARTH (RAW)"></label>
      <div class="totals" id="btot" style="margin-left:auto"></div>
    </div>
    <div class="row" style="margin-top:14px"><button id="mk">Create bill & print</button></div>
  </div>
  <div class="card"><h3>P.P. Enterprise bills · ${esc(S.fy)}</h3>
    <div class="tablewrap" style="max-height:420px"><table class="t"><thead><tr><th>No.</th><th>Date</th><th>Lorries</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">Total</th><th></th></tr></thead><tbody>
    ${bills.map(b => `<tr><td><b>${b.inv_no}</b> ${b.cancelled ? '<span class="badge red">cancelled</span>' : ''}</td><td>${dmy(b.date)}</td><td>${esc(b.lorry_no)}</td><td class="num">${qty(b.qty)}</td><td class="num">${money(b.taxable)}</td><td class="num">${money(b.total)}</td>
      <td><button class="small sec" onclick="window.open('/print/invoice/${b.id}','_blank')">Print</button> ${!b.legacy && !b.cancelled ? `<button class="small sec" onclick="cancelBill(${b.id})">Cancel</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div></div>`;
  const recalc = () => {
    const picks = $$('.pick:checked'); const q = picks.reduce((s, c) => s + Number(c.dataset.q), 0);
    const taxable = r2(picks.reduce((s, c) => s + r2(Number(c.dataset.q) * (+$('#brate').value || 0)), 0));
    const gst = r2(taxable * (+$('#bgst').value || 0) / 100); const total = Math.round(taxable + gst);
    $('#btot').innerHTML = `<div><span>${picks.length} lorries · ${qty(q)} MT</span><span></span></div><div><span>Taxable</span><b>${money(taxable)}</b></div>
      <div><span>CGST + SGST</span><b>${money(gst)}</b></div><div class="grand"><span>Total</span><span>${rs(total)}</span></div>`;
  };
  el.addEventListener('input', recalc); el.addEventListener('change', recalc); recalc();
  const all = $('#all'); if (all) all.onchange = () => { $$('.pick').forEach(c => c.checked = all.checked); recalc(); };
  $('#mk').onclick = async () => {
    const ids = $$('.pick:checked').map(c => Number(c.value));
    const r = await guard(() => POST('/api/ppe-bills', { inward_ids: ids, rate: $('#brate').value, date: $('#bdate').value, gst_rate: $('#bgst').value, item_name: $('#bitem').value }));
    toast('Bill created'); window.open('/print/invoice/' + r.id + '?print=1', '_blank'); route();
  };
};
async function cancelBill(id) {
  if (!confirm('Cancel this bill? Its lorries will become "not billed" again.')) return;
  await guard(() => POST(`/api/invoices/${id}/cancel`)); toast('Bill cancelled'); route();
}

// ---------- sales invoices list ----------
PAGES.invoices = async (el) => {
  el.innerHTML = `<div class="toolbar"><button onclick="go('#/newinvoice')">+ New invoice</button>
    <div class="tabs" id="ft"><button data-f="" class="on">PM + PF</button><button data-f="PM">Parakh Marketing</button><button data-f="PF">Parakh Fertilizer</button></div>
    <input type="search" id="q" placeholder="Search party, lorry, invoice no., e-way bill…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div>
    <div class="tablewrap" id="list"></div>`;
  let firm = '', rows = [];
  const load = async () => {
    rows = (await GET(`/api/invoices?fy=${S.fy}&kind=SALE&firm=${firm}&q=${encodeURIComponent($('#q').value)}`));
    $('#list').innerHTML = rows.length ? `<table class="t"><thead><tr><th>Firm</th><th>No.</th><th>Date</th><th>Party</th><th>Type</th><th>Lorry</th><th class="num">Qty</th><th class="num">Taxable</th><th class="num">GST</th><th class="num">Total</th><th>E-way bill</th><th>Email</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}"><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td><b>${r.inv_no}</b>${r.cancelled ? ' <span class="badge red">cancelled</span>' : ''}${r.legacy ? ' <span class="badge grey">Excel</span>' : ''}</td>
      <td>${dmy(r.date)}</td><td>${esc(r.party_name)}</td><td>${r.supply_type}</td><td>${esc(r.lorry_no)}</td><td class="num">${qty(r.qty)}${r.lines > 1 ? ` <span class="muted">(${r.lines} items)</span>` : ''}</td>
      <td class="num">${money(r.taxable)}</td><td class="num">${money(r.cgst + r.sgst + r.igst)}</td><td class="num"><b>${money(r.total)}</b></td><td>${esc(r.ewb_no)}</td><td>${r.email_sent_at ? '✓' : ''}</td></tr>`).join('')}
      </tbody></table>` : '<div class="empty">No invoices.</div>';
  };
  $('#q').oninput = debounce(load, 300);
  $$('#ft button').forEach(b => b.onclick = () => { $$('#ft button').forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.f; load(); });
  $('#list').onclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) go('#/invoice/' + tr.dataset.id); };
  $('#csv').onclick = () => downloadCsv(`sales_${S.fy}.csv`, rows);
  await load();
};

// ---------- sales invoice form (many items) ----------
PAGES.newinvoice = el => invoiceForm(el, null);
PAGES.invoice = (el, id) => invoiceForm(el, Number(id));

async function invoiceForm(el, id) {
  const [parties, items, transporters, inv] = await Promise.all([loadParties(), loadItems(), GET('/api/m/transporters'), id ? GET('/api/invoices/' + id) : null]);
  const active = parties.filter(p => p.active !== 0 && ['PM', 'PF'].includes(p.firm_code));
  const label = p => `${p.name} — ${p.city || ''} [${p.firm_code}]`;
  const locked = inv && (inv.legacy || inv.cancelled);
  const v = inv || { date: today(), items: [{}] };
  let party = inv ? parties.find(p => p.id === inv.party_id) || null : null;
  if (inv && !party) party = { id: null, name: inv.party_name, firm_code: inv.firm_code, gstin: inv.party_gstin, state: inv.party_state, state_code: inv.party_state_code, city: inv.party_city, address: inv.party_address };

  el.innerHTML = `
  ${datalist('dl-party', active.map(label))}${datalist('dl-item', items.map(i => i.name))}${datalist('dl-tr', transporters.map(t => t.name))}
  ${datalist('dl-bag', items.map(i => i.bag_type))}
  <form id="invf" autocomplete="off">
  <div class="card">
    <div class="grid g4">
      <label class="span2">Buyer (type to search)<input id="partyq" list="dl-party" value="${esc(party ? label(party) : '')}" ${inv ? 'readonly' : ''} placeholder="Start typing the buyer name…"></label>
      ${field({ name: 'inv_no', label: 'Invoice no.', ro: !!inv }, v.inv_no || '')}
      ${field({ name: 'date', label: 'Invoice date', type: 'date' }, v.date)}
    </div>
    <div class="grid g2" style="margin-top:12px">
      <div class="firmbox" id="firmbox">Choose a buyer. The billing firm comes from the buyer and cannot be changed here.</div>
      <div class="grid g2">
        ${field({ name: 'party_address', label: 'Bill-to address', type: 'textarea' }, v.party_address)}
        ${field({ name: 'ship_address', label: 'Delivery address', type: 'textarea' }, v.ship_address)}
      </div>
    </div>
  </div>
  <div class="card"><h3>Items</h3>
    <div id="pchips" class="row" style="gap:8px;margin-bottom:10px"></div>
    <table class="items"><thead><tr><th style="width:30px">#</th><th>Item</th><th>Grade</th><th style="width:80px">Bags</th><th style="width:70px">Kg / bag</th><th style="width:80px">HSN</th>
      <th style="width:95px">Qty (MT)</th><th style="width:100px">Rate / MT</th><th style="width:60px">GST %</th><th>Bag type</th><th style="width:150px">Packing</th><th style="width:115px" class="num">Amount</th><th></th></tr></thead>
      <tbody id="lines"></tbody></table>
    ${locked ? '' : '<button type="button" class="sec small" id="addline" style="margin-top:8px">+ Add item</button>'}
  </div>
  <div class="grid g2">
    <div class="card"><h3>Dispatch</h3><div class="grid g3">
      ${field({ name: 'lorry_no', label: 'Lorry no.' }, v.lorry_no)}
      ${field({ name: 'transporter', label: "Transporter (buyer's last used)", list: 'dl-tr' }, v.transporter)}
      ${field({ name: 'lr_no', label: 'L.R. no.' }, v.lr_no)}
      ${field({ name: 'driver_phone', label: 'Driver phone' }, v.driver_phone)}
      ${field({ name: 'plant', label: 'Dispatch plant', type: 'select', options: ['', ...S.meta.plants.map(p => p.name)] }, v.plant)}
      <label>E-way bill no. <span id="ewbreq" class="hint"></span>
        <div class="row" style="gap:6px;flex-wrap:nowrap;margin-top:3px"><input name="ewb_no" value="${esc(v.ewb_no || '')}" inputmode="numeric" maxlength="12" placeholder="12 digits">
        ${locked ? '' : '<button type="button" class="sec small" id="ewbjson" style="white-space:nowrap" title="Make the JSON file to upload on the e-way bill portal">⬇ JSON</button>'}</div></label>
      ${field({ name: 'freight_note', label: 'Freight (e.g. ₹3800/MT to pay)', span: 2 }, v.freight_note)}
      ${field({ name: 'advance_freight', label: 'Advance freight', type: 'number' }, v.advance_freight)}
      ${field({ name: 'notes', label: 'Note on invoice', span: 3 }, v.notes)}
    </div></div>
    <div class="card"><h3>Totals</h3><div class="totals" id="tot"></div>
      <div class="row" style="margin-top:14px">
        ${locked ? '' : '<button type="submit">Save</button><button type="button" id="saveprint">Save & print</button>'}
        ${inv ? `<button type="button" class="sec" id="print">Print / PDF</button>${!inv.legacy ? '<button type="button" class="rust" id="email">Email to buyer</button>' : ''}` : ''}
        <span class="spacer"></span>
        ${inv && !locked ? '<button type="button" class="sec" id="cancel">Cancel invoice</button>' : ''}
      </div>
      ${inv && inv.email_sent_at ? `<p class="hint">Email sent on ${esc(inv.email_sent_at)}</p>` : ''}
      ${inv && inv.legacy ? '<p class="hint">Imported from the old Excel file — view and print only.</p>' : ''}
    </div>
  </div>
  </form>`;

  const f = $('#invf');
  const lines = $('#lines');
  const lineHtml = (it = {}, i) => `<tr>
    <td>${i + 1}</td>
    <td><input data-k="item_name" list="dl-item" value="${esc(it.item_name)}"></td>
    <td><input data-k="grade" list="dl-grade-${i}" value="${esc(it.grade)}"><datalist id="dl-grade-${i}"></datalist></td>
    <td><input data-k="bags" type="number" class="num" value="${esc(it.bags ?? '')}"></td>
    <td><input data-k="pack_size" type="number" class="num" value="${esc(it.pack_size ?? '')}"></td>
    <td><input data-k="hsn" value="${esc(it.hsn || '')}"></td>
    <td><input data-k="qty" type="number" step="0.001" class="num" value="${esc(it.qty ?? '')}" title="Bags × kg per bag ÷ 1000"></td>
    <td><input data-k="rate" type="number" step="0.01" class="num" value="${esc(it.rate ?? '')}"></td>
    <td><input data-k="gst_rate" type="number" class="num" value="${esc(it.gst_rate ?? 5)}"></td>
    <td><input data-k="bag_type" list="dl-bag" value="${esc(it.bag_type || '')}"></td>
    <td><select data-k="packing">${PACKING.map(([k, tx]) => `<option value="${k}" ${k === packKey(it.bag_supply, it.liner) ? 'selected' : ''}>${tx}</option>`).join('')}</select></td>
    <td class="num amt">0.00</td>
    <td>${locked ? '' : '<button type="button" class="ghost del" title="Remove">✕</button>'}</td></tr>`;
  const readLines = () => $$('tr', lines).map(tr => {
    const o = {}; $$('[data-k]', tr).forEach(i => o[i.dataset.k] = i.value.trim());
    const [bs, ln] = (o.packing || '').split('|'); delete o.packing;
    o.bag_supply = bs || null; o.liner = bs ? Number(ln) : null; return o;
  });
  let pitems = [];
  const fromBuyer = (name, grade) => pitems.find(x => x.item_name === name && (x.grade || '') === grade) ||
    (!grade && pitems.filter(x => x.item_name === name).length === 1 ? pitems.find(x => x.item_name === name) : null);
  const fillLine = (tr, x, force) => {
    const set = (k, v) => { const inp = $(`[data-k=${k}]`, tr); if (v != null && v !== '' && (force || !inp.value)) inp.value = v; };
    const mm = items.find(i => i.name === x.item_name && (i.grade || '') === (x.grade || '')) || items.find(i => i.name === x.item_name) || {};
    set('item_name', x.item_name); set('grade', x.grade); set('hsn', x.hsn || mm.hsn); set('rate', x.rate); set('pack_size', x.pack_size); set('bag_type', x.bag_type);
    if (x.gst_rate != null) $('[data-k=gst_rate]', tr).value = x.gst_rate;
    if (x.bag_supply) $('[data-k=packing]', tr).value = packKey(x.bag_supply, x.liner);
  };
  const showChips = () => {
    $('#pchips').innerHTML = !party ? '' : pitems.length
      ? `<span class="hint">${esc(party.name)}'s items — click to add:</span>` + pitems.map(x => `<button type="button" class="small sec" data-pi="${x.id}">${esc(x.item_name)} ${esc(x.grade || '')} · ₹${money(x.rate)}${x.pack_size ? ' · ' + qty(x.pack_size) + 'kg' : ''}${x.bag_type ? ' ' + esc(x.bag_type) : ''}${packText(x.bag_supply, x.liner) ? ' · ' + esc(packText(x.bag_supply, x.liner)) : ''}</button>`).join('')
      : `<span class="hint">No items saved for this buyer yet — add them in Buyers so rates and packing fill in automatically.</span>`;
  };
  const renderLines = arr => { lines.innerHTML = arr.map(lineHtml).join(''); $$('tr', lines).forEach((tr, i) => fillGrades(tr, i)); };
  const fillGrades = (tr, i) => {
    const name = $('[data-k=item_name]', tr).value.trim().toUpperCase();
    $(`#dl-grade-${i}`, tr).innerHTML = items.filter(x => x.name === name).map(x => `<option value="${esc(x.grade || '')}">`).join('');
  };

  const showFirm = () => {
    const box = $('#firmbox');
    if (!party) { box.innerHTML = 'Choose a buyer. The billing firm comes from the buyer and cannot be changed here.'; return; }
    box.innerHTML = `Billed by <span class="badge ${party.firm_code}">${FIRM_NAME[party.firm_code]}</span><br>
      <b>${esc(party.name)}</b> · ${esc(party.city || '')}, ${esc(party.state || '')} ${party.state_code ? '(' + esc(party.state_code) + ')' : ''}<br>
      ${party.gstin ? 'GSTIN ' + esc(party.gstin) + ' · B2B' : '<span class="badge amber">No GSTIN · B2C</span>'}
      ${party.email ? '<br><span class="hint">' + esc(party.email) + '</span>' : ''}`;
  };

  const calc = () => {
    const arr = readLines();
    const intra = !party || !party.state_code || party.state_code === '08';
    let taxable = 0, tax = 0;
    $$('tr', lines).forEach((tr, i) => {
      const a = r2((+arr[i].qty || 0) * (+arr[i].rate || 0)); taxable += a; tax += r2(a * (+arr[i].gst_rate || 0) / 100);
      $('.amt', tr).textContent = money(a);
    });
    taxable = r2(taxable); tax = r2(tax);
    const raw = taxable + tax, total = Math.round(raw);
    S.invTotal = total;
    const req = $('#ewbreq'); if (req) req.textContent = total > 25000 ? '(required above ₹25,000)' : '';
    const totalQty = arr.reduce((s, x) => s + (+x.qty || 0), 0);
    $('#tot').innerHTML = `<div><span>Total quantity</span><b>${qty(totalQty)} MT</b></div><div><span>Taxable value</span><b>${money(taxable)}</b></div>
      ${intra ? `<div><span>CGST</span><b>${money(tax / 2)}</b></div><div><span>SGST</span><b>${money(tax / 2)}</b></div>` : `<div><span>IGST (other state)</span><b>${money(tax)}</b></div>`}
      <div><span>Round off</span><b>${money(total - raw)}</b></div><div class="grand"><span>Grand total</span><span>${rs(total)}</span></div>`;
  };

  const choose = async (p) => {
    party = p; showFirm();
    pitems = p && p.id ? await GET(`/api/parties/${p.id}/items`) : [];
    if (!locked) showChips();
    if (!p) return;
    if (!inv) {
      f.party_address.value = p.address || ''; f.ship_address.value = p.ship_address || '';
      f.transporter.value = p.transporter || '';      // buyer's last used transporter
      const n = await GET(`/api/invoices/next?firm=${p.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no;
    }
    calc();
  };

  renderLines(v.items.length ? v.items : [{}]);
  showFirm(); calc();
  if (party && party.id && !locked) { pitems = await GET(`/api/parties/${party.id}/items`); showChips(); }
  $('#pchips').onclick = e => {
    const b = e.target.closest('[data-pi]'); if (!b) return;
    const x = pitems.find(i => i.id === Number(b.dataset.pi));
    let arr = readLines(); const last = arr[arr.length - 1];
    if (last && (last.item_name || last.qty)) { arr.push({ gst_rate: 5 }); renderLines(arr); }
    const tr = $$('tr', lines).pop(); fillLine(tr, x, true); fillGrades(tr, $$('tr', lines).length - 1);
    calc(); S.dirty = true; $('[data-k=qty]', tr).focus();
  };
  if (locked) $$('input, select, textarea', f).forEach(x => x.disabled = true);
  else markDirty(f);

  $('#partyq').addEventListener('change', () => choose(active.find(p => label(p) === $('#partyq').value) || null));
  f.date.addEventListener('change', async () => { if (party && !inv) { const n = await GET(`/api/invoices/next?firm=${party.firm_code}&date=${f.date.value}`); f.inv_no.value = n.inv_no; } });
  lines.addEventListener('input', calc);
  lines.addEventListener('change', e => {
    const tr = e.target.closest('tr'); const i = $$('tr', lines).indexOf(tr);
    const k = e.target.dataset.k;
    if (k === 'item_name' || k === 'grade') {
      fillGrades(tr, i);
      const name = $('[data-k=item_name]', tr).value.trim().toUpperCase(), grade = $('[data-k=grade]', tr).value.trim().toUpperCase();
      const bm = fromBuyer(name, grade);
      if (bm) { fillLine(tr, bm, k === 'grade'); calc(); return; }
      const m = items.find(x => x.name === name && (x.grade || '') === grade) || (k === 'item_name' ? items.find(x => x.name === name) : null);
      if (m) {
        const set = (kk, val) => { const inp = $(`[data-k=${kk}]`, tr); if (val != null && val !== '' && !inp.value) inp.value = val; };
        set('hsn', m.hsn); set('rate', m.rate); set('bag_type', m.bag_type); set('pack_size', m.pack_size);
        const g = $('[data-k=gst_rate]', tr); if (m.gst_rate != null) g.value = m.gst_rate;
      }
    }
    calc();
  });
  // quantity (MT) = bags × kg per bag ÷ 1000
  lines.addEventListener('input', e => {
    const k = e.target.dataset.k; if (k !== 'bags' && k !== 'pack_size') return;
    const tr = e.target.closest('tr');
    const b = +$('[data-k=bags]', tr).value, pk = +$('[data-k=pack_size]', tr).value;
    if (b && pk) { $('[data-k=qty]', tr).value = String(Math.round(b * pk) / 1000); calc(); }
  });
  lines.addEventListener('click', e => { if (e.target.classList.contains('del')) { const arr = readLines(); arr.splice($$('tr', lines).indexOf(e.target.closest('tr')), 1); renderLines(arr.length ? arr : [{}]); calc(); S.dirty = true; } });
  const add = $('#addline'); if (add) add.onclick = () => { const arr = readLines(); arr.push({ gst_rate: 5 }); renderLines(arr); calc(); $$('tr', lines).pop().querySelector('input').focus(); };

  const save = async () => {
    if (!party || !party.id) { toast('Choose the buyer from the list.', true); return null; }
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    delete body.undefined;
    if (inv) delete body.inv_no;
    const r = await guard(() => inv ? PUT('/api/invoices/' + inv.id, body) : POST('/api/invoices', body));
    S.dirty = false; toast('Invoice saved'); return r.id;
  };
  f.onsubmit = async e => { e.preventDefault(); const nid = await save(); if (!nid) return; go('#/invoice/' + nid); if (inv) route(); };
  const sp = $('#saveprint'); if (sp) sp.onclick = async () => { const nid = await save(); if (!nid) return; window.open('/print/invoice/' + nid + '?print=1', '_blank'); go('#/invoice/' + nid); if (inv) route(); };
  const ej = $('#ewbjson'); if (ej) ej.onclick = async () => {
    if (!party || !party.id) return toast('Choose the buyer first.', true);
    const body = { ...formData(f), party_id: party.id, items: readLines().filter(x => x.item_name || x.qty) };
    const r = await guard(() => POST('/api/ewaybill-json', body));
    await saveToDesktop('ewaybill.json', JSON.stringify(r, null, 1));
  };
  const pr = $('#print'); if (pr) pr.onclick = () => window.open('/print/invoice/' + inv.id, '_blank');
  const cn = $('#cancel'); if (cn) cn.onclick = async () => { if (confirm('Cancel this invoice? It stays in the list marked cancelled.')) { await guard(() => POST(`/api/invoices/${inv.id}/cancel`)); toast('Invoice cancelled'); route(); } };
  const em = $('#email'); if (em) em.onclick = () => emailDialog(inv.id);
}

async function emailDialog(id) {
  const d = await guard(() => GET(`/api/invoices/${id}/email`));
  modal('Email invoice to buyer', `
    ${d.ready ? '' : '<p class="badge amber">Email is not set up for this firm yet. Open Settings → Email first.</p>'}
    <form id="emf"><div class="grid g2">
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <label class="span2">Message<textarea name="text" style="min-height:260px">${esc(d.text)}</textarea></label>
    </div><p class="hint">The invoice PDF is attached automatically. Sent from ${esc(d.from || '')}.</p>
    <div class="row"><button type="submit" ${d.ready ? '' : 'disabled'}>Send email</button></div></form>`, root => {
    $('#emf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try { const r = await POST(`/api/invoices/${id}/email`, formData(e.target)); toast('Email sent'); closeModal(); route(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ---------- masters ----------
const STATES = () => ['', ...S.meta.states];
const SPECS = {
  parties: {
    title: 'Buyer', wide: true, cols: [['name', 'Name'], ['firm_code', 'Billed by'], ['item_count', 'Items'], ['city', 'City'], ['state', 'State'], ['gstin', 'GSTIN'], ['mobile', 'Mobile'], ['email', 'Email']],
    after: (root, row, reopen) => partyItems(root, row, reopen),
    lists: async () => datalist('dl-m-tr', (await GET('/api/m/transporters')).map(t => t.name)),
    fields: () => [
      { name: 'name', label: 'Buyer name', span: 2 }, { name: 'firm_code', label: 'Billing firm (fixed rule)', type: 'select', options: [['', '— choose —'], ['PM', 'Parakh Marketing'], ['PF', 'Parakh Fertilizer']] },
      { name: 'gstin', label: 'GSTIN (blank for B2C)' }, { name: 'pan', label: 'PAN' }, { name: 'group_name', label: 'Group of company' },
      { name: 'address', label: 'Address', type: 'textarea', span: 2 }, { name: 'ship_address', label: 'Delivery address', type: 'textarea' },
      { name: 'pincode', label: 'Pincode (fills city & state)' }, { name: 'city', label: 'City' }, { name: 'state', label: 'State', type: 'select', options: STATES() },
      { name: 'email', label: 'Email (use ; for more)', span: 2 }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'transporter', label: 'Transporter (last used)', list: 'dl-m-tr' }, { name: 'km', label: 'Distance km', type: 'number' }, { name: 'payment_terms', label: 'Payment terms' }, { name: 'notes', label: 'Notes', span: 2 }]
  },
  items: { title: 'Item', cols: [['name', 'Item'], ['grade', 'Grade'], ['hsn', 'HSN'], ['gst_rate', 'GST %'], ['bag_type', 'Bag type'], ['pack_size', 'Kg/bag'], ['rate', 'Rate']],
    fields: () => [{ name: 'name', label: 'Item name', span: 2 }, { name: 'grade', label: 'Grade / mesh' }, { name: 'hsn', label: 'HSN' }, { name: 'gst_rate', label: 'GST %', type: 'number', def: 5 },
      { name: 'unit', label: 'Unit', def: 'MT' }, { name: 'bag_type', label: 'Bag type' }, { name: 'pack_size', label: 'Kg per bag', type: 'number' }, { name: 'rate', label: 'Usual rate / MT', type: 'number' }] },
  transporters: { title: 'Transporter', cols: [['name', 'Name'], ['mobile', 'Mobile'], ['phone', 'Phone'], ['district', 'District'], ['gstin', 'GSTIN'], ['pan', 'PAN']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'contact', label: 'Contact person' }, { name: 'mobile', label: 'Mobile' }, { name: 'phone', label: 'Phone' },
      { name: 'email', label: 'Email' }, { name: 'address', label: 'Address', span: 2 }, { name: 'district', label: 'District' }, { name: 'state', label: 'State' }, { name: 'gstin', label: 'GSTIN' },
      { name: 'pan', label: 'PAN' }, { name: 'bank_name', label: 'Bank' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }] },
  lorries: { title: 'Lorry', cols: [['lorry_no', 'Lorry no.'], ['owner', 'Owner'], ['pan', 'PAN'], ['mobile', 'Mobile'], ['driver_name', 'Driver'], ['upi', 'UPI'], ['tds_declaration', 'TDS dec.']],
    fields: () => [{ name: 'lorry_no', label: 'Lorry no.' }, { name: 'owner', label: 'Owner', span: 2 }, { name: 'pan', label: 'PAN' }, { name: 'mobile', label: 'Mobile' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'driver_name', label: 'Driver name' }, { name: 'driver_phone', label: 'Driver phone' }, { name: 'bank_name', label: 'Bank' }, { name: 'holder', label: 'Account holder' },
      { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi', label: 'UPI', span: 2 }, { name: 'tds_declaration', label: 'TDS declaration' }] },
  suppliers: { title: 'Supplier', cols: [['name', 'Name'], ['grade', 'Grade'], ['rate', 'Rate'], ['freight_rate', 'Freight / MT'], ['type', 'Type']],
    fields: () => [{ name: 'name', label: 'Name', span: 2 }, { name: 'grade', label: 'Grade' }, { name: 'rate', label: 'Rate', type: 'number' }, { name: 'freight_rate', label: 'Freight per MT', type: 'number' },
      { name: 'type', label: 'Type', type: 'select', options: ['REG', 'URD'] }] },
  plants: { title: 'Plant', cols: [['name', 'Short name'], ['full_name', 'Name'], ['address', 'Address']],
    fields: () => [{ name: 'name', label: 'Short name (e.g. PPI PLANT)' }, { name: 'full_name', label: 'Name' }, { name: 'address', label: 'Address', span: 2 }] },
  firms: { title: 'Firm', noAdd: true, cols: [['code', 'Code'], ['name', 'Name'], ['gstin', 'GSTIN'], ['phone', 'Phone'], ['email', 'Email'], ['bank_name', 'Bank']],
    fields: () => [{ name: 'name', label: 'Firm name', span: 2 }, { name: 'gstin', label: 'GSTIN' }, { name: 'pan', label: 'PAN' }, { name: 'address', label: 'Address', span: 2 },
      { name: 'city', label: 'City' }, { name: 'state', label: 'State' }, { name: 'state_code', label: 'State code' }, { name: 'pincode', label: 'Pincode' }, { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email' },
      { name: 'bank_name', label: 'Bank name' }, { name: 'bank_account', label: 'Account no.' }, { name: 'bank_ifsc', label: 'IFSC' }, { name: 'upi_id', label: 'UPI id' }, { name: 'terms', label: 'Terms on invoice', type: 'textarea', span: 4 }] }
};

async function masterTable(el, table, extraTools = '') {
  const sp = SPECS[table];
  el.innerHTML = `<div class="toolbar">${sp.noAdd ? '' : `<button id="add">+ Add ${sp.title.toLowerCase()}</button>`}${extraTools}
    <input type="search" id="q" placeholder="Search…"><span class="spacer"></span><button class="sec" id="csv">Export</button></div><div class="tablewrap" id="list"></div>`;
  let rows = [], firm = '';
  const load = async () => {
    rows = await GET(`/api/m/${table}?q=${encodeURIComponent($('#q', el).value)}${firm ? '&firm=' + firm : ''}`);
    $('#list', el).innerHTML = rows.length ? `<table class="t"><thead><tr>${sp.cols.map(c => `<th>${c[1]}</th>`).join('')}</tr></thead><tbody>
      ${rows.map(r => `<tr class="click" data-id="${r.id}" ${r.active === 0 ? 'style="opacity:.5"' : ''}>${sp.cols.map(([k]) => `<td>${k === 'firm_code' ? `<span class="badge ${r[k] || 'grey'}">${esc(FIRM_NAME[r[k]] || 'not set')}</span>` : esc(r[k])}</td>`).join('')}</tr>`).join('')}
      </tbody></table>` : '<div class="empty">Nothing found.</div>';
  };
  const edit = async (row) => {
    const lists = sp.lists ? await sp.lists() : '';
    modal((row ? 'Edit ' : 'New ') + sp.title.toLowerCase(), `${lists}<form id="mf"><div class="grid g4">${sp.fields().map(f => field(f, row ? row[f.name] : undefined)).join('')}</div>
      <div class="row" style="margin-top:16px"><button type="submit">Save</button><span class="spacer"></span>${row && !sp.noAdd ? '<button type="button" class="sec" id="mdel">Delete</button>' : ''}</div></form>
      <div id="mextra"></div>`, root => {
      hookPincode(root);
      if (sp.after) sp.after($('#mextra', root), row);
      $('#mf', root).onsubmit = async e => {
        e.preventDefault(); const d = formData(e.target);
        const r = await guard(() => row ? PUT(`/api/m/${table}/${row.id}`, d) : POST(`/api/m/${table}`, d));
        toast('Saved'); S.parties = null; S.items = null; await load();
        if (!row && sp.after) { const nr = await GET(`/api/m/${table}/${r.id}`); edit(nr); toast("Saved — now add this buyer's items below"); }
        else closeModal();
      };
      const del = $('#mdel', root); if (del) del.onclick = async () => {
        if (!confirm('Delete this record?')) return; const r = await guard(() => DEL(`/api/m/${table}/${row.id}`));
        toast(r.hidden ? 'Has invoices, so it was hidden instead of deleted' : 'Deleted'); closeModal(); S.parties = null; load();
      };
    });
  };
  $('#q', el).oninput = debounce(load, 300);
  const add = $('#add', el); if (add) add.onclick = () => edit(null);
  $('#list', el).onclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) edit(rows.find(r => r.id === Number(tr.dataset.id))); };
  $('#csv', el).onclick = () => downloadCsv(`${table}.csv`, rows);
  $$('[data-firm]', el).forEach(b => b.onclick = () => { $$('[data-firm]', el).forEach(x => x.classList.remove('on')); b.classList.add('on'); firm = b.dataset.firm; load(); });
  await load();
}

async function partyItems(box, row) {
  if (!row) { box.innerHTML = `<div class="firmbox" style="margin-top:16px">Save the buyer first, then add this buyer's items, rates and packing here.</div>`; return; }
  const master = await loadItems();
  const load = async () => {
    const list = await GET(`/api/parties/${row.id}/items`);
    box.innerHTML = `<div class="card" style="margin:18px 0 0;background:#f7fafb"><h3>Items, rates & packing for ${esc(row.name)}</h3>
      ${datalist('dl-pi-item', master.map(i => i.name))}${datalist('dl-pi-grade', master.map(i => i.grade))}${datalist('dl-pi-bag', [...BAG_TYPES, ...master.map(i => i.bag_type)])}
      <table class="t"><thead><tr><th>Item</th><th>Grade</th><th class="num">Rate / MT</th><th class="num">Kg / bag</th><th>Bag type</th><th>Packing</th><th>Notes</th><th></th></tr></thead><tbody>
      ${list.map(x => `<tr><td><b>${esc(x.item_name)}</b></td><td>${esc(x.grade)}</td><td class="num">${money(x.rate)}</td><td class="num">${qty(x.pack_size)}</td><td>${esc(x.bag_type)}</td>
        <td>${esc(packText(x.bag_supply, x.liner)) || '<span class="muted">—</span>'}</td><td>${esc(x.notes)}</td>
        <td style="white-space:nowrap"><button type="button" class="small sec" data-edit="${x.id}">Edit</button> <button type="button" class="small sec" data-del="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="8" class="muted">No items yet.</td></tr>'}
      </tbody></table>
      <form id="pif" class="grid" style="grid-template-columns:2fr 1.3fr 1fr .8fr 1.6fr 1.4fr 1.4fr auto;margin-top:12px;align-items:end">
        <label>Item<input name="item_name" list="dl-pi-item"></label><label>Grade / mesh<input name="grade" list="dl-pi-grade"></label>
        <label>Rate / MT<input name="rate" type="number" step="0.01"></label><label>Kg / bag<input name="pack_size" type="number" step="0.01"></label>
        <label>Bag type<input name="bag_type" list="dl-pi-bag"></label>
        <label>Packing<select name="packing">${PACKING.map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select></label>
        <label>Notes<input name="notes"></label><button type="submit" id="pisave">Add item</button>
      </form></div>`;
    let editing = null;
    const f = $('#pif', box);
    f.item_name.addEventListener('change', () => {
      const m = master.find(i => i.name === f.item_name.value.trim().toUpperCase());
      if (m && !f.pack_size.value && m.pack_size) f.pack_size.value = m.pack_size;
    });
    box.onclick = async e => {
      const ed = e.target.closest('[data-edit]'), dl = e.target.closest('[data-del]');
      if (ed) {
        const x = list.find(i => i.id === Number(ed.dataset.edit)); editing = x.id;
        ['item_name', 'grade', 'rate', 'pack_size', 'bag_type', 'notes'].forEach(k => f[k].value = x[k] ?? '');
        f.packing.value = packKey(x.bag_supply, x.liner); $('#pisave', box).textContent = 'Update item'; f.item_name.focus();
      }
      if (dl && confirm('Remove this item from the buyer?')) { await guard(() => DEL('/api/party-items/' + dl.dataset.del)); load(); }
    };
    f.onsubmit = async e => {
      e.preventDefault(); e.stopPropagation();
      const d = formData(f); const [bs, ln] = (d.packing || '').split('|'); delete d.packing;
      d.bag_supply = bs || null; d.liner = bs ? Number(ln) : null;
      await guard(() => editing ? PUT('/api/party-items/' + editing, d) : POST(`/api/parties/${row.id}/items`, d));
      toast(editing ? 'Item updated' : 'Item added'); load();
    };
  };
  await load();
}

PAGES.buyers = el => masterTable(el, 'parties', `<div class="tabs"><button data-firm="" class="on">All</button><button data-firm="PM">Parakh Marketing</button><button data-firm="PF">Parakh Fertilizer</button><button data-firm="NONE">Firm not set</button></div>`);
PAGES.masters = async (el, tab) => {
  tab = tab || 'items';
  const tabs = [['items', 'Items'], ['lorries', 'Lorries & owners'], ['transporters', 'Transporters'], ['suppliers', 'Suppliers'], ['plants', 'Plants'], ['firms', 'Our firms']];
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px">${tabs.map(([k, t]) => `<button class="${k === tab ? 'on' : ''}" onclick="go('#/masters/${k}')">${t}</button>`).join('')}</div><div id="mt"></div>`;
  await masterTable($('#mt'), tab);
};

// ---------- reports ----------
PAGES.reports = async (el) => {
  const d = await GET('/api/reports/monthly?fy=' + S.fy);
  const months = [...new Set([...d.sales.map(r => r.ym), ...d.inward.map(r => r.ym)])].filter(Boolean).sort();
  const cell = (ym, firm, k) => { const r = d.sales.find(x => x.ym === ym && x.firm_code === firm); return r ? r[k] : null; };
  el.innerHTML = `
  <div class="card"><div class="toolbar"><h3 style="margin:0">Month-wise sales · ${esc(S.fy)}</h3><span class="spacer"></span><button class="sec" id="c1">Export</button></div>
    <div class="tablewrap"><table class="t"><thead><tr><th>Month</th>${['PM', 'PF', 'PPE'].map(f => `<th class="num">${f} qty</th><th class="num">${f} total</th>`).join('')}</tr></thead><tbody>
    ${months.map(m => `<tr><td>${m}</td>${['PM', 'PF', 'PPE'].map(f => `<td class="num">${qty(cell(m, f, 'qty'))}</td><td class="num">${cell(m, f, 'total') == null ? '' : money(cell(m, f, 'total'))}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div></div>
  <div class="grid g2">
    <div class="card"><div class="toolbar"><h3 style="margin:0">Inward month-wise</h3><span class="spacer"></span><button class="sec" id="c2">Export</button></div>
      <table class="t"><thead><tr><th>Month</th><th class="num">Lorries</th><th class="num">Rawana MT</th><th class="num">Actual MT</th><th class="num">Freight</th></tr></thead><tbody>
      ${d.inward.map(r => `<tr><td>${r.ym}</td><td class="num">${r.n}</td><td class="num">${qty(r.rawana)}</td><td class="num">${qty(r.actual)}</td><td class="num">${money(r.freight)}</td></tr>`).join('')}</tbody></table></div>
    <div class="card"><div class="toolbar"><h3 style="margin:0">HSN summary (for GST return)</h3><span class="spacer"></span><button class="sec" id="c3">Export</button></div>
      <table class="t"><thead><tr><th>Firm</th><th>HSN</th><th class="num">GST %</th><th class="num">Qty MT</th><th class="num">Taxable</th></tr></thead><tbody>
      ${d.hsn.map(r => `<tr><td><span class="badge ${r.firm_code}">${r.firm_code}</span></td><td>${esc(r.hsn)}</td><td class="num">${r.gst_rate}</td><td class="num">${qty(r.qty)}</td><td class="num">${money(r.taxable)}</td></tr>`).join('')}</tbody></table></div>
  </div>`;
  $('#c1').onclick = () => downloadCsv(`sales_monthly_${S.fy}.csv`, d.sales);
  $('#c2').onclick = () => downloadCsv(`inward_monthly_${S.fy}.csv`, d.inward);
  $('#c3').onclick = () => downloadCsv(`hsn_${S.fy}.csv`, d.hsn);
};

// ---------- settings ----------
PAGES.settings = async (el) => {
  const s = await GET('/api/settings');
  el.innerHTML = `
  <div class="card"><h3>Backup folder</h3>
    <p class="hint">A full copy of the data is saved here after every new or changed invoice, and every hour. A Google Drive folder on the main PC works well, e.g. <code>G:\\My Drive\\Mineral Saathi Backup</code>.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="bf" value="${esc(s.backup_folder)}"></label><button id="savebf">Save folder</button><button class="sec" id="bnow">Backup now</button></div>
    <p>Last backup: <b>${s.last_backup ? new Date(s.last_backup).toLocaleString('en-IN') : 'not yet'}</b> ${s.last_backup_file ? `<span class="hint">${esc(s.last_backup_file)}</span>` : ''}</p>
    ${s.last_backup_error ? `<p class="badge red">Last error: ${esc(s.last_backup_error)}</p>` : ''}
    <details><summary>Latest backup files (${s.backups.length})</summary><ul>${s.backups.map(b => `<li>${esc(b.name)} <span class="hint">${(b.size / 1048576).toFixed(1)} MB</span></li>`).join('')}</ul></details>
  </div>
  <div class="card"><h3>Invoice PDF folder</h3>
    <p class="hint">PDFs made for emails are saved here, by financial year.</p>
    <div class="row"><label style="flex:1">Folder on the main PC<input id="pf" value="${esc(s.pdf_folder)}"></label><button id="savepf">Save folder</button></div>
  </div>
  <div class="card"><h3>Email (sent by the app — no Outlook needed)</h3>
    <p class="hint">For Gmail: turn on 2-step verification on the Google account, then make an <b>App password</b> (Google Account → Security → App passwords) and paste it here. Server smtp.gmail.com, port 465.</p>
    ${s.firms.filter(f => f.code !== 'PPE').map(f => `
    <form class="emailf grid g5" data-code="${f.code}" style="margin-bottom:12px">
      <label><span class="badge ${f.code}">${esc(f.name)}</span><input name="smtp_user" placeholder="sender@gmail.com" value="${esc(f.smtp_user || '')}"></label>
      <label>App password ${f.has_pass ? '(saved)' : ''}<input name="smtp_pass" type="password" placeholder="${f.has_pass ? '•••••••• (leave blank to keep)' : '16-letter app password'}"></label>
      <label>Server<input name="smtp_host" value="${esc(f.smtp_host || 'smtp.gmail.com')}"></label>
      <label>Port<input name="smtp_port" value="${esc(f.smtp_port || 465)}"></label>
      <div class="row"><button type="submit">Save</button><button type="button" class="sec test">Send test</button></div>
    </form>`).join('')}
  </div>
  <div class="card"><h3>Import data from an old Excel file</h3>
    <p class="hint">Choose a data file prepared from an old billing workbook (for example <b>parakh-fertilizer-data.json</b>). New buyers are added,
      empty details of existing buyers are filled in, and old invoices are added as view-only. Running it twice does not make duplicates.</p>
    <div class="row"><input type="file" id="impf" accept=".json" style="max-width:420px"><button id="impgo">Import</button></div>
    <div id="imprep" style="margin-top:12px"></div></div>
  <div class="card"><h3>Automatic updates</h3>
    <div id="upd"></div></div>
  <div class="card"><h3>About</h3><p>Mineral Saathi version <b>${esc(s.version)}</b>. Every PC loads the screens from the main PC, so updating the main PC updates all PCs automatically.</p></div>`;
  $('#savebf').onclick = async () => { await guard(() => PUT('/api/settings', { backup_folder: $('#bf').value })); toast('Backup folder saved'); route(); };
  $('#impgo').onclick = async () => {
    const file = $('#impf').files[0]; if (!file) return toast('Choose the data file first.', true);
    let data; try { data = JSON.parse(await file.text()); } catch { return toast('That file is not a Mineral Saathi data file.', true); }
    const isItems = data.kind === 'mineral-saathi-buyer-items';
    if (!confirm(isItems ? `Import items & rates for ${data.buyers?.length || 0} buyers?` : `Import ${data.buyers?.length || 0} buyers and ${data.invoices?.length || 0} invoices for ${FIRM_NAME[data.firm_code] || '?'}?`)) return;
    const b = $('#impgo'); b.disabled = true; b.textContent = 'Importing…';
    try {
      const r = await POST('/api/import', data); S.parties = null;
      const list = (title, arr) => arr.length ? `<p><b>${title} (${arr.length})</b><br>${arr.map(esc).join('<br>')}</p>` : '';
      if (r.kind === 'items') {
        $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.items_added} items added to ${r.buyers_touched} buyers${r.items_existing ? `, ${r.items_existing} were already there` : ''}.</p>
          ${list('Buyers in the file that are not in Buyers (not added)', r.buyers_not_found)}</div>`;
        toast('Import finished'); b.disabled = false; b.textContent = 'Import'; return;
      }
      $('#imprep').innerHTML = `<div class="firmbox"><p><b>Done.</b> ${r.invoices_added} invoices added${r.invoices_existing ? `, ${r.invoices_existing} were already imported` : ''}.
        ${r.buyers_added.length} new buyers added, ${r.buyers_filled} existing buyers had empty details filled in.</p>
        ${list('New buyers added (billing firm: ' + FIRM_NAME[data.firm_code] + ')', r.buyers_added)}
        ${list('Already in Buyers but linked to the other firm — check in Buyers', r.buyers_other_firm)}
        ${list('Already in Buyers with no firm set — set it in Buyers', r.buyers_no_firm)}
        ${list('Invoice numbers NOT imported because a new invoice with that number already exists', r.invoices_skipped)}</div>`;
      toast('Import finished');
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = 'Import';
  };
  const showUpd = u => {
    $('#upd').innerHTML = `<p>Installed version <b>${esc(u.current)}</b>${u.latest ? ` · newest available <b>${esc(u.latest)}</b>` : ''}
      ${u.last_check ? `<span class="hint"> · last checked ${new Date(u.last_check).toLocaleString('en-IN')}</span>` : ''}</p>
      ${u.message ? `<p class="firmbox">${esc(u.message)}</p>` : ''}
      <p class="hint">The main PC checks for a new version every 30 minutes and installs it by itself when nobody has saved anything for 5 minutes.
        It takes a backup first and never touches your data. All PCs switch to the new version automatically.</p>
      <div class="row"><label style="display:flex;gap:8px;align-items:center;font-size:14px;color:var(--text)"><input type="checkbox" id="updauto" style="width:auto" ${u.auto ? 'checked' : ''}> Install updates automatically</label>
        <span class="spacer"></span><button class="sec" id="updcheck">Check now</button><button id="updnow">Install update now</button></div>`;
    $('#updauto').onchange = async () => showUpd(await guard(() => PUT('/api/update/settings', { auto: $('#updauto').checked })));
    $('#updcheck').onclick = async () => { $('#updcheck').textContent = 'Checking…'; showUpd(await guard(() => POST('/api/update/check', { install: false }))); };
    $('#updnow').onclick = async () => {
      $('#updnow').textContent = 'Installing…'; $('#updnow').disabled = true;
      const r = await guard(() => POST('/api/update/check', { install: true }));
      if (r.installing) { toast(`Installing version ${r.installing} — the app will reload in a few seconds`); setTimeout(() => location.reload(), 9000); }
      else showUpd(r);
    };
  };
  showUpd(await GET('/api/update'));
  $('#savepf').onclick = async () => { await guard(() => PUT('/api/settings', { pdf_folder: $('#pf').value })); toast('PDF folder saved'); };
  $('#bnow').onclick = async () => { const r = await guard(() => POST('/api/backup')); toast('Backup saved'); route(); };
  $$('.emailf').forEach(f => {
    f.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/settings/email/' + f.dataset.code, formData(f))); toast('Email settings saved'); route(); };
    $('.test', f).onclick = async () => { const b = $('.test', f); b.disabled = true; b.textContent = 'Sending…';
      try { await POST(`/api/settings/email/${f.dataset.code}/test`, {}); toast('Test email sent — check the inbox'); } catch (e) { toast(e.message, true); }
      b.disabled = false; b.textContent = 'Send test'; };
  });
};

// ---------- misc ----------
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key.toLowerCase() === 'n' && $('#modal').hidden) {
    e.preventDefault();
    if (location.hash.startsWith('#/inward')) $('#newin')?.click(); else go('#/newinvoice');
  }
});

$('#fsbtn').onclick = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => {});
setInterval(() => { $('#clock').textContent = new Date().toLocaleString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); }, 1000);

// Auto-update: when the main PC gets a new version, every PC reloads it.
async function checkVersion() {
  try {
    const { version } = await GET('/api/version');
    if (S.version && version !== S.version) {
      if (!S.dirty && $('#modal').hidden) location.reload();
      else { const b = $('#banner'); b.hidden = false; b.innerHTML = `New version ${esc(version)} is installed. Save your work, then <button class="sec small" onclick="location.reload()">Reload now</button>`; }
    }
    $('#sidefoot').textContent = `Version ${version} · connected`;
  } catch { $('#sidefoot').textContent = '⚠ Main PC not reachable'; }
}

(async function start() {
  try {
    S.meta = await GET('/api/meta');
  } catch (e) {
    $('#page').innerHTML = `<div class="card"><h3>Cannot reach the main PC</h3><p>${esc(e.message)}</p><button onclick="location.reload()">Try again</button></div>`; return;
  }
  S.version = S.meta.version;
  S.fy = localStorage.getItem('ms_fy') && S.meta.fys.includes(localStorage.getItem('ms_fy')) ? localStorage.getItem('ms_fy') : S.meta.current_fy;
  const fys = [...new Set([S.meta.current_fy, ...S.meta.fys])].sort().reverse();
  $('#fy').innerHTML = fys.map(f => `<option ${f === S.fy ? 'selected' : ''}>${f}</option>`).join('');
  $('#fy').onchange = () => { S.fy = $('#fy').value; try { localStorage.setItem('ms_fy', S.fy); } catch { } route(); };
  checkVersion(); setInterval(checkVersion, 60000);
  route();
})();
