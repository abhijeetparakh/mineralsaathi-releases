'use strict';
// Marketing phase 4: Today's Calls, the Communication screen (log a call / WhatsApp, plan the next call),
// and the Google Calendar push of planned calls (queued and sent again when the internet is back).
const M = require('./db');
const qr = require('../qr');

const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const isoDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null;
const txt = v => { const s = String(v ?? '').trim(); return s || null; };
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';

module.exports = function register(route, settings) {
  // ---- Google Calendar: one event per planned call ----
  async function pushCalendar(fuId) {
    const s = settings(), url = s.calendar_url;
    const fu = M.get('SELECT * FROM follow_ups WHERE id = ?', fuId);
    if (!fu || !url || fu.status !== 'PENDING') return;
    const l = M.get('SELECT * FROM leads WHERE id = ?', fu.lead_id) || {};
    const last = M.get("SELECT c.note, c.response, c.date FROM communications c WHERE c.lead_id = ? ORDER BY c.date DESC, c.id DESC LIMIT 1", fu.lead_id) || {};
    const m = l.mobile1 || '';
    const payload = {
      title: `Call Ref :${l.ref_no} ${l.buyer_name || l.company || ''}`.trim(),
      startTime: `${fu.due_date}T11:00:00`,
      description: [fu.reason, l.company, last.response || last.note ? `Last: ${dmy(last.date)} ${[last.response, last.note].filter(Boolean).join(' — ')}` : '',
        m ? `Ph: ${m}` : '', m ? `WhatsApp: https://wa.me/91${m}` : ''].filter(Boolean).join('\n')
    };
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), redirect: 'follow', signal: AbortSignal.timeout(25000) });
      const t = (await r.text()).trim();
      if (!r.ok || /^<!doctype html|^<html/i.test(t)) throw new Error(`Google answered ${r.status}`);
      M.run("UPDATE follow_ups SET calendar_status = 'SENT', calendar_error = NULL WHERE id = ?", fuId);
    } catch (e) {
      M.run("UPDATE follow_ups SET calendar_status = 'FAILED', calendar_error = ? WHERE id = ?", String(e.message || e).slice(0, 200), fuId);
    }
  }
  // send what is waiting every 10 minutes (no internet, Google busy …), a minute after start
  async function sendWaiting() {
    if (!M.isOpen() || !settings().calendar_url) return;
    for (const f of M.all("SELECT id FROM follow_ups WHERE status = 'PENDING' AND calendar_status IN ('QUEUED', 'FAILED') AND due_date >= ? ORDER BY id LIMIT 20", today())) await pushCalendar(f.id);
  }
  setTimeout(() => sendWaiting().catch(() => {}), 60e3).unref();
  setInterval(() => sendWaiting().catch(() => {}), 10 * 60e3).unref();

  // ---- Today's Calls ----
  route('GET', '/api/mkt/calls', ({ q }) => {
    const day = isoDate(q.date) || today();
    const sql = `SELECT f.*, l.ref_no, l.company, l.buyer_name, l.mobile1, l.mobile2, l.city, l.state,
        (SELECT d.date || ' · ' || COALESCE(d.courier, '') FROM dispatches d WHERE d.lead_id = l.id ORDER BY d.date DESC, d.id DESC LIMIT 1) AS last_dispatch,
        (SELECT COALESCE(c.response, '') || CASE WHEN c.note IS NOT NULL THEN ' — ' || c.note ELSE '' END FROM communications c WHERE c.lead_id = l.id ORDER BY c.date DESC, c.id DESC LIMIT 1) AS last_talk
      FROM follow_ups f JOIN leads l ON l.id = f.lead_id`;
    return {
      date: day, today: today(),
      overdue: day === today() ? M.all(`${sql} WHERE f.status = 'PENDING' AND f.due_date < ? ORDER BY f.due_date, l.ref_no`, day) : [],
      due: M.all(`${sql} WHERE f.due_date = ? ORDER BY f.status = 'PENDING' DESC, l.ref_no`, day),
      upcoming: M.get("SELECT COUNT(*) n FROM follow_ups WHERE status = 'PENDING' AND due_date > ?", day).n
    };
  });

  // ---- a log entry and the next call, in one go ----
  route('POST', '/api/mkt/comm/:leadId', ({ p, body }) => {
    const leadId = Number(p.leadId);
    if (!M.get('SELECT 1 FROM leads WHERE id = ?', leadId)) throw new M.MktError('This enquiry is not there any more.');
    const date = isoDate(body.date) || today();
    const channel = ['CALL', 'WHATSAPP', 'EMAIL', 'VISIT', 'OTHER'].includes(body.channel) ? body.channel : 'CALL';
    const response = txt(body.response) ? String(body.response).trim().toUpperCase() : null, note = txt(body.note);
    const doneId = Number(body.done_follow_up_id) || null;
    const next = body.next && isoDate(body.next.date) ? { date: body.next.date, reason: txt(body.next.reason) ? String(body.next.reason).trim().toUpperCase() : null } : null;
    if (!response && !note && !doneId && !next && !body.delivered) throw new M.MktError('Choose a response, write a note or plan the next call.');
    if (next && next.date < today()) throw new M.MktError('The next call date has already passed.');
    if (doneId && !M.get("SELECT 1 FROM follow_ups WHERE id = ? AND lead_id = ?", doneId, leadId)) throw new M.MktError('That call is not there any more.');
    const s = settings();
    const out = M.tx(() => {
      let commId = null, nextId = null;
      if (response || note) commId = Number(M.run('INSERT INTO communications(lead_id, date, channel, response, note, follow_up_id) VALUES(?, ?, ?, ?, ?, ?)', leadId, date, channel, response, note, doneId).lastInsertRowid);
      if (doneId) M.run("UPDATE follow_ups SET status = 'DONE', done_on = ? WHERE id = ? AND status = 'PENDING'", date, doneId);
      if (next) nextId = Number(M.run('INSERT INTO follow_ups(lead_id, due_date, reason, calendar_status) VALUES(?, ?, ?, ?)', leadId, next.date, next.reason, s.calendar_url ? 'QUEUED' : null).lastInsertRowid);
      if (body.delivered) { const d = M.get('SELECT id FROM dispatches WHERE lead_id = ? ORDER BY date DESC, id DESC LIMIT 1', leadId); if (d) M.run('UPDATE dispatches SET delivered_on = COALESCE(delivered_on, ?) WHERE id = ?', date, d.id); }
      return { communication_id: commId, next_id: nextId };
    });
    if (out.next_id && s.calendar_url) pushCalendar(out.next_id).catch(() => {});
    return out;
  });

  // a call that is not needed any more
  route('POST', '/api/mkt/follow-ups/:id/skip', ({ p }) => { M.run("UPDATE follow_ups SET status = 'SKIPPED', done_on = ? WHERE id = ? AND status = 'PENDING'", today(), p.id); return { ok: true }; });
  route('POST', '/api/mkt/follow-ups/:id/calendar', async ({ p }) => {
    if (!settings().calendar_url) throw new M.MktError('Set the Google Calendar link first: Settings → Data Location.');
    M.run("UPDATE follow_ups SET calendar_status = 'QUEUED' WHERE id = ?", p.id); await pushCalendar(Number(p.id));
    return M.get('SELECT calendar_status, calendar_error FROM follow_ups WHERE id = ?', p.id);
  });
  // a WhatsApp message opened from the Communication screen goes into the history
  route('POST', '/api/mkt/whatsapp-log', ({ body }) => {
    const leadId = Number(body.lead_id);
    if (!M.get('SELECT 1 FROM leads WHERE id = ?', leadId)) throw new M.MktError('This enquiry is not there any more.');
    M.run("INSERT INTO communications(lead_id, date, channel, response, note) VALUES(?, ?, 'WHATSAPP', 'WHATSAPP MESSAGE SENT', ?)", leadId, today(), String(body.text || '').slice(0, 500) || null);
    return { ok: true };
  });
  route('DELETE', '/api/mkt/communications/:id', ({ p }) => { M.run('DELETE FROM communications WHERE id = ?', p.id); return { deleted: true }; });
  // QR code of a link (WhatsApp on the phone)
  route('POST', '/api/mkt/qr', ({ body }) => ({ svg: qr.svg(String(body.data || '').slice(0, 1200), Number(body.px) || 180) }));
};
