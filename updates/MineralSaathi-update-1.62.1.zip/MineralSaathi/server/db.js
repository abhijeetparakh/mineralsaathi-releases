'use strict';
// Database access. Only the server process on the main PC touches the database file,
// so several PCs can work at the same time without clashes.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const { ROOT, DATA_DIR, DB_FILE, SHARED } = require('./paths');

fs.mkdirSync(DATA_DIR, { recursive: true });

// Side files (mineral.db-journal / -wal) that Google Drive brought from ANOTHER computer which closed
// properly are old leftovers. Opening the data with them would mix two different states and damage it,
// so they are moved aside first.
if (SHARED) {
  let lk = null; try { lk = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'mineral.lock'), 'utf8')); } catch {}
  const here = require('node:os').hostname();
  if (!lk || lk.released || lk.pc !== here) {
    for (const ext of ['-journal', '-wal', '-shm']) {
      const f = DB_FILE + ext;
      if (fs.existsSync(f)) { try { fs.renameSync(f, f + '.old-' + Date.now()); console.log('  Moved aside an old side file: ' + path.basename(f)); } catch {} }
    }
  }
}

// The data file must be complete and healthy before anything is written to it.
function damaged(lines) {
  const bdir = path.join(DATA_DIR, 'backups');
  let newest = null;
  try { newest = fs.readdirSync(bdir).filter(n => /\.db$/i.test(n)).map(n => ({ n, t: fs.statSync(path.join(bdir, n)).mtimeMs })).sort((a, b) => b.t - a.t)[0]; } catch {}
  console.log('\n  ' + [...lines, '',
    'Nothing has been changed in the data.',
    ...(SHARED ? ['',
      'If the data is in Google Drive:',
      '  1. Open Google Drive on this PC, right-click the Mineral Saathi data folder,',
      '     choose "Offline access" -> "Available offline", and wait until syncing has finished.',
      '  2. Make sure Mineral Saathi is closed on the other computer ("Close for today").',
      '  3. Start Mineral Saathi again here.'] : []),
    '', 'If it still does not open, the file itself is damaged. Restore the latest backup:',
    `  copy the newest file from  ${bdir}`,
    `  over  ${DB_FILE}  (keep a copy of the damaged file first).`,
    ...(newest ? [`  Newest backup here: ${newest.n}  (${new Date(newest.t).toLocaleString('en-IN')})`] : [])
  ].join('\n  ') + '\n');
  if (require.main && /server\.js$/.test(require.main.filename || '')) {
    // ask "Where is the data?" at the restart, showing what went wrong
    require('./firstrun').askNextStart(`${lines.join('\n')}\nFolder: ${DATA_DIR}\n\n` +
      (SHARED ? 'If this is Google Drive: set the folder to "Available offline", wait until syncing has finished, and make sure Mineral Saathi is closed on the other computer. Then choose the data again below.\n' : '') +
      `If it still does not open, restore the newest backup from ${bdir} over ${DB_FILE}.`);
    console.log('  The window to choose the data opens in a few seconds.\n');
    process.exit(0);                     // Start-Server.bat restarts -> "Where is the data?" page
  }
  process.exit(3);
}
let db;
try {
  db = new DatabaseSync(DB_FILE);
  if (fs.statSync(DB_FILE).size > 0) {
    const r = db.prepare('PRAGMA quick_check').all().map(x => Object.values(x)[0]);
    if (!(r.length === 1 && r[0] === 'ok')) { try { db.close(); } catch {} damaged(['The data file mineral.db is DAMAGED or not fully downloaded yet.', 'Check result: ' + r.slice(0, 3).join(' | ')]); }
  }
} catch (e) {
  if (/malformed|not a database|corrupt|disk I\/O|file is encrypted/i.test(e.message)) { try { db && db.close(); } catch {} damaged(['The data file mineral.db cannot be read: ' + e.message, 'It is damaged or not fully downloaded yet.']); }
  throw e;
}
// In a synced folder (Google Drive) the data must always be ONE complete file,
// so every change is written straight into mineral.db (no side files).
db.exec(SHARED ? 'PRAGMA journal_mode = DELETE; PRAGMA synchronous = FULL; PRAGMA busy_timeout = 5000;'
               : 'PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---- upgrades for databases made by older versions ----
function addColumn(table, col, type) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`);
}
addColumn('invoice_items', 'bag_supply', 'TEXT');
addColumn('invoice_items', 'liner', 'INTEGER');
addColumn('inwards', 'to_party', 'TEXT');
addColumn('inwards', 'item', 'TEXT');           // item (Item name list); old vouchers take the supplier's item
addColumn('lists', 'flag', 'INTEGER DEFAULT 0');  // Item form: 1 = fuel is used to make it (Fuel tab)
addColumn('suppliers', 'ibm_no', 'TEXT');       // IBM registration no., e.g. IBM/18993/2014
addColumn('suppliers', 'item', 'TEXT');
addColumn('suppliers', 'hsn', 'TEXT');          // HSN code of the item supplied (HSN list)
addColumn('suppliers', 'gstin', 'TEXT');        // GSTIN on the rawana — finds the supplier when the rawana QR is scanned
// months saved before wage_months existed
db.exec(`INSERT OR IGNORE INTO wage_months(month, saved_at) SELECT month, datetime('now','localtime') FROM wage_entries GROUP BY month`);
addColumn('suppliers', 'lessee_name', 'TEXT');
for (const c of ['address', 'city', 'state', 'pincode', 'pan', 'email', 'mobile', 'phone']) addColumn('suppliers', c, 'TEXT');   // supplier contact (GST details fill them)  // "Name of the Lessee" on the rawana
addColumn('firms', 'logo', 'TEXT');
addColumn('firms', 'bank_branch', 'TEXT');
addColumn('firms', 'signature', 'TEXT');               // signature picture, printed on this firm's invoices and vouchers
addColumn('firms', 'bank_proof', 'TEXT');              // picture of a cancelled cheque / passbook
addColumn('transporters', 'proprietor', 'TEXT');      // declarant on the TDS declaration
addColumn('transporters', 'pan_card', 'TEXT');        // PAN card picture (cropped), attached to the TDS declaration
for (const c of ['colour', 'mesh', 'form', 'packing_type']) { addColumn('items', c, 'TEXT'); addColumn('party_items', c, 'TEXT'); }
addColumn('invoice_items', 'packing_type', 'TEXT');
addColumn('party_items', 'plant', 'TEXT');
addColumn('party_items', 'commission', 'REAL');        // commission ₹ per MT (private — never printed, emailed or in reports)
addColumn('invoice_items', 'comm_rate', 'REAL');       // commission rate when the invoice was saved
addColumn('party_items', 'agent', 'TEXT');
addColumn('parties', 'old_names', 'TEXT');
addColumn('parties', 'test_report', 'TEXT');
addColumn('parties', 'pay_days', 'INTEGER');         // Payment by: days from the invoice date (1–45)
addColumn('parties', 'pay_reminder', 'TEXT');      // Send payment reminder: YES / NO (NO = never)
addColumn('parties', 'location_url', 'TEXT');      // delivery location link (Google Maps) — QR on the back of the invoice
addColumn('party_addresses', 'location_url', 'TEXT');
addColumn('b2c_customers', 'location_url', 'TEXT');
addColumn('parties', 'print_loc', 'TEXT');           // print the delivery location QR on the invoice: YES (default) / NO
addColumn('b2c_customers', 'print_loc', 'TEXT');
addColumn('b2c_customers', 'payment_terms', 'TEXT');   // like Buyer B2B (list: Payment terms)
addColumn('b2c_customers', 'pay_days', 'INTEGER');
addColumn('b2c_customers', 'pay_reminder', 'TEXT');
addColumn('party_items', 'b2c_id', 'INTEGER');       // an item of one B2C customer (under the ONLINE SALE ledger); NULL = the buyer's own
addColumn('party_addresses', 'b2c_id', 'INTEGER');   // a delivery address of one B2C customer
addColumn('orders', 'b2c_id', 'INTEGER');            // B2C order: the customer (Buyers B2C); party = ONLINE SALE
addColumn('orders', 'calendar_status', 'TEXT');      // Google Calendar: QUEUED / SENT / FAILED
addColumn('orders', 'calendar_sent_for', 'TEXT');    // the dispatch date the calendar entries were made for
addColumn('orders', 'calendar_error', 'TEXT');
addColumn('order_items', 'bags', 'REAL');            // B2C orders: bags / packs
addColumn('invoices', 'reminder_on', 'TEXT');      // date of the last payment reminder (automatic: again every 5 days)           // test report compulsory: YES / NO
addColumn('parties', 'auto_email', 'INTEGER');         // email the invoice by itself one hour after it is made
addColumn('parties', 'auto_email_since', 'TEXT');      // only invoices made after the option was turned on
addColumn('party_items', 'lot_needed', 'TEXT');        // lot no. needed: YES / NO
addColumn('invoices', 'auto_mail_try', 'TEXT');        // last automatic email attempt
addColumn('invoices', 'auto_mail_error', 'TEXT');
addColumn('invoices', 'transporter_mail_at', 'TEXT');
addColumn('invoice_items', 'plant', 'TEXT');
addColumn('invoices', 'ewb_pdf', 'TEXT');
addColumn('invoices', 'order_id', 'INTEGER');
addColumn('invoices', 'pf_source_id', 'INTEGER');      // Parakh Marketing → Parakh Fertilizer invoice made from this PF invoice          // made from this entry of the Orders book
addColumn('transporters', 'bank_proof', 'TEXT');       // cancelled cheque / passbook picture
addColumn('transporters', 'signature', 'TEXT');        // signature picture, on the TDS declaration              // e-way bill PDF kept with the invoice (data folder)
addColumn('invoices', 'pdf_file', 'TEXT');             // the invoice PDF in the invoice folder           // dispatch plant of this line (printed small, for our own use)
addColumn('invoice_items', 'lot_no', 'TEXT');          // lot no. (compulsory when the buyer item says so)  // invoice copy emailed to the transporter
// group names already typed on buyers join the "Group of companies" list
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT DISTINCT 'group_company', upper(trim(group_name)), 100 FROM parties WHERE COALESCE(trim(group_name),'') <> ''`);             // names of this buyer on old Excel invoices (one per line)             // commission agent (list "Commission agent")
if (!db.prepare(`SELECT value FROM settings WHERE key = 'mig_comm_pay'`).get()) {
  db.exec(`INSERT INTO commission_pay(party_id, date, fy, amount, sent_to, sent_via, ref, notes, created_at)
           SELECT party_id, date, fy, amount, sent_to, sent_via, ref, notes, created_at FROM commission_payments ORDER BY id`);
  db.prepare(`INSERT INTO settings(key, value) VALUES('mig_comm_pay', '1')`).run();
}            // fixed dispatch plant for this buyer item (blank = any)
for (const c of ['ship_name', 'ship_city', 'ship_state', 'ship_state_code', 'ship_pincode']) addColumn('invoices', c, 'TEXT');
addColumn('invoices', 'delivery_id', 'INTEGER');
addColumn('invoices', 'trans_type', 'INTEGER');
addColumn('invoices', 'transporter_gstin', 'TEXT');
addColumn('invoices', 'freight_mode', 'TEXT');        // TO PAY, PAID, … (list "Freight payment mode")
addColumn('invoices', 'freight_total', 'REAL');
addColumn('email_templates', 'auto_send', 'INTEGER DEFAULT 1');
addColumn('email_templates', 'html', 'TEXT');                  // the formatted message (fonts, paragraphs …); body keeps the plain text   // sales template: 0 = never sent automatically
addColumn('parties', 'is_online', 'INTEGER DEFAULT 0');   // the ledger ONLINE SALE: B2C invoices (customer from Buyers B2C)
addColumn('invoices', 'b2c_id', 'INTEGER');               // B2C customer (Buyers B2C) of an ONLINE SALE invoice
addColumn('invoices', 'b2c_name', 'TEXT');
addColumn('invoices', 'sale_medium', 'TEXT');             // WEBSITE / SELF (list "Sale medium")
addColumn('invoices', 'send_by', 'TEXT');                 // LORRY (default) / COURIER
addColumn('invoices', 'courier', 'TEXT');
addColumn('invoices', 'docket_no', 'TEXT');
addColumn('invoices', 'tr_invoice', 'INTEGER DEFAULT 0');   // make the transporter's freight invoice to the buyer (No. = L.R. no.)
addColumn('invoices', 'tr_invoice_pdf', 'TEXT');
addColumn('invoices', 'paid', 'INTEGER DEFAULT 0');      // payment reminder: 1 = payment received
addColumn('invoices', 'paid_at', 'TEXT');
addColumn('invoices', 'reminder_at', 'TEXT');        // last payment reminder emailed       // freight rate per MT x total quantity (approx)   // transporter GSTIN / ID on the invoice and e-way bill      // e-way bill: 1 Regular, 2 Bill To-Ship To, 3 Bill From-Dispatch From, 4 Combination
// the old single "delivery address" text of a buyer becomes its first delivery address (once)
if (!db.prepare(`SELECT value FROM settings WHERE key = 'mig_ship_addr'`).get()) {
  const rows = db.prepare(`SELECT id, address, ship_address, city, state, state_code, pincode FROM parties
                           WHERE COALESCE(trim(ship_address),'') <> '' AND upper(trim(ship_address)) <> upper(trim(COALESCE(address,'')))`).all();
  const ins = db.prepare(`INSERT INTO party_addresses(party_id, godown_name, address, city, state, state_code, pincode, is_default) VALUES(?,?,?,?,?,?,?,1)`);
  for (const r of rows) {
    if (db.prepare('SELECT 1 FROM party_addresses WHERE party_id = ?').get(r.id)) continue;
    const pin = (String(r.ship_address).match(/\b(\d{6})\b/) || [])[1] || null;
    ins.run(r.id, 'DELIVERY', String(r.ship_address).trim(), pin ? null : r.city, pin ? null : r.state, pin ? null : r.state_code, pin);
  }
  db.prepare(`INSERT INTO settings(key, value) VALUES('mig_ship_addr', '1')`).run();
}
// delivery addresses with a pincode but no city/state: fill them from the pincode list
{
  const pinc = require('./pincode');
  for (const a of db.prepare(`SELECT id, pincode FROM party_addresses WHERE pincode IS NOT NULL AND (city IS NULL OR state IS NULL)`).all()) {
    const r = pinc.lookup(a.pincode); if (!r) continue;
    db.prepare('UPDATE party_addresses SET city = COALESCE(city, ?), state = COALESCE(state, ?) WHERE id = ?').run(r.city, r.state, a.id);
  }
}
// lorries with bank account + IFSC but no UPI: <account>@<IFSC>.ifsc.npci
for (const l of db.prepare(`SELECT id, bank_account, bank_ifsc FROM lorries WHERE COALESCE(upi,'') = '' AND COALESCE(bank_account,'') <> '' AND COALESCE(bank_ifsc,'') <> ''`).all()) {
  const acc = String(l.bank_account).toUpperCase().replace(/[^A-Z0-9]/g, ''), ifsc = String(l.bank_ifsc).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (acc && /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) db.prepare('UPDATE lorries SET upi = ? WHERE id = ?').run(`${acc}@${ifsc}.ifsc.npci`, l.id);
}
// old plant names from the Excel files -> plant short names (Karni Industries = KI PLANT, P.P. Industries = PPI PLANT)
for (const tbl of ['invoices', 'inwards', 'party_items']) {
  const key = `upper(replace(replace(replace(replace(COALESCE(plant,''),'.',''),' ',''),'-',''),',',''))`;
  db.exec(`UPDATE ${tbl} SET plant = 'KI PLANT' WHERE plant <> 'KI PLANT' AND (${key} LIKE 'KARNI%' OR ${key} IN ('KI','KIPLANT'))`);
  db.exec(`UPDATE ${tbl} SET plant = 'PPI PLANT' WHERE plant <> 'PPI PLANT' AND (${key} LIKE 'PPINDUSTRIES%' OR ${key} IN ('PPI','PPIPLANT'))`);
}
// freight payment mode of old invoices, read from the freight text ("3800/MT to pay", "PAID")
db.exec(`UPDATE invoices SET freight_mode = CASE WHEN freight_note LIKE '%door%' AND freight_note LIKE '%to%pay%' THEN 'TO PAY DOOR DELIVERY'
           WHEN freight_note LIKE '%door%' AND freight_note LIKE '%paid%' THEN 'PAID DOOR DELIVERY'
           WHEN freight_note LIKE '%to%pay%' OR freight_note LIKE '%topay%' THEN 'TO PAY' WHEN freight_note LIKE '%paid%' THEN 'PAID' ELSE freight_mode END
         WHERE freight_mode IS NULL AND COALESCE(freight_note,'') <> ''`);
// the two plants always exist (Item lists → Plants)
db.prepare(`INSERT OR IGNORE INTO plants(name, full_name, address) VALUES('PPI PLANT', 'P.P. Industries', 'F-106, Mandore Industrial Area RIICO, Jodhpur')`).run();
db.prepare(`INSERT OR IGNORE INTO plants(name, full_name, address) VALUES('KI PLANT', 'Karni Industries', 'F-100, Mandore Industrial Area RIICO, Jodhpur')`).run();
// GST numbers and PAN always in capitals
db.exec(`UPDATE parties SET gstin = upper(trim(gstin)) WHERE gstin <> upper(trim(gstin));
         UPDATE parties SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE transporters SET gstin = upper(trim(gstin)) WHERE gstin <> upper(trim(gstin));
         UPDATE transporters SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE firms SET gstin = upper(trim(gstin)), pan = upper(trim(pan));
         UPDATE invoices SET party_gstin = upper(trim(party_gstin)) WHERE party_gstin <> upper(trim(party_gstin));
         UPDATE lorries SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE inwards SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));`);

// starting values for the pick-lists (only for a list that is still empty)
const SEED = {
  product: ['DIATOMACEOUS EARTH', 'DIATOMACEOUS EARTH (RAW)', 'ZEOCLAY', 'BENTONITE', 'GYPSUM', 'ORGASIL', 'DEE-E', 'SUPER-SIL', 'FOUNDASIL', 'S.R.FILLER'],
  colour: ['YELLOW', 'WHITE', 'GREY', 'BROWN'],
  mesh: ['150', '200', '300', '325', '400+', '500+'],
  form: ['POWDER', 'GRANULES', 'CHIPS 2MM TO 4MM', 'LUMPS', 'RAW'],
  bag_type: ['PLAIN', 'PLAIN LAMINATED', 'PRINTED LAMINATED', '4 COLOUR LAMINATED', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'HDPE', 'JUMBO BAG'],
  hsn: [['251200', 'Diatomaceous earth / siliceous earths', 5], ['250810', 'Bentonite', 5], ['250840', 'Other clays (zeoclay)', 5], ['252010', 'Gypsum', 5], ['2512', 'Diatomaceous earth (4 digit)', 5]],
  bag_weight: [['1', '', 1], ['2', '', 2], ['5', '', 5], ['20', '', 20], ['22', '', 22], ['25', '', 25], ['30', '', 30], ['40', '', 40], ['50', '', 50], ['1000', 'Jumbo', 1000]],
  packing_type: ['SINGLE BAG', 'DOUBLE BAG', '5 KG x 6 (30 KG)', 'LOOSE / BULK'],
  unit: ['MT', 'KG', 'BAGS', 'NOS'],
  gst_rate: [['0', '', 0], ['5', '', 5], ['12', '', 12], ['18', '', 18]],
  condition: ['RAW', 'BROKEN', 'DRY', 'WET'],
  mines: ['BADIARA', 'MANDAI'],
  freight_mode: ['TO PAY', 'PAID', 'TO PAY DOOR DELIVERY', 'PAID DOOR DELIVERY'],
  payment_terms: ['100% ADVANCE', 'PAYMENT AFTER DELIVERY', '30 DAYS CREDIT'],
  group_company: [],
  sale_medium: ['WEBSITE', 'SELF'],
  raw_material: [['DIATOMACEOUS EARTH (RAW)', '251200'], ['GYPSUM', '252010']]   // what comes in on inward vouchers and Stock IN (note = HSN)
};
for (const [key, vals] of Object.entries(SEED)) {
  if (db.prepare('SELECT 1 FROM lists WHERE list_key = ? LIMIT 1').get(key)) continue;
  const ins = db.prepare('INSERT OR IGNORE INTO lists(list_key, value, note, num, sort) VALUES(?,?,?,?,?)');
  vals.forEach((v, i) => Array.isArray(v) ? ins.run(key, v[0], v[1] || null, v[2] ?? null, i) : ins.run(key, v, null, null, i));
}
// the B2C ledger ONLINE SALE of Parakh Marketing (no GSTIN; the customer comes from Buyers B2C on each invoice)
{
  const has = db.prepare(`SELECT id FROM parties WHERE is_online = 1 AND firm_code = 'PM'`).get();
  // an existing ledger "ONLINE SALE" / "ONLINE" of Parakh Marketing (with its items) becomes the B2C ledger
  const byName = has ? null : db.prepare(`SELECT id FROM parties WHERE upper(trim(name)) IN ('ONLINE SALE', 'ONLINE') AND firm_code = 'PM' AND COALESCE(gstin, '') = '' ORDER BY upper(trim(name)) = 'ONLINE SALE' DESC, id LIMIT 1`).get();
  if (byName) db.prepare(`UPDATE parties SET is_online = 1, is_b2c = 1, gstin = NULL, name = 'ONLINE SALE', active = 1 WHERE id = ?`).run(byName.id);
  else if (!has) {
    const f = db.prepare(`SELECT * FROM firms WHERE code = 'PM'`).get() || {};
    db.prepare(`INSERT INTO parties(name, firm_code, city, state, state_code, address, is_online, is_b2c, payment_terms, notes) VALUES('ONLINE SALE', 'PM', ?, ?, '08', ?, 1, 1, '100% ADVANCE', 'B2C sales ledger — add its items here; the customer is chosen from Buyers B2C on each invoice')`)
      .run(f.city || 'JODHPUR', f.state || 'RAJASTHAN', f.address || null);
  }
}
// B2C customers that were kept in Buyers (marked B2C, no GSTIN) move to Buyers B2C once; those without invoices leave Buyers B2B
if (!db.prepare(`SELECT 1 FROM settings WHERE key = 'b2c_moved'`).get()) {
  const ins = db.prepare('INSERT INTO b2c_customers(name, mobile, email, address, city, state, pincode, notes) VALUES(?,?,?,?,?,?,?,?)');
  for (const p of db.prepare(`SELECT * FROM parties WHERE is_b2c = 1 AND COALESCE(is_online, 0) = 0 AND COALESCE(gstin, '') = ''`).all()) {
    ins.run(String(p.name).trim().toUpperCase(), p.mobile || null, p.email || null, p.address || null, p.city ? String(p.city).toUpperCase() : null,
      p.state ? String(p.state).toUpperCase().replace(/^CHATTISGARH$/, 'CHHATTISGARH') : null, p.pincode || null, p.notes || null);
    if (!db.prepare('SELECT 1 FROM invoices WHERE party_id = ?').get(p.id)) db.prepare('UPDATE parties SET active = 0 WHERE id = ?').run(p.id);
  }
  db.prepare(`INSERT INTO settings(key, value) VALUES('b2c_moved', '1')`).run();
}
// every buyer in Buyers B2B without a GSTIN moves to Buyers B2C (once). Their old invoices stay as they are;
// the CASH ledger stays in B2B. A customer already in Buyers B2C with the same name is not made twice.
if (!db.prepare(`SELECT 1 FROM settings WHERE key = 'b2c_moved2'`).get()) {
  const ins = db.prepare('INSERT INTO b2c_customers(name, mobile, email, address, city, state, pincode, notes) VALUES(?,?,?,?,?,?,?,?)');
  const fix = s => s ? String(s).trim().toUpperCase().replace(/^CHATTISGARH$/, 'CHHATTISGARH') : null;
  for (const p of db.prepare(`SELECT * FROM parties WHERE COALESCE(trim(gstin), '') = '' AND COALESCE(is_online, 0) = 0 AND COALESCE(active, 1) = 1 AND upper(trim(name)) NOT IN ('CASH', 'ONLINE', 'ONLINE SALE')`).all()) {
    const name = String(p.name).trim().toUpperCase();
    const ex = db.prepare('SELECT * FROM b2c_customers WHERE upper(trim(name)) = ? AND active = 1').get(name);
    if (ex) db.prepare(`UPDATE b2c_customers SET mobile = COALESCE(mobile, ?), email = COALESCE(email, ?), address = COALESCE(address, ?), city = COALESCE(city, ?), state = COALESCE(state, ?), pincode = COALESCE(pincode, ?) WHERE id = ?`)
      .run(p.mobile || null, p.email || null, p.address || null, fix(p.city), fix(p.state), p.pincode || null, ex.id);
    else ins.run(name, p.mobile || null, p.email || null, p.address || null, fix(p.city), fix(p.state), p.pincode || null, p.notes || null);
    db.prepare('UPDATE parties SET active = 0, is_b2c = 1 WHERE id = ?').run(p.id);
  }
  db.prepare(`INSERT INTO settings(key, value) VALUES('b2c_moved2', '1')`).run();
}
// liner and who gives the bags have their own boxes now, so they leave the packing-type list
db.exec(`UPDATE lists SET active = 0 WHERE list_key = 'packing_type' AND value IN ('WITH LINER', 'WITHOUT LINER', 'BUYER''S OWN BAGS')`);
for (const v of ['SINGLE BAG', 'DOUBLE BAG']) db.prepare(`INSERT OR IGNORE INTO lists(list_key, value, sort) VALUES('packing_type', ?, 0)`).run(v);
// bag types already used in the data join the list
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'bag_type', upper(trim(bag_type)), 100 FROM items WHERE COALESCE(bag_type,'') <> ''`);
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'product', upper(trim(name)), 100 FROM items WHERE COALESCE(name,'') <> ''`);
// P.P. Enterprise vouchers: goods go FROM P.P. Enterprise TO Parakh Marketing
db.exec(`UPDATE inwards SET supplier = 'P.P.ENTERPRISE', to_party = 'PARAKH MARKETING'
         WHERE voucher_no LIKE 'PPE-V%' AND (to_party IS NULL OR supplier IS NOT 'P.P.ENTERPRISE')`);
// buyers without a usual transporter get the one from their latest invoice
db.exec(`UPDATE parties SET transporter = (SELECT i.transporter FROM invoices i WHERE i.party_id = parties.id AND COALESCE(i.transporter,'') <> ''
           ORDER BY i.date DESC, i.id DESC LIMIT 1) WHERE COALESCE(transporter,'') = ''`);
// e-mail addresses are always kept in small letters
db.exec(`UPDATE parties SET email = lower(email) WHERE email <> lower(email);
         UPDATE firms SET email = lower(email), smtp_user = lower(smtp_user) WHERE email <> lower(email) OR smtp_user <> lower(smtp_user);
         UPDATE transporters SET email = lower(email) WHERE email <> lower(email);`);

const fix = p => p.map(v => v === undefined ? null : (typeof v === 'boolean' ? (v ? 1 : 0) : v));
// Proforma invoices keep the same columns as invoices / invoice_items (made here, so new invoice columns follow by themselves)
for (const [src, dst] of [['invoices', 'proformas'], ['invoice_items', 'proforma_items']]) {
  const cols = db.prepare(`PRAGMA table_info(${src})`).all().filter(c => c.name !== 'id');
  db.exec(`CREATE TABLE IF NOT EXISTS ${dst} (id INTEGER PRIMARY KEY${dst === 'proformas' ? ", created_at_pi TEXT DEFAULT (datetime('now','localtime'))" : ''})`);
  const have = db.prepare(`PRAGMA table_info(${dst})`).all().map(c => c.name);
  for (const c of cols) if (!have.includes(c.name)) db.exec(`ALTER TABLE ${dst} ADD COLUMN ${c.name} ${c.type || ''}`);
}
addColumn('proformas', 'email_sent_at', 'TEXT');

const all = (sql, ...p) => db.prepare(sql).all(...fix(p)).map(r => ({ ...r }));
const get = (sql, ...p) => { const r = db.prepare(sql).get(...fix(p)); return r ? { ...r } : null; };
const run = (sql, ...p) => db.prepare(sql).run(...fix(p));

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}

const colCache = {};
function columns(table) {
  if (!colCache[table]) colCache[table] = all(`PRAGMA table_info(${table})`).map(c => c.name);
  return colCache[table];
}

function setting(key, fallback = null) {
  const r = get('SELECT value FROM settings WHERE key = ?', key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value == null ? null : String(value));
}

module.exports = { db, all, get, run, tx, columns, setting, setSetting, DB_FILE, DATA_DIR, ROOT, SHARED };
