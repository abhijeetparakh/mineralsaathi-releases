'use strict';
// Reports → IBM Return: Parakh Marketing only (like the IBM Excel sheet).
// Input  = P.P. Enterprise bills to Parakh Marketing (qty, amount before GST) + Stock IN (Parakh Marketing's own purchases:
//          supplier, qty, rate, amount). Each supplier shows with its IBM no. (Master → Suppliers).
// Output = Parakh Marketing sales invoices (qty, amount before GST).
// Opening balance as on 1 April 2026 (setting); every month: opening + input − output = closing, carried on to the next month.
const { all, setting, setSetting } = require('./db');
class E extends Error { constructor(m) { super(m); this.status = 400; } }
const r3 = n => Math.round((Number(n) || 0) * 1000) / 1000, r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const up = s => String(s || '').trim().toUpperCase();

function inputs(from, to) {
  const w = 'COALESCE(rawana_wt, actual_wt, 0)';          // input is always on the rawana weight
  // only HSN 251200 (diatomaceous / siliceous earth): P.P. Enterprise bill lines of that HSN
  const ppe = all(`SELECT i.date, it.hsn, it.qty, it.amount FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id
    WHERE i.kind = 'PPE_BILL' AND COALESCE(i.cancelled, 0) = 0 AND i.date >= ? AND i.date < ?`, from, to)
    .filter(r => isHsn(r.hsn)).map(r => ({ date: r.date, supplier: 'P.P.ENTERPRISE', qty: Number(r.qty) || 0, amount: Number(r.amount) || 0 }));
  // Stock IN: the supplier's HSN (Master → Suppliers) is 251200, or — HSN not set — the raw material is diatomaceous / siliceous earth
  const sup = new Map(all('SELECT name, hsn FROM suppliers').map(x => [up(x.name), x.hsn]));
  const st = all(`SELECT date, supplier, item, ${w} AS qty, amount FROM stock_in WHERE date >= ? AND date < ?`, from, to)
    .filter(r => { const h = sup.get(up(r.supplier)); return h ? isHsn(h) : /DIATOM|SILICEOUS/i.test(r.item || ''); })
    .map(r => ({ date: r.date, supplier: up(r.supplier) || '—', qty: Number(r.qty) || 0, amount: Number(r.amount) || 0 }));
  return [...ppe, ...st];
}
// HSN 251200 (2512 = 251200): the IBM return is only for this mineral
const isHsn = h => { let x = String(h || '').replace(/\D/g, ''); if (x.length === 4) x += '00'; return x.slice(0, 6) === '251200'; };
// Parakh Marketing sales: only the invoice lines of HSN 251200 (qty and amount before GST of those lines)
function sales(from, to) {
  const rows = all(`SELECT i.id, i.date, i.party_id, COALESCE(i.b2c_name, i.party_name) AS name, i.party_gstin, i.b2c_id, it.hsn, it.qty, it.amount
    FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id
    WHERE i.firm_code = 'PM' AND COALESCE(i.kind, 'SALE') = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND i.date >= ? AND i.date < ?`, from, to).filter(r => isHsn(r.hsn));
  const by = new Map();
  for (const r of rows) { const x = by.get(r.id) || { ...r, qty: 0, taxable: 0 }; x.qty += Number(r.qty) || 0; x.taxable += Number(r.amount) || 0; by.set(r.id, x); }
  return [...by.values()];
}
const monthsOf = fy => { const a = Number(fy.slice(0, 4)); return [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3].map(m => `${m >= 4 ? a : a + 1}-${String(m).padStart(2, '0')}`); };
const nextYm = ym => { const y = Number(ym.slice(0, 4)), m = Number(ym.slice(5)); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; };
const fyOf = iso => { const y = Number(iso.slice(0, 4)), m = Number(iso.slice(5, 7)); const a = m >= 4 ? y : y - 1; return `${a}-${String(a + 1).slice(2)}`; };

module.exports = function register(route) {
  route('GET', '/api/ibm', ({ q }) => {
    const openDate = setting('ibm_opening_date', '2026-04-01'), opening0 = Number(setting('ibm_opening', '1025.990')) || 0;
    const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10);
    const firstFy = fyOf(openDate), fy = /^\d{4}-\d{2}$/.test(q.fy || '') && q.fy >= firstFy ? q.fy : fyOf(today) < firstFy ? firstFy : fyOf(today);
    const months = monthsOf(fy), yStart = months[0] + '-01', yEnd = nextYm(months[11]) + '-01';
    // opening of the year = opening balance + input − output from the opening date to the start of this year
    const before = yStart > openDate ? r3(inputs(openDate, yStart).reduce((s, r) => s + r.qty, 0) - sales(openDate, yStart).reduce((s, r) => s + (Number(r.qty) || 0), 0)) : 0;
    let open = r3(opening0 + before);
    const ins = inputs(yStart, yEnd), outs = sales(yStart, yEnd);
    // suppliers (columns of the input table), P.P. ENTERPRISE last like the sheet
    const sup = new Map(all('SELECT name, ibm_no, gstin FROM suppliers').map(s => [up(s.name), s]));
    const names = [...new Set(ins.map(r => r.supplier))].sort((a, b) => (a === 'P.P.ENTERPRISE') - (b === 'P.P.ENTERPRISE') || a.localeCompare(b));
    const suppliers = names.map(n => ({ name: n, ibm_no: (sup.get(n) || sup.get(n.replace(/\./g, '').replace(/\s+/g, ' ')) || {}).ibm_no || '', gstin: (sup.get(n) || {}).gstin || '' }));
    const rows = months.map(ym => {
      const i = ins.filter(r => r.date.slice(0, 7) === ym), o = outs.filter(r => r.date.slice(0, 7) === ym);
      const by_sup = Object.fromEntries(names.map(n => { const x = i.filter(r => r.supplier === n), qty = r3(x.reduce((s, r) => s + r.qty, 0)), amount = r2(x.reduce((s, r) => s + r.amount, 0));
        return [n, { qty, amount, rate: qty ? r2(amount / qty) : null }]; }));
      const input = r3(i.reduce((s, r) => s + r.qty, 0)), output = r3(o.reduce((s, r) => s + (Number(r.qty) || 0), 0));
      const future = ym > today.slice(0, 7), notYet = (ym + '-01') < openDate;
      const row = { month: ym, opening: notYet ? null : open, input, input_amount: r2(i.reduce((s, r) => s + r.amount, 0)), output, output_amount: r2(o.reduce((s, r) => s + (Number(r.taxable) || 0), 0)),
        closing: notYet ? null : r3(open + input - output), by_sup, future };
      if (!notYet) open = row.closing;
      return row;
    });
    // buyer-wise details of one month
    const month = /^\d{4}-\d{2}$/.test(q.month || '') && months.includes(q.month) ? q.month : (months.includes(today.slice(0, 7)) ? today.slice(0, 7) : months[0]);
    const parties = new Map(all('SELECT id, name, gstin FROM parties').map(p => [p.id, p]));
    const buyers = new Map();
    for (const s of outs.filter(r => r.date.slice(0, 7) === month)) {
      const p = s.party_id ? parties.get(s.party_id) : null;
      const gst = s.b2c_id ? '' : up(s.party_gstin || (p && p.gstin));
      const name = s.b2c_id ? s.name : (p && p.name) || s.name;
      const k = gst || 'N' + up(name);
      const x = buyers.get(k) || { name, gstin: gst, invoices: 0, qty: 0, amount: 0 }; x.invoices++; x.qty += Number(s.qty) || 0; x.amount += Number(s.taxable) || 0; buyers.set(k, x);
    }
    const bl = [...buyers.values()].map(x => ({ ...x, qty: r3(x.qty), amount: r2(x.amount) })).sort((a, b) => a.name.localeCompare(b.name));
    return { fy, fys: (() => { const out = []; let f = firstFy; while (f <= fyOf(today)) { out.push(f); const a = Number(f.slice(0, 4)) + 1; f = `${a}-${String(a + 1).slice(2)}`; } return out; })(),
      opening_date: openDate, opening_balance: opening0, suppliers, rows, month, buyers: bl,
      buyers_qty: r3(bl.reduce((s, b) => s + b.qty, 0)), buyers_amount: r2(bl.reduce((s, b) => s + b.amount, 0)) };
  });
  route('PUT', '/api/ibm/settings', ({ body }) => {
    if (body.opening !== undefined) { const n = Number(body.opening); if (!(n >= 0)) throw new E('Enter the opening balance in MT.'); setSetting('ibm_opening', String(r3(n))); }
    return { ok: true };
  });
};
