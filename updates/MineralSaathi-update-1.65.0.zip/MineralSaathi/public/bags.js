'use strict';
/* Factory → Bags: stock of empty bags (PM + PF together). Tabs: Stock · Entries · Bag types · Used by invoices. */
TITLES.bags = 'Bags';
const BAG_KINDS = [['PURCHASE', 'Purchase of bags'], ['BUYER', 'Bags received from a buyer'], ['ADJUST', 'Adjustment (damaged / count)'], ['OPENING', '🔒 Opening stock']];
const BAG_TYPE_KINDS = [['OUTER', 'Bag'], ['INNER', '5 kg inner bag'], ['COMBO', 'Combo (1 outer + 4 / 6 inner)'], ['LINER', 'Liner']];
PAGES.bags = async (el, tab) => {
  tab = tab || 'stock';
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px">${[['stock', 'Stock'], ['entries', 'Bag entries'], ['types', 'Bag types'], ['used', 'Used by invoices']].map(([k, t]) =>
    `<button class="${tab === k ? 'on' : ''}" onclick="go('#/bags/${k}')">${t}</button>`).join('')}</div><div id="bgb"></div>`;
  const box = $('#bgb', el);
  if (tab === 'entries') return bagEntries(box);
  if (tab === 'types') return bagTypes(box);
  if (tab === 'used') return bagUsed(box);
  return bagStock(box);
};
const bagN = n => (Math.round((Number(n) || 0) * 1000) / 1000).toLocaleString('en-IN');

async function bagStock(box) {
  const [d, s] = await Promise.all([GET('/api/bags/stock'), GET('/api/bags/settings')]);
  const own = d.list.filter(x => !x.owner && x.kind !== 'LINER'), buyers = d.list.filter(x => x.owner), liner = d.list.filter(x => x.kind === 'LINER');
  const value = d.list.reduce((t, x) => t + (x.value || 0), 0), low = d.list.filter(x => x.low);
  const rowsHtml = list => list.map(x => `<tr${x.low ? ' style="background:#fff4e5"' : ''}><td><b>${esc(x.name)}</b>${x.kind === 'INNER' ? ' <span class="badge slate">5 kg inner</span>' : ''}${x.owner ? `<br><span class="hint">${esc(x.owner)}'s bags</span>` : ''}</td>
    <td class="num">${bagN(x.opening) || ''}</td><td class="num">${x.purchased ? bagN(x.purchased) : ''}</td><td class="num">${x.from_buyers ? bagN(x.from_buyers) : ''}</td><td class="num">${x.adjust ? bagN(x.adjust) : ''}</td>
    <td class="num">${x.used ? bagN(x.used) : ''}</td><td class="num">${x.wastage ? bagN(x.wastage) : ''}</td>
    <td class="num"><b style="color:${x.in_hand < 0 ? 'var(--bad)' : 'inherit'}">${bagN(x.in_hand)}</b>${x.low ? ' <span class="badge amber">⚠ low</span>' : ''}</td>
    <td class="num">${x.avg_cost != null ? money(x.avg_cost) : ''}</td><td class="num">${x.value != null ? rs(x.value) : ''}</td></tr>`).join('');
  const head = `<thead><tr><th>Bag type</th><th class="num">Opening</th><th class="num">Purchased</th><th class="num">From buyers</th><th class="num">Adjust</th><th class="num">Used</th><th class="num">Wastage</th><th class="num">In hand</th><th class="num">Avg cost / bag</th><th class="num">Value</th></tr></thead>`;
  box.innerHTML = `<div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
      <div class="stat"><div class="k">Bags in hand (ours)</div><div class="v">${bagN(own.reduce((t, x) => t + Math.max(0, x.in_hand), 0))}</div><div class="hint">${own.length} bag types</div></div>
      <div class="stat"><div class="k">Value of our bags</div><div class="v">${rs(value)}</div><div class="hint">at the average purchase cost</div></div>
      <div class="stat"><div class="k">Low stock</div><div class="v" style="color:${low.length ? 'var(--amber)' : 'inherit'}">${low.length}</div><div class="hint">${low.map(x => esc(x.name)).slice(0, 3).join(', ') || 'below the minimum you set'}</div></div>
      <div class="stat"><div class="k">Counting from</div><div class="v" style="font-size:20px">${dmy(d.start)}</div><div class="hint">PM + PF invoices use bags by themselves</div></div></div>
    ${d.no_type ? `<div class="firmbox" style="margin:10px 0">⚠ ${d.no_type} invoice line(s) (${bagN(d.no_type_bags)} bags) have no bag type, so they are not counted. See “Used by invoices”.</div>` : ''}
    <div class="card"><div class="toolbar"><h3 style="margin:0">Our bags</h3><span class="spacer"></span><button onclick="go('#/bags/entries')">+ Bag entry</button><button class="sec" id="bgx">Export</button></div>
      <div class="tablewrap"><table class="t">${head}<tbody>${rowsHtml(own) || '<tr><td colspan="10" class="muted">No bags yet — fill in the opening stock and the purchases (Bag entries).</td></tr>'}</tbody></table></div></div>
    ${liner.length ? `<div class="card"><h3>Liners</h3><table class="t">${head}<tbody>${rowsHtml(liner)}</tbody></table></div>` : ''}
    <div class="card"><h3>Buyers' own bags <span class="hint">— used only for that buyer's orders</span></h3><table class="t">${head}<tbody>${rowsHtml(buyers) || '<tr><td colspan="10" class="muted">None. Mark a bag type as a buyer\'s own in Bag types.</td></tr>'}</tbody></table></div>
    <div class="card" style="max-width:640px"><h3>Wastage</h3><div class="row" style="gap:10px;align-items:end"><label style="width:160px">Wastage % of bags used<input id="bgw" type="number" step="0.1" min="0" max="20" value="${s.wastage_pct}"></label><button id="bgws" class="sec">Save</button></div>
      <p class="hint">Bags torn while filling are taken off by this %. Count corrections and damaged bags go in Bag entries → Adjustment.</p></div>`;
  $('#bgws', box).onclick = async () => { await guard(() => PUT('/api/bags/settings', { wastage_pct: $('#bgw', box).value })); toast('Wastage saved'); bagStock(box); };
  $('#bgx', box).onclick = () => downloadCsv('bag_stock.csv', d.list.map(x => ({ bag_type: x.name, owner: x.owner, opening: x.opening, purchased: x.purchased, from_buyers: x.from_buyers, adjust: x.adjust, used: x.used, wastage: x.wastage, in_hand: x.in_hand, avg_cost: x.avg_cost, value: x.value })));
}

async function bagEntries(box, editId) {
  const [moves, T, sups] = await Promise.all([GET('/api/bags/moves'), GET('/api/bags/types'), GET('/api/m/suppliers').catch(() => [])]);
  // bag suppliers (Master → Suppliers) first
  const supNames = [...new Set(sups.slice().sort((a, b) => (/BAG/i.test(JSON.stringify(b)) - /BAG/i.test(JSON.stringify(a))) || String(a.name).localeCompare(String(b.name))).map(x => x.name).filter(Boolean))];
  const cur = editId ? moves.find(m => String(m.id) === String(editId)) : null;
  const typeNames = T.types.filter(t => !t.same_as && t.kind !== 'COMBO').map(t => t.name);
  const v = cur || { date: today(), kind: 'PURCHASE', rate_per: 'BAG' };
  box.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.6fr);align-items:start">
    <form id="bgf" class="card" autocomplete="off"><h3>${cur ? 'Change bag entry' : 'New bag entry'}</h3>
      <div class="grid g2">
        <label class="span2">Entry<select name="kind">${BAG_KINDS.map(([k, t]) => `<option value="${k}" ${v.kind === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label>Date<input name="date" type="date" value="${esc(v.date)}"></label>
        <label>Bag type<input name="bag_type" list="dl-bgt" value="${esc(cur ? cur.name : '')}" placeholder="Type or choose"><datalist id="dl-bgt">${typeNames.map(n => `<option value="${esc(n)}">`).join('')}</datalist></label>
        <label class="k-pur">Supplier <span class="hint">(Master → Suppliers)</span><input name="supplier" list="dl-bgs" value="${esc(v.supplier || '')}" placeholder="Choose the bag supplier"><datalist id="dl-bgs">${supNames.map(n => `<option value="${esc(n)}">`).join('')}</datalist></label>
        <label class="k-pur">Bill no.<input name="bill_no" value="${esc(v.bill_no || '')}"></label>
        <label class="span2 k-buy">Buyer who sent the bags<select name="party_id"><option value="">— choose —</option>${T.parties.map(p => `<option value="${p.id}" ${Number(v.party_id) === p.id ? 'selected' : ''}>${esc(p.name)}${p.city ? ' — ' + esc(p.city) : ''}</option>`).join('')}</select></label>
        <label>No. of bags <span class="hint k-adj">(− to take off)</span><input name="bags" type="number" step="1" value="${v.bags ?? ''}"></label>
        <label>Weight (kg) <span class="hint">— if the bill is by weight</span><input name="weight_kg" type="number" step="0.001" value="${v.weight_kg ?? ''}"></label>
        <label class="k-rate">Rate (₹)<input name="rate" type="number" step="0.01" value="${v.rate ?? ''}"></label>
        <label class="k-rate">Rate is<select name="rate_per"><option value="BAG" ${v.rate_per !== 'KG' ? 'selected' : ''}>per bag</option><option value="KG" ${v.rate_per === 'KG' ? 'selected' : ''}>per kg</option></select></label>
        <label class="span2">Note<input name="note" value="${esc(v.note || '')}"></label></div>
      <p class="hint" id="bgcalc" style="margin:8px 0 0"></p>
      <div class="row" style="margin-top:10px"><button type="submit">${cur ? 'Save changes' : 'Add entry'}</button>${cur ? '<button type="button" class="sec" id="bgcancel">Cancel</button>' : ''}</div>
      <p class="hint">Only the weight on the bill? Leave the number of bags empty — it is worked out from the empty weight of one bag (Bag types). Both given: the empty weight is learnt from them. The opening stock needs the edit password.</p></form>
    <div class="card"><div class="toolbar"><h3 style="margin:0">Bag entries</h3><span class="spacer"></span><button class="sec" id="bgex">Export</button></div>
      <div class="tablewrap" style="max-height:70vh"><table class="t"><thead><tr><th>Date</th><th>Entry</th><th>Bag type</th><th class="num">Bags</th><th class="num">Kg</th><th class="num">Cost / bag</th><th class="num">Amount</th><th>From</th><th></th></tr></thead><tbody>
      ${moves.map(m => `<tr><td>${dmy(m.date)}</td><td>${m.kind === 'OPENING' ? '🔒 Opening' : m.kind === 'PURCHASE' ? 'Purchase' : m.kind === 'BUYER' ? 'From buyer' : 'Adjustment'}</td><td><b>${esc(m.name)}</b></td>
        <td class="num">${bagN(m.bags)}</td><td class="num">${m.weight_kg ? bagN(m.weight_kg) : ''}</td><td class="num">${m.amount ? money(m.amount / m.bags) : ''}</td><td class="num">${m.amount ? rs(m.amount) : ''}</td>
        <td class="hint">${esc(m.party_name || m.supplier || '')}${m.bill_no ? ' · bill ' + esc(m.bill_no) : ''}${m.note ? ' · ' + esc(m.note) : ''}</td>
        <td style="white-space:nowrap"><button class="small sec" data-bge="${m.id}">Edit</button> <button class="small sec" data-bgd="${m.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="9" class="muted">No entries yet.</td></tr>'}</tbody></table></div></div></div>`;
  const f = $('#bgf', box);
  const show = () => { const k = f.kind.value;
    $$('.k-pur', f).forEach(x => x.hidden = k !== 'PURCHASE'); $$('.k-buy', f).forEach(x => x.hidden = k !== 'BUYER'); $$('.k-rate', f).forEach(x => x.hidden = k === 'BUYER' || k === 'ADJUST'); $$('.k-adj', f).forEach(x => x.hidden = k !== 'ADJUST');
    const t = T.types.find(x => x.name === f.bag_type.value.trim().toUpperCase() || x.names.includes(f.bag_type.value.trim()));
    const bags = Number(f.bags.value) || (Number(f.weight_kg.value) && t && t.empty_g ? Math.round(f.weight_kg.value * 1000 / t.empty_g) : 0), rate = Number(f.rate.value), w = Number(f.weight_kg.value);
    const amt = rate ? (f.rate_per.value === 'KG' ? rate * w : rate * bags) : 0;
    $('#bgcalc', box).innerHTML = [t && t.empty_g ? `Empty weight ${t.empty_g} g a bag.` : t ? 'Empty weight of this bag type not set yet.' : '',
      bags ? `<b>${bagN(bags)} bags</b>${!f.bags.value && w ? ' (from the weight)' : ''}` : '', amt && bags ? `amount ${rs(amt)} · <b>${money(amt / bags)} a bag</b>` : ''].filter(Boolean).join(' · '); };
  f.oninput = show; f.kind.onchange = show; show();
  f.onsubmit = async e => { e.preventDefault(); const d = formData(f);
    if (d.kind === 'OPENING' || (cur && cur.kind === 'OPENING')) { const pw = await askEditPassword('change the opening stock of bags'); if (!pw) return; d.edit_password = pw; }
    const r = await guard(() => cur ? PUT('/api/bags/moves/' + cur.id, d) : POST('/api/bags/moves', d));
    toast(`Saved · ${bagN(r.bags)} bags${r.cost_per_bag ? ' · ' + money(r.cost_per_bag) + ' a bag' : ''}`); bagEntries(box); };
  const c = $('#bgcancel', box); if (c) c.onclick = () => bagEntries(box);
  $('#bgex', box).onclick = () => downloadCsv('bag_entries.csv', moves.map(m => ({ date: m.date, entry: m.kind, bag_type: m.name, bags: m.bags, weight_kg: m.weight_kg, rate: m.rate, rate_per: m.rate_per, amount: m.amount, supplier: m.supplier, buyer: m.party_name, bill_no: m.bill_no, note: m.note })));
  box.onclick = async e => {
    const ed = e.target.closest('[data-bge]'), dl = e.target.closest('[data-bgd]');
    if (ed) bagEntries(box, ed.dataset.bge);
    if (dl) { const m = moves.find(x => String(x.id) === dl.dataset.bgd); let q = '';
      if (m.kind === 'OPENING') { const pw = await askEditPassword('delete an opening stock entry'); if (!pw) return; q = '?pw=' + encodeURIComponent(pw); }
      else if (!confirm('Delete this bag entry?')) return;
      await guard(() => DEL('/api/bags/moves/' + m.id + q)); toast('Entry deleted'); bagEntries(box); }
  };
}

async function bagTypes(box, editKey) {
  const T = await GET('/api/bags/types');
  const roots = T.types.filter(t => !t.same_as);
  const cur = T.types.find(t => t.nkey === editKey);
  const opt = (sel, filt = () => true) => '<option value=""></option>' + roots.filter(filt).map(t => `<option value="${esc(t.nkey)}" ${sel === t.nkey ? 'selected' : ''}>${esc(t.name)}</option>`).join('');
  const nameOf = k => (T.types.find(t => t.nkey === k) || {}).name || k;
  box.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);align-items:start">
    <div class="card"><h3>Bag types <span class="hint">${T.types.length} names · from Item List, buyers' items and invoices</span></h3>
      <div class="tablewrap" style="max-height:72vh"><table class="t"><thead><tr><th>Bag type</th><th>Kind</th><th class="num">Empty weight</th><th class="num">Min. stock</th><th></th></tr></thead><tbody>
      ${T.types.map(t => `<tr class="click" data-bt="${esc(t.nkey)}" style="${t.nkey === editKey ? 'background:#e6f3f7' : ''}"><td><b>${esc(t.name)}</b>${t.names.length > 1 ? `<br><span class="hint">also written: ${esc(t.names.filter(n => n.toUpperCase() !== t.name).join(' · '))}</span>` : ''}
        ${t.owner ? `<br><span class="hint">${esc(t.owner)}'s own bags</span>` : ''}</td>
        <td>${t.same_as ? `<span class="badge grey">same as ${esc(nameOf(t.same_as))}</span>` : t.kind === 'COMBO' ? `<span class="badge slate">1 ${esc(nameOf(t.combo_outer))} + ${t.combo_count} × ${esc(nameOf(t.combo_inner))}</span>`
          : (BAG_TYPE_KINDS.find(k => k[0] === t.kind) || [, 'Bag'])[1]}${t.has_liner ? ' <span class="badge grey">with liner</span>' : ''}</td>
        <td class="num">${t.empty_g ? t.empty_g + ' g' : '<span class="hint">—</span>'}</td><td class="num">${t.min_stock ?? ''}</td><td><button class="small sec">Edit</button></td></tr>`).join('')}</tbody></table></div></div>
    <form id="btf" class="card" autocomplete="off">${cur ? `<h3>${esc(cur.name)}</h3>
      <div class="grid g2">
        <label class="span2">Name<input name="name" value="${esc(cur.name)}"></label>
        <label class="span2">Same as <span class="hint">— another name of the same bag</span><select name="same_as">${opt(cur.same_as, t => t.nkey !== cur.nkey)}</select></label>
        <label>Kind<select name="kind">${BAG_TYPE_KINDS.map(([k, n]) => `<option value="${k}" ${cur.kind === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label>Empty weight of one bag (g)<input name="empty_g" type="number" step="0.1" value="${cur.empty_g ?? ''}"></label>
        <label class="cmb">Outer bag<select name="combo_outer">${opt(cur.combo_outer, t => t.kind === 'OUTER')}</select></label>
        <label class="cmb">Inner bag<select name="combo_inner">${opt(cur.combo_inner, t => t.kind === 'INNER')}</select></label>
        <label class="cmb">Inner bags in one<select name="combo_count">${[2, 3, 4, 5, 6, 8, 10].map(n => `<option ${Number(cur.combo_count) === n ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label>Minimum stock<input name="min_stock" type="number" step="1" value="${cur.min_stock ?? ''}"></label>
        <label class="span2">Buyer's own bags <span class="hint">— only for this buyer</span><select name="owner_party_id"><option value="">No — our bags</option>${T.parties.map(p => `<option value="${p.id}" ${Number(cur.owner_party_id) === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>
        <label class="span2" style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="has_liner" style="width:auto" ${cur.has_liner ? 'checked' : ''}> This bag has a liner in it (uses one liner a bag)</label></div>
      <div class="row" style="margin-top:10px"><button type="submit">Save</button></div>
      <p class="hint">A combo (e.g. PLAIN 5KG X6) is not kept in stock: each combo bag on an invoice uses 1 outer bag + its inner bags. Set the inner 5 kg bag first (Kind = 5 kg inner bag).</p>`
      : '<h3>Bag type</h3><p class="hint">Click a bag type to set its empty weight, kind (bag / 5 kg inner / combo / liner), minimum stock, whose bags they are, or to join two names of the same bag.</p>'}</form></div>`;
  box.onclick = e => { const r = e.target.closest('[data-bt]'); if (r) bagTypes(box, r.dataset.bt); };
  const f = $('#btf', box);
  if (cur) {
    const show = () => $$('.cmb', f).forEach(x => x.hidden = f.kind.value !== 'COMBO'); f.kind.onchange = show; show();
    f.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/bags/types/' + encodeURIComponent(cur.nkey), formData(f))); toast('Bag type saved'); bagTypes(box, cur.nkey); };
  }
}

async function bagUsed(box) {
  const st = S.bgu = S.bgu || { from: '', to: '' };
  const rows = await GET(`/api/bags/usage?from=${st.from}&to=${st.to}`);
  const by = new Map(); rows.forEach(r => by.set(r.name, (by.get(r.name) || 0) + r.bags));
  box.innerHTML = `<div class="card"><div class="toolbar"><h3 style="margin:0">Bags used by invoices</h3>
      <label>From<input type="date" id="bgf1" value="${esc(st.from)}"></label><label>To<input type="date" id="bgf2" value="${esc(st.to)}"></label><span class="spacer"></span><button class="sec" id="bgux">Export</button></div>
      <div class="row" style="gap:8px;flex-wrap:wrap;margin:8px 0">${[...by.entries()].sort((a, b) => b[1] - a[1]).map(([n, b]) => `<span class="badge ${n === '(no bag type)' ? 'amber' : 'slate'}">${esc(n)}: ${bagN(b)}</span>`).join('') || '<span class="muted">No invoices yet.</span>'}</div>
      <div class="tablewrap" style="max-height:66vh"><table class="t"><thead><tr><th>Date</th><th>Invoice</th><th>Buyer</th><th>Item</th><th>Bag type</th><th class="num">Bags</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" onclick="openInvoice(${r.invoice_id}, 'SALE')"><td>${dmy(r.date)}</td><td>${esc(r.inv)}</td><td>${esc(r.party)}</td><td class="hint">${esc(r.item)}</td>
        <td>${esc(r.name)}${r.part ? ` <span class="hint">(${r.part})</span>` : ''}</td><td class="num">${bagN(r.bags)}</td></tr>`).join('')}</tbody></table></div>
      <p class="hint">Parakh Marketing and Parakh Fertilizer sales invoices from the start date. A combo uses its outer and inner bags; WITH LINER uses a liner a bag.</p></div>`;
  $('#bgf1', box).onchange = e => { st.from = e.target.value; bagUsed(box); }; $('#bgf2', box).onchange = e => { st.to = e.target.value; bagUsed(box); };
  $('#bgux', box).onclick = () => downloadCsv('bags_used.csv', rows);
}
