'use strict';
// WhatsApp (Meta WhatsApp Cloud API) — a simple chat window and template messages for invoices, sample dispatches and payment reminders.
// Sending goes straight to Meta from this PC. Meta sends incoming messages to the callback of WMessage Saathi (cloud); for this
// number WMessage Saathi keeps them ("Linked app") and this app fetches them every few seconds with the linked-app key.
// The access token and the linked-app key are never sent to the screen.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { all, get, run, setting, setSetting } = require('./db');
const { DATA_DIR } = require('./paths');

run(`CREATE TABLE IF NOT EXISTS wa_chats (phone TEXT PRIMARY KEY, name TEXT, last_at INTEGER, last_in_at INTEGER, unread INTEGER DEFAULT 0, last_text TEXT)`);
run(`CREATE TABLE IF NOT EXISTS wa_msgs (id INTEGER PRIMARY KEY, wamid TEXT, phone TEXT NOT NULL, dir TEXT, type TEXT, text TEXT, media_id TEXT, file TEXT, mime TEXT, filename TEXT,
  status TEXT, error TEXT, at INTEGER, template TEXT, ref TEXT)`);
run('CREATE INDEX IF NOT EXISTS ix_wa_msgs_phone ON wa_msgs(phone, at)');
run('CREATE INDEX IF NOT EXISTS ix_wa_msgs_wamid ON wa_msgs(wamid)');
try { run('ALTER TABLE wa_msgs ADD COLUMN auto INTEGER'); } catch { /* there already */ }      // 1 = sent automatically
// automatic sends waiting / done, and manual sends that failed (Reports → Communication Log → WhatsApp log)
run(`CREATE TABLE IF NOT EXISTS wa_jobs (id INTEGER PRIMARY KEY, kind TEXT, ref_id INTEGER, ref TEXT, how TEXT DEFAULT 'AUTO', status TEXT, due_at INTEGER, tries INTEGER DEFAULT 0,
  error TEXT, note TEXT, created_at INTEGER, done_at INTEGER, msg_id INTEGER, phone TEXT, to_name TEXT)`);
run(`CREATE TABLE IF NOT EXISTS wa_templates (id TEXT PRIMARY KEY, name TEXT, language TEXT, status TEXT, category TEXT, components TEXT, param_format TEXT)`);

class E extends Error { constructor(m) { super(m); this.status = 400; } }
const MEDIA_DIR = () => path.join(DATA_DIR, 'whatsapp');
const DEFAULT_RELAY = 'https://parakhgroup.vyavsaysaarthi.in/webhook/relay';
const S = k => setting('wa_' + k, '');
const cfg = () => ({ phone_id: S('phone_id'), waba_id: S('waba_id'), token: S('token'), version: S('version') || 'v21.0', relay_url: S('relay_url') || DEFAULT_RELAY, relay_key: S('relay_key'), cc: S('cc') || '91' });
const W24 = 24 * 3600e3;

// ---- phone numbers: 10 digits → 91…
function normPhone(p) {
  let d = String(p || '').replace(/\D/g, '');
  if (d.length === 11 && d[0] === '0') d = d.slice(1);
  if (d.length === 10) d = cfg().cc + d;
  return d.length >= 11 && d.length <= 15 ? d : '';
}
const last10 = p => String(p || '').replace(/\D/g, '').slice(-10);
// who a number belongs to (Buyers B2B / B2C / Marketing enquiries)
function whoIs(phone) {
  const t = last10(phone); if (t.length < 10) return null;
  const like = '%' + t;
  const p = get(`SELECT id, name, city FROM parties WHERE replace(replace(COALESCE(mobile,''),' ',''),'-','') LIKE ? OR replace(replace(COALESCE(phone,''),' ',''),'-','') LIKE ? ORDER BY active DESC LIMIT 1`, like, like);
  if (p) return { name: p.name, city: p.city, kind: 'B2B', id: p.id };
  const c = get(`SELECT id, name, city FROM b2c_customers WHERE replace(COALESCE(mobile,''),' ','') LIKE ? LIMIT 1`, like);
  if (c) return { name: c.name, city: c.city, kind: 'B2C', id: c.id };
  try { const M = require('./marketing/db'); if (M.isOpen()) { const l = M.get(`SELECT id, company, buyer_name, city FROM leads WHERE replace(COALESCE(mobile1,''),' ','') LIKE ? OR replace(COALESCE(mobile2,''),' ','') LIKE ? LIMIT 1`, like, like); if (l) return { name: l.company || l.buyer_name, city: l.city, kind: 'Enquiry', id: l.id }; } } catch { /* marketing off */ }
  return null;
}

// ---- Meta Graph API
async function graph(method, p, body, { form } = {}) {
  const c = cfg(); if (!c.token) throw new E('WhatsApp is not set up — open Settings → Important Settings → WhatsApp and fill in the access token.');
  const r = await fetch(`${process.env.MS_WA_GRAPH || 'https://graph.facebook.com'}/${c.version}/${p}`, { method, headers: { Authorization: 'Bearer ' + c.token, ...(form ? {} : { 'Content-Type': 'application/json' }) },
    body: form || (body ? JSON.stringify(body) : undefined) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new E('WhatsApp: ' + ((j.error && (j.error.error_user_msg || j.error.message)) || 'error ' + r.status));
  return j;
}
function chatTouch(phone, { name, text, at, incoming }) {
  const ex = get('SELECT * FROM wa_chats WHERE phone = ?', phone);
  if (!ex) run('INSERT INTO wa_chats(phone, name, last_at, last_in_at, unread, last_text) VALUES(?,?,?,?,?,?)', phone, name || null, at, incoming ? at : null, incoming ? 1 : 0, text || '');
  else run('UPDATE wa_chats SET name = COALESCE(?, name), last_at = MAX(COALESCE(last_at, 0), ?), last_in_at = CASE WHEN ? THEN MAX(COALESCE(last_in_at, 0), ?) ELSE last_in_at END, unread = unread + ?, last_text = ? WHERE phone = ?',
    name || null, at, incoming ? 1 : 0, at, incoming ? 1 : 0, text || '', phone);
}
const preview = m => m.text || ({ image: '📷 Photo', document: '📄 ' + (m.filename || 'Document'), video: '🎬 Video', audio: '🎤 Audio', sticker: 'Sticker', location: '📍 Location', template: '📋 ' + (m.template || 'Template') }[m.type] || m.type);
function saveOut(phone, wamid, m) {
  const at = Date.now();
  const id = Number(run('INSERT INTO wa_msgs(wamid, phone, dir, type, text, media_id, file, mime, filename, status, at, template, ref, auto) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    wamid, phone, 'out', m.type, m.text || null, m.media_id || null, m.file || null, m.mime || null, m.filename || null, 'sent', at, m.template || null, m.ref || null, m.auto ? 1 : 0).lastInsertRowid);
  chatTouch(phone, { text: '➜ ' + preview(m), at, name: (whoIs(phone) || {}).name });
  return id;
}

// ---- incoming (from WMessage Saathi's linked-app store)
function onValue(v) {
  const c = cfg();
  if (!v || !v.metadata || String(v.metadata.phone_number_id) !== String(c.phone_id)) return;
  const names = Object.fromEntries((v.contacts || []).map(x => [x.wa_id, x.profile && x.profile.name]));
  for (const m of v.messages || []) {
    if (get('SELECT 1 FROM wa_msgs WHERE wamid = ?', m.id)) continue;
    const at = Math.min(Number(m.timestamp) * 1000 || Date.now(), Date.now());
    let text = null, media = null;
    if (m.type === 'text') text = m.text && m.text.body;
    else if (['image', 'document', 'video', 'audio', 'sticker'].includes(m.type)) { media = m[m.type] || {}; text = media.caption || null; }
    else if (m.type === 'button') text = m.button && m.button.text;
    else if (m.type === 'interactive') text = (m.interactive.button_reply || m.interactive.list_reply || {}).title || null;
    else if (m.type === 'location') text = `📍 ${m.location.name || ''} https://maps.google.com/?q=${m.location.latitude},${m.location.longitude}`.trim();
    else if (m.type === 'reaction') { const t = get('SELECT id FROM wa_msgs WHERE wamid = ?', m.reaction.message_id); if (t) run('UPDATE wa_msgs SET error = ? WHERE id = ?', 'reaction:' + (m.reaction.emoji || ''), t.id); continue; }
    else text = `(${m.type} message)`;
    const who = whoIs(m.from);
    run('INSERT INTO wa_msgs(wamid, phone, dir, type, text, media_id, mime, filename, status, at, ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
      m.id, m.from, 'in', m.type, text, media ? media.id : null, media ? media.mime_type : null, media ? media.filename || null : null, 'received', at, m.context ? m.context.id : null);
    chatTouch(m.from, { name: (who && who.name) || names[m.from], text: preview({ type: m.type, text, filename: media && media.filename }), at, incoming: true });
  }
  for (const s of v.statuses || []) {
    const err = s.errors && s.errors[0] ? (s.errors[0].error_data && s.errors[0].error_data.details) || s.errors[0].message || s.errors[0].title : null;
    const rank = { sent: 1, delivered: 2, read: 3, failed: 9 };
    const m = get('SELECT id, status FROM wa_msgs WHERE wamid = ?', s.id);
    if (m && (rank[s.status] || 0) > (rank[m.status] || 0)) run('UPDATE wa_msgs SET status = ?, error = COALESCE(?, error) WHERE id = ?', s.status, err, m.id);
  }
}
let polling = false, pollErr = '', lastPoll = 0;
async function poll() {
  const c = cfg(); if (polling || !c.relay_key || !c.phone_id) return;
  polling = true;
  try {
    for (let i = 0; i < 10; i++) {
      const after = Number(setting('wa_relay_seq', '0')) || 0;
      const r = await fetch(c.relay_url + (c.relay_url.includes('?') ? '&' : '?') + 'after=' + after, { headers: { Authorization: 'Bearer ' + c.relay_key } });
      if (r.status === 401) throw new Error('the linked-app key is not right (WMessage Saathi → Settings → Receive messages → Linked app)');
      if (!r.ok) throw new Error('could not reach WMessage Saathi (' + r.status + ')');
      const j = await r.json();
      if (j.seq < after) { setSetting('wa_relay_seq', '0'); continue; }   // the store was started again
      for (const e of j.events || []) { try { onValue(e.value); } catch (x) { console.error('WhatsApp event:', x.message); } setSetting('wa_relay_seq', String(e.seq)); }
      if (!j.events || j.events.length < 200) break;
    }
    pollErr = ''; lastPoll = Date.now();
  } catch (e) { pollErr = e.message; } finally { polling = false; }
}
setInterval(() => poll().catch(() => { }), 5000).unref();

// ---- media
const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'application/pdf': '.pdf', 'video/mp4': '.mp4', 'audio/ogg': '.ogg', 'audio/mpeg': '.mp3', 'audio/aac': '.aac', 'audio/mp4': '.m4a',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx', 'text/plain': '.txt' };
async function mediaFile(msg) {
  if (msg.file && fs.existsSync(msg.file)) return msg.file;
  if (!msg.media_id) throw new E('No file in this message.');
  const info = await graph('GET', msg.media_id);
  const r = await fetch(info.url, { headers: { Authorization: 'Bearer ' + cfg().token } });
  if (!r.ok) throw new E('The file could not be downloaded from WhatsApp (' + r.status + ').');
  fs.mkdirSync(MEDIA_DIR(), { recursive: true });
  const mime = (info.mime_type || msg.mime || '').split(';')[0];
  const file = path.join(MEDIA_DIR(), `${msg.id}${path.extname(msg.filename || '') || EXT[mime] || ''}`);
  fs.writeFileSync(file, Buffer.from(await r.arrayBuffer()));
  run('UPDATE wa_msgs SET file = ?, mime = COALESCE(mime, ?) WHERE id = ?', file, mime, msg.id);
  return file;
}
async function upload(buf, mime, filename) {
  const fd = new FormData();
  fd.append('messaging_product', 'whatsapp'); fd.append('type', mime); fd.append('file', new Blob([buf], { type: mime }), filename);
  return (await graph('POST', `${cfg().phone_id}/media`, null, { form: fd })).id;
}
const kindOf = mime => /^image\/(jpeg|png)$/.test(mime) ? 'image' : /^video\/(mp4|3gpp)$/.test(mime) ? 'video' : /^audio\//.test(mime) ? 'audio' : 'document';
function keep(buf, name) { fs.mkdirSync(MEDIA_DIR(), { recursive: true }); const f = path.join(MEDIA_DIR(), `out-${Date.now()}-${crypto.randomBytes(3).toString('hex')}${path.extname(name) || ''}`); fs.writeFileSync(f, buf); return f; }

// ---- sending
function canFree(phone) { const c = get('SELECT last_in_at FROM wa_chats WHERE phone = ?', phone); return !!(c && c.last_in_at && Date.now() - c.last_in_at < W24); }
async function sendText(phone, text) {
  phone = normPhone(phone); if (!phone) throw new E('Enter a right mobile number.');
  text = String(text || '').trim(); if (!text) throw new E('Write a message.');
  if (!canFree(phone)) throw new E('More than 24 hours since this customer last wrote — WhatsApp allows only an approved template message now.');
  const r = await graph('POST', `${cfg().phone_id}/messages`, { messaging_product: 'whatsapp', to: phone, type: 'text', text: { body: text, preview_url: /https?:\/\//.test(text) } });
  return { id: saveOut(phone, r.messages[0].id, { type: 'text', text }) };
}
async function sendFile(phone, { buf, mime, name, caption, ref }) {
  phone = normPhone(phone); if (!phone) throw new E('Enter a right mobile number.');
  if (!canFree(phone)) throw new E('More than 24 hours since this customer last wrote — send a template message first; files can be sent after the customer replies.');
  if (buf.length > 95 * 1024 * 1024) throw new E('The file is too big for WhatsApp (100 MB).');
  const k = kindOf(mime), mid = await upload(buf, mime, name), body = { id: mid };
  if (caption && k !== 'audio') body.caption = caption;
  if (k === 'document') body.filename = name;
  const r = await graph('POST', `${cfg().phone_id}/messages`, { messaging_product: 'whatsapp', to: phone, type: k, [k]: body });
  return { id: saveOut(phone, r.messages[0].id, { type: k, text: caption || null, media_id: mid, file: keep(buf, name), mime, filename: name, ref }) };
}
// template: params = { body: [..] or {name: value}, header: { type: 'document'|'image'|'text', file, name, text } }
async function sendTemplate(phone, name, language, params = {}, ref, auto) {
  phone = normPhone(phone); if (!phone) throw new E('Enter a right mobile number.');
  const t = get('SELECT * FROM wa_templates WHERE name = ? AND language = ?', name, language) || get('SELECT * FROM wa_templates WHERE name = ?', name);
  if (!t) throw new E(`Template ${name} is not in the list — press “Get templates from Meta” in Settings → Important Settings → WhatsApp.`);
  if (t.status !== 'APPROVED') throw new E(`Template ${name} is ${t.status} at Meta — only approved templates can be sent.`);
  const comps = JSON.parse(t.components || '[]'), named = t.param_format === 'NAMED', out = [];
  const head = comps.find(c => c.type === 'HEADER'), bodyC = comps.find(c => c.type === 'BODY');
  let file = null, headName = null;
  if (head && head.format && head.format !== 'TEXT') {
    const h = params.header || {};
    if (!h.buf) throw new E(`Template ${name} needs a ${head.format.toLowerCase()} on top.`);
    const mid = await upload(h.buf, h.mime, h.name), k = head.format.toLowerCase();
    out.push({ type: 'header', parameters: [{ type: k, [k]: k === 'document' ? { id: mid, filename: h.name } : { id: mid } }] });
    file = keep(h.buf, h.name); headName = h.name;
  } else if (head && head.format === 'TEXT' && /\{\{/.test(head.text || '')) {
    const v = (params.header && params.header.text) || '';
    out.push({ type: 'header', parameters: [named ? { type: 'text', parameter_name: (head.text.match(/\{\{\s*([^}\s]+)\s*\}\}/) || [])[1], text: v } : { type: 'text', text: v }] });
  }
  const keys = bodyC ? [...(bodyC.text || '').matchAll(/\{\{\s*([^}\s]+)\s*\}\}/g)].map(m => m[1]) : [];
  const vals = params.body || [];
  if (keys.length) out.push({ type: 'body', parameters: keys.map((k, i) => {
    const v = String((Array.isArray(vals) ? vals[i] : vals[k]) ?? '').replace(/[\n\t]+/g, ' ').replace(/ {4,}/g, '   ').trim() || '-';
    return named ? { type: 'text', parameter_name: k, text: v } : { type: 'text', text: v };
  }) });
  const r = await graph('POST', `${cfg().phone_id}/messages`, { messaging_product: 'whatsapp', to: phone, type: 'template', template: { name: t.name, language: { code: t.language }, components: out } });
  return { id: saveOut(phone, r.messages[0].id, { type: 'template', template: t.name, text: fillText(bodyC && bodyC.text, keys, vals), media_id: null, file, filename: headName, mime: params.header && params.header.mime, ref, auto }) };
}
function fillText(text, keys, vals) { let i = 0; return String(text || '').replace(/\{\{\s*([^}\s]+)\s*\}\}/g, () => { const k = keys[i]; const v = Array.isArray(vals) ? vals[i] : vals[k]; i++; return v == null || v === '' ? '-' : String(v); }); }

// ---- templates linked to the papers of the software
const SELLER = ['Seller name', 'Seller email', 'Seller mobile', 'Seller website'];
const PURPOSES = {
  SALE: { title: 'Sales invoice B2B', fields: ['Buyer name', 'Contact person', 'Invoice no.', 'Invoice date', 'Invoice amount', 'Quantity (MT)', 'Items', 'Lorry no.', 'Driver number', 'Transporter', 'L.R. no.',
    'E-way bill no.', 'Delivery plant', 'Dispatch plant', ...SELLER], doc: 'Invoice PDF', auto: 'when the L.R. copy is attached to the invoice' },
  B2C: { title: 'Sales invoice B2C', fields: ['Customer name', 'Contact person', 'Invoice no.', 'Invoice date', 'Invoice amount', 'Quantity', 'Items', 'Courier / lorry', 'Docket / L.R. no.',
    'Tracking link', 'Courier website', ...SELLER], doc: 'Invoice PDF', auto: 'when the L.R. / docket copy is attached to the invoice' },
  SAMPLE: { title: 'Sample dispatch', fields: ['Buyer name', 'Company', 'Ref no.', 'Dispatch date', 'Samples', 'Items', 'Courier', 'Tracking no.', 'Tracking link', 'Courier website', ...SELLER],
    doc: 'Sample cover letter PDF', auto: 'when the L.R. / tracking no. of the dispatch is filled in or changed' },
  REMINDER: { title: 'Payment reminder', fields: ['Buyer name', 'Contact person', 'Invoice list', 'Invoice count', 'Total due', 'Oldest invoice date', ...SELLER, 'Seller bank details'], doc: 'Firm bank proof', auto: null }
};
const courierSite = name => { if (!name) return ''; const c = get('SELECT website, tracking_url FROM couriers WHERE upper(name) = upper(?)', String(name).trim());
  if (!c) return ''; if (c.website) return c.website; try { return c.tracking_url ? new URL(c.tracking_url.replace('{tracking_no}', '')).origin : ''; } catch { return ''; } };
const sellerVals = f => ({ 'Seller name': f.name || '', 'Seller email': f.email || f.smtp_user || '', 'Seller mobile': f.phone || '', 'Seller website': f.website || '' });
const links = () => { try { return JSON.parse(setting('wa_links', '{}')) || {}; } catch { return {}; } };
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
const rs = n => 'Rs.' + Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const mtq = n => { const v = Math.round((Number(n) || 0) * 1000) / 1000; return String(v); };

function register(route, ctx) {
  // ctx: { makeInvoicePdf, paymentRows, firmBankProof }
  // values of each purpose
  function valuesFor(kind, id, ids) {
    if (kind === 'SALE' || kind === 'B2C') {
      const inv = require('./logic').invoiceFull(id); if (!inv) throw new E('Invoice not found.');
      const who = inv.b2c_id ? inv.customer || {} : inv.party || {}, f = inv.firm;
      const items = [...new Set(inv.items.map(i => [i.item_name, i.grade].filter(Boolean).join(' ')))].join(', ');
      const byUnit = {}; for (const i of inv.items) { const u = String(i.unit || 'MT').toUpperCase(); byUnit[u] = (byUnit[u] || 0) + (Number(i.qty) || 0); }
      const courier = inv.send_by === 'COURIER', docket = courier ? inv.docket_no || '' : inv.lr_no || '';
      const v = { 'Buyer name': inv.party_name, 'Customer name': inv.party_name, 'Contact person': who.contact_person || inv.party_name, 'Invoice no.': String(inv.inv_no), 'Invoice date': dmy(inv.date),
        'Invoice amount': rs(inv.total), 'Quantity (MT)': mtq(inv.items.reduce((s, i) => s + (Number(i.qty) || 0), 0)), Quantity: Object.entries(byUnit).map(([u, q]) => `${mtq(q)} ${u}`).join(' + '),
        Items: items, 'Lorry no.': inv.lorry_no || '', 'Driver number': inv.driver_phone || '', Transporter: inv.transporter || '', 'L.R. no.': inv.lr_no || '',
        'E-way bill no.': inv.ewb_no || '', 'Delivery plant': [inv.ship_name, inv.ship_city || inv.party_city].filter(Boolean).join(', '),
        'Dispatch plant': inv.plant || [...new Set(inv.items.map(i => i.plant).filter(Boolean))].join(', '),
        'Courier / lorry': courier ? inv.courier || '' : inv.lorry_no || '', 'Docket / L.R. no.': docket,
        'Tracking link': courier && docket ? require('./samplemail').trackLink(inv.courier, docket) : '', 'Courier website': courier ? courierSite(inv.courier) : '', ...sellerVals(f) };
      return { v, phone: who.mobile || who.phone || '', to: inv.party_name, ref: 'inv:' + inv.id, firm: f, doc: async () => { const file = await ctx.makeInvoicePdf(inv.id); return { buf: fs.readFileSync(file), mime: 'application/pdf', name: path.basename(file) }; } };
    }
    if (kind === 'SAMPLE') {
      const sm = require('./samplemail'), d = sm.dispatchData(id), sv = sm.sampleValues(d), L = d.lead || {};
      const v = { 'Buyer name': L.buyer_name || L.company || '', Company: L.company || '', 'Ref no.': String(L.ref_no ?? ''), 'Dispatch date': dmy(d.dispatch.date), Samples: sv.samples, Items: sv.items, Courier: d.dispatch.courier || '',
        'Tracking no.': d.dispatch.tracking_no || '', 'Tracking link': sv['tracking link'] || '', 'Courier website': courierSite(d.dispatch.courier), ...sellerVals(get('SELECT * FROM firms WHERE code = ?', d.firm.code) || d.firm) };
      return { v, phone: L.mobile1 || L.mobile2 || '', to: L.company || L.buyer_name, ref: 'disp:' + id, firm: d.firm, doc: async () => {     // the sample cover letter (Marketing → print papers)
        const safe = x => String(x || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
        const file = path.join(ctx.pdfFolder(), 'Marketing', safe(`${L.ref_no ?? ''} ${L.company || L.buyer_name || ''}`), safe(`${d.dispatch.date} Cover letter`) + '.pdf');
        await require('./pdf').makePdf(`http://127.0.0.1:${ctx.port()}/print/mkt/cover/${id}?shot=1`, file);
        return { buf: fs.readFileSync(file), mime: 'application/pdf', name: safe(`Cover letter Ref ${L.ref_no ?? ''} ${L.company || L.buyer_name || ''}`) + '.pdf' };
      } };
    }
    if (kind === 'REMINDER') {
      const rows = ctx.paymentRows(null, (ids || []).map(Number)); if (!rows.length) throw new E('Choose the invoices.');
      const r0 = rows[0], party = r0.party_id ? get('SELECT * FROM parties WHERE id = ?', r0.party_id) : null, f = get('SELECT * FROM firms WHERE code = ?', r0.firm_code) || {};
      const total = rows.reduce((s, r) => s + (Number(r.total) || 0), 0);
      const v = { 'Buyer name': r0.party_name, 'Contact person': (party && party.contact_person) || r0.party_name, 'Invoice list': rows.map(r => `${r.inv_no} dt ${dmy(r.date)} ${rs(r.total)}`).join('; '),
        'Invoice count': String(rows.length), 'Total due': rs(total), 'Oldest invoice date': dmy(rows[0].date), ...sellerVals(f),
        'Seller bank details': [f.bank_name, f.bank_account && 'A/c ' + f.bank_account, f.bank_ifsc && 'IFSC ' + f.bank_ifsc].filter(Boolean).join(' - ') };
      return { v, phone: party ? party.mobile || party.phone || '' : '', to: r0.party_name, ref: 'rem:' + rows.map(r => r.id).join(','), firm: f, doc: async () => ctx.firmBankProof(f) };
    }
    throw new E('Unknown kind.');
  }
  function plan(kind, id, ids) {
    const l = links()[kind]; if (!l || !l.template) throw new E(`No WhatsApp template is linked to “${PURPOSES[kind].title}” — set it in Settings → Important Settings → WhatsApp.`);
    const t = get('SELECT * FROM wa_templates WHERE name = ? AND language = ?', l.template, l.language) || get('SELECT * FROM wa_templates WHERE name = ?', l.template);
    if (!t) throw new E(`Template ${l.template} is not in the list — Settings → Important Settings → WhatsApp → Get templates from Meta.`);
    const x = valuesFor(kind, id, ids), comps = JSON.parse(t.components || '[]'), bodyC = comps.find(c => c.type === 'BODY'), head = comps.find(c => c.type === 'HEADER');
    const keys = bodyC ? [...(bodyC.text || '').matchAll(/\{\{\s*([^}\s]+)\s*\}\}/g)].map(m => m[1]) : [];
    const vals = keys.map((k, i) => { const m = (l.vars || [])[i] || ''; return m.startsWith('=') ? m.slice(1) : x.v[m] ?? ''; });
    return { x, t, keys, vals, text: fillText(bodyC && bodyC.text, keys, vals), header: head && head.format && head.format !== 'TEXT' ? head.format : null };
  }

  // ---- routes
  route('GET', '/api/wa/settings', () => { const c = cfg(); return { phone_id: c.phone_id, waba_id: c.waba_id, version: c.version, relay_url: c.relay_url, cc: c.cc,
    has_token: !!c.token, has_key: !!c.relay_key, links: links(), purposes: PURPOSES, poll: { error: pollErr, at: lastPoll, seq: Number(setting('wa_relay_seq', '0')) || 0 } }; });
  route('PUT', '/api/wa/settings', ({ body }) => {
    for (const [k, n] of [['phone_id', 'Phone number ID'], ['waba_id', 'WhatsApp Business Account ID']])
      if (body[k] && !/^\d{6,25}$/.test(String(body[k]).trim())) throw new E(`${n}: only digits (copy it from Meta → WhatsApp → API Setup). The browser may have filled in an email or name here — clear it.`);
    const tok = String(body.token || '').replace(/\s+/g, ''), key = String(body.relay_key || '').replace(/\s+/g, '');
    if (tok && !/^EA[A-Za-z0-9]{60,}$/.test(tok)) throw new E(`This is not a Meta access token (${tok.length} characters). A token starts with EA and is about 180–250 characters long — copy the whole token again from Meta.`);
    for (const k of ['phone_id', 'waba_id', 'version', 'relay_url', 'cc']) if (body[k] !== undefined) setSetting('wa_' + k, String(body[k] || '').trim());
    if (tok) setSetting('wa_token', tok);         // secret: only replaced when pasted
    if (key) setSetting('wa_relay_key', key);
    if (body.links) { const o = {}; for (const k of Object.keys(PURPOSES)) { const l = body.links[k] || {}; if (l.template) { const dl = Math.round(Number(l.delay) || 10); if (l.auto && (dl < 1 || dl > 90)) throw new E(`${PURPOSES[k].title}: send after 1 to 90 minutes.`);
      o[k] = { template: String(l.template), language: String(l.language || ''), vars: (l.vars || []).map(String), auto: !!(l.auto && PURPOSES[k].auto), delay: Math.min(90, Math.max(1, dl)) }; } } setSetting('wa_links', JSON.stringify(o)); }
    return { ok: true };
  });
  route('POST', '/api/wa/test', async () => {
    const c = cfg(); if (!c.phone_id) throw new E('Fill in the Phone number ID.');
    const p = await graph('GET', c.phone_id + '?fields=display_phone_number,verified_name,quality_rating');
    let relay = 'not set';
    if (c.relay_key) { const r = await fetch(c.relay_url + '?after=999999999', { headers: { Authorization: 'Bearer ' + c.relay_key } }).catch(e => ({ ok: false, status: e.message })); relay = r.ok ? 'connected' : r.status === 401 ? 'wrong key' : 'not reachable (' + r.status + ')'; }
    return { number: p.display_phone_number, name: p.verified_name, quality: p.quality_rating, relay };
  });
  route('POST', '/api/wa/templates/sync', async () => {
    const c = cfg(); if (!c.waba_id) throw new E('Fill in the WhatsApp Business Account ID.');
    let url = `${c.waba_id}/message_templates?fields=id,name,language,status,category,components,parameter_format&limit=200`, n = 0;
    const seen = [];
    while (url) {
      const j = await graph('GET', url);
      for (const t of j.data || []) { seen.push(t.id); n++;
        run('INSERT OR REPLACE INTO wa_templates(id, name, language, status, category, components, param_format) VALUES(?,?,?,?,?,?,?)', t.id, t.name, t.language, t.status, t.category, JSON.stringify(t.components || []), t.parameter_format || 'POSITIONAL'); }
      url = j.paging && j.paging.next ? j.paging.next.replace(/^https:\/\/graph\.facebook\.com\/v[\d.]+\//, '') : null;
    }
    if (seen.length) run(`DELETE FROM wa_templates WHERE id NOT IN (${seen.map(() => '?').join(',')})`, ...seen);
    return { count: n };
  });
  route('GET', '/api/wa/templates', () => all('SELECT * FROM wa_templates ORDER BY status = \'APPROVED\' DESC, name').map(t => ({ ...t, components: JSON.parse(t.components || '[]') })));
  route('GET', '/api/wa/chats', ({ q }) => {
    poll().catch(() => { });
    const rows = all(`SELECT * FROM wa_chats ${q.q ? 'WHERE phone LIKE ? OR name LIKE ?' : ''} ORDER BY last_at DESC LIMIT 300`, ...(q.q ? ['%' + q.q + '%', '%' + q.q + '%'] : []));
    return { chats: rows.map(c => ({ ...c, open: !!(c.last_in_at && Date.now() - c.last_in_at < W24) })), poll: { error: pollErr, at: lastPoll }, ready: !!(cfg().token && cfg().phone_id) };
  });
  route('GET', '/api/wa/chat/:phone', ({ p, q }) => {
    const phone = normPhone(p.phone) || p.phone;
    const msgs = all(`SELECT id, wamid, dir, type, text, media_id, mime, filename, status, error, at, template, (file IS NOT NULL OR media_id IS NOT NULL) AS has_file FROM wa_msgs WHERE phone = ? ${q.after ? 'AND id > ?' : ''} ORDER BY at, id LIMIT 1000`, phone, ...(q.after ? [Number(q.after)] : []));
    const c = get('SELECT * FROM wa_chats WHERE phone = ?', phone) || { phone, name: (whoIs(phone) || {}).name || null };
    if (c.unread) {
      run('UPDATE wa_chats SET unread = 0 WHERE phone = ?', phone);
      const lastIn = get("SELECT wamid FROM wa_msgs WHERE phone = ? AND dir = 'in' ORDER BY at DESC LIMIT 1", phone);
      if (lastIn && cfg().token) graph('POST', `${cfg().phone_id}/messages`, { messaging_product: 'whatsapp', status: 'read', message_id: lastIn.wamid }).catch(() => { });
    }
    return { chat: { ...c, open: !!(c.last_in_at && Date.now() - c.last_in_at < W24), who: whoIs(phone) }, msgs };
  });
  route('POST', '/api/wa/send', ({ body }) => sendText(body.phone, body.text));
  route('POST', '/api/wa/send-file', ({ body }) => {
    const m = String(body.data || '').match(/^data:([^;]*);base64,(.*)$/); if (!m) throw new E('No file.');
    return sendFile(body.phone, { buf: Buffer.from(m[2], 'base64'), mime: m[1] || 'application/octet-stream', name: String(body.name || 'file').slice(0, 120), caption: body.caption });
  });
  route('POST', '/api/wa/send-template', async ({ body }) => {
    const h = body.header && body.header.data ? (() => { const m = String(body.header.data).match(/^data:([^;]*);base64,(.*)$/); return m ? { buf: Buffer.from(m[2], 'base64'), mime: m[1], name: body.header.name || 'file' } : null; })() : null;
    return sendTemplate(body.phone, body.name, body.language, { body: body.params || [], header: h || (body.header_text ? { text: body.header_text } : {}) });
  });
  route('POST', '/api/wa/new-chat', ({ body }) => { const phone = normPhone(body.phone); if (!phone) throw new E('Enter a right mobile number.');
    if (!get('SELECT 1 FROM wa_chats WHERE phone = ?', phone)) run('INSERT INTO wa_chats(phone, name, last_at, unread, last_text) VALUES(?,?,?,0,?)', phone, (whoIs(phone) || {}).name || body.name || null, Date.now(), ''); return { phone }; });
  // a template for an invoice / B2C invoice / sample dispatch / payment reminder: GET = what will be sent, POST = send
  route('POST', '/api/wa/for/:kind/preview', ({ p, body }) => {
    const kind = p.kind.toUpperCase(), x = plan(kind, body.id, body.ids);
    return { kind, title: PURPOSES[kind].title, phone: normPhone(x.x.phone) || x.x.phone || '', to: x.x.to, template: x.t.name, language: x.t.language, status: x.t.status, text: x.text, header: x.header, doc: PURPOSES[kind].doc };
  });
  async function sendFor(kind, id, ids, phone, auto) {
    const x = plan(kind, id, ids);
    let header = {};
    if (x.header) { header = await x.x.doc(); if (!header) throw new E(`Template ${x.t.name} needs a ${x.header.toLowerCase()} on top, but there is none for this ${PURPOSES[kind].title.toLowerCase()}.`); }
    const to = phone || x.x.phone; if (!normPhone(to)) throw new E(`No WhatsApp number for ${x.x.to || 'this buyer'} — add the mobile number in the master.`);
    const r = await sendTemplate(to, x.t.name, x.t.language, { body: x.vals, header }, x.x.ref, auto);
    return { ...r, to: x.x.to, ref: x.x.ref, phone: normPhone(to) };
  }
  route('POST', '/api/wa/for/:kind', async ({ p, body }) => {
    const kind = p.kind.toUpperCase();
    try { return await sendFor(kind, body.id, body.ids, body.phone, false); }
    catch (e) {      // kept for the WhatsApp log
      let to = null; try { to = valuesFor(kind, body.id, body.ids).to; } catch { /* not found */ }
      run("INSERT INTO wa_jobs(kind, ref_id, ref, how, status, error, created_at, done_at, phone, to_name) VALUES(?,?,?,'MANUAL','FAILED',?,?,?,?,?)", kind, Number(body.id) || null,
        kind === 'REMINDER' ? 'rem:' + (body.ids || []).join(',') : (kind === 'SAMPLE' ? 'disp:' : 'inv:') + body.id, String(e.message).slice(0, 300), Date.now(), Date.now(), normPhone(body.phone) || null, to);
      throw e;
    }
  });

  // ---- automatic sending: B2B / B2C invoice when its L.R. copy is attached, sample dispatch when its L.R. / tracking no. is filled in.
  // Sent 1–90 minutes later (Settings → Important Settings → WhatsApp, per paper), so a second L.R. page or a corrected number is waited for.
  function queue(kind, refId, note) {
    try {
      const l = links()[kind]; if (!l || !l.template || !l.auto) return;
      const ref = (kind === 'SAMPLE' ? 'disp:' : 'inv:') + refId;
      run("UPDATE wa_jobs SET status = 'REPLACED', done_at = ? WHERE kind = ? AND ref_id = ? AND status = 'WAIT'", Date.now(), kind, refId);
      run("INSERT INTO wa_jobs(kind, ref_id, ref, how, status, due_at, note, created_at) VALUES(?,?,?,'AUTO','WAIT',?,?,?)", kind, refId, ref, Date.now() + (Number(l.delay) || 10) * 60e3, note || null, Date.now());
    } catch (e) { console.error('WhatsApp queue:', e.message); }
  }
  const hooks = require('./hooks');
  hooks.on('lrcopy', invId => {
    const inv = get('SELECT id, kind, b2c_id, cancelled, pf_source_id FROM invoices WHERE id = ?', invId);
    if (!inv || inv.cancelled || inv.pf_source_id || inv.kind !== 'SALE') return;        // not the PM → PF invoice made inside the group
    queue(inv.b2c_id ? 'B2C' : 'SALE', inv.id, 'L.R. copy attached');
  });
  hooks.on('tracking', (did, oldNo, newNo) => { newNo = String(newNo || '').trim(); if (newNo && newNo !== String(oldNo || '').trim()) queue('SAMPLE', did, 'L.R. / tracking no. ' + newNo); });
  let busy = false;
  async function worker() {
    if (busy || !cfg().token) return; busy = true;
    try {
      for (const j of all("SELECT * FROM wa_jobs WHERE status = 'WAIT' AND due_at <= ? ORDER BY id LIMIT 10", Date.now())) {
        const done = (status, extra = {}) => run('UPDATE wa_jobs SET status = ?, error = ?, done_at = ?, msg_id = ?, phone = COALESCE(?, phone), to_name = COALESCE(?, to_name) WHERE id = ?',
          status, extra.error || null, Date.now(), extra.msg || null, extra.phone || null, extra.to || null, j.id);
        try { if (!j.to_name) { const w = valuesFor(j.kind, j.ref_id); run('UPDATE wa_jobs SET to_name = ?, phone = ? WHERE id = ?', w.to || null, normPhone(w.phone) || null, j.id); } } catch { /* shown by the send */ }
        const l = links()[j.kind];
        if (!l || !l.template || !l.auto) { done('OFF', { error: 'Automatic sending was switched off.' }); continue; }
        // already sent (by hand or automatically): an invoice once; a sample dispatch once after this L.R. / tracking no.
        const sent = get("SELECT id FROM wa_msgs WHERE ref = ? AND dir = 'out' AND status <> 'failed' AND at >= ? ORDER BY id DESC LIMIT 1", j.ref, j.kind === 'SAMPLE' ? j.created_at : 0);
        if (sent) { done('SKIPPED', { error: 'Already sent on WhatsApp.', msg: sent.id }); continue; }
        if (j.kind === 'SAMPLE') {
          try { const M = require('./marketing/db'); const d = M.isOpen() && M.get('SELECT tracking_no FROM dispatches WHERE id = ?', j.ref_id);
            if (!d) { done('SKIPPED', { error: 'The dispatch is not there any more.' }); continue; } } catch { /* marketing closed: try anyway */ }
        }
        try { const r = await sendFor(j.kind, j.ref_id, null, null, true); done('SENT', { msg: r.id, phone: r.phone, to: r.to });
          console.log(`  WhatsApp ${PURPOSES[j.kind].title} (${j.ref}) sent to ${r.to} (automatic).`); }
        catch (e) {
          const tries = (j.tries || 0) + 1, hard = /No WhatsApp number|not found|not there|No WhatsApp template/i.test(e.message);
          if (tries >= 3 || hard) done('FAILED', { error: String(e.message).slice(0, 300) });
          else run('UPDATE wa_jobs SET tries = ?, error = ?, due_at = ? WHERE id = ?', tries, String(e.message).slice(0, 300), Date.now() + 15 * 60e3, j.id);     // again in 15 minutes
        }
      }
    } catch (e) { console.error('WhatsApp automatic:', e.message); } finally { busy = false; }
  }
  setInterval(() => worker().catch(() => { }), 30e3).unref();

  // Reports → Communication Log → WhatsApp log: every message sent, automatic ones waiting, and failed sends
  const refLabel = ref => {
    const m = String(ref || '').match(/^(inv|disp|rem):(.+)$/); if (!m) return '';
    try {
      if (m[1] === 'inv') { const i = get('SELECT firm_code, inv_no, b2c_id FROM invoices WHERE id = ?', m[2]); return i ? `${i.b2c_id ? 'B2C invoice' : 'Invoice'} ${i.firm_code} ${i.inv_no}` : 'Invoice'; }
      if (m[1] === 'disp') { const M = require('./marketing/db'); const d = M.isOpen() && M.get('SELECT l.ref_no, d.tracking_no FROM dispatches d JOIN leads l ON l.id = d.lead_id WHERE d.id = ?', m[2]);
        return d ? `Sample dispatch · Ref ${d.ref_no}${d.tracking_no ? ' · ' + d.tracking_no : ''}` : 'Sample dispatch'; }
      return `Payment reminder (${m[2].split(',').length} invoice${m[2].includes(',') ? 's' : ''})`;
    } catch { return ''; }
  };
  route('GET', '/api/wa/log', ({ q }) => {
    const from = /^\d{4}-\d{2}-\d{2}$/.test(q.from || '') ? new Date(q.from + 'T00:00:00').getTime() : 0, to = /^\d{4}-\d{2}-\d{2}$/.test(q.to || '') ? new Date(q.to + 'T23:59:59').getTime() : 9e15;
    const msgs = all("SELECT m.id, m.phone, m.at, m.type, m.template, m.text, m.filename, m.status, m.error, m.ref, m.auto, c.name FROM wa_msgs m LEFT JOIN wa_chats c ON c.phone = m.phone WHERE m.dir = 'out' AND m.at BETWEEN ? AND ? ORDER BY m.at DESC LIMIT 1000", from, to)
      .map(m => ({ at: m.at, phone: m.phone, name: m.name || (whoIs(m.phone) || {}).name || '', what: refLabel(m.ref) || (m.template ? 'Template' : 'Chat'), template: m.template || '', text: m.text || (m.filename ? '📄 ' + m.filename : ''),
        how: m.auto ? 'Automatic' : 'By hand', status: m.status === 'failed' ? 'FAILED' : String(m.status || 'sent').toUpperCase(), error: m.error && !/^reaction:/.test(m.error) ? m.error : '' }));
    const jobs = all("SELECT * FROM wa_jobs WHERE status IN ('WAIT', 'FAILED', 'SKIPPED', 'OFF') AND COALESCE(done_at, created_at) BETWEEN ? AND ? ORDER BY id DESC LIMIT 500", from, to)
      .map(j => ({ at: j.status === 'WAIT' ? j.due_at : j.done_at || j.created_at, phone: j.phone || '', name: j.to_name || '', what: refLabel(j.ref), template: (links()[j.kind] || {}).template || '', text: j.note || '',
        how: j.how === 'MANUAL' ? 'By hand' : 'Automatic', status: j.status === 'WAIT' ? 'WAITING' : j.status, error: j.status === 'WAIT' ? (j.error ? `Will try again — ${j.error}` : `Will be sent at ${new Date(j.due_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`) : j.error || '' }));
    const rows = [...msgs, ...jobs].sort((a, b) => b.at - a.at);
    return q.status ? rows.filter(r => r.status === q.status || (q.status === 'SENT' && ['SENT', 'DELIVERED', 'READ'].includes(r.status))) : rows;
  });
  route('GET', '/api/wa/sent-for', ({ q }) => all('SELECT ref, status, at FROM wa_msgs WHERE ref LIKE ? ORDER BY id DESC LIMIT 50', String(q.ref || '') + '%'));
}

// file of a message (shown in the chat)
async function serveMedia(id, res, send) {
  const m = get('SELECT * FROM wa_msgs WHERE id = ?', id); if (!m) return send(res, 404, 'Not found', 'text/plain');
  try {
    const f = await mediaFile(m), mime = m.mime || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Content-Disposition': `inline; filename="${String(m.filename || path.basename(f)).replace(/"/g, '')}"`, 'Cache-Control': 'private, max-age=86400' });
    fs.createReadStream(f).pipe(res);
  } catch (e) { send(res, 502, e.message, 'text/plain'); }
}
module.exports = { register, serveMedia, normPhone, poll, onValue };
