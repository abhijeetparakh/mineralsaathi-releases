'use strict';
// Factory → Bags: stock of empty bags (Parakh Marketing and Parakh Fertilizer share one stock; P.P. Enterprise uses none).
// In:  purchase (count, or weight ÷ empty weight of one bag; rate per bag or per kg), bags received from a buyer, adjustments,
//      opening stock (edit password).
// Out: every PM / PF sales invoice from the start date uses its bags by itself — a combo bag type (e.g. 1 outer + 6 × 5 kg bags)
//      uses its parts; WITH LINER uses one liner a bag; wastage % on top.
// Bag types are matched without spaces / dots / case ("PLAIN 5KG X6 (30KG)" = "Plain 5kg x 6 (30KG)"); "same as" joins other names.
const { all, get, run, setting, setSetting, tx } = require('./db');

run(`CREATE TABLE IF NOT EXISTS bag_info (
  nkey TEXT PRIMARY KEY, name TEXT NOT NULL,
  empty_g REAL,                 -- empty weight of one bag, grams
  kind TEXT DEFAULT 'OUTER',    -- OUTER / INNER (5 kg bag) / COMBO / LINER
  combo_outer TEXT, combo_inner TEXT, combo_count INTEGER,
  has_liner INTEGER DEFAULT 0,  -- the bag type itself has a liner in it (e.g. PLAIN BAGS WITH LINER)
  same_as TEXT,                 -- nkey of the bag type this name is the same as
  owner_party_id INTEGER,       -- buyer's own (printed) bags: only for that buyer
  min_stock INTEGER)`);
run(`CREATE TABLE IF NOT EXISTS bag_moves (
  id INTEGER PRIMARY KEY, date TEXT NOT NULL, kind TEXT NOT NULL,   -- OPENING / PURCHASE / BUYER / ADJUST
  nkey TEXT NOT NULL, bags REAL NOT NULL, weight_kg REAL, rate REAL, rate_per TEXT, amount REAL,
  supplier TEXT, bill_no TEXT, party_id INTEGER, note TEXT, created_at TEXT DEFAULT (datetime('now','localtime')))`);

try { run('ALTER TABLE bag_moves ADD COLUMN grp INTEGER'); } catch { /* there already */ }      // entries of one bill / one invoice saved together
const nk = s => String(s || '').toUpperCase().replace(/LINNER/g, 'LINER').replace(/[^A-Z0-9]/g, '');
const LINER = 'LINER';
// the key of a bag type typed by name (a renamed type keeps its first key)
const keyOf = n => { const b = get('SELECT nkey FROM bag_info WHERE upper(trim(name)) = upper(trim(?))', String(n || '')); return b ? b.nkey : nk(n); };
const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10);
if (!setting('bags_start')) setSetting('bags_start', localToday());          // invoices use bags from this day (the opening count)
if (!get('SELECT 1 FROM bag_info WHERE nkey = ?', LINER)) run("INSERT INTO bag_info(nkey, name, kind) VALUES(?, 'LINER', 'LINER')", LINER);

class E extends Error { constructor(m) { super(m); this.status = 400; } }
const r3 = n => Math.round((Number(n) || 0) * 1000) / 1000, r2 = n => Math.round((Number(n) || 0) * 100) / 100;

// every bag type name in use (Item List, buyers' items, invoices of the last year) with its settings
function types() {
  const names = new Map();
  const add = (n, src) => { const k = nk(n); if (!k) return; const x = names.get(k) || { nkey: k, names: new Set(), src: new Set() }; x.names.add(String(n).trim()); x.src.add(src); names.set(k, x); };
  all("SELECT value FROM lists WHERE list_key = 'bag_type' AND COALESCE(active, 1) = 1").forEach(r => add(r.value, 'list'));
  all('SELECT DISTINCT bag_type FROM party_items WHERE active = 1 AND bag_type IS NOT NULL').forEach(r => add(r.bag_type, 'buyers'));
  all(`SELECT DISTINCT it.bag_type FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id WHERE i.date >= date('now', '-400 days') AND it.bag_type IS NOT NULL`).forEach(r => add(r.bag_type, 'invoices'));
  const info = new Map(all('SELECT * FROM bag_info').map(b => [b.nkey, b]));
  for (const k of info.keys()) if (!names.has(k)) names.set(k, { nkey: k, names: new Set([info.get(k).name]), src: new Set(['bags']) });
  const parties = new Map(all('SELECT id, name FROM parties').map(p => [p.id, p.name]));
  return [...names.values()].map(x => { const b = info.get(x.nkey) || {};
    return { nkey: x.nkey, name: b.name || [...x.names][0], names: [...x.names], src: [...x.src], empty_g: b.empty_g ?? null, kind: b.kind || 'OUTER',
      combo_outer: b.combo_outer || null, combo_inner: b.combo_inner || null, combo_count: b.combo_count || null, has_liner: b.has_liner ? 1 : 0, same_as: b.same_as || null,
      owner_party_id: b.owner_party_id || null, owner: b.owner_party_id ? parties.get(b.owner_party_id) || '' : '', min_stock: b.min_stock ?? null,
      in_list: x.src.has('list') || x.nkey === LINER ? 1 : 0 }; })
    .sort((a, b) => a.name.localeCompare(b.name));
}
// the stock key of a bag type name (follows "same as")
function resolver() {
  const info = new Map(all('SELECT * FROM bag_info').map(b => [b.nkey, b]));
  const root = k => { let x = k, n = 0; while (info.get(x) && info.get(x).same_as && n++ < 5) x = info.get(x).same_as; return x; };
  return { info, root };
}
// bags used by the invoices from..to (PM / PF sales; the PM → PF copy of a PF invoice is not counted twice)
function usage(from, to) {
  const { info, root } = resolver();
  const lines = all(`SELECT i.id, i.date, i.firm_code, i.inv_no, i.party_name, i.party_id, it.item_name, it.grade, it.qty, it.bags, it.bag_type, it.bag_supply, it.liner
    FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id
    WHERE i.firm_code IN ('PM', 'PF') AND COALESCE(i.kind, 'SALE') = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND i.pf_source_id IS NULL
      AND i.date >= ? AND i.date <= ? AND COALESCE(it.bags, 0) > 0 ORDER BY i.date, i.id`, from, to);
  const out = [];          // [date, nkey, bags, invoice, item, qty MT]
  for (const l of lines) {
    const k = root(nk(l.bag_type)); if (!k) { out.push({ date: l.date, nkey: '', bags: l.bags, l }); continue; }
    const b = info.get(k);
    if (b && b.kind === 'COMBO' && b.combo_outer && b.combo_inner && b.combo_count) {
      out.push({ date: l.date, nkey: root(b.combo_outer), bags: l.bags, l });
      out.push({ date: l.date, nkey: root(b.combo_inner), bags: l.bags * b.combo_count, l, inner: 1 });
    } else out.push({ date: l.date, nkey: k, bags: l.bags, l });
    if (Number(l.liner) === 1 || (b && b.has_liner)) out.push({ date: l.date, nkey: LINER, bags: l.bags, l, liner: 1 });
  }
  return out;
}
function stock(asOf) {
  const start = setting('bags_start'), to = asOf || localToday(), pct = Number(setting('bag_wastage_pct', '0')) || 0;
  const { info, root } = resolver();
  const T = new Map(types().map(t => [t.nkey, t]));
  const row = k => { if (!S.has(k)) S.set(k, { nkey: k, name: (T.get(k) || info.get(k) || {}).name || k, opening: 0, purchased: 0, from_buyers: 0, adjust: 0, used: 0, wastage: 0, buy_bags: 0, buy_amt: 0 }); return S.get(k); };
  const S = new Map();
  for (const m of all('SELECT * FROM bag_moves WHERE date <= ?', to)) {
    const x = row(root(m.nkey));
    if (m.kind === 'OPENING') { x.opening += m.bags; if (m.amount) { x.buy_bags += m.bags; x.buy_amt += m.amount; } }
    else if (m.kind === 'PURCHASE') { x.purchased += m.bags; x.buy_bags += m.bags; x.buy_amt += Number(m.amount) || 0; }
    else if (m.kind === 'BUYER') x.from_buyers += m.bags;
    else x.adjust += m.bags;
  }
  const used = usage(start, to), noType = [];
  for (const u of used) { if (!u.nkey) { noType.push(u.l); continue; } row(u.nkey).used += u.bags; }
  const list = [...S.values()].map(x => { const t = T.get(x.nkey) || {}; x.wastage = Math.round(x.used * pct / 100);
    x.in_hand = r3(x.opening + x.purchased + x.from_buyers + x.adjust - x.used - x.wastage);
    x.avg_cost = x.buy_bags > 0 ? r2(x.buy_amt / x.buy_bags) : null; x.value = x.avg_cost != null ? r2(Math.max(0, x.in_hand) * x.avg_cost) : null;
    return { ...x, kind: t.kind || 'OUTER', owner: t.owner || '', min_stock: t.min_stock ?? null, empty_g: t.empty_g ?? null, low: t.min_stock != null && x.in_hand < t.min_stock, in_list: t.in_list ? 1 : 0 }; })
    .filter(x => x.opening || x.purchased || x.from_buyers || x.adjust || x.used).sort((a, b) => a.name.localeCompare(b.name));
  return { start, to, wastage_pct: pct, list, no_type: noType.length, no_type_bags: noType.reduce((s, l) => s + (Number(l.bags) || 0), 0) };
}

module.exports = function register(route, { checkEditPassword, backup }) {
  route('GET', '/api/bags/types', () => ({ types: types(), parties: all("SELECT id, name, city FROM parties WHERE COALESCE(active, 1) = 1 AND COALESCE(is_online, 0) = 0 ORDER BY name"),
    // "Buyer who sent the bags": only buyers with an item that uses the buyer's own bags (Buyers → items, Bags supplied by BUYER) or with their own bag type
    bag_buyers: all(`SELECT id, name, city FROM parties p WHERE COALESCE(active, 1) = 1 AND (EXISTS (SELECT 1 FROM party_items pi WHERE pi.party_id = p.id AND pi.active = 1 AND pi.bag_supply = 'BUYER')
      OR EXISTS (SELECT 1 FROM bag_info b WHERE b.owner_party_id = p.id) OR EXISTS (SELECT 1 FROM bag_moves m WHERE m.party_id = p.id)) ORDER BY name`) }));
  route('PUT', '/api/bags/types/:nkey', ({ p, body }) => {
    const k = nk(decodeURIComponent(p.nkey)); if (!k) throw new E('Bag type not found.');
    const kind = ['OUTER', 'INNER', 'COMBO', 'LINER'].includes(body.kind) ? body.kind : 'OUTER';
    const o = { name: String(body.name || '').trim().toUpperCase() || k, empty_g: body.empty_g === '' || body.empty_g == null ? null : Number(body.empty_g), kind,
      combo_outer: kind === 'COMBO' ? keyOf(body.combo_outer) || null : null, combo_inner: kind === 'COMBO' ? keyOf(body.combo_inner) || null : null,
      combo_count: kind === 'COMBO' ? Math.round(Number(body.combo_count)) || null : null, has_liner: Number(body.has_liner) ? 1 : 0,
      same_as: keyOf(body.same_as) && keyOf(body.same_as) !== k ? keyOf(body.same_as) : null, owner_party_id: Number(body.owner_party_id) || null,
      min_stock: body.min_stock === '' || body.min_stock == null ? null : Math.round(Number(body.min_stock)) };
    if (o.empty_g != null && !(o.empty_g > 0)) throw new E('Empty weight: enter the grams of one empty bag.');
    if (kind === 'COMBO' && (!o.combo_outer || !o.combo_inner || !(o.combo_count > 0))) throw new E('A combo needs its outer bag, its inner bag and how many inner bags (e.g. 4 or 6).');
    if (o.same_as && get('SELECT 1 FROM bag_info WHERE nkey = ? AND same_as = ?', o.same_as, k)) throw new E('These two names point at each other.');
    const keys = Object.keys(o);
    run(`INSERT INTO bag_info(nkey, ${keys.join(',')}) VALUES(?, ${keys.map(() => '?').join(',')}) ON CONFLICT(nkey) DO UPDATE SET ${keys.map(x => `${x} = excluded.${x}`).join(', ')}`, k, ...keys.map(x => o[x]));
    return { ok: true };
  });
  route('GET', '/api/bags/settings', () => ({ start: setting('bags_start'), wastage_pct: Number(setting('bag_wastage_pct', '0')) || 0 }));
  route('PUT', '/api/bags/settings', ({ body }) => {
    if (body.wastage_pct !== undefined) { const n = Number(body.wastage_pct); if (!(n >= 0 && n <= 20)) throw new E('Wastage: 0 to 20 %.'); setSetting('bag_wastage_pct', String(n)); }
    if (body.start !== undefined) { checkEditPassword(body.edit_password); if (!/^\d{4}-\d{2}-\d{2}$/.test(String(body.start))) throw new E('Choose the start date.'); setSetting('bags_start', body.start); }
    return { ok: true };
  });
  route('GET', '/api/bags/stock', ({ q }) => stock(q.to));
  route('GET', '/api/bags/moves', ({ q }) => all(`SELECT m.*, p.name AS party_name FROM bag_moves m LEFT JOIN parties p ON p.id = m.party_id
    WHERE (? = '' OR m.date >= ?) AND (? = '' OR m.date <= ?) ORDER BY m.date DESC, m.id DESC LIMIT 2000`, q.from || '', q.from || '', q.to || '', q.to || '')
    .map(m => ({ ...m, name: (get('SELECT name FROM bag_info WHERE nkey = ?', m.nkey) || {}).name || m.nkey })));
  // bags used by invoices, month by month and invoice by invoice
  route('GET', '/api/bags/usage', ({ q }) => {
    const start = setting('bags_start'), from = q.from && q.from > start ? q.from : start, to = q.to || localToday();
    const T = new Map(types().map(t => [t.nkey, t.name]));
    return usage(from, to).map(u => ({ date: u.date, nkey: u.nkey, name: T.get(u.nkey) || u.nkey || '(no bag type)', bags: u.bags, inv: `${u.l.firm_code} ${u.l.inv_no}`, invoice_id: u.l.id,
      party: u.l.party_name, item: [u.l.item_name, u.l.grade].filter(Boolean).join(' '), qty: u.l.qty, part: u.inner ? 'inner' : u.liner ? 'liner' : '' }));
  });
  function saveMove(b, id) {
    const kind = String(b.kind || '').toUpperCase();
    if (!['OPENING', 'PURCHASE', 'BUYER', 'ADJUST'].includes(kind)) throw new E('Choose the kind of entry.');
    const k = keyOf(b.bag_type); if (!k) throw new E('Choose the bag type.');
    const old = id ? get('SELECT * FROM bag_moves WHERE id = ?', id) : null;
    // only the bag types of Master → Item List → Bag type (or another name joined to one of them)
    const { root } = resolver(), rk = root(k);
    if (rk !== LINER && !types().some(t => t.in_list && t.nkey === rk)) throw new E(`"${b.bag_type}" is not in Master → Item List → Bag type. Add it there first (or join it to one with "Same as").`);
    if (id && !old) throw new E('This entry is not there any more.');
    if (kind === 'OPENING' || (old && old.kind === 'OPENING')) checkEditPassword(b.edit_password);          // opening stock: edit password
    let bags = b.bags === '' || b.bags == null ? null : Number(b.bags), w = b.weight_kg === '' || b.weight_kg == null ? null : Number(b.weight_kg);
    const info = get('SELECT * FROM bag_info WHERE nkey = ?', k) || {};
    if (kind !== 'ADJUST' && bags != null && bags < 0) throw new E('The number of bags cannot be below 0.');
    if (bags == null && w > 0) {          // count from the weight on the bill
      if (!(info.empty_g > 0)) throw new E(`Enter the number of bags, or first set the empty weight of ${info.name || b.bag_type} (Bags → Bag types).`);
      bags = Math.round(w * 1000 / info.empty_g);
    }
    if (!bags) throw new E('Enter the number of bags (or the weight).');
    if (w > 0 && bags > 0 && !(info.empty_g > 0))        // learn the empty weight from the bill
      run(`INSERT INTO bag_info(nkey, name, empty_g) VALUES(?, ?, ?) ON CONFLICT(nkey) DO UPDATE SET empty_g = excluded.empty_g`, k, String(b.bag_type).trim().toUpperCase(), r2(w * 1000 / bags));
    const rate = b.rate === '' || b.rate == null ? null : Number(b.rate), per = String(b.rate_per || 'BAG').toUpperCase() === 'KG' ? 'KG' : 'BAG';
    if (per === 'KG' && rate && !(w > 0)) throw new E('Rate per kg needs the weight in kg.');
    const amount = kind === 'BUYER' || !rate ? null : r2(per === 'KG' ? rate * w : rate * bags);
    const party = kind === 'BUYER' ? Number(b.party_id) || null : null;
    if (kind === 'BUYER' && !party) throw new E('Choose the buyer who sent the bags.');
    if (!get('SELECT 1 FROM bag_info WHERE nkey = ?', k)) run('INSERT INTO bag_info(nkey, name) VALUES(?, ?)', k, String(b.bag_type).trim().toUpperCase());
    const o = { date: b.date || localToday(), kind, nkey: k, bags, weight_kg: w, rate, rate_per: rate ? per : null, amount, supplier: kind === 'PURCHASE' ? String(b.supplier || '').trim().toUpperCase() || null : null,
      bill_no: String(b.bill_no || '').trim() || null, party_id: party, note: String(b.note || '').trim() || null, grp: b.grp || null };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(o.date)) throw new E('Enter the date.');
    const keys = Object.keys(o);
    if (id) run(`UPDATE bag_moves SET ${keys.map(x => x + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(x => o[x]), id);
    else id = Number(run(`INSERT INTO bag_moves(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(x => o[x])).lastInsertRowid);
    backup.backupSoon('bags');
    return { id, bags, cost_per_bag: amount ? r2(amount / bags) : null };
  }
  route('POST', '/api/bags/moves', ({ body }) => saveMove(body));
  // one bill / invoice with several bag types: { head: {kind, date, supplier, bill_no, party_id, note, edit_password}, lines: [{bag_type, bags, weight_kg, rate, rate_per}], ids: [entries it replaces] }
  route('POST', '/api/bags/batch', ({ body }) => {
    const head = body.head || {}, lines = (Array.isArray(body.lines) ? body.lines : []).filter(l => l && (String(l.bag_type || '').trim() || l.bags || l.weight_kg));
    if (!lines.length) throw new E('Add at least one bag type.');
    if (lines.length > 50) throw new E('At most 50 bag types in one entry.');
    const ids = (Array.isArray(body.ids) ? body.ids : []).map(Number).filter(Boolean);
    const olds = ids.map(i => get('SELECT * FROM bag_moves WHERE id = ?', i)).filter(Boolean);
    if (olds.some(o => o.kind === 'OPENING') && String(head.kind).toUpperCase() !== 'OPENING') checkEditPassword(head.edit_password);
    const seen = new Set();
    for (const [i, l] of lines.entries()) { const k = keyOf(l.bag_type); if (!k) throw new E(`Line ${i + 1}: choose the bag type.`);
      if (seen.has(k)) throw new E(`${String(l.bag_type).trim().toUpperCase()} is twice — put the bags together in one line.`); seen.add(k); }
    const grp = olds.find(o => o.grp) ? olds.find(o => o.grp).grp : Date.now();
    const out = tx(() => {
      for (const o of olds) run('DELETE FROM bag_moves WHERE id = ?', o.id);
      return lines.map((l, i) => { try { return saveMove({ ...head, ...l, grp: lines.length > 1 || olds.length > 1 ? grp : null }); }
        catch (e) { if (lines.length > 1) e.message = `Line ${i + 1} (${String(l.bag_type || '').trim().toUpperCase()}): ${e.message}`; throw e; } });
    });
    return { saved: out.length, bags: out.reduce((a, r) => a + r.bags, 0), lines: out };
  });
  route('PUT', '/api/bags/moves/:id', ({ p, body }) => saveMove(body, Number(p.id)));
  route('DELETE', '/api/bags/moves/:id', ({ p, q }) => {
    const m = get('SELECT kind FROM bag_moves WHERE id = ?', p.id); if (!m) return { deleted: true };
    if (m.kind === 'OPENING') checkEditPassword(q.pw);
    run('DELETE FROM bag_moves WHERE id = ?', p.id); backup.backupSoon('bags'); return { deleted: true };
  });
};
module.exports.nk = nk;
// a bag type renamed in Item List keeps its settings and its stock
module.exports.renamed = (oldName, newName) => {
  const a = nk(oldName), b = nk(newName); if (!a || !b || a === b) return;
  const info = get('SELECT * FROM bag_info WHERE nkey = ?', a);
  if (info && !get('SELECT 1 FROM bag_info WHERE nkey = ?', b)) {
    run(`INSERT INTO bag_info(nkey, name, empty_g, kind, combo_outer, combo_inner, combo_count, has_liner, owner_party_id, min_stock) SELECT ?, ?, empty_g, kind, combo_outer, combo_inner, combo_count, has_liner, owner_party_id, min_stock FROM bag_info WHERE nkey = ?`, b, String(newName).trim().toUpperCase(), a);
  }
  run('UPDATE bag_moves SET nkey = ? WHERE nkey = ?', b, a);
  run(`INSERT INTO bag_info(nkey, name, same_as) VALUES(?, ?, ?) ON CONFLICT(nkey) DO UPDATE SET same_as = excluded.same_as`, a, String(oldName).trim().toUpperCase(), b);
  run('UPDATE bag_info SET combo_outer = ? WHERE combo_outer = ?', b, a); run('UPDATE bag_info SET combo_inner = ? WHERE combo_inner = ?', b, a); run('UPDATE bag_info SET same_as = ? WHERE same_as = ? AND nkey <> ?', b, a, a);
};
