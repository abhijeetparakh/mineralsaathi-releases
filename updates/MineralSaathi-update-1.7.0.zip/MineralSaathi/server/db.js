'use strict';
// Database access. Only the server process on the main PC touches the database file,
// so several PCs can work at the same time without clashes.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.MS_DATA_DIR || path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'mineral.db');

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---- upgrades for databases made by older versions ----
function addColumn(table, col, type) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`);
}
addColumn('invoice_items', 'bag_supply', 'TEXT');
addColumn('invoice_items', 'liner', 'INTEGER');
addColumn('inwards', 'to_party', 'TEXT');
addColumn('firms', 'logo', 'TEXT');
for (const c of ['colour', 'mesh', 'form', 'packing_type']) addColumn('items', c, 'TEXT');

// starting values for the pick-lists (only for a list that is still empty)
const SEED = {
  product: ['DIATOMACEOUS EARTH', 'DIATOMACEOUS EARTH (RAW)', 'ZEOCLAY', 'BENTONITE', 'GYPSUM', 'ORGASIL', 'DEE-E', 'SUPER-SIL', 'FOUNDASIL', 'S.R.FILLER'],
  colour: ['YELLOW', 'WHITE', 'GREY', 'BROWN'],
  mesh: ['150', '200', '300', '325', '400+', '500+'],
  form: ['POWDER', 'GRANULES', 'CHIPS 2MM TO 4MM', 'LUMPS', 'RAW'],
  bag_type: ['PLAIN', 'PLAIN LAMINATED', 'PRINTED LAMINATED', '4 COLOUR LAMINATED', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'HDPE', 'JUMBO BAG'],
  hsn: [['251200', 'Diatomaceous earth / siliceous earths', 5], ['250810', 'Bentonite', 5], ['250840', 'Other clays (zeoclay)', 5], ['252010', 'Gypsum', 5], ['2512', 'Diatomaceous earth (4 digit)', 5]],
  bag_weight: [['1', '', 1], ['2', '', 2], ['5', '', 5], ['20', '', 20], ['22', '', 22], ['25', '', 25], ['30', '', 30], ['40', '', 40], ['50', '', 50], ['1000', 'Jumbo', 1000]],
  packing_type: ['WITH LINER', 'WITHOUT LINER', "BUYER'S OWN BAGS", '5 KG x 6 (30 KG)', 'LOOSE / BULK'],
  unit: ['MT', 'KG', 'BAGS', 'NOS'],
  gst_rate: [['0', '', 0], ['5', '', 5], ['12', '', 12], ['18', '', 18]],
  condition: ['RAW', 'BROKEN', 'DRY', 'WET'],
  mines: ['BADIARA', 'MANDAI']
};
for (const [key, vals] of Object.entries(SEED)) {
  if (db.prepare('SELECT 1 FROM lists WHERE list_key = ? LIMIT 1').get(key)) continue;
  const ins = db.prepare('INSERT OR IGNORE INTO lists(list_key, value, note, num, sort) VALUES(?,?,?,?,?)');
  vals.forEach((v, i) => Array.isArray(v) ? ins.run(key, v[0], v[1] || null, v[2] ?? null, i) : ins.run(key, v, null, null, i));
}
// bag types already used in the data join the list
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'bag_type', upper(trim(bag_type)), 100 FROM items WHERE COALESCE(bag_type,'') <> ''`);
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'product', upper(trim(name)), 100 FROM items WHERE COALESCE(name,'') <> ''`);
// P.P. Enterprise vouchers: goods go FROM P.P. Enterprise TO Parakh Marketing
db.exec(`UPDATE inwards SET supplier = 'P.P.ENTERPRISE', to_party = 'PARAKH MARKETING'
         WHERE voucher_no LIKE 'PPE-V%' AND (to_party IS NULL OR supplier IS NOT 'P.P.ENTERPRISE')`);
// buyers without a usual transporter get the one from their latest invoice
db.exec(`UPDATE parties SET transporter = (SELECT i.transporter FROM invoices i WHERE i.party_id = parties.id AND COALESCE(i.transporter,'') <> ''
           ORDER BY i.date DESC, i.id DESC LIMIT 1) WHERE COALESCE(transporter,'') = ''`);
// e-mail addresses are always kept in small letters
db.exec(`UPDATE parties SET email = lower(email) WHERE email <> lower(email);
         UPDATE firms SET email = lower(email), smtp_user = lower(smtp_user) WHERE email <> lower(email) OR smtp_user <> lower(smtp_user);
         UPDATE transporters SET email = lower(email) WHERE email <> lower(email);`);

const fix = p => p.map(v => v === undefined ? null : (typeof v === 'boolean' ? (v ? 1 : 0) : v));
const all = (sql, ...p) => db.prepare(sql).all(...fix(p)).map(r => ({ ...r }));
const get = (sql, ...p) => { const r = db.prepare(sql).get(...fix(p)); return r ? { ...r } : null; };
const run = (sql, ...p) => db.prepare(sql).run(...fix(p));

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}

const colCache = {};
function columns(table) {
  if (!colCache[table]) colCache[table] = all(`PRAGMA table_info(${table})`).map(c => c.name);
  return colCache[table];
}

function setting(key, fallback = null) {
  const r = get('SELECT value FROM settings WHERE key = ?', key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value == null ? null : String(value));
}

module.exports = { db, all, get, run, tx, columns, setting, setSetting, DB_FILE, DATA_DIR, ROOT };
