'use strict';
// Mineral Saathi server — runs on the main office PC. Every PC opens http://<main-pc>:7070 full screen.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { all, get, run, columns, setting, setSetting, ROOT, DATA_DIR } = require('./db');
const L = require('./logic');
const backup = require('./backup');
const { invoiceHtml, voucherHtml } = require('./print');
const { smtpSend, splitAddr } = require('./mailer');
const { makePdf } = require('./pdf');
const updater = require('./updater');

const PORT = Number(process.env.MS_PORT || 8765);
const PUBLIC = path.join(ROOT, 'public');
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;

const MASTER_TABLES = ['parties', 'items', 'transporters', 'lorries', 'suppliers', 'plants', 'firms'];
const SEARCH_COLS = {
  parties: ['name', 'city', 'gstin', 'group_name'], items: ['name', 'grade', 'hsn'], transporters: ['name', 'district', 'gstin'],
  lorries: ['lorry_no', 'owner', 'pan', 'driver_name'], suppliers: ['name', 'grade'], plants: ['name', 'full_name'], firms: ['name', 'code']
};
const ORDER = { parties: 'name', items: 'name, grade', transporters: 'name', lorries: 'lorry_no', suppliers: 'name', plants: 'name', firms: 'id' };

// ---------- helpers ----------
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', c => { d += c; if (d.length > 50e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { reject(new L.UserError('Bad data sent.')); } });
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

function serveStatic(res, urlPath) {
  const p = path.normalize(path.join(PUBLIC, urlPath === '/' ? 'index.html' : urlPath));
  if (!p.startsWith(PUBLIC) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) return send(res, 404, 'Not found', 'text/plain');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(p).pipe(res);
}

function cleanRow(table, body) {
  const cols = columns(table).filter(c => c !== 'id');
  const o = {};
  for (const c of cols) if (body[c] !== undefined) o[c] = body[c] === '' ? null : body[c];
  L.normalize(o);
  return o;
}

function checkParty(o, id) {
  if (o.name !== undefined && !String(o.name || '').trim()) throw new L.UserError('Enter the buyer name.');
  if (!id && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Choose the billing firm for this buyer (Parakh Marketing or Parakh Fertilizer).');
  if (o.firm_code !== undefined && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Billing firm must be Parakh Marketing or Parakh Fertilizer.');
  if (id && o.firm_code !== undefined) {
    const cur = get('SELECT firm_code FROM parties WHERE id = ?', id);
    const used = get('SELECT COUNT(*) AS n FROM invoices WHERE party_id = ? AND legacy = 0', id).n;
    if (cur && cur.firm_code && cur.firm_code !== o.firm_code && used)
      throw new L.UserError('This buyer already has invoices, so its billing firm is fixed.');
  }
  if (o.gstin) {
    o.gstin = String(o.gstin).toUpperCase().trim();
    if (!/^\d{2}[A-Z0-9]{13}$/.test(o.gstin)) throw new L.UserError('GSTIN should be 15 characters, like 08AIVPP2793C1ZQ.');
    o.state_code = o.gstin.slice(0, 2);
    if (!o.pan) o.pan = o.gstin.slice(2, 12);
  } else if (o.state) {
    o.state_code = L.stateCode(o.state) || o.state_code;
  }
  if (o.state) o.state = String(o.state).toUpperCase();
  o.is_b2c = o.gstin ? 0 : (o.is_b2c ?? 1);
}

function emailDraft(inv) {
  const f = inv.firm;
  const it = inv.items.map(i => `${i.item_name}${i.grade ? ' ' + i.grade : ''} — ${i.qty} ${i.unit}${i.bags ? ' (' + i.bags + ' bags)' : ''}`).join('\n');
  const d = inv.date ? inv.date.split('-').reverse().join('.') : '';
  const text = `Dear Sir / Madam,

Please find attached our invoice. Details of the dispatch are below${inv.ewb_no ? ', and the E-Way Bill No. is ' + inv.ewb_no : ''}.

Invoice No.: ${inv.inv_no}   Date: ${d}
${it}
Lorry No.: ${inv.lorry_no || '-'}
Transporter: ${inv.transporter || '-'}   L.R. No.: ${inv.lr_no || '-'}
Driver Ph.: ${inv.driver_phone || '-'}
${inv.freight_note ? 'Freight: ' + inv.freight_note + '\n' : ''}Invoice amount: Rs. ${Number(inv.total).toLocaleString('en-IN')}

Kindly acknowledge receipt.

Regards,
${f.name}
${f.phone || ''}  ${f.email || ''}`;
  const to = inv.party ? splitAddr(inv.party.email) : [];
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: `Invoice ${inv.inv_no} dt ${d} — ${f.name}`, text };
}

function pdfFolder() { return setting('pdf_folder') || path.join(DATA_DIR, 'pdf'); }
function safeName(s) { return String(s).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80); }

// ---------- routes ----------
const routes = [];
const route = (method, pattern, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

route('GET', '/api/version', () => ({ version: VERSION }));

route('GET', '/api/meta', () => ({
  version: VERSION,
  firms: all('SELECT id, code, name, gstin, state_code FROM firms ORDER BY id'),
  plants: all('SELECT name, full_name FROM plants ORDER BY name'),
  current_fy: L.fyOf(),
  fys: all(`SELECT fy FROM (SELECT fy FROM invoices UNION SELECT fy FROM inwards) ORDER BY fy DESC`).map(r => r.fy),
  states: Object.keys(L.STATE_CODES),
  host: os.hostname()
}));

route('GET', '/api/dashboard', ({ q }) => {
  const fy = q.fy || L.fyOf();
  const month = new Date().toISOString().slice(0, 7);
  return {
    fy,
    sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total, ROUND(SUM(taxable)) taxable FROM invoices WHERE fy = ? AND cancelled = 0 GROUP BY firm_code`, fy),
    month_sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total FROM invoices WHERE date LIKE ? AND cancelled = 0 GROUP BY firm_code`, month + '%'),
    inward: get(`SELECT COUNT(*) n, ROUND(SUM(actual_wt), 2) actual, ROUND(SUM(rawana_wt), 2) rawana, ROUND(SUM(freight_amt)) freight FROM inwards WHERE fy = ?`, fy),
    unbilled: get(`SELECT COUNT(*) n, ROUND(SUM(rawana_wt), 2) qty FROM inwards WHERE fy = ? AND ppe_invoice_id IS NULL AND supplier LIKE '%ENTERPRISE%'`, fy),
    recent: all(`SELECT id, firm_code, inv_no, date, party_name, total, kind FROM invoices WHERE cancelled = 0 ORDER BY date DESC, id DESC LIMIT 8`),
    last_backup: setting('last_backup'), backup_error: setting('last_backup_error')
  };
});

// masters
route('GET', '/api/m/:table', ({ p, q }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const where = []; const args = [];
  if (q.q) { where.push('(' + SEARCH_COLS[p.table].map(c => `${c} LIKE ?`).join(' OR ') + ')'); SEARCH_COLS[p.table].forEach(() => args.push('%' + q.q + '%')); }
  if (q.firm === 'NONE' && p.table === 'parties') where.push('firm_code IS NULL');
  else if (q.firm && p.table === 'parties') { where.push('firm_code = ?'); args.push(q.firm); }
  const limit = Math.min(Number(q.limit) || 500, 2000);
  const extra = p.table === 'parties' ? ', (SELECT COUNT(*) FROM party_items pi WHERE pi.party_id = parties.id AND pi.active = 1) AS item_count' : '';
  const rows = all(`SELECT *${extra} FROM ${p.table} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${ORDER[p.table]} LIMIT ${limit}`, ...args);
  if (p.table === 'firms') rows.forEach(r => delete r.smtp_pass);      // never send passwords to the screen
  return rows;
});
route('GET', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const r = get(`SELECT * FROM ${p.table} WHERE id = ?`, p.id);
  if (r && p.table === 'firms') delete r.smtp_pass;
  return r;
});
route('POST', '/api/m/:table', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table) || p.table === 'firms') throw new L.UserError('Cannot add here.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') checkParty(o);
  const keys = Object.keys(o);
  if (!keys.length) throw new L.UserError('Nothing to save.');
  const r = run(`INSERT INTO ${p.table}(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
  return { id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/m/:table/:id', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') checkParty(o, p.id);
  if (p.table === 'firms') {
    delete o.code; delete o.smtp_pass;
    if (o.state) { o.state = String(o.state).toUpperCase(); o.state_code = L.stateCode(o.state, o.gstin) || o.state_code; }
    if (o.gstin) o.gstin = String(o.gstin).toUpperCase().trim();
    if (o.pan) o.pan = String(o.pan).toUpperCase().trim();
    if (o.logo && !/^data:image\/(png|jpeg|webp);base64,/.test(o.logo)) throw new L.UserError('The logo must be a PNG or JPG picture.');
  }
  const keys = Object.keys(o);
  run(`UPDATE ${p.table} SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table) || ['firms'].includes(p.table)) throw new L.UserError('Cannot delete here.');
  if (p.table === 'parties' && get('SELECT 1 FROM invoices WHERE party_id = ?', p.id)) {
    run('UPDATE parties SET active = 0 WHERE id = ?', p.id);
    return { hidden: true };
  }
  run(`DELETE FROM ${p.table} WHERE id = ?`, p.id);
  return { deleted: true };
});

// items, rates and packing for one buyer
const PI_COLS = ['item_name', 'grade', 'hsn', 'gst_rate', 'rate', 'pack_size', 'bag_type', 'bag_supply', 'liner', 'notes', 'active'];
function cleanPartyItem(b) {
  const o = {};
  for (const c of PI_COLS) if (b[c] !== undefined) o[c] = b[c] === '' ? null : b[c];
  if (o.item_name !== undefined) { o.item_name = String(o.item_name || '').trim().toUpperCase(); if (!o.item_name) throw new L.UserError('Enter the item name.'); }
  if (o.grade) o.grade = String(o.grade).trim().toUpperCase();
  if (o.bag_type) o.bag_type = String(o.bag_type).trim().toUpperCase();
  for (const c of ['gst_rate', 'rate', 'pack_size']) if (o[c] != null) o[c] = Number(o[c]);
  if (o.liner != null) o.liner = Number(o.liner) ? 1 : 0;
  L.normalize(o);
  if (o.bag_supply && !['OUR', 'BUYER'].includes(o.bag_supply)) o.bag_supply = null;
  return o;
}
route('GET', '/api/parties/:id/items', ({ p }) => all('SELECT * FROM party_items WHERE party_id = ? AND active = 1 ORDER BY item_name, grade', p.id));
route('POST', '/api/parties/:id/items', ({ p, body }) => {
  if (!get('SELECT 1 FROM parties WHERE id = ?', p.id)) throw new L.UserError('Buyer not found.');
  const o = cleanPartyItem(body);
  if (!o.item_name) throw new L.UserError('Enter the item name.');
  if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'') AND active = 1`, p.id, o.item_name, o.grade))
    throw new L.UserError('This buyer already has this item and grade. Use Edit to change it.');
  const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
  if (!o.hsn) o.hsn = m?.hsn || '2512';
  if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
  o.party_id = Number(p.id);
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/party-items/:id', ({ p, body }) => {
  const o = cleanPartyItem(body); const keys = Object.keys(o);
  run(`UPDATE party_items SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/party-items/:id', ({ p }) => { run('DELETE FROM party_items WHERE id = ?', p.id); return { deleted: true }; });

// pick-lists
const LIST_KEYS = ['product', 'colour', 'mesh', 'form', 'bag_type', 'hsn', 'bag_weight', 'packing_type', 'unit', 'gst_rate', 'condition', 'mines'];
route('GET', '/api/lists', () => {
  const out = Object.fromEntries(LIST_KEYS.map(k => [k, []]));
  for (const r of all('SELECT * FROM lists WHERE active = 1 ORDER BY list_key, sort, value')) if (out[r.list_key]) out[r.list_key].push(r);
  return out;
});
function cleanList(b) {
  const o = {};
  if (b.list_key !== undefined) { if (!LIST_KEYS.includes(b.list_key)) throw new L.UserError('Unknown list.'); o.list_key = b.list_key; }
  if (b.value !== undefined) {
    o.value = String(b.value || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (!o.value) throw new L.UserError('Enter a value.');
  }
  if (b.note !== undefined) o.note = String(b.note || '').trim() || null;
  if (b.num !== undefined) o.num = b.num === '' || b.num == null ? null : Number(b.num);
  if (b.sort !== undefined) o.sort = Number(b.sort) || 0;
  return o;
}
route('POST', '/api/lists', ({ body }) => {
  const o = cleanList(body);
  if (!o.list_key || !o.value) throw new L.UserError('Enter a value.');
  if (['hsn', 'bag_weight', 'gst_rate'].includes(o.list_key) && !/^\d+(\.\d+)?$/.test(o.value)) throw new L.UserError('This list takes numbers only.');
  if (o.list_key === 'bag_weight' && o.num == null) o.num = Number(o.value);
  if (o.list_key === 'gst_rate') o.num = Number(o.value);
  if (get('SELECT 1 FROM lists WHERE list_key = ? AND value = ? AND active = 1', o.list_key, o.value)) throw new L.UserError(`"${o.value}" is already in the list.`);
  const old = get('SELECT id FROM lists WHERE list_key = ? AND value = ?', o.list_key, o.value);
  if (old) { run('UPDATE lists SET active = 1, note = ?, num = ? WHERE id = ?', o.note ?? null, o.num ?? null, old.id); return { id: old.id }; }
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO lists(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/lists/:id', ({ p, body }) => {
  const o = cleanList(body); delete o.list_key;
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE lists SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/lists/:id', ({ p }) => { run('UPDATE lists SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

// city & state from pincode (offline list of Indian pincodes)
let PINS = null;
route('GET', '/api/pincode/:pin', ({ p }) => {
  if (!PINS) PINS = JSON.parse(fs.readFileSync(path.join(__dirname, 'pincodes.json'), 'utf8'));
  const v = PINS[String(p.pin).replace(/\D/g, '')];
  if (!v) return { found: false };
  const [city, state] = v.split('|');
  return { found: true, city, state, state_code: L.stateCode(state) };
});

route('GET', '/api/lorry/:no', ({ p }) => {
  const no = decodeURIComponent(p.no).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const l = get('SELECT * FROM lorries WHERE lorry_no = ?', no);
  const last = get('SELECT supplier, mines, grade, plant, freight_rate, owner_name, pan, driver_name, driver_phone, upi FROM inwards WHERE lorry_no = ? ORDER BY id DESC LIMIT 1', no);
  return { lorry: l, last };
});

// inwards
route('GET', '/api/inwards', ({ q }) => {
  const where = ['w.fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.q) { where.push('(w.lorry_no LIKE ? OR w.voucher_no LIKE ? OR w.rawana_no LIKE ? OR w.supplier LIKE ? OR w.owner_name LIKE ?)'); for (let i = 0; i < 5; i++) args.push('%' + q.q + '%'); }
  if (q.status === 'unbilled') where.push('w.ppe_invoice_id IS NULL');
  if (q.status === 'billed') where.push('w.ppe_invoice_id IS NOT NULL');
  if (q.supplier) { where.push('w.supplier LIKE ?'); args.push('%' + q.supplier + '%'); }
  return all(`SELECT w.*, i.inv_no AS ppe_inv_no FROM inwards w LEFT JOIN invoices i ON i.id = w.ppe_invoice_id
              WHERE ${where.join(' AND ')} ORDER BY w.date DESC, w.id DESC LIMIT 2000`, ...args);
});
route('GET', '/api/inwards/next', ({ q }) => ({ voucher_no: L.nextVoucherNo(q.fy || L.fyOf(q.date), q.firm) }));
route('GET', '/api/inwards/:id', ({ p }) => get('SELECT * FROM inwards WHERE id = ?', p.id));
route('POST', '/api/inwards', ({ body }) => ({ id: L.saveInward(body) }));
route('PUT', '/api/inwards/:id', ({ p, body }) => ({ id: L.saveInward(body, Number(p.id)) }));
route('DELETE', '/api/inwards/:id', ({ p }) => {
  const w = get('SELECT * FROM inwards WHERE id = ?', p.id);
  if (!w) throw new L.UserError('Not found.');
  if (w.ppe_invoice_id) throw new L.UserError('This lorry is billed. Cancel the P.P. Enterprise bill first.');
  run('DELETE FROM inwards WHERE id = ?', p.id);
  return { deleted: true };
});

// invoices
route('GET', '/api/invoices', ({ q }) => {
  const where = ['fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.firm) { where.push('firm_code = ?'); args.push(q.firm); }
  if (q.kind) { where.push('kind = ?'); args.push(q.kind); }
  if (q.q) { where.push('(party_name LIKE ? OR lorry_no LIKE ? OR CAST(inv_no AS TEXT) = ? OR ewb_no LIKE ?)'); args.push('%' + q.q + '%', '%' + q.q + '%', q.q, '%' + q.q + '%'); }
  return all(`SELECT id, firm_code, fy, inv_no, date, kind, party_name, party_gstin, supply_type, lorry_no, ewb_no, taxable, cgst, sgst, igst, total,
              email_sent_at, legacy, cancelled, (SELECT ROUND(SUM(qty), 3) FROM invoice_items WHERE invoice_id = invoices.id) AS qty,
              (SELECT COUNT(*) FROM invoice_items WHERE invoice_id = invoices.id) AS lines
              FROM invoices WHERE ${where.join(' AND ')} ORDER BY date DESC, inv_no DESC LIMIT 3000`, ...args);
});
route('GET', '/api/invoices/next', ({ q }) => ({ inv_no: L.nextInvoiceNo(q.firm, q.fy || L.fyOf(q.date)) }));
route('GET', '/api/invoices/:id', ({ p }) => L.invoiceFull(p.id));
route('POST', '/api/invoices', ({ body }) => { const id = L.saveSale(body); backup.backupSoon('invoice'); return { id }; });
route('PUT', '/api/invoices/:id', ({ p, body }) => { const id = L.saveSale(body, Number(p.id)); backup.backupSoon('invoice'); return { id }; });
route('POST', '/api/invoices/:id/cancel', ({ p }) => { L.cancelInvoice(p.id); backup.backupSoon('cancel'); return { ok: true }; });
route('POST', '/api/ppe-bills', ({ body }) => { const id = L.savePpeBill(body); backup.backupSoon('invoice'); return { id }; });
route('PUT', '/api/ppe-bills/:id', ({ p, body }) => { const id = L.savePpeBill(body, Number(p.id)); backup.backupSoon('invoice'); return { id }; });
route('POST', '/api/ewaybill-json', ({ body }) => L.ewayBillJson(body));
route('POST', '/api/totals', ({ body }) => {
  // live preview of totals while typing an invoice
  const firmCode = body.firm_code || (body.party_id && get('SELECT firm_code FROM parties WHERE id = ?', body.party_id)?.firm_code) || 'PM';
  const f = get('SELECT * FROM firms WHERE code = ?', firmCode);
  const items = (body.items || []).map(it => ({ qty: Number(it.qty) || 0, rate: Number(it.rate) || 0, gst_rate: Number(it.gst_rate ?? 5) }));
  const t = L.computeTotals(items, f, L.stateCode(body.state, body.gstin) || body.state_code);
  return { ...t, words: L.inWords(t.total) };
});

route('GET', '/api/invoices/:id/email', ({ p }) => {
  const inv = L.invoiceFull(p.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  return { ...emailDraft(inv), from: inv.firm.smtp_user || inv.firm.email, ready: !!(inv.firm.smtp_user && inv.firm.smtp_pass) };
});
route('POST', '/api/invoices/:id/email', async ({ p, body }) => {
  const inv = L.invoiceFull(p.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  const f = inv.firm;
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError(`Email is not set up for ${f.name}. Open Settings → Email.`);
  const to = splitAddr(body.to), cc = splitAddr(body.cc);
  if (!to.length) throw new L.UserError('Enter the buyer email address.');
  const file = path.join(pdfFolder(), inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} ${inv.party_name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/invoice/${inv.id}`, file);
  const attachments = [{ path: file, filename: path.basename(file) }];
  for (const extra of body.extra_files || []) if (extra && fs.existsSync(extra)) attachments.push({ path: extra });
  await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, to, cc, subject: body.subject || 'Invoice', text: body.text || '', attachments });
  const at = new Date().toLocaleString('en-IN');
  run('UPDATE invoices SET email_sent_at = ? WHERE id = ?', at, inv.id);
  return { sent: true, at, pdf: file };
});
route('POST', '/api/invoices/:id/pdf', async ({ p }) => {
  const inv = L.invoiceFull(p.id);
  const file = path.join(pdfFolder(), inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} ${inv.party_name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/invoice/${inv.id}`, file);
  return { pdf: file };
});

// settings & backup
route('GET', '/api/settings', () => ({
  backup_folder: backup.folder(), pdf_folder: pdfFolder(), last_backup: setting('last_backup'),
  last_backup_file: setting('last_backup_file'), last_backup_error: setting('last_backup_error'), backups: backup.list(), version: VERSION,
  firms: all(`SELECT id, code, name, smtp_host, smtp_port, smtp_user, CASE WHEN smtp_pass IS NULL OR smtp_pass = '' THEN 0 ELSE 1 END AS has_pass FROM firms`)
}));
route('PUT', '/api/settings', ({ body }) => {
  if (body.backup_folder !== undefined) {
    const dir = String(body.backup_folder).trim();
    if (!dir) throw new L.UserError('Enter a backup folder.');
    try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); }
    catch { throw new L.UserError('The main PC cannot write to that folder. Check the path.'); }
    setSetting('backup_folder', dir);
  }
  if (body.pdf_folder !== undefined) {
    const dir = String(body.pdf_folder).trim();
    if (dir) { try { fs.mkdirSync(dir, { recursive: true }); } catch { throw new L.UserError('Cannot use that PDF folder.'); } }
    setSetting('pdf_folder', dir || null);
  }
  return { ok: true };
});
route('PUT', '/api/settings/email/:code', ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f) throw new L.UserError('Unknown firm.');
  run('UPDATE firms SET smtp_host = ?, smtp_port = ?, smtp_user = ? WHERE id = ?', body.smtp_host || 'smtp.gmail.com', Number(body.smtp_port) || 465, body.smtp_user || null, f.id);
  if (body.smtp_pass) run('UPDATE firms SET smtp_pass = ? WHERE id = ?', String(body.smtp_pass).replace(/\s+/g, ''), f.id);
  return { ok: true };
});
route('POST', '/api/settings/email/:code/test', async ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError('Save the email and app password first.');
  await smtpSend({ host: f.smtp_host, port: f.smtp_port, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, to: splitAddr(body.to || f.smtp_user), cc: [], subject: 'Mineral Saathi test email', text: 'Email from Mineral Saathi is working.' });
  return { sent: true };
});
route('POST', '/api/backup', () => ({ file: backup.backupNow('manual') }));

// automatic updates
route('GET', '/api/update', () => updater.status());
route('POST', '/api/update/check', ({ body }) => updater.check({ install: !!body.install, force: !!body.install }));
route('PUT', '/api/update/settings', ({ body }) => {
  if (body.auto !== undefined) setSetting('auto_update', body.auto ? '1' : '0');
  if (body.source !== undefined) setSetting('update_source', String(body.source || '').trim() || null);
  return updater.status();
});

// import data file made from an old Excel workbook (buyers + invoices).
// Safe to run twice: existing invoice numbers are skipped, existing buyers are never moved to another firm.
route('POST', '/api/import', ({ body }) => {
  if (body.kind === 'mineral-saathi-buyer-items') return importBuyerItems(body);
  if (body.kind !== 'mineral-saathi-import' || !['PM', 'PF'].includes(body.firm_code)) throw new L.UserError('This is not a Mineral Saathi data file.');
  const firm = body.firm_code;
  const BUYER_COLS = ['gstin', 'pan', 'address', 'city', 'state', 'state_code', 'pincode', 'ship_address', 'email', 'mobile', 'phone', 'transporter', 'km', 'group_name', 'payment_terms', 'notes'];
  const rep = { buyers_added: [], buyers_filled: 0, buyers_other_firm: [], buyers_no_firm: [], invoices_added: 0, invoices_skipped: [], invoices_existing: 0 };
  const findParty = (gstin, name, city) =>
    (gstin && get('SELECT * FROM parties WHERE upper(gstin) = upper(?)', gstin)) ||
    get(`SELECT * FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, name || '', city || '') ||
    (!city ? get('SELECT * FROM parties WHERE upper(name) = upper(?)', name || '') : null);

  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      if (!b.name || (!b.gstin && !b.city && !b.address)) continue;          // skip placeholder rows like "ONLINE"
      if (b.email) b.email = String(b.email).toLowerCase();
      const ex = findParty(b.gstin, b.name, b.city);
      if (!ex) {
        const o = { name: b.name, firm_code: firm, is_b2c: b.gstin ? 0 : 1 };
        for (const c of BUYER_COLS) if (b[c] != null && b[c] !== '') o[c] = b[c];
        const keys = Object.keys(o);
        run(`INSERT INTO parties(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.buyers_added.push(`${b.name}${b.city ? ' — ' + b.city : ''}`);
        continue;
      }
      // fill only empty fields, never overwrite what is already there
      const fill = BUYER_COLS.filter(c => (ex[c] == null || ex[c] === '') && b[c] != null && b[c] !== '');
      if (fill.length) { run(`UPDATE parties SET ${fill.map(c => c + ' = ?').join(', ')} WHERE id = ?`, ...fill.map(c => b[c]), ex.id); rep.buyers_filled++; }
      if (!ex.firm_code) rep.buyers_no_firm.push(ex.name);
      else if (ex.firm_code !== firm) rep.buyers_other_firm.push(`${ex.name}${ex.city ? ' — ' + ex.city : ''}`);
    }
    for (const inv of body.invoices || []) {
      const ex = get('SELECT legacy FROM invoices WHERE firm_code = ? AND fy = ? AND inv_no = ?', firm, inv.fy, inv.inv_no);
      if (ex) { if (ex.legacy) rep.invoices_existing++; else rep.invoices_skipped.push(`${inv.fy} no. ${inv.inv_no}`); continue; }
      const p = findParty(inv.party_gstin, inv.party_name, inv.party_city);
      const cols = ['fy', 'inv_no', 'date', 'party_name', 'party_gstin', 'party_address', 'party_city', 'party_state', 'party_state_code', 'ship_address',
        'supply_type', 'lorry_no', 'transporter', 'lr_no', 'driver_phone', 'plant', 'ewb_no', 'freight_note', 'email_sent_at', 'notes', 'taxable', 'cgst', 'sgst', 'igst', 'total'];
      const r = run(`INSERT INTO invoices(firm_code, kind, legacy, round_off, party_id, party_pan, ${cols.join(',')})
                     VALUES(?, 'SALE', 1, 0, ?, ?, ${cols.map(() => '?').join(',')})`, firm, p ? p.id : null, p ? p.pan : null, ...cols.map(c => inv[c] ?? null));
      const id = Number(r.lastInsertRowid);
      (inv.items || []).forEach((it, i) => run(`INSERT INTO invoice_items(invoice_id, sl, item_name, grade, hsn, qty, unit, rate, amount, gst_rate, bags, pack_size, bag_type, lorry_no)
        VALUES(?,?,?,?,?,?,'MT',?,?,?,?,?,?,?)`, id, i + 1, it.item_name, it.grade, it.hsn, it.qty, it.rate, it.amount, it.gst_rate, it.bags, it.pack_size, it.bag_type, it.lorry_no));
      rep.invoices_added++;
    }
  });
  backup.backupSoon('import');
  return rep;
});

// buyer items & rates from the old Excel buyer lists. Adds only item+grade pairs the buyer does not have yet.
function importBuyerItems(body) {
  const rep = { items_added: 0, buyers_touched: 0, items_existing: 0, buyers_not_found: [] };
  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      const ex = (b.gstin && get('SELECT id FROM parties WHERE upper(gstin) = upper(?)', b.gstin)) ||
        get(`SELECT id FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, b.name || '', b.city || '');
      if (!ex) { rep.buyers_not_found.push(b.name); continue; }
      let touched = false;
      for (const it of b.items || []) {
        const o = cleanPartyItem(it);
        if (!o.item_name) continue;
        if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'')`, ex.id, o.item_name, o.grade)) { rep.items_existing++; continue; }
        o.party_id = ex.id;
        const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
        if (!o.hsn) o.hsn = m?.hsn || '2512';
        if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
        const keys = Object.keys(o);
        run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.items_added++; touched = true;
      }
      if (touched) rep.buyers_touched++;
    }
  });
  backup.backupSoon('import');
  return { ...rep, buyers_added: [], buyers_other_firm: [], buyers_no_firm: [], invoices_skipped: [], invoices_added: 0, buyers_filled: 0, kind: 'items' };
}

// reports
route('GET', '/api/reports/monthly', ({ q }) => {
  const fy = q.fy || L.fyOf();
  return {
    sales: all(`SELECT substr(date,1,7) ym, firm_code, COUNT(*) n, ROUND(SUM(qty),3) qty, ROUND(SUM(taxable)) taxable,
                ROUND(SUM(cgst+sgst+igst)) tax, ROUND(SUM(total)) total
                FROM (SELECT i.*, (SELECT SUM(qty) FROM invoice_items WHERE invoice_id = i.id) qty FROM invoices i WHERE fy = ? AND cancelled = 0)
                GROUP BY ym, firm_code ORDER BY ym, firm_code`, fy),
    inward: all(`SELECT substr(date,1,7) ym, COUNT(*) n, ROUND(SUM(rawana_wt),3) rawana, ROUND(SUM(actual_wt),3) actual, ROUND(SUM(freight_amt)) freight
                 FROM inwards WHERE fy = ? GROUP BY ym ORDER BY ym`, fy),
    hsn: all(`SELECT i.firm_code, it.hsn, it.gst_rate, ROUND(SUM(it.qty),3) qty, ROUND(SUM(it.amount),2) taxable
              FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id WHERE i.fy = ? AND i.cancelled = 0 GROUP BY 1,2,3 ORDER BY 1,2`, fy)
  };
});

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const q = Object.fromEntries(url.searchParams);
  try {
    let m;
    if ((m = url.pathname.match(/^\/print\/invoice\/(\d+)$/))) {
      const inv = L.invoiceFull(m[1]);
      return inv ? send(res, 200, invoiceHtml(inv, q.print === '1'), 'text/html; charset=utf-8') : send(res, 404, 'Not found', 'text/plain');
    }
    if ((m = url.pathname.match(/^\/print\/voucher\/(\d+)$/))) {
      const w = get('SELECT * FROM inwards WHERE id = ?', m[1]);
      return w ? send(res, 200, voucherHtml(w, q.print === '1'), 'text/html; charset=utf-8') : send(res, 404, 'Not found', 'text/plain');
    }
    if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const mm = url.pathname.match(r.re);
      if (!mm) continue;
      const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {};
      if (req.method !== 'GET' && !url.pathname.startsWith('/api/update')) updater.markWrite();
      const out = await r.fn({ p: mm.groups || {}, q, body, req });
      return send(res, 200, out ?? null);
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    if (!e.status) console.error(new Date().toISOString(), req.method, req.url, e);
    send(res, e.status || 500, { error: e.status ? e.message : 'Something went wrong: ' + e.message });
  }
});

if (require.main === module) {
  server.on('error', async e => {
    if (e.code !== 'EADDRINUSE') { console.error(e); process.exit(1); }
    let ours = false;
    try { const r = await fetch(`http://127.0.0.1:${PORT}/api/version`); ours = r.ok && !!(await r.json()).version; } catch { /* not ours */ }
    if (ours) {
      console.log(`\n  Mineral Saathi server is ALREADY RUNNING on this PC (port ${PORT}).`);
      console.log('  Nothing more to do — this extra window can be closed.\n');
      process.exit(2);
    }
    console.log(`\n  Port ${PORT} is used by another program on this PC.`);
    console.log('  Close that program, or restart the PC, then start Mineral Saathi again.\n');
    process.exit(3);
  });
  server.listen(PORT, '0.0.0.0', () => {
    const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
    console.log(`\n  Mineral Saathi server ${VERSION} is running.`);
    console.log(`  On this PC:      http://localhost:${PORT}`);
    for (const ip of ips) console.log(`  On other PCs:    http://${ip}:${PORT}`);
    console.log(`  Backups go to:   ${backup.folder()}\n  Keep this window open (you can minimise it).\n`);
  });
  server.once('listening', () => {
    updater.start();
    backup.startHourly();
    try { backup.backupNow('start'); } catch (e) { console.error('Start-up backup failed:', e.message); }
  });
}

module.exports = { server, routes };
