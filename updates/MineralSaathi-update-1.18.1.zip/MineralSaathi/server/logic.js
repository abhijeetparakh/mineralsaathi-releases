'use strict';
// Business rules for Mineral Saathi.
const { all, get, run, tx } = require('./db');

const STATE_CODES = {
  'JAMMU AND KASHMIR': '01', 'HIMACHAL PRADESH': '02', 'PUNJAB': '03', 'CHANDIGARH': '04', 'UTTARAKHAND': '05',
  'HARYANA': '06', 'DELHI': '07', 'RAJASTHAN': '08', 'UTTAR PRADESH': '09', 'BIHAR': '10', 'SIKKIM': '11',
  'ARUNACHAL PRADESH': '12', 'NAGALAND': '13', 'MANIPUR': '14', 'MIZORAM': '15', 'TRIPURA': '16', 'MEGHALAYA': '17',
  'ASSAM': '18', 'WEST BENGAL': '19', 'JHARKHAND': '20', 'ODISHA': '21', 'ORISSA': '21', 'CHHATTISGARH': '22',
  'CHATTISGARH': '22', 'MADHYA PRADESH': '23', 'GUJARAT': '24', 'DADRA AND NAGAR HAVELI AND DAMAN AND DIU': '26',
  'MAHARASHTRA': '27', 'KARNATAKA': '29', 'GOA': '30', 'LAKSHADWEEP': '31', 'KERALA': '32', 'TAMIL NADU': '33',
  'PUDUCHERRY': '34', 'ANDAMAN AND NICOBAR ISLANDS': '35', 'TELANGANA': '36', 'ANDHRA PRADESH': '37', 'LADAKH': '38'
};

const r2 = n => Math.round((Number(n) || 0) * 100) / 100;

// House rules for typed values:
//  e-mail: small letters · lorry no.: capitals, no spaces · pincode/phone: numbers only · amounts & weights: numbers
const PHONE_FIELDS = ['phone', 'mobile', 'driver_phone'];
const NUMBER_FIELDS = ['rate', 'qty', 'amount', 'rawana_wt', 'actual_wt', 'freight_rate', 'freight_amt', 'advance', 'cash_amt', 'bank_amt',
  'royalty', 'dmft', 'nmet', 'advance_freight', 'pack_size', 'gst_rate', 'bags', 'km', 'freight_rate'];
function normalize(o) {
  for (const k of Object.keys(o)) {
    const v = o[k];
    if (v == null || v === '') continue;
    if (k === 'email' || k === 'smtp_user') o[k] = String(v).toLowerCase().replace(/\s*[,;]\s*/g, '; ').trim();
    else if (k === 'lorry_no') o[k] = String(v).toUpperCase().split(',').map(x => x.replace(/[^A-Z0-9]/g, '')).filter(Boolean).join(', ');
    else if (k === 'gstin' || k === 'party_gstin' || k === 'pan' || k === 'party_pan' || k === 'transporter_gstin') o[k] = String(v).toUpperCase().replace(/[^A-Z0-9]/g, '') || null;
    else if (k === 'ewb_no') o[k] = String(v).replace(/\D/g, '') || null;
    else if (k === 'pincode' || k === 'party_pincode') o[k] = String(v).replace(/\D/g, '').slice(0, 6) || null;
    else if (PHONE_FIELDS.includes(k)) o[k] = String(v).split(/[,;/]/).map(x => x.replace(/\D/g, '')).filter(Boolean).join(', ') || null;
    else if (NUMBER_FIELDS.includes(k)) {
      const n = Number(String(v).replace(/[^0-9.\-]/g, ''));
      if (!Number.isFinite(n)) throw new UserError(`"${k.replace(/_/g, ' ')}" must be a number.`);
      o[k] = n;
    }
  }
  return o;
}

// Lorry owner's UPI made from the bank account: <account no>@<IFSC>.ifsc.npci  (e.g. 13020110030097@UCBA0001302.ifsc.npci)
// A UPI typed by hand (e.g. 98xxxxxxxx@ybl) is kept; one made this way is remade when the account or IFSC changes.
const IFSC_RE = /^[A-Z]{4}0[A-Z0-9]{6}$/;
function bankUpi(acc, ifsc) {
  acc = String(acc || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); ifsc = String(ifsc || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return acc && IFSC_RE.test(ifsc) ? `${acc}@${ifsc}.ifsc.npci` : null;
}
function lorryUpi(o, cur = {}) {
  if (o.bank_account != null) o.bank_account = String(o.bank_account).toUpperCase().replace(/[^A-Z0-9]/g, '') || null;
  if (o.bank_ifsc != null) o.bank_ifsc = String(o.bank_ifsc).toUpperCase().replace(/[^A-Z0-9]/g, '') || null;
  if (o.bank_ifsc && !IFSC_RE.test(o.bank_ifsc)) throw new UserError('IFSC must be 11 characters, e.g. UCBA0001302.');
  const acc = o.bank_account !== undefined ? o.bank_account : cur.bank_account;
  const ifsc = o.bank_ifsc !== undefined ? o.bank_ifsc : cur.bank_ifsc;
  const upi = o.upi !== undefined ? o.upi : cur.upi;
  if (!upi || /\.ifsc\.npci$/i.test(upi)) o.upi = bankUpi(acc, ifsc) || (upi && !/\.ifsc\.npci$/i.test(upi) ? upi : null);
  else o.upi = String(upi).trim();
  return o;
}

const EWB_LIMIT = 25000;
class UserError extends Error { constructor(msg) { super(msg); this.status = 400; } }

function fyOf(isoDate) {
  const d = isoDate ? new Date(isoDate) : new Date();
  const y = d.getFullYear(), m = d.getMonth() + 1;
  const start = m >= 4 ? y : y - 1;
  return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
}

function stateCode(state, gstin) {
  if (gstin && /^\d\d/.test(gstin)) return gstin.slice(0, 2);
  return STATE_CODES[String(state || '').trim().toUpperCase()] || null;
}

function nextInvoiceNo(firmCode, fy) {
  const r = get('SELECT COALESCE(MAX(inv_no), 0) + 1 AS n FROM invoices WHERE firm_code = ? AND fy = ?', firmCode, fy);
  return r.n;
}

// ---------- Inward / freight voucher ----------
// Freight is paid on the ACTUAL weight received.
// The voucher prints the RAWANA weight, with the rate adjusted so the amount stays the same.
// Freight vouchers: P.P. Enterprise makes PPE-V.., Parakh Marketing makes PM-V..
function voucherSeries(firm) {
  if (firm === 'PPE') return 'PPE-V';
  if (firm === 'PM') return 'PM-V';
  throw new UserError('Choose which firm makes this freight voucher: P.P. Enterprise or Parakh Marketing.');
}

function nextVoucherNo(fy, firm) {
  const series = voucherSeries(firm);
  const rows = all('SELECT voucher_no FROM inwards WHERE fy = ? AND voucher_no LIKE ?', fy, series + '%');
  let max = 0;
  for (const r of rows) { const m = r.voucher_no.match(/V(\d+)/); if (m) max = Math.max(max, +m[1]); }
  return series + (max + 1);
}

function freightFigures(inw) {
  const amount = r2((inw.actual_wt || 0) * (inw.freight_rate || 0));
  const shownRate = inw.rawana_wt ? r2(amount / inw.rawana_wt) : inw.freight_rate;
  return { amount, shownRate };
}

const INWARD_FIELDS = ['date', 'voucher_date', 'supplier', 'to_party', 'mines', 'lorry_no', 'grade', 'condition', 'plant', 'rawana_no',
  'challan_no', 'rawana_wt', 'actual_wt', 'freight_rate', 'advance', 'pay_mode', 'cash_amt', 'bank_amt', 'chq_no',
  'owner_name', 'pan', 'driver_name', 'driver_phone', 'upi', 'transporter', 'lr_no', 'royalty', 'dmft', 'nmet', 'remarks'];

function cleanInward(b) {
  const o = {};
  for (const f of INWARD_FIELDS) if (b[f] !== undefined) o[f] = b[f] === '' ? null : b[f];
  for (const f of ['rawana_wt', 'actual_wt', 'freight_rate', 'advance', 'cash_amt', 'bank_amt', 'royalty', 'dmft', 'nmet'])
    if (o[f] != null) o[f] = Number(o[f]);
  normalize(o);
  if (!o.date) throw new UserError('Enter the date received.');
  if (!o.lorry_no) throw new UserError('Enter the lorry number.');
  if (!(o.rawana_wt > 0)) throw new UserError('Enter the rawana weight.');
  if (!(o.actual_wt > 0)) throw new UserError('Enter the actual weight received.');
  o.freight_amt = freightFigures(o).amount;
  return o;
}

function rememberLorry(o) {
  if (!o.lorry_no) return;
  const ex = get('SELECT id FROM lorries WHERE lorry_no = ?', o.lorry_no);
  if (ex) {
    run(`UPDATE lorries SET owner = COALESCE(?, owner), pan = COALESCE(?, pan), driver_name = COALESCE(?, driver_name),
         driver_phone = COALESCE(?, driver_phone), upi = COALESCE(?, upi) WHERE id = ?`,
      o.owner_name, o.pan, o.driver_name, o.driver_phone, o.upi, ex.id);
  } else {
    run('INSERT INTO lorries(lorry_no, owner, pan, driver_name, driver_phone, upi) VALUES(?,?,?,?,?,?)',
      o.lorry_no, o.owner_name, o.pan, o.driver_name, o.driver_phone, o.upi);
  }
}

function saveInward(body, id) {
  const o = cleanInward(body);
  return tx(() => {
    if (id) {
      const cur = get('SELECT * FROM inwards WHERE id = ?', id);
      if (!cur) throw new UserError('Inward not found.');
      if (/^PPE-V/i.test(cur.voucher_no)) { o.supplier = 'P.P.ENTERPRISE'; o.to_party = 'PARAKH MARKETING'; }
      else if (!o.to_party) o.to_party = cur.to_party || 'PARAKH MARKETING';
      if (cur.ppe_invoice_id && (o.rawana_wt !== cur.rawana_wt))
        throw new UserError('This lorry is already billed by P.P. Enterprise. Cancel that bill first to change the rawana weight.');
      const keys = Object.keys(o);
      run(`UPDATE inwards SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), id);
      rememberLorry(o);
      return id;
    }
    o.fy = body.fy || fyOf(o.date);
    o.voucher_no = nextVoucherNo(o.fy, body.voucher_firm);
    if (body.voucher_firm === 'PPE') o.supplier = 'P.P.ENTERPRISE';
    o.to_party = 'PARAKH MARKETING';
    if (!o.voucher_date) o.voucher_date = new Date().toISOString().slice(0, 10);
    if (get('SELECT 1 FROM inwards WHERE fy = ? AND voucher_no = ?', o.fy, o.voucher_no))
      throw new UserError(`Voucher ${o.voucher_no} already exists in ${o.fy}.`);
    if (o.rawana_no && get('SELECT 1 FROM inwards WHERE rawana_no = ?', o.rawana_no))
      throw new UserError(`Rawana ${o.rawana_no} is already entered.`);
    const keys = Object.keys(o);
    const r = run(`INSERT INTO inwards(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
    rememberLorry(o);
    return Number(r.lastInsertRowid);
  });
}

// ---------- Invoices ----------
function firm(code) {
  const f = get('SELECT * FROM firms WHERE code = ?', code);
  if (!f) throw new UserError('Unknown firm ' + code);
  return f;
}

function computeTotals(items, firmRow, partyStateCode) {
  const intra = !partyStateCode || partyStateCode === (firmRow.state_code || '08');
  let taxable = 0, cgst = 0, sgst = 0, igst = 0;
  for (const it of items) {
    it.amount = r2(it.qty * it.rate);
    taxable += it.amount;
    const t = r2(it.amount * (it.gst_rate || 0) / 100);
    if (intra) { cgst += t / 2; sgst += t / 2; } else igst += t;
  }
  taxable = r2(taxable); cgst = r2(cgst); sgst = r2(sgst); igst = r2(igst);
  const raw = taxable + cgst + sgst + igst;
  const total = Math.round(raw);
  return { taxable, cgst, sgst, igst, round_off: r2(total - raw), total, intra };
}

function cleanItems(items) {
  if (!Array.isArray(items) || !items.length) throw new UserError('Add at least one item.');
  return items.map((it, i) => {
    const o = {
      sl: i + 1, item_name: (it.item_name || '').trim(), grade: it.grade || null, hsn: it.hsn || '2512',
      qty: Number(it.qty), unit: it.unit || 'MT', rate: Number(it.rate), gst_rate: it.gst_rate === '' || it.gst_rate == null ? 5 : Number(it.gst_rate),
      bags: it.bags ? Number(it.bags) : null, pack_size: it.pack_size ? Number(it.pack_size) : null, bag_type: it.bag_type || null,
      inward_id: it.inward_id || null, lorry_no: it.lorry_no || null, rawana_no: it.rawana_no || null, challan_no: it.challan_no || null,
      bag_supply: ['OUR', 'BUYER'].includes(it.bag_supply) ? it.bag_supply : null,
      packing_type: it.packing_type ? String(it.packing_type).toUpperCase() : null,
      liner: it.liner === '' || it.liner == null ? null : (Number(it.liner) ? 1 : 0)
    };
    if (!o.item_name) throw new UserError(`Item ${i + 1}: choose the item.`);
    if (!(o.qty > 0)) throw new UserError(`Item ${i + 1}: enter the quantity.`);
    if (!(o.rate > 0)) throw new UserError(`Item ${i + 1}: enter the rate.`);
    return o;
  });
}

const HEAD_FIELDS = ['date', 'party_address', 'party_city', 'party_state', 'party_pincode', 'ship_address', 'lorry_no', 'transporter', 'transporter_gstin',
  'lr_no', 'driver_phone', 'plant', 'ewb_no', 'freight_note', 'advance_freight', 'notes'];

function insertItems(invId, items) {
  run('DELETE FROM invoice_items WHERE invoice_id = ?', invId);
  for (const it of items) {
    run(`INSERT INTO invoice_items(invoice_id, sl, item_name, grade, hsn, qty, unit, rate, amount, gst_rate, bags, pack_size, bag_type,
         inward_id, lorry_no, rawana_no, challan_no, bag_supply, liner, packing_type) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      invId, it.sl, it.item_name, it.grade, it.hsn, it.qty, it.unit, it.rate, it.amount, it.gst_rate, it.bags, it.pack_size,
      it.bag_type, it.inward_id, it.lorry_no, it.rawana_no, it.challan_no, it.bag_supply ?? null, it.liner ?? null, it.packing_type ?? null);
  }
}

// Invoice lines take item, grade, rate, HSN, GST, bag and packing ONLY from the buyer's own items
// (Buyers menu). On the invoice only the bags / quantity are typed.
function applyBuyerItems(party, items) {
  if (!Array.isArray(items)) return items;
  const own = all('SELECT * FROM party_items WHERE party_id = ? AND active = 1', party.id);
  return items.filter(it => it && (it.item_name || it.party_item_id || it.qty || it.bags)).map((it, i) => {
    let pi = it.party_item_id ? own.find(x => x.id === Number(it.party_item_id)) : null;
    if (!pi) pi = own.find(x => x.item_name === String(it.item_name || '').toUpperCase() && (x.grade || '') === String(it.grade || '').toUpperCase());
    if (!pi) throw new UserError(`Line ${i + 1}: "${[it.item_name, it.grade].filter(Boolean).join(' ') || 'item'}" is not in ${party.name}'s items. Add it in Buyers first.`);
    if (!(pi.rate > 0)) throw new UserError(`Set the rate for ${pi.item_name} ${pi.grade || ''} in Buyers → ${party.name} first.`);
    let qty = Number(it.qty);
    if (Number(it.bags) > 0 && pi.pack_size > 0) qty = Math.round(Number(it.bags) * pi.pack_size) / 1000;
    return {
      ...it, party_item_id: pi.id, item_name: pi.item_name, grade: pi.grade, hsn: pi.hsn || '2512', gst_rate: pi.gst_rate ?? 5, rate: pi.rate,
      pack_size: pi.pack_size, bag_type: pi.bag_type, packing_type: pi.packing_type, bag_supply: pi.bag_supply, liner: pi.liner, qty,
      fixed_plant: pi.plant || null
    };
  });
}

// Dispatch details that must be filled before the e-way bill file / email, and for invoices above Rs 25,000
const DISPATCH_NEEDED = [['lorry_no', 'Lorry no.'], ['transporter', 'Transporter'], ['transporter_gstin', 'Transporter GSTIN'], ['lr_no', 'L.R. no.'],
  ['freight_note', 'Freight'], ['plant', 'Dispatch plant']];
function missingDispatch(o) { return DISPATCH_NEEDED.filter(([k]) => !String(o[k] ?? '').trim()).map(([, t]) => t); }

// Transporter GSTIN is LOCKED on the invoice: it always comes from Masters → Lorries & more → Transporters.
function fixTransporter(head) {
  if (head.transporter) head.transporter = String(head.transporter).trim().toUpperCase();
  const tr = head.transporter ? get('SELECT * FROM transporters WHERE upper(trim(name)) = ?', head.transporter) : null;
  head.transporter_gstin = (tr && tr.gstin) || null;
  return tr;
}
function transporterHelp(head, miss) {
  if (!miss.includes('Transporter GSTIN') || !head.transporter) return '';
  return ` The GSTIN of "${head.transporter}" is taken from Masters → Lorries & more → Transporters — add it there.`;
}

// a buyer item fixed to a plant decides the dispatch plant
function fixPlant(head, rawItems) {
  const fixed = [...new Set(rawItems.map(x => x.fixed_plant).filter(Boolean))];
  if (fixed.length > 1) throw new UserError(`These items are fixed to different plants (${fixed.join(', ')}). Make a separate invoice for each plant.`);
  if (fixed.length === 1) head.plant = fixed[0];
}

// Delivery (ship-to) address of the invoice: one of the buyer's godowns, or none (= goods go to the registered address).
// E-way bill transaction type: 1 Regular (Bill To only), 2 Bill To - Ship To, 3 Bill From - Dispatch From, 4 Combination of 2 and 3.
// If not chosen, it is 2 when the delivery pincode differs from the registered pincode, else 1.
const TRANS_TYPES = { 1: 'Regular', 2: 'Bill To - Ship To', 3: 'Bill From - Dispatch From', 4: 'Combination of 2 and 3' };
function resolveShip(party, body) {
  const out = { delivery_id: null, ship_name: null, ship_address: null, ship_city: null, ship_state: null, ship_state_code: null, ship_pincode: null, ship_km: null };
  const did = Number(body.delivery_id) || null;
  if (did) {
    const a = get('SELECT * FROM party_addresses WHERE id = ?', did);
    if (!a || a.party_id !== party.id) throw new UserError('The chosen delivery address is not of this buyer. Choose it again.');
    Object.assign(out, { delivery_id: a.id, ship_name: a.godown_name || null, ship_address: a.address || null, ship_city: a.city || null,
      ship_state: a.state || null, ship_state_code: a.state_code || stateCode(a.state) || null, ship_pincode: a.pincode || null, ship_km: a.km || null });
  }
  const regPin = String(body.party_pincode || party.pincode || '').replace(/\D/g, '');
  const differs = !!(out.ship_pincode && out.ship_pincode !== regPin);
  let tt = Number(body.trans_type) || 0;
  if (!TRANS_TYPES[tt]) tt = differs ? 2 : 1;
  out.trans_type = tt;
  out.differs = differs;
  return out;
}

// Sales invoice of Parakh Marketing or Parakh Fertilizer.
// Rule: the buyer master is shared, and each buyer is fixed to one billing firm.
function saveSale(body, id) {
  const party = get('SELECT * FROM parties WHERE id = ?', body.party_id);
  if (!party) throw new UserError('Choose the buyer.');
  if (!['PM', 'PF'].includes(party.firm_code)) throw new UserError(`Buyer "${party.name}" is not linked to a billing firm. Set it in Buyers master.`);
  const firmCode = party.firm_code;
  const f = firm(firmCode);
  const raw = applyBuyerItems(party, body.items);
  const items = cleanItems(raw);
  const head = {};
  for (const k of HEAD_FIELDS) head[k] = body[k] === '' || body[k] === undefined ? null : body[k];
  normalize(head);
  fixPlant(head, raw);
  fixTransporter(head);
  if (!head.date) throw new UserError('Enter the invoice date.');
  const gstin = party.gstin || null;
  const psc = stateCode(head.party_state || party.state, gstin) || party.state_code;
  const t = computeTotals(items, f, psc);
  const fy = fyOf(head.date);
  // house rule: an invoice above Rs 25,000 is never saved without its e-way bill number
  if (t.total > EWB_LIMIT) {
    const miss = missingDispatch(head);
    if (!head.ewb_no) miss.push('E-way bill number');
    if (miss.length) throw new UserError(`Invoice total is ₹${t.total.toLocaleString('en-IN')} (above ₹25,000). Fill in: ${miss.join(', ')}.${transporterHelp(head, miss)}${!head.ewb_no ? ' Use the ⬇ JSON button to make the e-way bill file.' : ''}`);
  }
  if (head.ewb_no && !/^\d{12}$/.test(head.ewb_no)) throw new UserError('E-way bill number must be 12 digits.');
  const ship = resolveShip(party, body);

  return tx(() => {
    const data = {
      ...head, firm_code: firmCode, fy, kind: 'SALE', party_id: party.id, party_name: party.name, party_gstin: gstin,
      party_pan: party.pan, party_address: head.party_address ?? party.address, party_city: head.party_city ?? party.city,
      party_state: head.party_state ?? party.state, party_state_code: psc, party_pincode: head.party_pincode ?? party.pincode,
      ship_address: ship.ship_address, ship_name: ship.ship_name, ship_city: ship.ship_city, ship_state: ship.ship_state,
      ship_state_code: ship.ship_state_code, ship_pincode: ship.ship_pincode, delivery_id: ship.delivery_id, trans_type: ship.trans_type,
      supply_type: gstin ? 'B2B' : 'B2C',
      taxable: t.taxable, cgst: t.cgst, sgst: t.sgst, igst: t.igst, round_off: t.round_off, total: t.total
    };
    let invId = id;
    if (id) {
      const cur = get('SELECT * FROM invoices WHERE id = ?', id);
      if (!cur) throw new UserError('Invoice not found.');
      if (cur.legacy) throw new UserError('Old invoices imported from Excel cannot be edited.');
      if (cur.firm_code !== firmCode) throw new UserError('Buyer belongs to another firm. Make a new invoice instead.');
      if (cur.fy !== fy) throw new UserError('Date is in another financial year.');
      const keys = Object.keys(data);
      run(`UPDATE invoices SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => data[k]), id);
    } else {
      data.inv_no = body.inv_no ? Number(body.inv_no) : nextInvoiceNo(firmCode, fy);
      if (get('SELECT 1 FROM invoices WHERE firm_code = ? AND fy = ? AND inv_no = ?', firmCode, fy, data.inv_no))
        throw new UserError(`Invoice no. ${data.inv_no} already exists for ${f.name} in ${fy}.`);
      const keys = Object.keys(data);
      invId = Number(run(`INSERT INTO invoices(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => data[k])).lastInsertRowid);
    }
    insertItems(invId, items);
    // the transporter used last becomes the buyer's default for the next invoice
    if (data.transporter && data.transporter !== party.transporter) run('UPDATE parties SET transporter = ? WHERE id = ?', data.transporter, party.id);
    return invId;
  });
}

// P.P. Enterprise -> Parakh Marketing bill, made from inward lorries. Quantity = RAWANA weight.
function savePpeBill(body, id) {
  const ids = (body.inward_ids || []).map(Number).filter(Boolean);
  if (!ids.length) throw new UserError('Tick at least one inward lorry.');
  const rate = Number(body.rate);
  if (!(rate > 0)) throw new UserError('Enter the rate per MT.');
  const date = body.date;
  if (!date) throw new UserError('Enter the bill date.');
  const gst = body.gst_rate === undefined || body.gst_rate === '' ? 5 : Number(body.gst_rate);
  const ppe = firm('PPE'), pm = firm('PM');
  const fy = fyOf(date);

  return tx(() => {
    const inws = ids.map(i => get('SELECT * FROM inwards WHERE id = ?', i));
    inws.forEach((w, k) => {
      if (!w) throw new UserError('Inward not found.');
      if (w.ppe_invoice_id && w.ppe_invoice_id !== Number(id)) throw new UserError(`Lorry ${w.lorry_no} (${w.voucher_no}) is already billed.`);
      if (!(w.rawana_wt > 0)) throw new UserError(`Lorry ${w.lorry_no} has no rawana weight.`);
    });
    const items = inws.map((w, k) => ({
      sl: k + 1, item_name: body.item_name || 'DIATOMACEOUS EARTH (RAW)', grade: w.grade, hsn: body.hsn || '2512', qty: w.rawana_wt, unit: 'MT',
      rate, gst_rate: gst, inward_id: w.id, lorry_no: w.lorry_no, rawana_no: w.rawana_no, challan_no: w.challan_no
    }));
    const t = computeTotals(items, ppe, pm.state_code);
    const data = {
      firm_code: 'PPE', fy, date, kind: 'PPE_BILL', party_id: null, party_name: pm.name.toUpperCase(), party_gstin: pm.gstin, party_pan: pm.pan,
      party_address: pm.address, party_city: pm.city, party_state: pm.state, party_state_code: pm.state_code, party_pincode: pm.pincode,
      ship_address: body.ship_address || null, supply_type: 'B2B', lorry_no: inws.map(w => w.lorry_no).join(', '), notes: body.notes || null,
      taxable: t.taxable, cgst: t.cgst, sgst: t.sgst, igst: t.igst, round_off: t.round_off, total: t.total
    };
    let invId = id ? Number(id) : null;
    if (invId) {
      const cur = get('SELECT * FROM invoices WHERE id = ?', invId);
      if (!cur || cur.kind !== 'PPE_BILL') throw new UserError('Bill not found.');
      if (cur.legacy) throw new UserError('Old bills imported from Excel cannot be edited.');
      run('UPDATE inwards SET ppe_invoice_id = NULL WHERE ppe_invoice_id = ?', invId);
      const keys = Object.keys(data);
      run(`UPDATE invoices SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => data[k]), invId);
    } else {
      data.inv_no = body.inv_no ? Number(body.inv_no) : nextInvoiceNo('PPE', fy);
      if (get('SELECT 1 FROM invoices WHERE firm_code = ? AND fy = ? AND inv_no = ?', 'PPE', fy, data.inv_no))
        throw new UserError(`Bill no. ${data.inv_no} already exists for P.P. Enterprise in ${fy}.`);
      const keys = Object.keys(data);
      invId = Number(run(`INSERT INTO invoices(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => data[k])).lastInsertRowid);
    }
    insertItems(invId, items);
    for (const w of inws) run('UPDATE inwards SET ppe_invoice_id = ? WHERE id = ?', invId, w.id);
    return invId;
  });
}

function cancelInvoice(id) {
  return tx(() => {
    const cur = get('SELECT * FROM invoices WHERE id = ?', id);
    if (!cur) throw new UserError('Invoice not found.');
    run('UPDATE invoices SET cancelled = 1 WHERE id = ?', id);
    run('UPDATE inwards SET ppe_invoice_id = NULL WHERE ppe_invoice_id = ?', id);
  });
}

function invoiceFull(id) {
  const inv = get('SELECT * FROM invoices WHERE id = ?', id);
  if (!inv) return null;
  inv.items = all('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sl', id);
  inv.firm = get('SELECT * FROM firms WHERE code = ?', inv.firm_code);
  if (inv.party_id) inv.party = get('SELECT * FROM parties WHERE id = ?', inv.party_id);
  if (inv.transporter && !inv.transporter_gstin) { const tr = get('SELECT gstin FROM transporters WHERE upper(trim(name)) = upper(trim(?))', inv.transporter); inv.transporter_gstin = tr ? tr.gstin : null; }
  return inv;
}

// E-way bill bulk-upload JSON (NIC format 1.0.0621), made from the invoice form before saving.
function ewayBillJson(body) {
  const party = get('SELECT * FROM parties WHERE id = ?', body.party_id);
  if (!party) throw new UserError('Choose the buyer.');
  if (!['PM', 'PF'].includes(party.firm_code)) throw new UserError('Set the billing firm for this buyer first.');
  const f = firm(party.firm_code);
  const raw = applyBuyerItems(party, body.items);
  const items = cleanItems(raw);
  const head = {}; for (const k of HEAD_FIELDS) head[k] = body[k] === '' || body[k] === undefined ? null : body[k];
  normalize(head);
  fixPlant(head, raw);
  fixTransporter(head);
  const miss = missingDispatch(head);
  if (miss.length) throw new UserError(`Fill in ${miss.join(', ')} before making the e-way bill file.${transporterHelp(head, miss)}`);
  if (!head.date) throw new UserError('Enter the invoice date.');
  const psc = stateCode(head.party_state || party.state, party.gstin) || party.state_code;
  const t = computeTotals(items, f, psc);
  const fy = fyOf(head.date);
  const invNo = body.inv_no ? Number(body.inv_no) : nextInvoiceNo(party.firm_code, fy);
  const pin = v => Number(String(v || '').replace(/\D/g, '').slice(0, 6)) || 0;
  const dmy = iso => iso ? iso.split('-').reverse().join('/') : '';
  const words = s => String(s || '').replace(/\s+/g, ' ').trim();
  const ship = resolveShip(party, body);
  const toShip = (ship.trans_type === 2 || ship.trans_type === 4) && ship.delivery_id;
  if ((ship.trans_type === 2 || ship.trans_type === 4) && !ship.delivery_id) throw new UserError('For "Bill To - Ship To" choose the delivery address (Deliver to).');
  const addr = words(toShip ? ship.ship_address : (head.party_address ?? party.address));
  const fromAddr = words(f.address);
  const hsnNum = h => Number(String(h || '2512').replace(/\D/g, '')) || 2512;
  // main HSN = the one with the largest value
  const byHsn = {}; for (const it of items) byHsn[it.hsn] = (byHsn[it.hsn] || 0) + it.amount;
  const mainHsn = Object.entries(byHsn).sort((a, b) => b[1] - a[1])[0][0];
  const intra = t.intra;
  const bill = {
    genMode: 'Excel', userGstin: f.gstin, supplyType: 'O', subSupplyType: 1, subSupplyDesc: '', docType: 'INV',
    docNo: String(invNo), docDate: dmy(head.date), transType: ship.trans_type,
    fromGstin: f.gstin, fromTrdName: f.name.toUpperCase(), fromAddr1: fromAddr.slice(0, 120), fromAddr2: '', fromPlace: (f.city || '').toUpperCase(),
    fromPincode: pin(f.pincode), fromStateCode: Number(f.state_code || 8), actualFromStateCode: Number(f.state_code || 8),
    toGstin: party.gstin || 'URP', toTrdName: party.name.toUpperCase(), toAddr1: addr.slice(0, 120), toAddr2: addr.slice(120, 240),
    toPlace: ((toShip ? ship.ship_city : null) || head.party_city || party.city || '').toUpperCase(),
    toPincode: pin(toShip ? ship.ship_pincode : (head.party_pincode || party.pincode)),
    toStateCode: Number(psc || 0), actualToStateCode: Number((toShip && ship.ship_state_code) || psc || 0),
    totalValue: t.taxable, cgstValue: t.cgst, sgstValue: t.sgst, igstValue: t.igst, cessValue: 0, TotNonAdvolVal: 0,
    OthValue: t.round_off, totInvValue: t.total,
    transMode: 1, transDistance: String((toShip ? ship.ship_km : null) || party.km || 0),
    transporterName: head.transporter || '', transporterId: head.transporter_gstin || '',
    transDocNo: head.lr_no || '', transDocDate: head.lr_no ? dmy(head.date) : '',
    vehicleNo: head.lorry_no ? String(head.lorry_no).split(',')[0].trim() : '', vehicleType: 'R',
    mainHsnCode: hsnNum(mainHsn),
    itemList: items.map((it, i) => ({
      itemNo: i + 1, productName: it.item_name, productDesc: [it.item_name, it.grade].filter(Boolean).join(' '),
      hsnCode: hsnNum(it.hsn), quantity: it.qty, qtyUnit: 'MTS', taxableAmount: it.amount,
      sgstRate: intra ? it.gst_rate / 2 : 0, cgstRate: intra ? it.gst_rate / 2 : 0, igstRate: intra ? 0 : it.gst_rate, cessRate: 0, cessNonAdvol: 0
    }))
  };
  const missing = [];
  if (!bill.toPincode) missing.push(toShip ? 'pincode of the delivery address' : "buyer's pincode");
  if (!bill.toStateCode) missing.push("buyer's state");
  if (missing.length) throw new UserError('Fill in the ' + missing.join(' and ') + ' in Buyers before making the e-way bill file.');
  return { version: '1.0.0621', billLists: [bill] };
}

// Indian-style amount in words.
function inWords(n) {
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen',
    'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const two = x => x < 20 ? a[x] : b[Math.floor(x / 10)] + (x % 10 ? ' ' + a[x % 10] : '');
  const three = x => (x >= 100 ? a[Math.floor(x / 100)] + ' Hundred' + (x % 100 ? ' ' : '') : '') + two(x % 100);
  let num = Math.floor(Math.abs(n));
  const paise = Math.round((Math.abs(n) - num) * 100);
  if (num === 0 && !paise) return 'Rupees Zero Only';
  const parts = [];
  const crore = Math.floor(num / 1e7); num %= 1e7;
  const lakh = Math.floor(num / 1e5); num %= 1e5;
  const thousand = Math.floor(num / 1e3); num %= 1e3;
  if (crore) parts.push(three(crore) + ' Crore');
  if (lakh) parts.push(two(lakh) + ' Lakh');
  if (thousand) parts.push(two(thousand) + ' Thousand');
  if (num) parts.push(three(num));
  let s = 'Rupees ' + parts.join(' ');
  if (paise) s += ' and ' + two(paise) + ' Paise';
  return s + ' Only';
}

module.exports = {
  UserError, normalize, fyOf, stateCode, nextInvoiceNo, nextVoucherNo, voucherSeries, freightFigures, saveInward, saveSale, savePpeBill,
  cancelInvoice, invoiceFull, ewayBillJson, missingDispatch, computeTotals, inWords, STATE_CODES, r2, TRANS_TYPES, bankUpi, lorryUpi
};
