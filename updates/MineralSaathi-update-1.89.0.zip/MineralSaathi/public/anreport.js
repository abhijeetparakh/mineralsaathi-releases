'use strict';
// Master → Analysis Reports: test report templates (Sl No. · Content · Observed Value in % · Protocol Adopted),
// linked to Item + Colour + Form + Mesh, printed / emailed as a PDF on the firm's letter head.
TITLES.anreports = 'Analysis Reports';

// Item List → Item group: a group name with the item names in it (an Analysis Report can be linked to a group)
async function itemGroupList(box, def, lists, editId) {
  const { groups, names } = await GET('/api/item-groups');
  const cur = groups.find(g => g.id === Number(editId)) || null;
  const all = [...new Set([...names, ...(cur ? cur.items : [])])].sort();
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${LISTS.map(([k, t, h]) => `<a class="listhead ${k === 'item_group' ? 'on' : ''}" onclick="go('#/itemlists/${k}')">
      <b>${t}</b><span class="badge grey">${k === 'item_group' ? groups.length : (lists[k] || []).length || ''}</span><br><span class="hint">${h}</span></a>`).join('')}</div>
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="igf" autocomplete="off" class="firmbox" style="margin-bottom:14px"><b>${cur ? 'Change group' : 'New group'}</b>
        <label style="margin-top:6px;max-width:420px">Group name<input name="name" value="${esc(cur ? cur.name : '')}" placeholder="e.g. FILLERS"></label>
        <div style="margin-top:8px"><span class="lbl" style="font-weight:600">Items in this group</span> <span class="hint">— tick the item names (from Item name and the items of the Item List)</span>
          <div class="grid" style="grid-template-columns:repeat(3,minmax(0,1fr));gap:4px 12px;margin-top:6px">${all.map(n => `<label style="display:flex;gap:8px;align-items:center;font-weight:500"><input type="checkbox" data-it="${esc(n)}" style="width:auto" ${cur && cur.items.includes(n) ? 'checked' : ''}> ${esc(n)}</label>`).join('')}</div></div>
        <div class="row" style="margin-top:10px"><button type="submit">${cur ? 'Save group' : 'Add group'}</button>${cur ? '<button type="button" class="sec" id="igcancel">Cancel</button>' : ''}</div></form>
      <table class="t"><thead><tr><th>Group</th><th>Items</th><th style="width:150px"></th></tr></thead><tbody>
        ${groups.map(g => `<tr><td><b>${esc(g.name)}</b></td><td>${g.items.map(esc).join(', ')}</td><td style="white-space:nowrap"><button class="small sec" data-ged="${g.id}">Edit</button> <button class="small sec" data-grm="${g.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="3" class="muted">No group yet.</td></tr>'}</tbody></table>
      <p class="hint">Use a group in Master → Analysis Reports → Linked to → Item group: the report then fits every item of the group (colour, form and mesh are still checked if chosen).</p></div></div>`;
  $('#igf', box).onsubmit = async e => {
    e.preventDefault();
    const v = { name: e.target.name.value, items: $$('[data-it]', box).filter(c => c.checked).map(c => c.dataset.it) };
    await guard(() => cur ? PUT('/api/item-groups/' + cur.id, v) : POST('/api/item-groups', v)); toast(cur ? 'Group saved' : 'Group added'); itemGroupList(box, def, lists);
  };
  const c = $('#igcancel', box); if (c) c.onclick = () => itemGroupList(box, def, lists);
  box.querySelector('table.t').onclick = async e => {
    const ed = e.target.closest('[data-ged]'), rm = e.target.closest('[data-grm]');
    if (ed) { await itemGroupList(box, def, lists, ed.dataset.ged); box.scrollIntoView({ block: 'start' }); }
    if (rm && confirm('Remove this item group?')) { await guard(() => DEL('/api/item-groups/' + rm.dataset.grm)); toast('Removed'); itemGroupList(box, def, lists); }
  };
}

PAGES.anreports = async (el, editId) => {
  await loadLists();
  const [list, fr, parties, ig] = await Promise.all([GET('/api/anreports'), GET('/api/anreports-firms'), GET('/api/m/parties?limit=2000').catch(() => []), GET('/api/item-groups').catch(() => ({ groups: [] }))]);
  const igName = id => { const g = ig.groups.find(x => x.id === Number(id)); return g ? g.name : ''; };
  const pName = id => { const x = parties.find(p => p.id === Number(id)); return x ? `${x.name}${x.city ? ' — ' + x.city : ''}` : ''; };
  const isNew = editId === 'new';
  const cur = isNew ? { name: '', heading: 'Chemical & Physical Properties', product: '', colour: '', form: '', mesh: '', rows: [['', '', ''], ['', '', ''], ['', '', '']], note: '' }
    : list.find(r => String(r.id) === String(editId)) || list[0] || null;
  S.anrFirm = S.anrFirm || 'PM';
  const opt = (key, v) => `<option value="">— any —</option>${[...new Set([...lv(key), ...(v ? [v] : [])])].map(x => `<option ${x === v ? 'selected' : ''}>${esc(x)}</option>`).join('')}`;
  const link = r => [r.party_id ? '👤 ' + pName(r.party_id) : '', r.group_name ? '🏢 ' + r.group_name : '', r.coa ? 'Certificate of Analysis' : '', r.item_group_id ? '📦 ' + igName(r.item_group_id) : '', r.product, r.colour, r.form, r.mesh ? r.mesh + ' MESH' : ''].filter(Boolean).join(' · ') || '<span class="badge amber">not linked</span>';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,2.2fr);align-items:start">
    <div class="card"><div class="toolbar"><h3 style="margin:0">Reports</h3><span class="spacer"></span><button class="small" onclick="go('#/anreports/new')">+ New report</button></div>
      ${list.map(r => `<a class="listhead ${cur && r.id === cur.id && !isNew ? 'on' : ''}" style="display:block;padding:8px 10px;border-bottom:1px solid var(--line);cursor:pointer" onclick="go('#/anreports/${r.id}')">
        <b>${esc(r.name)}</b><br><span class="hint">${link(r)}</span></a>`).join('') || '<p class="hint">No report yet.</p>'}
      <p class="hint" style="margin-top:10px">Each report is linked to an Item, Colour, Form and Mesh (from Master → Item List; “any” = not checked).
        When you email an invoice or a sample dispatch with “Analysis report” ticked, the report of the same combination as the item sent goes with it as a PDF, on that firm's letter head.
        If two reports fit, the one with more fields filled in is used.</p></div>
    ${cur ? `<form id="arf" class="card" autocomplete="off" data-nocase>
      <div class="toolbar"><h3 style="margin:0">${isNew ? 'New analysis report' : 'Edit report'}</h3><span class="spacer"></span>
        ${isNew ? '' : `<button type="button" class="sec small" id="arcopy">⧉ Duplicate</button><button type="button" class="sec small" id="ardel">Delete</button>`}</div>
      <div class="grid g2">
        <label>Heading (first line)<input name="heading" value="${esc(cur.heading || '')}" placeholder="Chemical & Physical Properties"></label>
        <label>Report name (second line)<input name="name" value="${esc(cur.name)}" placeholder="Diatomaceous Earth Light Yellow"></label></div>
      ${cur.print_name && cur.print_name !== cur.name ? `<p class="hint" style="margin:4px 0 0">Printed as: <b>${esc(cur.print_name)}</b> — “Diatomaceous Earth” is replaced by the Item linked below.</p>` : ''}
      <div class="firmbox" style="margin-top:10px"><b>Linked to</b> <span class="hint">— sent with invoices / sample dispatches of this item</span>
        <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:6px">
          <label>Item<select name="product">${opt('product', cur.product)}</select></label>
          <label>Colour<select name="colour">${opt('colour', cur.colour)}</select></label>
          <label>Form<select name="form">${opt('form', cur.form)}</select></label>
          <label>Mesh<select name="mesh">${opt('mesh', cur.mesh)}</select></label></div>
        <label style="margin-top:6px">Item group (optional) — the report fits every item of the group<select name="item_group_id"><option value="">— no item group —</option>${ig.groups.map(g => `<option value="${g.id}" ${Number(cur.item_group_id) === g.id ? 'selected' : ''}>${esc(g.name)} (${esc(g.items.join(', '))})</option>`).join('')}</select></label>
        <div class="grid g2" style="gap:8px;margin-top:6px">
          <label>Buyer (only for this buyer)<select name="party_id"><option value="">— any buyer —</option>${parties.filter(p => p.active !== 0).map(p => `<option value="${p.id}" ${Number(cur.party_id) === p.id ? 'selected' : ''}>${esc(p.name)}${p.city ? ' — ' + esc(p.city) : ''}</option>`).join('')}</select></label>
          <label>Group of companies (only for its buyers)<select name="group_name">${opt('group_company', cur.group_name).replace('— any —', '— any group —')}</select></label></div>
        <p class="hint" style="margin:4px 0 0">Buyer or group chosen: this report goes only to that buyer / the buyers of that group, before any general report. Not chosen: it goes by Item, Colour, Form and Mesh.</p></div>
      <div class="firmbox" style="margin-top:10px"><label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" name="coa" value="1" style="width:auto" ${cur.coa ? 'checked' : ''}> Print the “Certificate of Analysis” block before the table (J K group style)</label>
        <div class="grid g2" style="gap:8px;margin-top:6px" id="coaf" ${cur.coa ? '' : 'hidden'}>
          <label>Material JKI Code No.<input name="material_code" value="${esc(cur.material_code || 'SR FILLER CODE 7777')}"></label>
          <label>Brand Name Of Product<input name="brand_name" value="${esc(cur.brand_name || '')}"></label></div>
        <p class="hint" style="margin:4px 0 0">With an invoice: Report No. and Invoice No. = the invoice number, Name of the Customer = the buying firm, Plant = its delivery city, Batch / Lot No. = the lot no. of the invoice, Date of Dispatch = the invoice date.
          Without the tick: the buyer's contact person, company name and address are printed before the table.</p></div>
      <table class="t" style="margin-top:12px" id="artab"><thead><tr><th style="width:60px">Sl No.</th><th>Content</th><th style="width:150px">Observed Value in %</th><th>Protocol Adopted</th><th style="width:76px"></th></tr></thead><tbody></tbody></table>
      <div class="row" style="margin-top:6px"><button type="button" class="sec small" id="aradd">+ Add row</button></div>
      <label style="margin-top:10px">Note (printed after the table)<textarea name="note" rows="3" placeholder="e.g. The above values are typical and may vary slightly from lot to lot.">${esc(cur.note || '')}</textarea></label>
      <div class="row" style="margin-top:12px;gap:8px;align-items:end;flex-wrap:wrap"><button type="submit">${isNew ? 'Add report' : 'Save'}</button>
        <span class="spacer"></span>
        <label style="width:260px">For buyer (optional)<input id="arbuyer" list="arbl" placeholder="type the buyer name"><datalist id="arbl">${parties.map(p => `<option value="${esc(p.name + (p.city ? ' — ' + p.city : ''))}">`).join('')}</datalist></label>
        <label style="width:auto">Firm (letter head)<select id="arfirm">${fr.firms.map(f => `<option value="${esc(f.code)}" ${f.code === S.anrFirm ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>
        <button type="button" class="sec" id="arprint">🖨 Print</button><button type="button" class="sec" id="armail">✉ Email PDF</button></div>
      <p class="hint">Print and Email use the saved report — press Save first after a change.</p></form>` : '<div class="card"><p>Add the first report with “+ New report”.</p></div>'}</div>`;
  if (!cur) return;
  const f = $('#arf', el), tb = $('#artab tbody', el);
  let rows = cur.rows.map(r => [...r]);
  const read = () => { rows = $$('tr', tb).map(tr => $$('input', tr).map(i => i.value)); };
  const draw = () => {
    tb.innerHTML = rows.map((r, i) => `<tr><td class="c"><b>${i + 1}.</b></td>${r.map((v, j) => `<td><input value="${esc(v)}" ${j === 1 ? 'style="text-align:center"' : ''}></td>`).join('')}
      <td style="white-space:nowrap"><button type="button" class="small sec" data-up="${i}" title="Move up" ${i ? '' : 'disabled'}>↑</button><button type="button" class="small sec" data-rm="${i}" title="Remove the row">✕</button></td></tr>`).join('');
  };
  draw();
  tb.onclick = e => {
    const u = e.target.closest('[data-up]'), x = e.target.closest('[data-rm]'); if (!u && !x) return; read();
    if (u) { const i = +u.dataset.up; [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; } else rows.splice(+x.dataset.rm, 1);
    draw();
  };
  $('#aradd', el).onclick = () => { read(); rows.push(['', '', '']); draw(); $$('tr:last-child input', tb)[0].focus(); };
  // an item group chosen: the single Item is not used
  const igSel = f.querySelector('[name=item_group_id]'), prodSel = f.querySelector('[name=product]');
  const igSync = () => { prodSel.disabled = !!igSel.value; if (igSel.value) prodSel.value = ''; }; igSel.onchange = igSync; igSync();
  const coaBox = f.querySelector('[name=coa]'); coaBox.onchange = () => { $('#coaf', el).hidden = !coaBox.checked; };
  const buyerId = () => { const t = $('#arbuyer', el).value.trim(); const x = parties.find(p => `${p.name}${p.city ? ' — ' + p.city : ''}` === t) || parties.find(p => p.name === t); return x ? x.id : null; };
  const save = async () => { read(); const v = formData(f); v.rows = rows; v.coa = coaBox.checked ? 1 : 0;
    return isNew ? (await POST('/api/anreports', v)).id : (await PUT('/api/anreports/' + cur.id, v)).id; };
  f.onsubmit = async e => { e.preventDefault(); const id = await guard(save); toast('Report saved'); go('#/anreports/' + id); if (!isNew) PAGES.anreports(el, id); };
  $('#arfirm', el).onchange = e => { S.anrFirm = e.target.value; };
  $('#arprint', el).onclick = async () => { if (isNew) { const id = await guard(save); go('#/anreports/' + id); return; } window.open(`/print/anreport/${cur.id}?firm=${encodeURIComponent($('#arfirm', el).value)}${buyerId() ? '&party=' + buyerId() : ''}`, '_blank'); };
  $('#armail', el).onclick = () => { if (isNew) return toast('Save the report first', true); anrEmail(cur, $('#arfirm', el).value, fr.firms, parties.find(p => p.id === buyerId())); };
  if (!isNew) {
    $('#arcopy', el).onclick = async () => { const r = await guard(() => POST(`/api/anreports/${cur.id}/copy`, {})); toast('Copy made — change its name and link'); go('#/anreports/' + r.id); };
    $('#ardel', el).onclick = async () => { if (!confirm(`Delete the report “${cur.name}”?`)) return; await guard(() => DEL('/api/anreports/' + cur.id)); toast('Deleted'); go('#/anreports'); };
  }
};

function anrEmail(rep, firmCode, firms, buyer) {
  const fm = firms.find(x => x.code === firmCode) || {};
  modal(`Email analysis report · ${rep.print_name || rep.name}`, `${fm.email ? '' : `<p class="badge amber">Email is not set up for ${esc(fm.name || firmCode)}. Open Settings → Companies → Email sending first.</p>`}
    <form id="aem"><div class="grid g2">
      ${buyer ? `<p class="span2" style="margin:0">For <b>${esc(buyer.name)}</b> — the buyer's contact person, name and address are printed on the report.</p>` : ''}
      ${field({ name: 'to', label: 'To (more than one: comma between)' }, buyer ? buyer.email || '' : '')}${field({ name: 'cc', label: 'CC' }, '')}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, `Analysis report — ${rep.print_name || rep.name} — ${fm.name || ''}`)}
      ${field({ name: 'text', label: 'Message', type: 'textarea', span: 2 }, `Dear Sir / Madam,\n\nPlease find attached the analysis report of ${rep.print_name || rep.name}.\n\nRegards,\n${fm.name || ''}`)}</div>
      <div class="row" style="margin-top:8px"><button type="submit" ${fm.email ? '' : 'disabled'}>Send email</button><span class="hint">The report goes as a PDF on the letter head of ${esc(fm.name || '')}.</span></div></form>`, root => {
    const t = $('#aem [name=text]', root); if (t) t.rows = 7;
    $('#aem', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Making the PDF and sending…';
      try { await POST(`/api/anreports/${rep.id}/email`, { ...formData(e.target), firm_code: firmCode, party_id: buyer ? buyer.id : null }); toast('Analysis report sent'); closeModal(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}
