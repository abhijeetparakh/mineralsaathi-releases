'use strict';
// Same writing everywhere, as you type (the main PC checks it again when saving):
//   names, company, city, state … CAPITALS · email small letters · mobile / pincode / Aadhaar digits only, with their fixed length
//   GSTIN, PAN, IFSC, lorry no. CAPITALS without spaces. A form marked data-nocase (company settings, templates …) is left as typed.
const IR_UPPER = ['name', 'company', 'buyer_name', 'contact_person', 'owner', 'owner_name', 'driver_name', 'proprietor', 'transporter', 'party_name', 'b2c_name',
  'city', 'state', 'district', 'ship_name', 'ship_city', 'party_city', 'courier', 'd_courier', 'bank_name', 'grade', 'lot_no', 'full_name', 'mines', 'supplier'];
const IR_LOWER = ['email', 'smtp_user', 'to', 'cc'];
const IR_CODE = { gstin: 15, party_gstin: 15, transporter_gstin: 15, gst: 15, pan: 10, party_pan: 10, bank_ifsc: 11, ifsc: 11, lorry_no: 0, tracking_no: 0, d_tracking_no: 0, udyam_no: 0, vehicle_no: 0, tempo_no: 0 };
const IR_DIGITS = { pincode: 6, party_pincode: 6, ship_pincode: 6, owner_aadhaar: 12, aadhaar: 12, ewb_no: 12 };
const IR_MOBILE = ['mobile', 'mobile1', 'mobile2', 'driver_phone', 'phone', 'whatsapp'];
let IR_N = 10;   // digits of a mobile number (Settings → Universal rules)
GET('/api/rules').then(r => { if (r && r.mobile_digits) IR_N = Number(r.mobile_digits); }).catch(() => {});
function irRule(el) {
  if (!el || el.tagName !== 'INPUT' || !el.name || ['password', 'number', 'date', 'file', 'checkbox', 'radio', 'color', 'hidden', 'search'].includes(el.type)) return null;
  if (el.closest('[data-nocase]') || el.id === 'waq' || el.id === 'mfind') return null;
  const n = el.name;
  if (IR_LOWER.includes(n)) return 'lower';
  if (n in IR_CODE) return 'code';
  if (n in IR_DIGITS) return 'digits';
  if (IR_MOBILE.includes(n)) return 'mobile';
  if (IR_UPPER.includes(n)) return 'upper';
  return null;
}
document.addEventListener('input', e => {
  const el = e.target, r = irRule(el); if (!r) return;
  const v = el.value, pos = el.selectionStart;
  let nv = v;
  if (r === 'upper') nv = v.toUpperCase();
  else if (r === 'lower') nv = v.toLowerCase();
  else if (r === 'code') { nv = v.toUpperCase().replace(el.name === 'lorry_no' ? /[^A-Z0-9,]/g : el.name === 'udyam_no' ? /[^A-Z0-9-]/g : /[^A-Z0-9]/g, ''); const m = IR_CODE[el.name]; if (m) nv = nv.slice(0, m); }
  else if (r === 'digits') nv = v.replace(/\D/g, '').slice(0, IR_DIGITS[el.name]);
  else if (r === 'mobile') nv = v.replace(/[^\d,;/ +]/g, '');
  if (nv !== v) { const cut = v.length - nv.length; el.value = nv; try { el.setSelectionRange(Math.max(0, pos - cut), Math.max(0, pos - cut)); } catch { /* not a text box */ } }
  el.style.outline = ''; el.title = '';
}, true);
// on leaving the box: a wrong length is shown in red (saving is still checked by the main PC)
document.addEventListener('blur', e => {
  const el = e.target, r = irRule(el); if (!r || !el.value.trim()) return;
  let bad = '';
  if (r === 'mobile' && el.name !== 'phone') {
    const nums = el.value.split(/[,;/]/).map(x => x.replace(/\D/g, '')).filter(Boolean)
      .map(x => x.length === IR_N + 2 && x.startsWith('91') ? x.slice(2) : x.length === IR_N + 1 && x.startsWith('0') ? x.slice(1) : x);
    const b = nums.find(x => x.length !== IR_N); if (b) bad = `A mobile number has ${IR_N} digits ("${b}" has ${b.length}).`;
    else el.value = nums.join(', ');
  } else if (r === 'digits' && el.value.length !== IR_DIGITS[el.name]) bad = `${el.name.includes('pin') ? 'Pincode' : el.name.includes('aadhaar') ? 'Aadhaar' : 'This number'} must have ${IR_DIGITS[el.name]} digits.`;
  else if (r === 'code' && IR_CODE[el.name] && el.value.length !== IR_CODE[el.name]) bad = `${el.name.includes('gst') ? 'GSTIN' : el.name.includes('pan') ? 'PAN' : 'IFSC'} must have ${IR_CODE[el.name]} characters.`;
  else if (r === 'code' && /gst/.test(el.name) && !/^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z0-9]Z[A-Z0-9]$/.test(el.value)) bad = 'This GSTIN does not look right (e.g. 08ABCDE1234F1Z5).';
  else if (r === 'code' && /pan/.test(el.name) && !/^[A-Z]{5}\d{4}[A-Z]$/.test(el.value)) bad = 'This PAN does not look right (e.g. ABCDE1234F).';
  else if (r === 'code' && /ifsc/.test(el.name) && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(el.value)) bad = 'This IFSC does not look right (e.g. SBIN0001234).';
  else if (r === 'lower' && ['email', 'smtp_user'].includes(el.name) && el.value.split(/[,;\s]+/).filter(Boolean).some(x => !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))) bad = 'This email does not look right.';
  if (bad) { el.style.outline = '2px solid var(--bad)'; el.title = bad; toast(bad, true); }
}, true);
