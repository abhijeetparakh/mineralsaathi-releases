'use strict';
// WhatsApp: a simple chat window (text, photos, files) and template messages linked to invoices, sample dispatches and payment reminders.
TITLES.wa = 'WhatsApp';
TITLES.wasettings = 'WhatsApp Settings';
// WhatsApp settings live in Settings → Important Settings → WhatsApp (edit password); the old address goes there
SETTINGS.whatsapp = box => waSettingsPage(box);

const waTime = t => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) + ' ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }); };
const waPhone = p => { const d = String(p || ''); return d.length === 12 && d.startsWith('91') ? '+91 ' + d.slice(2, 7) + ' ' + d.slice(7) : '+' + d; };
const waTick = m => m.dir !== 'out' ? '' : m.status === 'read' ? '<span style="color:#34b7f1">✓✓</span>' : m.status === 'delivered' ? '✓✓' : m.status === 'failed' ? `<span style="color:var(--bad)" title="${esc(m.error || '')}">⚠ not sent</span>` : '✓';
const waFmt = s => esc(s).replace(/\*([^*\n]+)\*/g, '<b>$1</b>').replace(/_([^_\n]+)_/g, '<i>$1</i>').replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank">$1</a>').replace(/\n/g, '<br>');
const WA_CSS = `<style>
.wa{display:grid;grid-template-columns:320px 1fr;height:calc(100vh - 120px);min-height:480px;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff}
.wa .side{border-right:1px solid var(--line);display:flex;flex-direction:column;min-height:0}.wa .side .top{padding:10px;display:flex;gap:6px;border-bottom:1px solid var(--line)}
.wa .list{overflow:auto;flex:1}.wa .ci{padding:10px 12px;border-bottom:1px solid #f0f3f4;cursor:pointer;display:flex;gap:10px;align-items:center}.wa .ci:hover{background:#f5f8f9}.wa .ci.on{background:#e6f3ef}
.wa .av{width:40px;height:40px;border-radius:50%;background:#cfe6dd;color:#1f5f4a;display:grid;place-items:center;font-weight:700;flex:none}
.wa .ci .n{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.wa .ci .l{color:#667781;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wa .ci .u{background:#25d366;color:#fff;border-radius:10px;font-size:11px;padding:1px 7px;font-weight:700}
.wa .main{display:flex;flex-direction:column;min-height:0;background:#efeae2}.wa .head{background:#f0f2f5;padding:10px 14px;display:flex;gap:10px;align-items:center;border-bottom:1px solid var(--line)}
.wa .msgs{flex:1;overflow:auto;padding:14px 6%}.wa .b{max-width:70%;margin:4px 0;padding:6px 9px 4px;border-radius:8px;box-shadow:0 1px .5px rgba(0,0,0,.13);font-size:14px;line-height:1.4;word-wrap:break-word;clear:both}
.wa .b.in{background:#fff;float:left;border-top-left-radius:0}.wa .b.out{background:#d9fdd3;float:right;border-top-right-radius:0}
.wa .b .t{font-size:11px;color:#667781;text-align:right;margin-top:2px}.wa .b img{max-width:280px;max-height:300px;border-radius:6px;display:block;cursor:pointer}
.wa .b .doc{display:flex;gap:8px;align-items:center;background:rgba(0,0,0,.05);padding:8px;border-radius:6px;text-decoration:none;color:inherit}
.wa .b .tp{font-size:11px;color:#1f7a5a;font-weight:600;margin-bottom:2px}.wa .day{clear:both;text-align:center;margin:10px 0}.wa .day span{background:#fff;padding:3px 10px;border-radius:8px;font-size:12px;color:#54656f}
.wa .comp{background:#f0f2f5;padding:8px 10px;display:flex;gap:8px;align-items:flex-end}.wa .comp textarea{flex:1;resize:none;border-radius:8px;min-height:40px;max-height:140px}
.wa .closed{background:#fff8e1;color:#6d5500;padding:8px 12px;font-size:13px;display:flex;gap:10px;align-items:center;justify-content:space-between}
.wa .empty2{margin:auto;color:#667781;text-align:center}
</style>`;

PAGES.wa = async (el, phoneArg) => {
  el.innerHTML = WA_CSS + `<div class="wa"><div class="side"><div class="top"><input id="waq" placeholder="Search name or number"><button class="small" id="wanew" title="Start a chat with a number">+ New</button></div><div class="list" id="walist"></div><div id="wapoll" class="hint" style="padding:6px 10px"></div></div>
    <div class="main" id="wamain"><div class="empty2"><div style="font-size:46px">💬</div>Choose a chat on the left</div></div></div>`;
  let cur = phoneArg || null, lastId = 0, chats = [];
  const drawList = async () => {
    const r = await GET('/api/wa/chats' + ($('#waq', el).value ? '?q=' + encodeURIComponent($('#waq', el).value) : '')).catch(() => null); if (!r) return;
    chats = r.chats;
    $('#walist', el).innerHTML = r.ready ? chats.map(c => `<div class="ci ${c.phone === cur ? 'on' : ''}" data-ph="${esc(c.phone)}"><div class="av">${esc((c.name || '#').replace(/[^A-Za-z0-9 ]/g, '').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '#')}</div>
      <div style="flex:1;min-width:0"><div class="row" style="justify-content:space-between;gap:6px"><span class="n">${esc(c.name || waPhone(c.phone))}</span><span class="hint" style="font-size:11px">${c.last_at ? waTime(c.last_at) : ''}</span></div>
      <div class="row" style="justify-content:space-between;gap:6px"><span class="l">${esc(c.last_text || '')}</span>${c.unread ? `<span class="u">${c.unread}</span>` : ''}</div></div></div>`).join('') || '<p class="hint" style="padding:12px">No chats yet.</p>'
      : '<p style="padding:12px">WhatsApp is not set up yet. <a href="#/settings/whatsapp">Open Settings → Important Settings → WhatsApp</a></p>';
    $('#wapoll', el).innerHTML = r.poll.error ? `<span style="color:var(--bad)">⚠ Messages not coming in: ${esc(r.poll.error)}</span>` : r.poll.at ? `Checked ${waTime(r.poll.at)}` : '';
  };
  const drawChat = async (full) => {
    if (!cur) return;
    const r = await GET(`/api/wa/chat/${cur}${full ? '' : '?after=' + lastId}`).catch(e => { toast(e.message, true); return null; }); if (!r) return;
    const main = $('#wamain', el);
    if (full) {
      const c = r.chat, who = c.who;
      main.innerHTML = `<div class="head"><div class="av" style="width:38px;height:38px;border-radius:50%;background:#cfe6dd;display:grid;place-items:center;font-weight:700">${esc((c.name || '#')[0])}</div>
        <div style="flex:1"><b>${esc(c.name || waPhone(c.phone))}</b><div class="hint">${esc(waPhone(c.phone))}${who ? ` · ${esc(who.kind)}${who.city ? ' · ' + esc(who.city) : ''}` : ''}</div></div>
        <button class="small sec" id="watpl">📋 Template</button></div>
        <div class="msgs" id="wamsgs"></div>
        ${c.open ? '' : `<div class="closed"><span>🔒 More than 24 hours since this customer last wrote — WhatsApp allows only an approved <b>template</b> message. Chat opens again when the customer replies.</span><button class="small" id="watpl2">📋 Send template</button></div>`}
        <div class="comp"><button class="sec" id="waatt" title="Send a photo or file" ${c.open ? '' : 'disabled'}>📎</button><input type="file" id="wafile" multiple hidden>
          <textarea id="watxt" rows="1" placeholder="${c.open ? 'Type a message' : 'Only a template can be sent now'}" ${c.open ? '' : 'disabled'}></textarea><button id="wasend" ${c.open ? '' : 'disabled'}>Send</button></div>`;
      lastId = 0;
      const t = $('#watxt', el), send = async () => {
        const v = t.value.trim(); if (!v) return; $('#wasend', el).disabled = true;
        try { await POST('/api/wa/send', { phone: cur, text: v }); t.value = ''; await drawChat(false); drawList(); } catch (e) { toast(e.message, true); } finally { $('#wasend', el).disabled = false; t.focus(); }
      };
      $('#wasend', el).onclick = send;
      t.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
      t.oninput = () => { t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight) + 'px'; };
      $('#waatt', el).onclick = () => $('#wafile', el).click();
      $('#wafile', el).onchange = async e => { const files = [...e.target.files]; e.target.value = ''; waSendFiles(cur, files, async () => { await drawChat(false); drawList(); }); };
      $('#watpl', el).onclick = () => waTemplateDialog(cur, async () => { await drawChat(false); drawList(); });
      const t2 = $('#watpl2', el); if (t2) t2.onclick = $('#watpl', el).onclick;
    }
    const box = $('#wamsgs', el); if (!box) return;
    const atEnd = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    let lastDay = box.dataset.day || '';
    const html = r.msgs.map(m => {
      lastId = Math.max(lastId, m.id);
      const day = new Date(m.at).toDateString(), sep = day !== lastDay ? `<div class="day"><span>${esc(new Date(m.at).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }))}</span></div>` : ''; lastDay = day;
      const isImg = m.has_file && (m.type === 'image' || m.type === 'sticker' || /^image\//.test(m.mime || ''));
      const file = m.has_file ? isImg ? `<a href="/wa-media/${m.id}" target="_blank"><img src="/wa-media/${m.id}" loading="lazy" alt=""></a>`
        : `<a class="doc" href="/wa-media/${m.id}" target="_blank">📄 <span>${esc(m.filename || (m.type === 'audio' ? 'Voice / audio' : m.type === 'video' ? 'Video' : 'File'))}</span></a>` : '';
      const react = m.error && m.error.startsWith('reaction:') ? ` <span>${esc(m.error.slice(9))}</span>` : '';
      return `${sep}<div class="b ${m.dir}">${m.template ? `<div class="tp">📋 ${esc(m.template)}</div>` : ''}${file}${m.text ? `<div>${waFmt(m.text)}</div>` : ''}<div class="t">${waTime(m.at)} ${waTick(m)}${react}</div>${m.status === 'failed' && m.error && !m.error.startsWith('reaction:') ? `<div class="hint" style="color:var(--bad)">${esc(m.error)}</div>` : ''}</div>`;
    }).join('');
    box.dataset.day = lastDay;
    if (full) box.innerHTML = html + '<div style="clear:both"></div>'; else if (html) box.lastElementChild.insertAdjacentHTML('beforebegin', html);
    if (full || atEnd) box.scrollTop = box.scrollHeight;
    // ticks of earlier messages change: redraw them all now and then
  };
  const open = async phone => { cur = phone; history.replaceState(null, '', '#/wa/' + phone); await drawChat(true); drawList(); };
  $('#walist', el).onclick = e => { const c = e.target.closest('[data-ph]'); if (c) open(c.dataset.ph); };
  let qT; $('#waq', el).oninput = () => { clearTimeout(qT); qT = setTimeout(drawList, 300); };
  $('#wanew', el).onclick = () => modal('New WhatsApp chat', `<form id="wanf">${field({ name: 'phone', label: 'Mobile number (10 digits, or with country code)' }, '')}
      <p class="hint">A new chat can start only with an approved template message (WhatsApp rule).</p><div class="row"><button type="submit">Open chat</button></div></form>`, root => {
    $('#wanf', root).onsubmit = async e => { e.preventDefault(); const r = await guard(() => POST('/api/wa/new-chat', { phone: e.target.phone.value })); closeModal(); open(r.phone); };
  });
  await drawList(); if (cur) await drawChat(true);
  let n = 0;
  const timer = setInterval(async () => {
    if (!el.isConnected || !location.hash.startsWith('#/wa') || location.hash.startsWith('#/wasettings')) return clearInterval(timer);
    n++; await drawList(); if (cur) await drawChat(n % 6 === 0);     // every 30 s a full redraw (ticks)
  }, 5000);
};

function waSendFiles(phone, files, after) {
  if (!files.length) return;
  const big = files.find(f => f.size > 30e6); if (big) return toast(`${big.name} is too big (30 MB at most here).`, true);
  modal(`Send ${files.length === 1 ? 'file' : files.length + ' files'}`, `<form id="waff">${files.map((f, i) => `<div class="row" style="gap:10px;align-items:center;margin-bottom:8px">${/^image\//.test(f.type) ? `<img id="wapv${i}" style="width:70px;height:70px;object-fit:cover;border-radius:6px">` : '<span style="font-size:34px">📄</span>'}
      <div style="flex:1"><b>${esc(f.name)}</b> <span class="hint">${(f.size / 1024 / 1024).toFixed(2)} MB</span><input name="cap${i}" placeholder="Caption (optional)"></div></div>`).join('')}
    <div class="row"><button type="submit">Send</button></div></form>`, root => {
    files.forEach((f, i) => { const im = $('#wapv' + i, root); if (im) im.src = URL.createObjectURL(f); });
    $('#waff', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true;
      for (let i = 0; i < files.length; i++) {
        b.textContent = `Sending ${i + 1} of ${files.length}…`;
        try { await POST('/api/wa/send-file', { phone, name: files[i].name, data: await readAsDataUrl(files[i]), caption: e.target['cap' + i].value }); }
        catch (err) { toast(`${files[i].name}: ${err.message}`, true); b.disabled = false; b.textContent = 'Send'; return; }
      }
      toast('Sent'); closeModal(); after && after();
    };
  });
}

// choose an approved template and fill in its {{variables}}
async function waTemplateDialog(phone, after) {
  const list = (await guard(() => GET('/api/wa/templates'))).filter(t => t.status === 'APPROVED');
  if (!list.length) return toast('No approved template yet — Settings → Important Settings → WhatsApp → Get templates from Meta.', true);
  modal('Send a template message', `<form id="watf"><label>Template<select name="tpl">${list.map((t, i) => `<option value="${i}">${esc(t.name)} (${esc(t.language)}) · ${esc(t.category || '')}</option>`).join('')}</select></label>
    <div id="watb" style="margin-top:8px"></div><div class="row" style="margin-top:10px"><button type="submit">Send</button></div></form>`, root => {
    const f = $('#watf', root);
    const show = () => {
      const t = list[Number(f.tpl.value)], body = t.components.find(c => c.type === 'BODY') || {}, head = t.components.find(c => c.type === 'HEADER');
      const keys = [...(body.text || '').matchAll(/\{\{\s*([^}\s]+)\s*\}\}/g)].map(m => m[1]);
      $('#watb', root).innerHTML = `<div class="firmbox" style="white-space:pre-wrap;font-size:13.5px">${esc(body.text || '')}</div>
        ${head && head.format && head.format !== 'TEXT' ? `<label style="margin-top:8px">${esc(head.format.toLowerCase())} on top (required)<input type="file" name="hfile" ${head.format === 'IMAGE' ? 'accept="image/jpeg,image/png"' : head.format === 'VIDEO' ? 'accept="video/mp4"' : ''}></label>` : ''}
        ${head && head.format === 'TEXT' && /\{\{/.test(head.text || '') ? `<label style="margin-top:8px">Heading value (${esc(head.text)})<input name="htext"></label>` : ''}
        ${keys.map((k, i) => `<label style="margin-top:6px">{{${esc(k)}}}<input name="v${i}"></label>`).join('')}`;
    };
    f.tpl.onchange = show; show();
    f.onsubmit = async e => {
      e.preventDefault(); const t = list[Number(f.tpl.value)], b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const params = [...f.querySelectorAll('[name^=v]')].map(i => i.value);
      const hf = f.hfile && f.hfile.files[0];
      try { await POST('/api/wa/send-template', { phone, name: t.name, language: t.language, params, header: hf ? { name: hf.name, data: await readAsDataUrl(hf) } : null, header_text: f.htext ? f.htext.value : '' });
        toast('Template sent'); closeModal(); after && after(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send'; }
    };
  });
}

// 💬 WhatsApp from an invoice (SALE / B2C), a sample dispatch (SAMPLE) or a payment reminder (REMINDER, ids)
async function waFor(kind, ref, after) {
  const p = await guard(() => POST(`/api/wa/for/${kind}/preview`, ref));
  modal(`WhatsApp · ${p.title} · ${p.to || ''}`, `<form id="wafr">
    <p style="margin:0 0 8px">Template <b>${esc(p.template)}</b> (${esc(p.language)})${p.status !== 'APPROVED' ? ` <span class="badge red">${esc(p.status)}</span>` : ''}${p.header ? ` · with the <b>${esc(p.doc)}</b> on top` : ''}</p>
    ${field({ name: 'phone', label: 'WhatsApp number' }, p.phone)}
    <div class="firmbox" style="white-space:pre-wrap;font-size:13.5px;margin-top:8px">${esc(p.text)}</div>
    <div class="row" style="margin-top:10px"><button type="submit" ${p.status === 'APPROVED' ? '' : 'disabled'}>💬 Send on WhatsApp</button><a href="#/wa/${esc(p.phone)}" onclick="closeModal()">Open the chat</a></div></form>`, root => {
    $('#wafr', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      try { await POST(`/api/wa/for/${kind}`, { ...ref, phone: e.target.phone.value }); toast('Sent on WhatsApp to ' + (p.to || p.phone)); closeModal(); after && after(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = '💬 Send on WhatsApp'; }
    };
  });
}

// ---------- Settings → Important Settings → WhatsApp ----------
PAGES.wasettings = () => go('#/settings/whatsapp');
async function waSettingsPage(el) {
  const [s, tpls] = await Promise.all([GET('/api/wa/settings'), GET('/api/wa/templates')]);
  const approved = tpls.filter(t => t.status === 'APPROVED');
  const bodyKeys = t => { const b = t && t.components.find(c => c.type === 'BODY'); return b ? [...(b.text || '').matchAll(/\{\{\s*([^}\s]+)\s*\}\}/g)].map(m => m[1]) : []; };
  const linkBox = k => {
    const P = s.purposes[k], l = s.links[k] || {}, t = tpls.find(x => x.name === l.template && x.language === l.language) || tpls.find(x => x.name === l.template);
    const keys = bodyKeys(t), body = t && (t.components.find(c => c.type === 'BODY') || {}).text, head = t && t.components.find(c => c.type === 'HEADER');
    return `<div class="card" data-link="${k}"><h3>${esc(P.title)}</h3>
      <label>Template<select data-ltpl="${k}"><option value="">— not linked —</option>${approved.map(x => `<option value="${esc(x.name + '|' + x.language)}" ${t && x.id === t.id ? 'selected' : ''}>${esc(x.name)} (${esc(x.language)})</option>`).join('')}</select></label>
      ${t ? `<div class="firmbox" style="white-space:pre-wrap;font-size:13px;margin-top:8px">${esc(body || '')}</div>
        ${head && head.format && head.format !== 'TEXT' ? `<p class="hint" style="margin:6px 0 0">On top (${esc(head.format.toLowerCase())}): <b>${esc(P.doc)}</b> is sent by itself.</p>` : ''}
        ${keys.length ? `<table class="t" style="margin-top:8px"><thead><tr><th style="width:90px">Variable</th><th>Filled with</th></tr></thead><tbody>${keys.map((key, i) => { const v = (l.vars || [])[i] || ''; const fixed = v.startsWith('=');
          return `<tr><td><b>{{${esc(key)}}}</b></td><td><div class="row" style="gap:6px"><select data-lv="${k}:${i}">${['', ...P.fields].map(o => `<option value="${esc(o)}" ${!fixed && o === v ? 'selected' : ''}>${o ? esc(o) : '— choose —'}</option>`).join('')}<option value="=" ${fixed ? 'selected' : ''}>Fixed text…</option></select>
            <input data-lf="${k}:${i}" value="${esc(fixed ? v.slice(1) : '')}" placeholder="fixed text" ${fixed ? '' : 'hidden'}></div></td></tr>`; }).join('')}</tbody></table>` : '<p class="hint">This template has no variables.</p>'}
        ${P.auto ? `<div class="firmbox" style="margin-top:10px"><label style="display:flex;gap:8px;align-items:center;margin:0"><input type="checkbox" data-lauto="${k}" style="width:auto" ${l.auto ? 'checked' : ''}> <b>Send automatically</b> ${esc(P.auto)}</label>
          <div class="row" style="gap:8px;margin-top:6px;align-items:center">after <input type="number" min="1" max="90" data-ldelay="${k}" value="${esc(l.delay || 10)}" style="width:80px"> minutes <span class="hint">(1 to 90)</span></div>
          <p class="hint" style="margin:6px 0 0">Sent once — not again when it was already sent (by hand or automatically). The 💬 button still sends by hand any time. Every message is in Reports → Communication Log → WhatsApp log.</p></div>`
          : '<p class="hint" style="margin-top:8px">Sent by hand only (💬 WhatsApp button on the payment reminder).</p>'}` : ''}</div>`;
  };
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start">
    <form class="card" id="wasf" autocomplete="off" data-nocase data-norefine><h3>WhatsApp Cloud API (Meta)</h3>
      <div class="grid g2">
        ${field({ name: 'phone_id', label: 'Phone number ID' }, s.phone_id)}${field({ name: 'waba_id', label: 'WhatsApp Business Account ID' }, s.waba_id)}
        <label class="span2">Access token (permanent, system user) <span class="hint" id="watoklen"></span><textarea name="token" rows="2" spellcheck="false" autocomplete="off" style="font-family:monospace;font-size:12px" placeholder="${s.has_token ? '•••••••• saved — paste a new token here only to replace it' : 'EAAG… (paste the whole token from Meta)'}"></textarea></label>
        ${field({ name: 'version', label: 'Graph API version' }, s.version)}${field({ name: 'cc', label: 'Country code for 10-digit numbers' }, s.cc)}</div>
      <h3 style="margin-top:14px">Incoming messages (from WMessage Saathi)</h3>
      <p class="hint" style="margin-top:0">Meta sends this number's messages to the WMessage Saathi callback URL. In WMessage Saathi → Settings → 📥 Receive messages → <b>Linked app</b>, press “Turn on”, then copy its fetch URL and key here.</p>
      <div class="grid g2">${field({ name: 'relay_url', label: 'Fetch URL', span: 2 }, s.relay_url)}
        <label class="span2">Linked-app key<textarea name="relay_key" rows="1" spellcheck="false" autocomplete="off" style="font-family:monospace;font-size:12px" placeholder="${s.has_key ? '•••••••• saved — paste a new key here only to replace it' : 'paste the key'}"></textarea></label></div>
      <p class="hint">${s.poll.error ? `<span style="color:var(--bad)">⚠ ${esc(s.poll.error)}</span>` : s.poll.at ? `✅ Messages checked ${waTime(s.poll.at)}` : 'Not fetching yet.'}</p>
      <div class="row" style="gap:8px;margin-top:8px"><button type="submit">Save</button><button type="button" class="sec" id="watest">🔌 Test connection</button><button type="button" class="sec" id="wasync">⟳ Get templates from Meta</button></div>
      <div id="wares" class="hint" style="margin-top:8px"></div>
      <p class="hint">Templates are made and approved in Meta (WhatsApp Manager → Message templates). ${tpls.length} template${tpls.length === 1 ? '' : 's'} here, ${approved.length} approved. No calls — this is only for messages.</p></form>
    <div><div class="card"><h3>Templates linked to the software</h3><p class="hint" style="margin:0">Choose a template for each paper and what fills each {{variable}}. Then the 💬 WhatsApp button on the invoice, the sample dispatch and the payment reminder sends it.</p></div>
      ${Object.keys(s.purposes).map(linkBox).join('')}
      <div class="row"><button id="walsave">Save links</button></div></div></div>`;
  const f = $('#wasf', el);
  // the token box is a text box, not a password box, so the browser's password manager cannot put a saved password into it
  f.token.oninput = () => { const t = f.token.value.replace(/\s+/g, ''); $('#watoklen', el).textContent = t ? `— ${t.length} characters${/^EA/.test(t) ? '' : ' · a Meta token starts with EA'}` : ''; };
  f.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/wa/settings', formData(f))); toast('WhatsApp settings saved'); waSettingsPage(el); };
  $('#watest', el).onclick = async () => { await guard(() => PUT('/api/wa/settings', formData(f))); $('#wares', el).textContent = 'Checking…';
    try { const r = await POST('/api/wa/test'); $('#wares', el).innerHTML = `✅ <b>${esc(r.number)}</b> · ${esc(r.name)} · quality ${esc(r.quality || '—')} · incoming messages: <b>${esc(r.relay)}</b>`; } catch (e) { $('#wares', el).innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; } };
  $('#wasync', el).onclick = async () => { await guard(() => PUT('/api/wa/settings', formData(f))); const r = await guard(() => POST('/api/wa/templates/sync')); toast(`${r.count} templates from Meta`); waSettingsPage(el); };
  const collect = () => { const links = {}; for (const k of Object.keys(s.purposes)) { const sel = $(`[data-ltpl="${k}"]`, el).value; if (!sel) continue; const [template, language] = sel.split('|');
    const vars = $$(`[data-lv^="${k}:"]`, el).map(x => x.value === '=' ? '=' + $(`[data-lf="${x.dataset.lv}"]`, el).value : x.value);
    const au = $(`[data-lauto="${k}"]`, el), dl = $(`[data-ldelay="${k}"]`, el);
    links[k] = { template, language, vars, auto: !!(au && au.checked), delay: dl ? Number(dl.value) || 10 : (s.links[k] || {}).delay || 10 }; } return links; };
  el.onchange = async e => {
    if (e.target.matches('[data-ltpl]')) { await guard(() => PUT('/api/wa/settings', { links: collect() })); waSettingsPage(el); }
    if (e.target.matches('[data-lv]')) { const i = $(`[data-lf="${e.target.dataset.lv}"]`, el); i.hidden = e.target.value !== '='; if (!i.hidden) i.focus(); }
    if (e.target.matches('[data-ldelay]')) { const n = Number(e.target.value); if (n >= 1 && n <= 90) { await guard(() => PUT('/api/wa/settings', { links: collect() })); toast(`Sent ${n} minute${n === 1 ? '' : 's'} after`); } else toast('Enter 1 to 90 minutes.', true); }
    if (e.target.matches('[data-lauto]')) { await guard(() => PUT('/api/wa/settings', { links: collect() }));
      toast(e.target.checked ? `Automatic WhatsApp on: ${s.purposes[e.target.dataset.lauto].title}` : `Automatic WhatsApp off: ${s.purposes[e.target.dataset.lauto].title}`); }
  };
  $('#walsave', el).onclick = async () => { await guard(() => PUT('/api/wa/settings', { links: collect() })); toast('Template links saved'); };
}

// ---------- Reports → Communication Log → WhatsApp log ----------
async function waLog(el) {
  const st = S.walog = S.walog || { status: '', from: '', to: '' };
  const rows = await GET(`/api/wa/log?status=${st.status}&from=${st.from}&to=${st.to}`);
  const tm = t => new Date(t), d2 = n => String(n).padStart(2, '0');
  const badge = s => s === 'FAILED' ? '<span class="badge red">FAILED</span>' : s === 'WAITING' ? '<span class="badge">WAITING</span>' : ['SKIPPED', 'OFF'].includes(s) ? `<span class="badge grey">${s}</span>` : `<span class="badge slate">${esc(s)}</span>`;
  el.innerHTML = `<div class="card"><div class="toolbar">
      <label>Status<select id="wls"><option value="">All</option>${['SENT', 'FAILED', 'WAITING', 'SKIPPED'].map(x => `<option ${st.status === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
      <label>From<input type="date" id="wlfr" value="${st.from}"></label><label>To<input type="date" id="wlto" value="${st.to}"></label>
      <span class="spacer"></span><button class="sec" id="wlx">Export</button></div>
    <div class="tablewrap" style="max-height:70vh"><table class="t"><thead><tr><th>Date</th><th>Time</th><th>To</th><th>For</th><th>Template / message</th><th>How</th><th>Status</th></tr></thead><tbody>
    ${rows.map(r => { const t = tm(r.at); return `<tr><td>${d2(t.getDate())}.${d2(t.getMonth() + 1)}.${t.getFullYear()}</td><td>${d2(t.getHours())}:${d2(t.getMinutes())}</td>
      <td>${esc(r.name)}<br><span class="hint">${r.phone ? `<a href="#/wa/${esc(r.phone)}">+${esc(r.phone)}</a>` : ''}</span></td><td><b>${esc(r.what)}</b></td>
      <td>${r.template ? `<b>${esc(r.template)}</b><br>` : ''}<span class="hint">${esc(String(r.text || '').slice(0, 140))}</span></td><td>${esc(r.how)}</td>
      <td>${badge(r.status)}${r.error ? `<br><span class="hint">${esc(r.error)}</span>` : ''}</td></tr>`; }).join('') || '<tr><td colspan="7" class="muted">No WhatsApp messages yet.</td></tr>'}
    </tbody></table></div></div>`;
  const re = () => waLog(el);
  $('#wls').onchange = e => { st.status = e.target.value; re(); };
  $('#wlfr').onchange = e => { st.from = e.target.value; re(); }; $('#wlto').onchange = e => { st.to = e.target.value; re(); };
  $('#wlx').onclick = () => downloadCsv('whatsapp_log.csv', rows.map(r => ({ at: new Date(r.at).toLocaleString('en-IN'), to: r.name, phone: r.phone, for: r.what, template: r.template, message: r.text, how: r.how, status: r.status, error: r.error })));
}
