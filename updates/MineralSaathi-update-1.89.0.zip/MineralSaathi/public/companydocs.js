'use strict';
// Settings → Companies → Documents / Vendor form, and Buyer → "📇 Send company details"
function companySubTabs(code, sub) {
  return `<div class="tabs" style="margin-bottom:14px">${[['', '🏢 Company details'], ['docs', '📎 Documents'], ['vendor', '📝 Vendor form']]
    .map(([k, t]) => `<button class="${k === sub ? 'on' : ''}" onclick="go('#/settings/company:${code}${k ? ':' + k : ''}')">${t}</button>`).join('')}</div>`;
}

async function companyDocsPage(box, code, sub) {
  const firms = await GET('/api/m/firms');
  code = firms.some(f => f.code === code) ? code : 'PM';
  const f = firms.find(x => x.code === code), d = await GET('/api/firm-docs/' + code);
  const head = `<div class="tabs" style="margin-bottom:14px">${firms.map(x => `<button class="${x.code === code ? 'on' : ''}" onclick="go('#/settings/company:${x.code}:${sub}')"><span class="badge ${x.code}" style="margin-right:6px">${x.code}</span>${esc(x.name)}</button>`).join('')}</div>
    ${companySubTabs(code, sub)}`;
  if (sub === 'docs') {
    const doc = k => d.docs.filter(x => x.kind === k).pop();
    box.innerHTML = head + `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(230px,1fr));align-items:start">
      ${Object.entries(d.kinds).map(([k, t]) => { const x = doc(k), pic = k === 'BANK' && !x && d.bank_picture;
        return `<div class="card" style="text-align:center"><h3>${esc(t)}</h3>
          <div style="height:160px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--line);border-radius:10px;background:#fafcfc;margin-bottom:10px;overflow:hidden">
            ${x ? (/^image\//.test(x.mime) ? `<img src="/firm-doc/${x.id}" style="max-height:150px;max-width:100%">` : `<a href="/firm-doc/${x.id}" target="_blank" style="font-size:48px;text-decoration:none">📄</a>`)
              : pic ? `<img src="${esc(f.bank_proof)}" style="max-height:150px;max-width:100%">` : '<span class="muted">Not uploaded</span>'}</div>
          ${x ? `<div class="hint" style="margin-bottom:6px">${esc(x.name)}</div>` : pic ? '<div class="hint" style="margin-bottom:6px">the bank proof picture of Company details</div>' : ''}
          <div class="row" style="justify-content:center;gap:6px"><button type="button" data-up="${k}">${x || pic ? 'Replace' : 'Upload'}</button>${x ? `<a class="small" href="/firm-doc/${x.id}" target="_blank">Open</a> <button type="button" class="sec small" data-rm="${x.id}">Remove</button>` : ''}</div>
        </div>`; }).join('')}</div>
      <input type="file" id="cdfile" accept="application/pdf,image/png,image/jpeg,image/webp" hidden>
      <p class="hint">PDF or photo, 10 MB at most. These go with the “Company details” email to a buyer (Master → Buyer → 📇 Send company details), each one only if ticked.</p>`;
    let kind = null; const fi = $('#cdfile', box);
    $$('[data-up]', box).forEach(b => b.onclick = () => { kind = b.dataset.up; fi.value = ''; fi.click(); });
    fi.onchange = async () => {
      const file = fi.files[0]; if (!file || !kind) return;
      const img = /^image\//.test(file.type), data = img ? await shrinkPhoto(file) : await readAsDataUrl(file);
      await guard(() => POST('/api/firm-docs/' + code, { kind, name: img ? `${d.kinds[kind]}.jpg` : file.name, data })); toast(d.kinds[kind] + ' saved'); companyDocsPage(box, code, sub);
    };
    $$('[data-rm]', box).forEach(b => b.onclick = async () => { if (!confirm('Remove this document?')) return; await guard(() => DEL('/api/firm-docs/' + b.dataset.rm)); companyDocsPage(box, code, sub); });
    return;
  }
  // vendor form: questions and answers, add / delete / move
  // rows: [particular (without "A) "), answer, particular as saved, sub-row?]; a sub-row belongs to the row above and gets A), B) … by itself
  const SUBRE = /^[A-Za-z]\)\s*/;
  let rows = d.vendor.map(r => [String(r[0]).replace(SUBRE, ''), r[1], r[0], SUBRE.test(r[0])]);
  const letters = () => { let k = 0; return rows.map((r, i) => { if (!r[3] || !i) { k = 0; return ''; } return String.fromCharCode(65 + k++) + ')'; }); };
  box.innerHTML = head + `<div class="card"><div class="toolbar"><h3 style="margin:0">Vendor registration form <span class="hint">— printed on the letter head of ${esc(f.name)} with the signature</span></h3><span class="spacer"></span>
      <a class="small sec" style="padding:5px 10px;border-radius:6px;border:1px solid var(--line);text-decoration:none" href="/print/vendorform/${code}" target="_blank">🖨 Print / preview</a></div>
    ${d.vendor_saved ? '' : '<p class="badge amber" style="display:block;padding:8px 10px">Details filled from the company details — check them, fill in the empty answers and press Save.</p>'}
    <table class="t" id="vft"><thead><tr><th style="width:74px">Sl</th><th style="width:38%">Particulars</th><th>Details</th><th style="width:190px"></th></tr></thead><tbody></tbody></table>
    <div class="row" style="margin-top:8px;gap:8px"><button type="button" class="sec small" id="vfadd">+ Add row</button><button type="button" id="vfsave">Save vendor form</button></div>
    <p class="hint"><b>The particulars and their order are the same for every company</b> — a row added, removed, renamed or moved here changes the form of all companies; only the details (answers) are each company's own.<br>
      <b>Move a row:</b> hold ⠿ and drag it up or down (a main row takes its sub-rows with it), then press Save.<br><b>Sub-section</b> (like Banking Information → A) Bank Name, B) Bank Address …): press <b>+ Sub</b> on the main row to add a sub-row under it, or <b>↳</b> to make a row a sub-row of the row above (↳ again makes it a main row). Sub-rows get A), B), C) … by themselves. The form goes with the “Company details” email as a PDF.</p></div>`;
  const tb = $('#vft tbody', box);
  const read = () => { rows = $$('tr', tb).map(tr => [$('[data-q]', tr).value, $('[data-a]', tr).value, tr.dataset.was || '', tr.dataset.sub === '1']); };
  const draw = () => { let n = 0; const L = letters();
    tb.innerHTML = rows.map((r, i) => { const sub2 = r[3] && i > 0;
      return `<tr data-was="${esc(r[2] || '')}" data-sub="${sub2 ? 1 : 0}" data-i="${i}" draggable="true"><td class="c" style="white-space:nowrap"><span class="vgrip" title="Drag to move up or down" style="cursor:grab;color:#8aa0a6;font-size:16px;margin-right:4px">⠿</span>${sub2 ? `<span class="hint">${L[i]}</span>` : '<b>' + ++n + '.</b>'}</td>
      <td style="${sub2 ? 'padding-left:26px' : ''}"><input data-q value="${esc(r[0])}" placeholder="${sub2 ? 'Sub-row, e.g. Bank Name' : 'Particular'}"></td><td><textarea data-a rows="1" style="min-height:34px">${esc(r[1])}</textarea></td>
      <td style="white-space:nowrap">${sub2 ? '' : `<button type="button" class="small sec" data-addsub="${i}" title="Add a sub-row (A, B, C …) under this row">+ Sub</button>`}<button type="button" class="small sec" data-sub="${i}" title="${sub2 ? 'Make it a main row' : 'Make it a sub-row of the row above'}" ${i ? '' : 'disabled'}>${sub2 ? '↰' : '↳'}</button><button type="button" class="small sec" data-up2="${i}" ${i ? '' : 'disabled'} title="Move up">↑</button><button type="button" class="small sec" data-del="${i}" title="Remove">✕</button></td></tr>`; }).join(''); };
  draw();
  // drag a row (a main row takes its sub-rows with it) and drop it where it should go
  let dragFrom = null;
  tb.addEventListener('dragstart', e => {
    if (e.target.closest('input,textarea,button')) { e.preventDefault(); return; }
    const tr = e.target.closest('tr[data-i]'); if (!tr) return; read(); dragFrom = +tr.dataset.i;
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(dragFrom)); tr.style.opacity = '.4';
  });
  tb.addEventListener('dragend', () => { $$('tr', tb).forEach(t => { t.style.opacity = ''; t.style.boxShadow = ''; }); });
  tb.addEventListener('dragover', e => { if (dragFrom == null) return; e.preventDefault(); const tr = e.target.closest('tr[data-i]'); if (!tr) return;
    $$('tr', tb).forEach(t => { t.style.boxShadow = ''; }); const below = e.clientY > tr.getBoundingClientRect().top + tr.offsetHeight / 2;
    tr.style.boxShadow = below ? 'inset 0 -3px 0 #1c8fa8' : 'inset 0 3px 0 #1c8fa8'; tr.dataset.below = below ? 1 : 0; });
  tb.addEventListener('drop', e => {
    e.preventDefault(); const tr = e.target.closest('tr[data-i]'); if (dragFrom == null || !tr) return;
    let to = +tr.dataset.i + (tr.dataset.below === '1' ? 1 : 0);
    let n = 1; if (!rows[dragFrom][3] || dragFrom === 0) while (rows[dragFrom + n] && rows[dragFrom + n][3]) n++;   // main row + its sub-rows
    if (to > dragFrom && to <= dragFrom + n) { dragFrom = null; draw(); return; }
    const block = rows.splice(dragFrom, n); if (to > dragFrom) to -= n;
    rows.splice(to, 0, ...block); dragFrom = null; draw();
  });
  tb.onclick = e => {
    const u = e.target.closest('[data-up2]'), x = e.target.closest('[data-del]'), sb = e.target.closest('button[data-sub]'), as = e.target.closest('[data-addsub]');
    if (!u && !x && !sb && !as) return; read();
    if (u) { const i = +u.dataset.up2; [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; }
    else if (x) rows.splice(+x.dataset.del, 1);
    else if (sb) { const i = +sb.dataset.sub; rows[i][3] = !rows[i][3]; }
    else { let i = +as.dataset.addsub + 1; while (i < rows.length && rows[i][3]) i++; rows.splice(i, 0, ['', '', '', true]); draw(); $$('[data-q]', tb)[i].focus(); return; }
    draw();
  };
  $('#vfadd', box).onclick = () => { read(); rows.push(['', '', '', false]); draw(); $$('[data-q]', tb).pop().focus(); };
  $('#vfsave', box).onclick = async () => {
    read(); const L = letters();
    const send = rows.map((r, i) => [r[3] && i ? `${L[i]} ${r[0].trim()}` : r[0].trim(), r[1], r[2]]).filter(r => r[0] && !/^[A-Z]\)\s*$/.test(r[0]));
    await guard(() => PUT('/api/vendor-form/' + code, { rows: send })); toast('Vendor form saved'); companyDocsPage(box, code, sub);
  };
}

// Master → Buyer: email our company details with the chosen documents and the vendor form
async function companyMail(ref, firm, tid) {
  const qs = new URLSearchParams({ ...ref, ...(firm ? { firm } : {}), ...(tid ? { tid } : {}) });
  const d = await guard(() => GET('/api/company-mail?' + qs));
  modal(`📇 Company details · ${d.buyer}`, `${d.ready ? '' : `<p class="badge amber">Email is not set up for ${esc(d.firm)}. Open Settings → Companies → Email sending first.</p>`}
    <form id="cmf"><div class="grid g2">
      <label>From company<select id="cmfirm">${d.firms.map(x => `<option value="${x.code}" ${x.code === d.firm_code ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
      ${d.templates.length > 1 ? `<label>Email template<select id="cmtpl">${d.templates.map(x => `<option value="${x.id}" ${String(x.id) === String(tid) ? 'selected' : ''}>${esc(x.name)}${x.is_default ? ' (default)' : ''}</option>`).join('')}</select></label>` : '<span></span>'}
      <div class="span2 firmbox" style="margin:0"><b>Send these documents?</b><div class="grid g3" style="margin-top:6px">${d.att.map(a => `<label style="display:flex;gap:8px;align-items:center;font-weight:500;${a.has ? '' : 'opacity:.5'}">
        <input type="checkbox" data-att="${a.k}" style="width:auto" ${a.has ? 'checked' : 'disabled'}> ${esc(a.label)}${a.has ? '' : ' <span class="hint">(not uploaded)</span>'}${a.k === 'VENDOR' ? ` <a class="small" href="/print/vendorform/${d.firm_code}" target="_blank">👁</a>` : ''}</label>`).join('')}</div>
        <p class="hint" style="margin:6px 0 0">Upload the documents in Settings → Companies → ${esc(d.firm)} → 📎 Documents; the vendor form is in 📝 Vendor form.</p></div>
      ${field({ name: 'to', label: 'To' }, d.to)}${field({ name: 'cc', label: 'CC' }, d.cc)}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, d.subject)}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text', d.html || textToHtmlC(d.text), 260)}</div></div>
      <div class="row" style="margin-top:8px"><button type="submit" ${d.ready ? '' : 'disabled'}>Send email</button><span class="hint">Sent from ${esc(d.from)} (${esc(d.firm)}). Change the words in Master → Email Templates → Company details.</span></div></form>`, root => {
    richInit(root);
    $('#cmfirm', root).onchange = e => { closeModal(); companyMail(ref, e.target.value, tid); };
    const ts = $('#cmtpl', root); if (ts) ts.onchange = () => { closeModal(); companyMail(ref, d.firm_code, ts.value); };
    $('#cmf', root).onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const attach = {}; $$('[data-att]', root).forEach(c => { attach[c.dataset.att] = c.checked ? 1 : 0; });
      const f = e.target;
      try { const r = await POST('/api/company-mail', { ...ref, firm: d.firm_code, to: f.to.value, cc: f.cc.value, subject: f.subject.value, text: f.text.value, html: f.html.value, attach,
          template_name: ts ? ts.selectedOptions[0].text.replace(' (default)', '') : d.template_name });
        toast(`Company details sent${r.attached.length ? ' with ' + r.attached.join(', ') : ''}`); closeModal(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}

// ✉ Write email: choose the sending company first, then write a new email; the company's documents can be ticked, more files dropped in
TITLES.writemail = 'Write Email';
PAGES.writemail = async el => {
  el.innerHTML = `<div class="card" style="max-width:640px"><h3>✉ Write a new email</h3><p class="hint">A blank email from Parakh Marketing or Parakh Fertilizer (or any company with email set up): choose the company, write the email,
    tick the company documents to attach (GST, PAN, bank proof, MSME, Aadhaar, Jan Aadhaar, company details form) and drop in any other file.</p>
    <button id="wmopen">✉ Write email</button></div>`;
  $('#wmopen', el).onclick = () => writeEmail();
  writeEmail();
};
async function writeEmail(firm, keep) {
  const d = await guard(() => GET('/api/write-mail' + (firm ? '?firm=' + firm : '')));
  const k = keep || {};
  modal('✉ Write email', `<form id="wmf"><div class="grid g2">
      <label class="span2">1. Sending company<select id="wmfirm">${d.firms.map(x => `<option value="${x.code}" ${x.code === d.firm_code ? 'selected' : ''}>${esc(x.name)}${x.ready ? '' : ' (email not set up)'}</option>`).join('')}</select></label>
      ${d.ready ? '' : `<p class="badge amber span2" style="display:block;padding:8px 10px">Email is not set up for ${esc(d.firm)}. Open Settings → Companies → Email sending first.</p>`}
      ${field({ name: 'to', label: '2. To (choose a buyer or type; comma between more)' }, k.to || '')}${field({ name: 'cc', label: 'CC' }, k.cc || '')}
      ${field({ name: 'subject', label: 'Subject', span: 2 }, k.subject || '')}
      <div class="span2"><span class="lbl" style="font-weight:600">Message</span>${richArea('text', k.html || '', 220)}</div>
      <div class="span2 firmbox" style="margin:0"><b>Company documents to attach</b> <span class="hint">— ${esc(d.firm)}</span><div class="grid g3" style="margin-top:6px">${d.att.map(a => `<label style="display:flex;gap:8px;align-items:center;font-weight:500;${a.has ? '' : 'opacity:.5'}">
        <input type="checkbox" data-att="${a.k}" style="width:auto" ${a.has ? '' : 'disabled'} ${k.attach && k.attach[a.k] && a.has ? 'checked' : ''}> ${esc(a.label === 'Vendor registration form' ? 'Company details form' : a.label)}${a.has ? '' : ' <span class="hint">(not uploaded)</span>'}${a.k === 'VENDOR' ? ` <a class="small" href="/print/vendorform/${d.firm_code}" target="_blank">👁</a>` : ''}</label>`).join('')}</div></div></div>
      <datalist id="wmto">${d.contacts.map(c => `<option value="${esc(c.email)}">${esc(c.name)}</option>`).join('')}</datalist>
      <div class="row" style="margin-top:8px"><button type="submit" ${d.ready ? '' : 'disabled'}>Send email</button><span class="hint">From ${esc(d.from)} (${esc(d.firm)})</span></div></form>`, root => {
    richInit(root);
    const f = $('#wmf', root); f.to.setAttribute('list', 'wmto');
    const state = () => { const attach = {}; $$('[data-att]', root).forEach(c => { attach[c.dataset.att] = c.checked ? 1 : 0; }); return { to: f.to.value, cc: f.cc.value, subject: f.subject.value, html: f.html.value, attach }; };
    $('#wmfirm', root).onchange = e => { const s = state(); closeModal(); writeEmail(e.target.value, s); };   // choose the company first: added files are cleared
    f.onsubmit = async e => {
      e.preventDefault(); const b = $('button[type=submit]', root); b.disabled = true; b.textContent = 'Sending…';
      const s = state();
      try { const r = await POST('/api/company-mail', { blank: 1, firm: d.firm_code, to: s.to, cc: s.cc, subject: s.subject, text: f.text.value, html: s.html, attach: s.attach });
        toast(`Email sent${r.attached.length ? ' with ' + r.attached.join(', ') : ''}`); closeModal(); }
      catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Send email'; }
    };
  });
}
