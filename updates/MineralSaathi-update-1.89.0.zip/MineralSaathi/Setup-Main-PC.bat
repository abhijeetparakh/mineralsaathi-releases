@echo off
rem Run ONCE on the main office PC: right-click -> Run as administrator
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo  Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
echo  1. Allowing other office PCs to connect (Windows Firewall, port 8765)...
netsh advfirewall firewall delete rule name="Mineral Saathi" >nul 2>&1
rem all network types (also "Public"), but only PCs of the same office network
netsh advfirewall firewall add rule name="Mineral Saathi" dir=in action=allow protocol=TCP localport=8765 profile=any remoteip=localsubnet >nul
echo  2. Starting the server automatically when Windows starts...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Mineral Saathi Server.lnk');$s.TargetPath='wscript.exe';$s.Arguments='""%~dp0windows\Start-Tray.vbs""';$s.WorkingDirectory='%~dp0';$s.Save()"
echo  3. Making the desktop icon...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('CommonDesktopDirectory')+'\Mineral Saathi.lnk');$s.TargetPath='%~dp0Open-Mineral-Saathi.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0windows\mineral-saathi.ico';$s.WindowStyle=7;$s.Save()"
echo.
echo  Done. This PC's address for the other PCs:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo     %%a:8765
echo.
echo  Now double-click the "Mineral Saathi" desktop icon. The server runs with its icon near the clock.
pause
