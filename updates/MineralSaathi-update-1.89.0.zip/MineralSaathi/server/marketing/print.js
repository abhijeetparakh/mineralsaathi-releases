'use strict';
// Marketing papers for one dispatch. Each paper is an HTML page drawn at the paper size of its kind
// (Settings → This computer → Printers): A4 papers use the "invoice" setup, 4x6 stickers the "label"
// setup and envelopes the "envelope" setup — the same printers and nudges as billing.
//   one SAMPLE STICKER for each sample · one COVER LETTER for the whole dispatch · and the postal papers
const fs = require('node:fs');
const path = require('node:path');
const M = require('./db');
const { get: mGet, all: mAll } = require('../db');
const { shell, barcode128, setupFor } = require('../print');
const { inWords } = require('../logic');
const qr = require('../qr');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nl = s => esc(s).replace(/\n/g, '<br>');
const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const money = n => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const kg = n => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 });
const title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
const img = (src, h, w) => /^data:image\/(png|jpeg|webp);base64,/.test(src || '') ? `<img src="${src}" alt="" style="max-height:${h}px;max-width:${w}px">` : '';

// ---- the papers: key → name, paper kind (printer setup), how many pages, ticked by default ----
const DOCS = [
  { key: 'stickers', name: 'Sample stickers', kind: 'label', note: 'one for each sample', pages: d => d.lines.length, def: true },
  { key: 'cover', name: 'Cover letter', kind: 'invoice', note: 'one for the dispatch, lists every sample', pages: () => 1, def: true },
  { key: 'address', name: 'Address label (To / From)', kind: 'label', pages: () => 1 },
  { key: 'bags', name: 'Bag stickers (Bag 1 of N)', kind: 'label', note: 'one for each parcel', pages: d => Math.max(1, d.dispatch.parcels || 1) },
  { key: 'envelope', name: 'Envelope', kind: 'envelope', pages: () => 1 },
  { key: 'annexure', name: 'Annexure-A (sample declaration)', kind: 'invoice', pages: () => 1 },
  { key: 'cdf', name: 'Customer Declaration Form CDF-I (India Post)', kind: 'invoice', pages: () => 1 },
  { key: 'cn23', name: 'Customs declaration CN 23', kind: 'invoice', pages: () => 1 },
  { key: 'towhom', name: 'To Whom It May Concern', kind: 'invoice', pages: () => 1 },
  { key: 'note', name: 'Sample note (WhatsApp + call QR codes)', kind: 'invoice', pages: () => 1 },
  { key: 'freight', name: 'Local freight letter', kind: 'invoice', note: 'needs driver and amount', pages: () => 1 }
];

function dispatchFull(id) {
  const dispatch = M.get('SELECT * FROM dispatches WHERE id = ?', id);
  if (!dispatch) return null;
  const s = require('./routes').settings();
  const firm = mGet('SELECT * FROM firms WHERE code = ?', dispatch.firm_code) || mGet('SELECT * FROM firms ORDER BY id LIMIT 1') || { name: '', code: dispatch.firm_code };
  return {
    dispatch, s, firm,
    lead: M.get('SELECT * FROM leads WHERE id = ?', dispatch.lead_id),
    lines: M.all('SELECT * FROM samples WHERE dispatch_id = ? ORDER BY id', id),
    freight: M.get('SELECT * FROM dispatch_freight WHERE dispatch_id = ? ORDER BY id DESC LIMIT 1', id)
  };
}

// small pieces used on several papers
const items = d => [...new Set(d.lines.map(l => title(l.item_name)).filter(Boolean))].join(', ') || 'Natural mineral';
const minOrder = (d, l) => l.unit === 'KG' ? d.s.min_order_kg : l.unit === 'MT' ? d.s.min_order_mt : '';
const rateTxt = l => l.rate != null ? `Rs.${money(l.rate)} per ${l.unit || ''}`.trim() : '';
const packTxt = l => [l.bag_weight ? kg(l.bag_weight) + ' KG BAG' : '', l.bag_type, l.packing_type, l.liner === 1 ? 'WITH LINER' : l.liner === 0 ? 'WITHOUT LINER' : ''].filter(Boolean).join(' · ');
const signer = d => d.s.signer || d.firm.name || '';
const toName = l => l.buyer_name || '';
const phones = l => [l.mobile1, l.mobile2].filter(Boolean).join(' , ');
const fromLines = d => { const f = d.firm;
  return [esc(f.address), `${esc(f.city || '')}${f.pincode ? ' - ' + esc(f.pincode) : ''}${f.state ? ', ' + esc(f.state) : ''}`,
    [f.phone ? 'Ph. ' + esc(f.phone) : '', f.email ? esc(f.email) : ''].filter(Boolean).join(' · '),
    [d.s.sender_digipin ? 'Digipin ' + esc(d.s.sender_digipin) : '', f.gstin ? 'GSTIN ' + esc(f.gstin) : ''].filter(Boolean).join(' · ')].filter(Boolean).join('<br>'); };
const toLines = l => [esc(l.address).replace(/\n/g, '<br>'), `${esc(l.city || '')}${l.pincode ? ' - <b>' + esc(l.pincode) + '</b>' : ''}`, esc(l.state || ''),
  l.digipin ? 'Digipin ' + esc(l.digipin) : '', phones(l) ? 'Ph. <b>' + esc(phones(l)) + '</b>' : '', l.gst ? 'GSTIN ' + esc(l.gst) : ''].filter(Boolean).join('<br>');
const brandBlock = (f, h = 40, w = 200, size = 18) => img(f.logo, h, w) || `<div style="font-size:${size}px;font-weight:800;letter-spacing:.4px">${esc(String(f.name || '').toUpperCase())}</div>`;
const trackBar = (no, h = 34, unit = 1.2) => no ? `<div style="display:inline-block;text-align:center">${barcode128(no, h, unit)}<div style="font-size:11px;letter-spacing:1px">${esc(no)}</div></div>` : '';
const LBL = `<style>.lb { color:#000; font-family:Arial,sans-serif; } .lb .k { font-size:10px; font-weight:800; letter-spacing:1px; }
  .lb table td { border:0; padding:1.2mm 1mm; vertical-align:top; } .lb .kv td:first-child { width:30mm; font-size:11px; color:#333; } .lb .kv td:last-child { font-size:14px; font-weight:700; }</style>`;

// pages from..to (1-based) of a multi-page paper — direct printing draws at most 10 at a time
const range = (pages, o) => { const a = Math.max(1, Number(o.from) || 1), b = Math.min(pages.length, Number(o.to) || pages.length); return pages.slice(a - 1, Math.max(a, b)); };

// moisture range of the sample's form (Item List → Item form)
const moist = l => { try { return require('../anreport').moistureFor(l, null, true); } catch { return ''; } };
// ---- 1. sample sticker: one for each sample (4x6) ----
function stickers(d, o) {
  const L = d.lead, s = setupFor('label', o.setup);
  const pages = d.lines.map((l, i) => `<div class="lb" style="height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column;border:2px solid #000;padding:2.5mm">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:1.5mm">
      <div>${brandBlock(d.firm, 36, 190, 17)}<div style="font-size:11px;font-weight:700;margin-top:1mm">SAMPLE · NOT FOR SALE · ${dmy(d.dispatch.date)}</div></div>
      <div style="text-align:right;font-size:11px">Ref No.<div style="font-size:22px;font-weight:800">${esc(L.ref_no)}</div>${d.lines.length > 1 ? `${i + 1} of ${d.lines.length}` : ''}</div></div>
    <table class="kv" style="margin-top:1.5mm"><tbody>
      ${toName(L) ? `<tr><td>To</td><td>${esc(toName(L))}</td></tr>` : ''}
      <tr><td>Company</td><td>${esc(L.company || '')}</td></tr>
      <tr><td>City</td><td>${esc([L.city, L.state].filter(Boolean).join(', '))}</td></tr>
      <tr><td>Grade</td><td style="font-size:20px">${esc(l.grade || '')}</td></tr>
      <tr><td>Item</td><td>${esc(l.item_name || '')}</td></tr>
      <tr><td>Sample size</td><td>${esc(l.sample_size || '')}</td></tr>
      ${l.colour ? `<tr><td>Colour</td><td>${esc(l.colour)}</td></tr>` : ''}${l.mesh ? `<tr><td>Mesh</td><td>${esc(l.mesh)}</td></tr>` : ''}
      ${moist(l) ? `<tr><td>Moisture</td><td>${esc(moist(l))}</td></tr>` : ''}
      ${packTxt(l) ? `<tr><td>Bulk packing</td><td style="font-size:12px">${esc(packTxt(l))}</td></tr>` : ''}
      ${d.s.delivery_time ? `<tr><td>Delivery time</td><td>${esc(d.s.delivery_time)}</td></tr>` : ''}
      ${minOrder(d, l) ? `<tr><td>Minimum order</td><td>${esc(minOrder(d, l))}</td></tr>` : ''}
      ${l.rate != null ? `<tr><td>Rate</td><td style="font-size:18px">${esc(rateTxt(l))}<div style="font-size:10.5px;font-weight:600">${esc(d.s.gst_note || '')}</div></td></tr>` : ''}
      ${l.note ? `<tr><td>Note</td><td style="font-size:11.5px">${esc(l.note)}</td></tr>` : ''}
    </tbody></table>
    <div style="margin-top:auto;border-top:1px solid #000;padding-top:1.5mm;font-size:10px;line-height:1.35;display:flex;justify-content:space-between;gap:2mm;align-items:flex-end">
      <div>${fromLines(d)}</div></div></div>`);
  const part = range(pages, o); part[0] = LBL + part[0];
  return shell(`Sample stickers · Ref ${L.ref_no}`, part, { ...o, setup: s });
}

// ---- 2. cover letter: one for the whole dispatch, every sample in one table (A4) ----
function cover(d, o) {
  const L = d.lead, f = d.firm, anyKg = d.lines.some(l => l.unit === 'KG'), anyM = d.lines.some(l => moist(l));
  const rows = d.lines.map((l, i) => `<tr><td class="c">${i + 1}</td><td><b>${esc(l.grade || '')}</b><br><span class="muted">${esc(title(l.item_name))}</span></td>
    <td>${esc(l.colour || '')}</td><td>${esc(l.mesh || '')}</td>${anyM ? `<td style="white-space:nowrap">${esc(moist(l))}</td>` : ''}<td>${esc(l.sample_size || '')}</td><td>${esc(packTxt(l))}</td>
    <td class="r" style="white-space:nowrap"><b>${esc(rateTxt(l))}</b></td><td>${esc(minOrder(d, l))}</td></tr>`).join('');
  const body = `<div style="font-size:13.5px;line-height:1.5;color:#111;padding:2mm 3mm;height:270mm;display:flex;flex-direction:column">
    <div class="head"><div>${brandBlock(f, 64, 260, 26)}<div class="muted" style="font-size:11.5px;margin-top:2px">${fromLines(d)}</div></div>
      <div style="text-align:right;white-space:nowrap">Date: <b>${dmy(d.dispatch.date)}</b><br>Ref No. <b>${esc(L.ref_no)}</b></div></div>
    <div style="margin-top:6mm">To,<br>${toName(L) ? `Shri <b>${esc(toName(L))}</b><br>` : ''}M/s. <b>${esc(L.company || '')}</b><br>${esc([L.city, L.state].filter(Boolean).join(', '))}</div>
    <div style="margin-top:6mm">Dear Sir / Madam,</div>
    <div style="margin-top:2mm">Thank you for your enquiry. We are pleased to send ${d.lines.length === 1 ? 'a sample' : `samples of ${d.lines.length} grades`} of <b>${esc(items(d))}</b>
      ${d.dispatch.courier ? ` by <b>${esc(d.dispatch.courier)}</b>` : ''} and offer the following:</div>
    <table style="margin-top:4mm;font-size:12.5px"><thead><tr><th>#</th><th>Grade</th><th>Colour</th><th>Mesh</th>${anyM ? '<th>Moisture</th>' : ''}<th>Sample</th><th>Bulk packing</th><th class="r">Rate</th><th>Minimum order</th></tr></thead>
      <tbody>${rows}</tbody></table>
    <table style="margin-top:4mm;font-size:12.5px;width:auto"><tbody>
      ${d.s.gst_note ? `<tr><td class="muted" style="border:0;padding:2px 10px 2px 0">Rates</td><td style="border:0;padding:2px 0"><b>${esc(d.s.gst_note)}</b></td></tr>` : ''}
      <tr><td class="muted" style="border:0;padding:2px 10px 2px 0">Freight</td><td style="border:0;padding:2px 0">To pay (not included in the above price)</td></tr>
      ${d.s.delivery_time ? `<tr><td class="muted" style="border:0;padding:2px 10px 2px 0">Delivery time</td><td style="border:0;padding:2px 0">${esc(d.s.delivery_time)}</td></tr>` : ''}
      ${d.s.payment_terms ? `<tr><td class="muted" style="border:0;padding:2px 10px 2px 0">Payment terms</td><td style="border:0;padding:2px 0">${esc(d.s.payment_terms)}</td></tr>` : ''}</tbody></table>
    <div style="margin-top:5mm">${anyKg ? 'All consignments sent via transport that do not meet a full truckload will be packed in double HDPE bags to ensure product safety during transit. ' : ''}We look forward to your confirmation and are happy to assist with dispatch and logistics. Please feel free to reach out for any clarification or customization.</div>
    <div style="margin-top:8mm">Thank you,</div>
    <div style="height:18mm;display:flex;align-items:flex-end">${img(f.signature, 62, 180)}</div>
    <div><b>${esc(signer(d))}</b><br>${esc(f.name || '')}</div>
    <div style="margin-top:auto;border-top:1px solid #9A4A2A;padding-top:2mm;font-size:11px" class="muted">${[f.phone ? 'Call us: ' + esc(f.phone) : '', f.email ? esc(f.email) : ''].filter(Boolean).join(' · ')}</div></div>`;
  return shell(`Cover letter · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 3. address label To / From (4x6): tracking barcode in the centre of the label ----
function address(d, o) {
  const L = d.lead, s = setupFor('label', o.setup);
  const body = `${LBL}<div class="lb" style="height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column;border:2px solid #000">
    <div style="flex:1.35 1 0;padding:3mm;overflow:hidden"><div class="k">TO</div>
      ${toName(L) ? `<div style="font-size:18px;font-weight:700;margin-top:1mm">${esc(toName(L))}</div>` : ''}
      <div style="font-size:22px;font-weight:800;line-height:1.15">${esc(L.company || '')}</div>
      <div style="font-size:15px;line-height:1.35;margin-top:1.5mm">${toLines(L)}</div></div>
    ${d.dispatch.tracking_no ? `<div style="border-top:2px dashed #000;border-bottom:2px dashed #000;padding:2.5mm 0;text-align:center">${trackBar(d.dispatch.tracking_no, 46, 1.5)}</div>` : '<div style="border-top:2px dashed #000"></div>'}
    <div style="flex:1 1 0;padding:3mm;display:flex;flex-direction:column"><div class="k">FROM</div>
      ${brandBlock(d.firm, 34, 200, 15)}<div style="font-size:11.5px;line-height:1.35;margin-top:1mm">${fromLines(d)}</div>
      <div style="margin-top:auto;font-size:12px">Ref No. <b style="font-size:20px">${esc(L.ref_no)}</b></div></div></div>`;
  return shell(`Address label · Ref ${L.ref_no}`, body, { ...o, setup: s });
}

// ---- 4. bag stickers: one for each parcel, Bag n / N (4x6) ----
function bags(d, o) {
  const L = d.lead, s = setupFor('label', o.setup), of = Math.max(1, d.dispatch.parcels || 1);
  const wt = d.dispatch.total_weight ? kg(d.dispatch.total_weight / of) + ' kg' : '';
  const pages = []; for (let n = 1; n <= of; n++) pages.push(`<div class="lb" style="height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column">
    <div style="flex:1.5 1 0;border:2px solid #000;padding:3mm;overflow:hidden"><div class="k">TO</div>
      <div style="font-size:22px;font-weight:800;line-height:1.15;margin-top:1mm">M/s. ${esc(L.company || toName(L))}</div>${L.company && toName(L) ? `<div style="font-size:16px;font-weight:700">${esc(toName(L))}</div>` : ''}
      <div style="font-size:16px;line-height:1.35;margin-top:1.5mm">${esc(L.city || '')}${L.pincode ? ' - <b>' + esc(L.pincode) + '</b>' : ''}<br>${esc(L.state || '')}${phones(L) ? '<br>Ph. ' + esc(phones(L)) : ''}</div></div>
    <div style="flex:1 1 0;border:2px solid #000;border-top:2px dashed #000;padding:3mm;display:flex;flex-direction:column"><div class="k">FROM</div>
      ${brandBlock(d.firm, 30, 190, 14)}<div style="font-size:11px;line-height:1.3;margin-top:1mm">${fromLines(d)}</div>
      <div style="margin-top:auto;display:flex;justify-content:space-between;align-items:flex-end"><div style="font-size:12px">Ref No. <b>${esc(L.ref_no)}</b> · ${dmy(d.dispatch.date)}${wt ? '<br>Bag weight ' + esc(wt) : ''}</div>
        <div style="border:2px solid #000;padding:1mm 3mm;text-align:center"><span style="font-size:10px;font-weight:700;display:block">BAG NO.</span><b style="font-size:26px">${n}</b> / <b style="font-size:26px">${of}</b></div></div></div></div>`);
  const part = range(pages, o); part[0] = LBL + part[0];
  return shell(`Bag stickers · Ref ${L.ref_no}`, part, { ...o, setup: s });
}

// ---- 5. envelope: From left, To right ----
function envelope(d, o) {
  const L = d.lead, s = setupFor('envelope', o.setup);
  const body = `<div style="height:${s.h - 2 * s.margin}mm;display:grid;grid-template-columns:1fr 1.3fr;gap:6mm;color:#000;font-family:Arial,sans-serif">
    <div style="font-size:11px;line-height:1.45"><div style="font-size:10px;font-weight:800;letter-spacing:1px">FROM</div>${brandBlock(d.firm, 44, 200, 15)}${fromLines(d)}
      <div style="margin-top:3mm;border:1px solid #000;padding:2mm;line-height:1.6">Ref No. <b>${esc(L.ref_no)}</b> · ${dmy(d.dispatch.date)}<br>${esc(d.dispatch.courier || '')}<br>${trackBar(d.dispatch.tracking_no, 26, 1)}</div></div>
    <div style="align-self:center;border-left:2px solid #000;padding-left:5mm"><div style="font-size:11px;font-weight:700;letter-spacing:1px">TO</div>
      ${toName(L) ? `<div style="font-size:15px;font-weight:700">${esc(toName(L))}</div>` : ''}<div style="font-size:18px;font-weight:800;margin:1mm 0">M/s. ${esc(L.company || '')}</div>
      <div style="font-size:13px;line-height:1.4">${toLines(L)}</div></div></div>`;
  return shell(`Envelope · Ref ${L.ref_no}`, body, { ...o, setup: s });
}

// ---- 6. Annexure-A: sample declaration for the post (A4) ----
const CONTENT = d => `SAMPLE OF ${items(d).toUpperCase()} — ${d.lines.map(l => [l.grade, l.sample_size].filter(Boolean).join(' ')).join(', ')}. 100% natural mineral, it has no commercial value, non-hazardous, non-explosive and can be carried in passenger aircraft, train or any means of transport.`;
function annexure(d, o) {
  const L = d.lead, f = d.firm;
  const kv = (k, v) => `<tr><td class="lbl" style="width:32%">${k}</td><td>${v}</td></tr>`;
  const body = `<div style="font-size:13px;line-height:1.45;padding:3mm">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #9A4A2A;padding-bottom:2mm">
      <div>Date: <b>${dmy(d.dispatch.date)}</b><br>Ref No. <b>${esc(L.ref_no)}</b></div><div style="font-size:20px;font-weight:800">ANNEXURE - A</div><div>${trackBar(d.dispatch.tracking_no, 34, 1.2)}</div></div>
    <div style="margin:3mm 0;font-weight:700">EXPRESS / BUSINESS / SPEED POST / REGISTERED PARCEL${d.dispatch.courier ? ' — ' + esc(d.dispatch.courier) : ''}</div>
    <table><tbody>${kv('Customer ID', esc(L.ref_no))}${kv('Contents', esc(CONTENT(d)))}${kv('Value', 'NIL (AS IT IS A FREE SAMPLE)')}${d.dispatch.total_weight ? kv('Weight', esc(kg(d.dispatch.total_weight)) + ' kg') : ''}</tbody></table>
    <div class="grid2" style="margin-top:4mm">
      <div class="box"><div class="lbl">Sending to</div><div class="big">${esc(L.company || '')}</div>${toName(L) ? esc(toName(L)) + '<br>' : ''}${toLines(L)}</div>
      <div class="box"><div class="lbl">Sender / return address</div><div class="big">${esc(f.name || '')}</div>${esc(signer(d))}<br>${fromLines(d)}</div></div>
    <div style="margin-top:14mm;text-align:right">${img(f.signature, 56, 170)}<br>Signature of sender / Co. stamp</div></div>`;
  return shell(`Annexure-A · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 7. Customer Declaration Form CDF-I (India Post) (A4) ----
function cdf(d, o) {
  const L = d.lead, f = d.firm;
  const side = (h, rows) => `<div class="box"><div class="lbl" style="margin-bottom:2mm">${h}</div><table class="kvt"><tbody>${rows.map(([k, v]) => `<tr><td style="width:30%;border:0;color:#555;padding:2px 4px 2px 0">${k}</td><td style="border:0;padding:2px 0"><b>${v}</b></td></tr>`).join('')}</tbody></table></div>`;
  const body = `<div style="font-size:13px;line-height:1.45;padding:3mm">
    <div style="display:flex;justify-content:space-between"><div>Ref No. <b>${esc(L.ref_no)}</b></div><div><b>Annexure - 1</b></div></div>
    <div style="text-align:center;font-size:19px;font-weight:800;margin-top:2mm">Customer Declaration Form (CDF-I)</div>
    <div style="text-align:center;font-weight:700">INDIA POST / SPEED POST PARCEL</div>
    <table style="margin-top:4mm"><tbody><tr><td class="lbl" style="width:22%">Customer ID</td><td><b>${esc(L.ref_no)}</b></td><td class="lbl" style="width:18%">Tracking ID</td><td>${trackBar(d.dispatch.tracking_no, 30, 1.1)}</td></tr>
      <tr><td class="lbl">Content of the parcel</td><td colspan="3"><b>${esc(items(d))} (natural mineral)</b> — ${esc(d.lines.map(l => [l.grade, l.sample_size].filter(Boolean).join(' ')).join(', '))}</td></tr>
      <tr><td class="lbl">Whether the parcel contains dry coconut / battery or battery-inbuilt electronic equipment / flammable items / chemical substances / liquids / magnetic material</td><td colspan="3" style="vertical-align:middle"><b>NO</b></td></tr>
      <tr><td class="lbl">Total value in Rs.</td><td colspan="3"><b>NIL</b> (as this is a sample, it has no commercial value)</td></tr></tbody></table>
    <div class="grid2" style="margin-top:4mm">
      ${side('Sender / return address', [['Name', esc(signer(d))], ['Company', esc(f.name || '')], ['Address', esc(f.address || '')], ['City / State', esc([f.city, f.state].filter(Boolean).join(', '))],
        ['Pin code', esc(f.pincode || '')], ['Digipin', esc(d.s.sender_digipin || '')], ['Contact no.', esc(f.phone || '')]])}
      ${side('Addressee address', [['Name', esc(toName(L))], ['Company', esc(L.company || '')], ['Address', nl(L.address || '')], ['City / State', esc([L.city, L.state].filter(Boolean).join(', '))],
        ['Pin code', esc(L.pincode || '')], ['Digipin', esc(L.digipin || '')], ['Contact no.', esc(phones(L))]])}</div>
    <p style="margin-top:5mm">I, the undersigned, whose name and address are mentioned above, certify that the particulars given in this declaration are correct and that this item does not contain any dangerous article or articles prohibited by legislation or by postal or customs regulations.</p>
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:10mm"><div>Date: <b>${dmy(d.dispatch.date)}</b></div>
      <div style="text-align:center">${img(f.signature, 56, 170)}<br>( ${esc(signer(d))} )<br>Sender signature</div></div></div>`;
  return shell(`CDF-I · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 8. CN 23 customs declaration (A4) ----
function cn23(d, o) {
  const L = d.lead, f = d.firm;
  const c = (k, v, cs = 1) => `<td colspan="${cs}"><div class="lbl">${k}</div><b>${v || '&nbsp;'}</b></td>`;
  const rows = d.lines.map(l => `<tr><td>${esc(title(l.item_name))} (mineral) — ${esc(l.grade || '')}<br><span class="muted">100% natural, non-toxic and non-explosive</span></td><td class="c">1</td><td class="c">${esc(l.sample_size || '')}</td><td class="c">NIL</td><td class="c">2512</td><td class="c">INDIA</td></tr>`).join('');
  const body = `<div style="font-size:12px;line-height:1.35;padding:2mm">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #000;padding-bottom:2mm">
      <div>(Designated operator)<br>Ref No. <b>${esc(L.ref_no)}</b></div><div style="font-size:20px;font-weight:800">CUSTOMS DECLARATION &nbsp; CN 23</div><div>${trackBar(d.dispatch.tracking_no, 32, 1.1)}<div class="muted" style="font-size:10px">May be opened officially</div></div></div>
    <table style="margin-top:2mm"><tbody>
      <tr><td rowspan="4" style="width:9%;font-weight:700">From</td>${c('Name', esc(signer(d)))}${c('Business', esc(f.name || ''))}</tr>
      <tr>${c('Street', esc(f.address || ''), 2)}</tr>
      <tr>${c('Postcode / City / State', esc([f.pincode, f.city, f.state].filter(Boolean).join(' · ')))}${c('Phone · GSTIN', esc([f.phone, f.gstin].filter(Boolean).join(' · ')))}</tr>
      <tr>${c('Country', 'INDIA')}${c('Digipin', esc(d.s.sender_digipin || ''))}</tr>
      <tr><td rowspan="4" style="font-weight:700">To</td>${c('Name', esc(toName(L)))}${c('Business', esc(L.company || ''))}</tr>
      <tr>${c('Street', nl(L.address || ''), 2)}</tr>
      <tr>${c('Postcode / City / State', esc([L.pincode, L.city, L.state].filter(Boolean).join(' · ')))}${c('Phone · GSTIN', esc([phones(L), L.gst].filter(Boolean).join(' · ')))}</tr>
      <tr>${c('Country', 'INDIA')}${c('Digipin', esc(L.digipin || ''))}</tr></tbody></table>
    <table style="margin-top:2mm"><thead><tr><th>Detailed description of contents (1)</th><th class="c">Quantity (2)</th><th class="c">Net weight (3)</th><th class="c">Value (5)</th><th class="c">HS tariff no. (7)</th><th class="c">Country of origin (8)</th></tr></thead>
      <tbody>${rows}<tr><td class="r"><b>Total</b></td><td class="c"><b>${d.lines.length}</b></td><td class="c"><b>${d.dispatch.total_weight ? esc(kg(d.dispatch.total_weight)) + ' kg' : ''}</b></td><td class="c"><b>NIL</b></td><td></td><td></td></tr></tbody></table>
    <table style="margin-top:2mm"><tbody><tr><td style="width:50%"><div class="lbl">Category of item (10)</div>☐ Gift &nbsp; ☐ Documents &nbsp; ☐ Sale of goods &nbsp; ☒ <b>Commercial free sample</b> &nbsp; ☐ Returned goods &nbsp; ☐ Other</td>
      <td><div class="lbl">Office of origin and date of posting</div><b>${esc([f.city, f.state].filter(Boolean).join(' / '))} / INDIA · ${dmy(d.dispatch.date)}</b></td></tr>
      <tr><td><div class="lbl">Comments (11)</div>Free sample, no commercial value</td><td>I certify that the particulars given in this customs declaration are correct and that this item does not contain any dangerous article or articles prohibited by legislation or by postal or customs regulations.
        <div style="margin-top:6mm;display:flex;justify-content:space-between;align-items:flex-end"><span>Date and sender's signature (15): ${dmy(d.dispatch.date)}</span>${img(f.signature, 46, 150)}</div></td></tr></tbody></table></div>`;
  return shell(`CN 23 · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 9. To Whom It May Concern (A4) ----
function towhom(d, o) {
  const L = d.lead, f = d.firm;
  const body = `<div style="font-size:14px;line-height:1.6;padding:4mm;height:268mm;display:flex;flex-direction:column">
    <div class="head"><div>${brandBlock(f, 60, 260, 24)}</div><div style="text-align:right">Date: <b>${dmy(d.dispatch.date)}</b>${f.gstin ? `<br>GSTIN: ${esc(f.gstin)}` : ''}<br>Ref No. <b>${esc(L.ref_no)}</b></div></div>
    <div style="text-align:center;font-size:20px;font-weight:800;text-decoration:underline;margin:8mm 0 5mm">TO WHOM IT MAY CONCERN</div>
    <p>This is to certify that the consignment with this letter is only for <b>sample use</b>. It is a natural mineral, absolutely <b>non-hazardous</b>, not injurious to health, and it has no commercial value.</p>
    <table style="margin:4mm 0;font-size:13.5px"><thead><tr><th>Mineral</th><th>Quality</th><th>Quantity</th></tr></thead><tbody>
      ${d.lines.map(l => `<tr><td>${esc(l.item_name || '')}</td><td><b>${esc(l.grade || '')}</b></td><td>${esc(l.sample_size || '')}</td></tr>`).join('')}</tbody></table>
    ${d.dispatch.parcels || d.dispatch.total_weight ? `<p>${d.dispatch.parcels ? `Packages: <b>${d.dispatch.parcels} ${d.dispatch.parcels === 1 ? 'bag' : 'bags'}</b>` : ''}${d.dispatch.parcels && d.dispatch.total_weight ? ' · ' : ''}${d.dispatch.total_weight ? `Net weight: <b>${esc(kg(d.dispatch.total_weight))} kg</b>` : ''}</p>` : ''}
    <div style="margin-top:2mm">For<br><b>M/s. ${esc(L.company || '')}</b>${toName(L) ? `<br>Mr. ${esc(toName(L))}` : ''}<br>${toLines(L)}</div>
    ${d.dispatch.courier ? `<p style="margin-top:4mm">Via: <b>${esc(d.dispatch.courier)}</b>${d.dispatch.tracking_no ? ' · ' + esc(d.dispatch.tracking_no) : ''}</p>` : ''}
    <div style="margin-top:8mm">Thank you</div><div style="height:16mm;display:flex;align-items:flex-end">${img(f.signature, 58, 170)}</div><div><b>${esc(signer(d))}</b><br>${esc(f.name || '')}</div>
    <div style="margin-top:auto;text-align:center;font-size:11px" class="muted">${fromLines(d).replace(/<br>/g, ' · ')}</div></div>`;
  return shell(`To whom it may concern · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 10. sample note with QR codes: WhatsApp the customer, call the customer (A4) ----
function note(d, o) {
  const L = d.lead, m = L.mobile1 || '', st = setupFor('invoice', o.setup), edit = !o.shot;
  const wa = `https://api.whatsapp.com/send?phone=91${m}&text=${encodeURIComponent('Ref No. ' + L.ref_no + ' ')}`;
  const ce = edit ? ' contenteditable="true"' : '';
  const kv = (k, v) => `<tr><td class="lbl" style="width:28%">${k}</td><td${ce}><b>${v}</b></td></tr>`;
  const LH = 9;   // mm between the note-book lines
  const body = `<style>
    .snote { font-size:14px; line-height:1.5; padding:4mm; height:${st.h - 2 * st.margin}mm; display:flex; flex-direction:column; }
    .snote .lines { flex:1 1 auto; margin-top:5mm; border-top:1.5px solid #2F4F5A; position:relative; overflow:hidden;
      background: repeating-linear-gradient(to bottom, transparent 0, transparent ${LH - 0.25}mm, #9fb3b9 ${LH - 0.25}mm, #9fb3b9 ${LH}mm); }
    .snote .lines .txt { position:absolute; inset:0; padding:0 2mm; font-size:15px; line-height:${LH}mm; white-space:pre-wrap; outline:none; font-family:'Segoe Print','Comic Sans MS',cursive; color:#123; }
    .snote [contenteditable]:hover { background:rgba(26,155,181,.06); } .snote [contenteditable]:focus { outline:1px dashed #1A9BB5; }
    @media print { .snote [contenteditable]:hover { background:none; } .snote [contenteditable]:focus { outline:none; } }
    .edbar { position:fixed; right:14px; bottom:14px; background:#1A3E4A; color:#fff; padding:8px 10px; border-radius:8px; font:13px 'Segoe UI',Arial; box-shadow:0 2px 10px rgba(0,0,0,.3); z-index:9; }
    .edbar button { font-size:13px; padding:6px 12px; background:#1A9BB5; color:#fff; border:0; border-radius:6px; cursor:pointer; margin-left:6px; }
  </style>
  <div class="snote">
    <div class="head"><div style="font-size:22px;font-weight:800"${ce}>SAMPLE NOTE</div><div style="text-align:right"${ce}>Date <b>${dmy(d.dispatch.date)}</b><br>Ref No. <b style="font-size:20px">${esc(L.ref_no)}</b></div></div>
    <div style="display:grid;grid-template-columns:1fr 150px;gap:6mm;margin-top:4mm"><table><tbody>
      ${toName(L) ? kv('Name', esc(toName(L))) : ''}${kv('Company', esc(L.company || ''))}${kv('City / State', esc([L.city, L.state].filter(Boolean).join(', ')))}${kv('Phone', esc(phones(L)))}
      ${kv('Sent by', esc(d.dispatch.courier || ''))}${kv('Tracking no.', esc(d.dispatch.tracking_no || ''))}</tbody></table>
      <div style="text-align:center">${m ? qr.svg(wa, 130) + '<div style="font-size:11px;font-weight:700">Scan — WhatsApp</div>' : ''}
        ${m ? '<div style="margin-top:3mm">' + qr.svg('tel:' + m, 100) + '<div style="font-size:11px;font-weight:700">Scan to call</div></div>' : ''}</div></div>
    <table style="margin-top:4mm"><thead><tr><th>Grade</th><th>Item</th><th>Sample size</th><th>Rate</th><th>Packing</th><th>Note</th></tr></thead><tbody>
      ${d.lines.map(l => `<tr><td${ce}><b>${esc(l.grade || '')}</b></td><td${ce}>${esc(title(l.item_name))}</td><td${ce}>${esc(l.sample_size || '')}</td><td${ce}>${esc(rateTxt(l))}</td><td${ce}>${esc(packTxt(l))}</td><td${ce}>${esc(l.note || '')}</td></tr>`).join('')}</tbody></table>
    ${d.dispatch.note || L.note ? `<div class="box" style="margin-top:3mm"${ce}><div class="lbl">Note</div>${nl([d.dispatch.note, L.note].filter(Boolean).join('\n'))}</div>` : ''}
    <div class="lines"><div class="txt" id="ntxt"${edit ? ' contenteditable="plaintext-only"' : ''}>${esc(d.dispatch.note_text || '')}</div></div>
  </div>
  ${edit ? `<div class="edbar no-print">✏ Click anywhere on the page to change it. Notes on the lines are kept.
    <button onclick="saveNote()">Save notes</button><button onclick="window.print()">Print</button></div>
  <script>
    async function saveNote() {
      const r = await fetch('/api/mkt/dispatches/${d.dispatch.id}/note-text', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: document.getElementById('ntxt').innerText }) });
      const b = document.querySelector('.edbar button'); b.textContent = r.ok ? 'Saved ✓' : 'Not saved'; setTimeout(() => b.textContent = 'Save notes', 2000);
    }
  </script>` : ''}`;
  return shell(`Sample note · Ref ${L.ref_no}`, body, { ...o, setup: st });
}

// ---- 11. local freight letter: the courier pays the tempo that takes the parcels to its godown (A4) ----
function freight(d, o) {
  const L = d.lead, f = d.firm, lf = d.freight;
  if (!lf) return shell('Local freight letter', '<div style="padding:10mm;font-size:16px">Enter the driver and the amount first (Print → Local freight letter).</div>', { ...o, setup: setupFor('invoice', o.setup) });
  const words = inWords(Math.round(lf.amount || 0)).replace(/^Rupees\s*/i, '').replace(/\s*only\.?$/i, '');
  const row = (k, v) => `<tr><td style="border:0;width:90px;padding:4px 0">${k}</td><td style="border:0;padding:4px 0"><b><i>${v}</i></b></td></tr>`;
  const body = `<div style="font-family:'Bookman Old Style','Book Antiqua',Georgia,serif;font-size:14px;color:#000;padding:4mm;height:262mm;position:relative">
    ${brandBlock(f, 70, 280, 22)}
    <div style="margin-top:12px;font-size:12px">${dmy(today())}</div>
    <div style="margin-top:20px">To<br>The Manager<br><b>${esc(d.dispatch.courier || '')}</b><br>${esc(title(f.city || ''))}</div>
    <div style="margin-top:28px">Dear Sir,</div>
    <table style="margin-top:6px;width:auto"><tbody>
      <tr><td style="border:0;width:90px;padding:4px 0">Kindly pay</td><td style="border:0;padding:4px 0">Rs.${money(lf.amount)} ( ${esc(words)} Only.)</td></tr>
      ${row('Name', esc(lf.driver || ''))}${lf.mobile ? row('Mobile No.', esc(lf.mobile)) : ''}${lf.tempo_no ? row('Vehicle No.', esc(lf.tempo_no)) : ''}</tbody></table>
    <div style="margin-top:6px">for the delivery of goods from our factory (${esc(lf.from_place || f.city || '')}) to <b>${esc(d.dispatch.courier || '')}</b>, ${esc(title(f.city || ''))}.</div>
    <div style="margin-top:30px"><b><i>${d.dispatch.parcels ? `${d.dispatch.parcels} ${d.dispatch.parcels === 1 ? 'Bag' : 'Bags'}` : ''}${d.dispatch.total_weight ? ` · Total ${esc(kg(d.dispatch.total_weight))} Kg` : ''}</i></b></div>
    <div style="margin-top:12px">for</div>
    <div style="margin-top:8px;font-family:Arial,sans-serif;font-size:17px;font-weight:bold">M/s. ${esc(L.company || '')}</div>
    ${toName(L) ? `<div style="font-family:Arial,sans-serif;font-weight:bold">${esc(toName(L))}</div>` : ''}
    <div style="margin-top:6px;font-family:Arial,sans-serif;font-weight:bold">${esc(String([L.city, L.pincode].filter(Boolean).join('-')).toUpperCase())}<br>${esc(String(L.state || '').toUpperCase())}</div>
    <div style="margin-top:28px">Ref No. <b>${esc(L.ref_no)}</b> &nbsp; Dated <b>${dmy(d.dispatch.date)}</b></div>
    <div style="margin-top:30px">Thank you</div><div style="margin-top:14px">${esc(signer(d))}</div>
    <div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:10px;font-weight:bold">${fromLines(d)}</div></div>`;
  return shell(`Local freight letter · Ref ${L.ref_no}`, body, { ...o, setup: setupFor('invoice', o.setup) });
}

// ---- 12. quick sticker: walk-in / phone enquiry with WhatsApp and call QR codes (4x6) ----
function quickHtml(r, firm, o) {
  const s = setupFor('label'), m = String(r.mobile || '');
  const wa = `https://api.whatsapp.com/send?phone=91${m}&text=${encodeURIComponent('Ref ' + (r.ref || '') + ' Hello ')}`;
  const kv = (k, v) => v ? `<tr><td>${k}</td><td>${v}</td></tr>` : '';
  const body = `${LBL}<div class="lb" style="height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column;border:2px solid #000;padding:2.5mm">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:1.5mm">
      <div>${brandBlock(firm, 34, 190, 17)}<div style="font-size:11px;font-weight:700;margin-top:1mm">${dmy(r.date)}</div></div>
      <div style="text-align:right;font-size:11px">Ref<div style="font-size:20px;font-weight:800">${esc(r.ref || '')}</div></div></div>
    <table class="kv" style="margin-top:1.5mm"><tbody>${kv('Name', esc(r.name))}${kv('Company', esc(r.company))}${kv('Mobile', esc(m))}${kv('Item', esc(r.item))}
      ${kv('City / State', esc([r.city, r.pincode].filter(Boolean).join(' - ') + (r.state ? ', ' + r.state : '')))}
      ${r.rate != null ? kv('Price', `<span style="font-size:18px">Rs.${money(r.rate)}${r.unit ? ' per ' + esc(r.unit) : ''}</span>`) : ''}${kv('Note', esc(r.remark))}</tbody></table>
    ${m ? `<div style="margin-top:auto;display:flex;justify-content:space-around;align-items:flex-end;text-align:center;font-size:10px;font-weight:700">
      <div>${qr.svg(wa, 120)}<div>Scan — WhatsApp</div></div><div>${qr.svg('tel:' + m, 110)}<div>Scan to call</div></div></div>` : ''}</div>`;
  return shell(`Quick sticker ${r.ref || ''}`, body, { ...o, setup: s });
}

// ---- 13. letters: letter pad (A4), bus parcel label (4x6), blank envelope ----
function letterHtml(r, firm, sx, o) {
  const d = JSON.parse(r.data || '{}'), f = firm;
  if (r.type === 'BUS') {
    const s = setupFor('label');
    const body = `${LBL}<div class="lb" style="height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column">
      <div style="flex:1.5 1 0;border:2px solid #000;padding:3mm;overflow:hidden"><div class="k">TO</div>
        <div style="font-size:19px;font-weight:800;line-height:1.3;margin-top:1mm">${nl(d.to || '')}</div>
        ${d.phone ? `<div style="font-size:17px;margin-top:2mm">Ph. <b>${esc(d.phone)}</b></div>` : ''}</div>
      ${d.contents ? `<div style="border:2px solid #000;border-top:0;padding:2mm 3mm;font-size:16px;font-weight:800;text-align:center">${esc(d.contents)}</div>` : ''}
      <div style="flex:1 1 0;border:2px solid #000;border-top:2px dashed #000;padding:3mm;display:flex;flex-direction:column"><div class="k">FROM</div>
        <div style="font-size:15px;font-weight:800;margin-top:1mm">${esc(d.from || sx.signer || f.name || '')}</div>
        <div style="font-size:12px;line-height:1.35;margin-top:1mm">${fromLines({ firm: f, s: sx })}</div>
        <div style="margin-top:auto;font-size:12px">${dmy(d.date || today())}</div></div></div>`;
    return shell('Bus parcel label', body, { ...o, setup: s });
  }
  if (r.type === 'ENVELOPE') {
    const s = setupFor('envelope');
    const body = `<div style="height:${s.h - 2 * s.margin}mm;display:grid;grid-template-columns:1fr 1.4fr;gap:6mm;color:#000;font-family:Arial,sans-serif">
      <div style="font-size:11px;line-height:1.45">${d.show_from === false ? '' : `<div style="font-size:10px;font-weight:800;letter-spacing:1px">FROM</div>${brandBlock(f, 44, 200, 15)}${fromLines({ firm: f, s: sx })}`}</div>
      <div style="align-self:center;border-left:2px solid #000;padding-left:5mm;font-size:15px;line-height:1.45">${d.heading ? `<div style="font-size:11px;font-weight:700;letter-spacing:1px">${esc(d.heading)}</div>` : ''}${nl(d.to || '')}</div></div>`;
    return shell('Envelope', body, { ...o, setup: s });
  }
  // letter pad: letterhead, date, To, subject, text, signature (editable on screen before printing)
  const s = setupFor('invoice'), ce = o.shot ? '' : ' contenteditable="true"';
  const body = `<style>.lp [contenteditable]:hover { background:rgba(26,155,181,.06); } .lp [contenteditable]:focus { outline:1px dashed #1A9BB5; } @media print { .lp [contenteditable]:hover { background:none; } }</style>
    <div class="lp" style="font-size:14px;line-height:1.55;color:#111;padding:2mm 3mm;height:${s.h - 2 * s.margin}mm;display:flex;flex-direction:column">
    <div class="head"><div>${brandBlock(f, 64, 260, 26)}<div class="muted" style="font-size:11.5px;margin-top:2px">${fromLines({ firm: f, s: sx })}</div></div>
      <div style="text-align:right;white-space:nowrap"${ce}>Date: <b>${dmy(d.date || today())}</b>${d.ref ? `<br>Ref No. <b>${esc(d.ref)}</b>` : ''}</div></div>
    ${d.to ? `<div style="margin-top:6mm"${ce}>To,<br>${nl(d.to)}</div>` : ''}
    ${d.subject ? `<div style="margin-top:5mm"${ce}><b>Subject: ${esc(d.subject)}</b></div>` : ''}
    <div style="margin-top:5mm;white-space:pre-wrap;flex:1 1 auto"${ce}>${esc(d.body || '')}</div>
    <div${ce}>Thank you,</div><div style="height:18mm;display:flex;align-items:flex-end">${img(f.signature, 62, 180)}</div>
    <div${ce}><b>${esc(d.signer || sx.signer || '')}</b><br>For ${esc(f.name || '')}</div></div>
    ${o.shot ? '' : '<div class="no-print" style="position:fixed;right:14px;bottom:14px;background:#1A3E4A;color:#fff;padding:8px 12px;border-radius:8px;font:13px Segoe UI,Arial">✏ Click on the letter to change any word before printing.</div>'}`;
  return shell('Letter', body, { ...o, setup: s });
}

const LAYOUT = { stickers, cover, address, bags, envelope, annexure, cdf, cn23, towhom, note, freight };

// GET /print/mkt/<paper>/<dispatch id>  (?print=1 opens the print window, ?shot=1 for direct printing / PDF)
function serve(url, q, res, send, PS) {
  const m = url.pathname.match(/^\/print\/mkt\/([a-z0-9]+)\/(\d+)$/);
  if (m && (m[1] === 'quick' || m[1] === 'letter')) {     // quick sticker / letter: their own records
    const r = M.get(`SELECT * FROM ${m[1] === 'quick' ? 'quick_stickers' : 'letters'} WHERE id = ?`, m[2]);
    if (!r) return send(res, 404, 'Not found', 'text/plain');
    const sx = require('./routes').settings();
    const firm = mGet('SELECT * FROM firms WHERE code = ?', r.firm_code || sx.default_firm) || mGet('SELECT * FROM firms ORDER BY id LIMIT 1') || { name: '' };
    const o = { autoPrint: q.print === '1', shot: q.shot === '1' };
    if (m[1] === 'quick') return send(res, 200, quickHtml(r, firm, { ...o, page: PS.get('mkt_quick') }), 'text/html; charset=utf-8');
    return send(res, 200, letterHtml(r, firm, sx, { ...o, page: PS.get(r.type === 'BUS' ? 'mkt_bus' : r.type === 'ENVELOPE' ? 'mkt_blankenv' : 'mkt_letter') }), 'text/html; charset=utf-8');
  }
  const doc = m && DOCS.find(x => x.key === m[1]);
  if (!doc) return send(res, 404, 'Not found', 'text/plain');
  let d;
  try { d = dispatchFull(Number(m[2])); } catch (e) { return send(res, 500, e.message, 'text/plain'); }
  if (!d) return send(res, 404, 'This dispatch is not there any more.', 'text/plain');
  // drawn at its own size, placed on the paper by its page setup (Settings → Page setup)
  const html = LAYOUT[doc.key](d, { autoPrint: q.print === '1', shot: q.shot === '1', page: PS.get('mkt_' + doc.key), from: q.from, to: q.to });
  return send(res, 200, html, 'text/html; charset=utf-8');
}

const safe = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);

function register(route, settings, h) {
  const winprint = require('../winprint');
  const { makePdf } = require('../pdf');

  route('GET', '/api/mkt/print-docs', ({ req }) => {
    const { paperSize } = require('../print');
    const PN = { A4: 'A4', A5: 'A5', LETTER: 'Letter', LABEL4X6: '4×6 label', ENV_DL: 'DL envelope', ENV_C5: 'C5 envelope', ENV_10: 'No.10 envelope' };
    return { docs: DOCS.map(x => { const s = h.PS.get('mkt_' + x.key), [w, hh] = paperSize(s);
        return { key: x.key, name: x.name, kind: x.kind, note: x.note || '', def: !!x.def, printer: s.printer || '',
          paper: `${PN[s.paper] || `${Math.round(w)}×${Math.round(hh)} mm`}${s.landscape ? ' landscape' : ''}${s.area !== 'full' ? ' · ' + s.area : ''}${s.across * s.down > 1 ? ` · ${s.across}×${s.down} per sheet` : ''}` }; }),
      direct: winprint.supported(), local: h.isLocal(req) };
  });

  // local freight letter details (driver, vehicle, amount) for a dispatch
  route('PUT', '/api/mkt/dispatches/:id/freight', ({ p, body }) => {
    if (!M.get('SELECT 1 FROM dispatches WHERE id = ?', p.id)) throw new M.MktError('This dispatch is not there any more.');
    const amount = Number(body.amount);
    if (!String(body.driver || '').trim()) throw new M.MktError('Enter the driver name.');
    if (!(amount > 0)) throw new M.MktError('Enter the amount.');
    M.run('INSERT INTO dispatch_freight(dispatch_id, driver, tempo_no, mobile, amount, from_place) VALUES(?, ?, ?, ?, ?, ?)', p.id,
      String(body.driver).trim().toUpperCase(), String(body.tempo_no || '').trim().toUpperCase().replace(/\s/g, '') || null, String(body.mobile || '').replace(/\D/g, '') || null, amount, String(body.from_place || '').trim() || null);
    return { ok: true };
  });
  route('PUT', '/api/mkt/dispatches/:id/note-text', ({ p, body }) => {
    const t = String(body.text ?? '').replace(/\r\n/g, '\n').replace(/\n+$/, '').slice(0, 5000);
    if (!M.run('UPDATE dispatches SET note_text = ? WHERE id = ?', t || null, p.id).changes) throw new M.MktError('This dispatch is not there any more.');
    return { ok: true };
  });
  route('GET', '/api/mkt/dispatches/:id/freight', ({ p }) => M.get('SELECT * FROM dispatch_freight WHERE dispatch_id = ? ORDER BY id DESC LIMIT 1', p.id) || {});

  // print the ticked papers: straight to this PC's printer for each paper kind, otherwise the print window
  route('POST', '/api/mkt/print', async ({ body, req }) => {
    const d = dispatchFull(Number(body.dispatch_id));
    if (!d) throw new M.MktError('This dispatch is not there any more.');
    const keys = (Array.isArray(body.docs) ? body.docs : []).filter(k => DOCS.some(x => x.key === k));
    if (!keys.length) throw new M.MktError('Tick at least one paper to print.');
    if (keys.includes('freight') && !d.freight) throw new M.MktError('Local freight letter: enter the driver and the amount first.');
    const port = h.port(), printed = [], browser = [];
    for (const k of keys) {
      const doc = DOCS.find(x => x.key === k), s = h.PS.get('mkt_' + k), n = doc.pages(d), base = `/print/mkt/${k}/${d.dispatch.id}`;
      const direct = winprint.supported() && s.printer && (h.isLocal(req) || body.where === 'main' || (body.where_map || {})[k] === 'main');
      if (!direct) { browser.push({ doc: k, name: doc.name, url: base + '?print=1', reason: !s.printer ? 'no-printer' : 'not-this-pc' }); continue; }
      if (n > 300) throw new M.MktError(`${doc.name}: print at most 300 at a time.`);
      const job = h.PS.jobs('mkt_' + k, n, base, port);
      await winprint.printPages(job.printer, job.pages, `Ref ${d.lead.ref_no} ${doc.name}`);
      printed.push({ doc: k, name: doc.name, printer: s.printer, pages: n });
      M.run('INSERT INTO print_log(sample_id, document, printer) VALUES(?, ?, ?)', d.dispatch.id, k, s.printer);
    }
    for (const b of browser) M.run('INSERT INTO print_log(sample_id, document, printer) VALUES(?, ?, ?)', d.dispatch.id, b.doc, 'print window');
    // a small PDF copy of the cover letter and the stickers, in the PDF folder → Marketing → "<Ref> <Company>"
    if (winprint.supported() && (keys.includes('cover') || keys.includes('stickers'))) savePdfs(d, port).catch(e => console.error('Marketing PDF:', e.message));
    return { printed, browser };
  });

  // ---- quick stickers ----
  route('GET', '/api/mkt/quick', () => M.all('SELECT * FROM quick_stickers ORDER BY id DESC LIMIT 100'));
  route('POST', '/api/mkt/quick', ({ body }) => {
    const up = v => { const t = String(v ?? '').trim().replace(/\s+/g, ' '); return t ? t.toUpperCase() : null; };
    const o = { date: /^\d{4}-\d{2}-\d{2}$/.test(body.date || '') ? body.date : today(), ref: up(body.ref), name: up(body.name), company: up(body.company),
      mobile: String(body.mobile || '').replace(/\D/g, '').slice(-10) || null, pincode: String(body.pincode || '').replace(/\D/g, '') || null, city: up(body.city), state: up(body.state),
      item: up(body.item), rate: body.rate === '' || body.rate == null || isNaN(Number(body.rate)) ? null : Number(body.rate), unit: up(body.unit), remark: String(body.remark || '').trim() || null };
    if (!o.name && !o.company) throw new M.MktError('Enter the name or the company.');
    if (o.mobile && o.mobile.length !== 10) throw new M.MktError('Check the mobile number: 10 digits.');
    const k = Object.keys(o);
    return { id: Number(M.run(`INSERT INTO quick_stickers(${k.join(',')}) VALUES(${k.map(() => '?').join(',')})`, ...k.map(x => o[x])).lastInsertRowid) };
  });
  route('DELETE', '/api/mkt/quick/:id', ({ p }) => { M.run('DELETE FROM quick_stickers WHERE id = ?', p.id); return { deleted: true }; });
  // ---- letters ----
  route('GET', '/api/mkt/letters', () => M.all('SELECT * FROM letters ORDER BY id DESC LIMIT 100'));
  route('POST', '/api/mkt/letters', ({ body }) => {
    const type = ['PAD', 'BUS', 'ENVELOPE'].includes(body.type) ? body.type : null;
    if (!type) throw new M.MktError('Unknown letter.');
    const data = body.data && typeof body.data === 'object' ? body.data : {};
    if (!String(data.to || data.body || '').trim()) throw new M.MktError(type === 'PAD' ? 'Write the letter first.' : 'Enter the To address.');
    return { id: Number(M.run('INSERT INTO letters(type, lead_id, firm_code, data) VALUES(?, ?, ?, ?)', type, Number(body.lead_id) || null, body.firm_code || null, JSON.stringify(data).slice(0, 20000)).lastInsertRowid) };
  });
  route('DELETE', '/api/mkt/letters/:id', ({ p }) => { M.run('DELETE FROM letters WHERE id = ?', p.id); return { deleted: true }; });
  // print one quick sticker or letter: its printer from Page Setup, otherwise the print window
  route('POST', '/api/mkt/print-one', async ({ body, req }) => {
    const what = body.what === 'quick' ? 'quick' : 'letter';
    const r = M.get(`SELECT * FROM ${what === 'quick' ? 'quick_stickers' : 'letters'} WHERE id = ?`, body.id);
    if (!r) throw new M.MktError('Not found.');
    const key = what === 'quick' ? 'mkt_quick' : r.type === 'BUS' ? 'mkt_bus' : r.type === 'ENVELOPE' ? 'mkt_blankenv' : 'mkt_letter';
    const s = h.PS.get(key), base = `/print/mkt/${what}/${r.id}`;
    if (!(winprint.supported() && s.printer && (h.isLocal(req) || body.where === 'main'))) return { browser: true, url: base + '?print=1' };
    const job = h.PS.jobs(key, 1, base, h.port());
    await winprint.printPages(job.printer, job.pages, what === 'quick' ? `Quick sticker ${r.ref || ''}` : 'Letter');
    return { printed: true, printer: s.printer };
  });

  route('POST', '/api/mkt/pdf', async ({ body }) => {
    const d = dispatchFull(Number(body.dispatch_id));
    if (!d) throw new M.MktError('This dispatch is not there any more.');
    return { files: await savePdfs(d, h.port()) };
  });

  async function savePdfs(d, port) {
    const dir = path.join(h.pdfFolder(), 'Marketing', safe(`${d.lead.ref_no} ${d.lead.company || d.lead.buyer_name || ''}`));
    const out = [];
    for (const k of ['cover', 'stickers']) {
      const file = path.join(dir, safe(`${d.dispatch.date} ${k === 'cover' ? 'Cover letter' : 'Sample stickers'}`) + '.pdf');
      await makePdf(`http://127.0.0.1:${port}/print/mkt/${k}/${d.dispatch.id}?shot=1`, file);
      out.push(file);
    }
    return out;
  }
}

module.exports = { serve, register, DOCS, dispatchFull, LAYOUT };
