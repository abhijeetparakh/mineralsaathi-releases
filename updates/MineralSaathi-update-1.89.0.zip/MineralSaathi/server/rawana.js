'use strict';
// Reads an eRawanna (Rajasthan mines department) from the QR code on the rawana:
// the QR holds a link like http://mines.rajasthan.gov.in/DMG2/Public/eRawannaStatus/VBBA1102154730
// The page is opened on this PC and read by its labels.
const http = require('http'), https = require('https');

const HOST = /(^|\.)mines\.rajasthan\.gov\.in$/i;

// What the scanner typed: the link, or just the rawana number
function parseCode(code) {
  const s = String(code || '').trim();
  let m = s.match(/eRawannaStatus\/([A-Za-z0-9]+)/i);
  if (m) return { no: m[1].toUpperCase(), url: s.replace(/\s+/g, '') };
  m = s.match(/^[A-Za-z]{2,6}\d{6,}$/);
  if (m) return { no: s.toUpperCase(), url: 'http://mines.rajasthan.gov.in/DMG2/Public/eRawannaStatus/' + s.toUpperCase() };
  return null;
}

function fetchPage(url, hops = 0) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch { return reject(new Error('This is not a rawana link.')); }
    if (!HOST.test(u.hostname)) return reject(new Error('Only links of mines.rajasthan.gov.in are opened.'));
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.get(u, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) MineralSaathi', Accept: 'text/html' }, timeout: 20000 }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && hops < 4) { res.resume(); return resolve(fetchPage(new URL(res.headers.location, u).href, hops + 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`The mines website answered ${res.statusCode}. Try again in a minute.`)); }
      const chunks = []; let size = 0;
      res.on('data', c => { size += c.length; if (size > 3e6) req.destroy(); else chunks.push(c); });
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    });
    req.on('timeout', () => req.destroy(new Error('The mines website did not answer. Check the internet and try again.')));
    req.on('error', e => reject(/ENOTFOUND|EAI_AGAIN|ECONN/.test(e.code || e.message) ? new Error('Cannot reach the mines website. Check the internet.') : e));
  });
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
// The page as a list of text pieces in reading order (table cells, labels, values …)
function pieces(html) {
  const t = String(html)
    .replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<input[^>]*\bvalue\s*=\s*"([^"]*)"[^>]*>/gi, '\u0001$1\u0001')
    .replace(/<\/?(td|th|tr|br|div|p|li|label|span|b|strong|h\d|table|tbody|thead|dt|dd|option)\b[^>]*>/gi, '\u0001')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&(#\d+|#x[0-9a-f]+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCharCode(e[1] === 'x' ? parseInt(e.slice(2), 16) : Number(e.slice(1))) : (ENT[e.toLowerCase()] ?? m));
  return t.split('\u0001').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
}

// The value written after a label: "Label : value" in one piece, or the next piece
function after(list, re, ok = () => true) {
  for (let i = 0; i < list.length; i++) {
    const s = list[i]; const m = s.match(re); if (!m) continue;
    const raw = s.slice(m.index + m[0].length), dash = v => /^[\s:]*[-–]\s*$/.test(v);          // ": -" = nothing written
    if (dash(raw)) return { v: '-', i, unit: '' };
    const rest = raw.replace(/^[\s:.\-–=]+/, '').trim();
    if (rest && !/^(details?)$/i.test(rest) && ok(rest)) return { v: rest, i, unit: '' };
    for (let j = i + 1; j < Math.min(list.length, i + 4); j++) { if (dash(list[j])) return { v: '-', i: j, unit: rest }; const n = list[j].replace(/^[\s:.\-–=]+/, '').trim(); if (n && ok(n)) return { v: n, i: j, unit: rest }; }
  }
  return null;
}

// 20-11-2026, 20/11/2026 10:22, 20-Nov-2026, 2026-11-20 … → 2026-11-20
const MONS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function isoDate(s) {
  s = String(s || '');
  let m = s.match(/\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b/), y, mo, d;
  if (m) [y, mo, d] = [+m[1], +m[2], +m[3]];
  else if ((m = s.match(/\b(\d{1,2})[-/.\s]([A-Za-z]{3})[A-Za-z]*[-/.,\s]+(\d{2,4})\b/))) [d, mo, y] = [+m[1], MONS[m[2].toLowerCase()], +m[3]];
  else if ((m = s.match(/\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})\b/))) [d, mo, y] = [+m[1], +m[2], +m[3]];
  else return null;
  if (y < 100) y += 2000;
  if (!(y > 2000 && y < 2100 && mo >= 1 && mo <= 12 && d >= 1 && d <= 31)) return null;
  return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
function read(html, code) {
  const p = pieces(html), out = { rawana_no: code.no };
  const no = after(p, /e-?\s*rawann?a\s*(no\.?|number|id)\b/i);
  if (no) { const m = no.v.match(/[A-Z]{2,6}\d{6,}/i); if (m) out.rawana_no = m[0].toUpperCase(); }
  // the page heading: "RJ19GJ1454 is having eRawanna No. VBBA1102154730 (Confirmed) …"
  const head = p.join(' ').match(/\b([A-Z]{2}\s*-?\d{1,2}\s*-?[A-Z]{0,3}\s*-?\d{3,4})\s+is\s+having\s+e-?rawann?a/i);
  if (head) out.lorry_no = head[1].toUpperCase().replace(/[^A-Z0-9]/g, '');
  const lorry = head ? null : after(p, /\b(vehicle|lorry|truck)\s*(no\.?|number|reg(istration)?(\s*no\.?)?)\b/i, v => /\d/.test(v));
  if (lorry) { const m = lorry.v.toUpperCase().replace(/[^A-Z0-9]/g, '').match(/[A-Z]{2}\d{1,2}[A-Z]{0,3}\d{3,4}/); out.lorry_no = m ? m[0] : lorry.v.toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  const wt = after(p, /\bnet\s*(mineral\s*)?(weight|wt\.?|qty|quantity)\b/i, v => /\d/.test(v));
  if (wt) {
    const m = wt.v.replace(/,/g, '').match(/\d+(\.\d+)?/);
    if (m) { let n = Number(m[0]); if (/\bkgs?\b|kilo/i.test(wt.v + ' ' + wt.unit) || n > 200) n = n / 1000; out.rawana_wt = Math.round(n * 1000) / 1000; }
  }
  const dName = after(p, /\bdriver'?s?\s*name\b/i), dMob = after(p, /\bdriver'?s?\s*(mobile|mob\.?|phone|contact)(\s*no\.?)?\b/i, v => /\d{10}/.test(v.replace(/[\s-]/g, '')));
  const dAll = after(p, /\bdriver'?s?\s*details?\b/i);
  const mobile = s => { const m = String(s || '').replace(/[\s-]/g, '').match(/(?:\+?91)?([6-9]\d{9})/); return m ? m[1] : ''; };
  if (dName) out.driver_name = dName.v.replace(/[\d+()\-,/]+/g, ' ').replace(/\s+/g, ' ').trim().toUpperCase();
  if (dMob) out.driver_phone = mobile(dMob.v);
  if (dAll && (!out.driver_name || !out.driver_phone)) {
    const txt = p.slice(dAll.i, dAll.i + 6).join(' ');
    if (!out.driver_phone) out.driver_phone = mobile(txt);
    if (!out.driver_name) { const nm = dAll.v.replace(/(?:\+?91)?[6-9]\d{9}/g, '').replace(/\b(name|mobile|mob|no|phone)\b\.?/gi, '').replace(/[\d:+()\-,/]+/g, ' ').replace(/\s+/g, ' ').trim(); if (nm) out.driver_name = nm.toUpperCase(); }
  }
  const text = (re, ok) => { const x = after(p, re, ok); const v = x && x.v.replace(/^[:\s]+/, '').trim(); return v && v !== '-' ? v : null; };
  const g = text(/\bgstin\b|\bgst\s*(in|no\.?|number)\b/i, v => /\d{2}[A-Z]{5}\d{4}[A-Z]/i.test(v));
  if (g) out.gstin = g.toUpperCase().match(/\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]{3}/)?.[0];
  out.lessee = text(/\bname\s*of\s*(the\s*)?lessee\b|\blessee\s*name\b/i)?.toUpperCase();
  out.mineral = text(/^mineral(\s*name)?\b/i)?.toUpperCase();
  out.lease_no = text(/\blease\s*no\.?/i);
  out.ibm_no = text(/\bibm\s*(reg(istration)?\.?\s*)?no\.?/i)?.toUpperCase();
  const amt = re => { const v = text(re, v => /\d/.test(v)); return v ? Number(v.replace(/[^\d.]/g, '').replace(/\.$/, '')) || null : null; };
  out.royalty = amt(/^royalty\b(?!\s*schedule)/i); out.dmft = amt(/^dmft\b/i); out.nmet = amt(/^nme?dt\b|^nmet\b/i);
  // the confirm date of the rawana (else the date it was made) → the date of the Stock IN
  const cd = after(p, /\bconfirm(ed|ation)?\s*(date|on|dt\.?)(\s*(and|&)\s*time)?\b/i, v => !!isoDate(v))
    || after(p, /\b(generat(ed|ion)|issue[d]?|dispatch(ed)?|journey\s*start|e-?rawann?a)\s*(date|on|dt\.?)(\s*(and|&)\s*time)?\b/i, v => !!isoDate(v));
  if (cd) out.confirm_date = isoDate(cd.v);
  else { const m = p.join(' ').match(/\(\s*confirmed\s*\)[^0-9]{0,40}(\d{1,2}[-/.][0-9A-Za-z]{1,3}[-/.]\d{2,4})/i); if (m) out.confirm_date = isoDate(m[1]); }
  for (const k of Object.keys(out)) if (out[k] === '' || out[k] == null) delete out[k];
  return out;
}

async function lookup(code) {
  const c = parseCode(code);
  if (!c) throw Object.assign(new Error('Scan the QR code on the rawana (or type the rawana no.).'), { user: true });
  const html = await fetchPage(c.url);
  const r = read(html, c);
  r.found = ['lorry_no', 'rawana_wt', 'driver_name', 'driver_phone'].filter(k => r[k] != null);
  r.url = c.url;
  return { r, html };
}

module.exports = { parseCode, pieces, read, lookup, isoDate };
