'use strict';
// Master → Suppliers: each supplier's items (raw material, grade, HSN) with the purchase rate per MT and the freight per MT.
// The first item is also kept on the supplier (item, grade, hsn, rate, freight_rate) for the inward voucher and Stock IN.
const { all, get, run } = require('./db');
run(`CREATE TABLE IF NOT EXISTS supplier_items (id INTEGER PRIMARY KEY, supplier_id INTEGER NOT NULL, item TEXT, grade TEXT, hsn TEXT, rate REAL, freight_rate REAL, sort INTEGER DEFAULT 0, active INTEGER DEFAULT 1)`);
run('CREATE INDEX IF NOT EXISTS ix_sup_items ON supplier_items(supplier_id)');
// first time: each supplier's one item becomes its first item row
for (const s of all('SELECT * FROM suppliers WHERE (item IS NOT NULL OR grade IS NOT NULL OR COALESCE(freight_rate, 0) > 0 OR COALESCE(rate, 0) > 0) AND id NOT IN (SELECT supplier_id FROM supplier_items)'))
  run('INSERT INTO supplier_items(supplier_id, item, grade, hsn, rate, freight_rate) VALUES(?,?,?,?,?,?)', s.id, s.item, s.grade, s.hsn, Number(s.rate) > 0 ? s.rate : null, Number(s.freight_rate) > 0 ? s.freight_rate : null);
class E extends Error { constructor(m) { super(m); this.status = 400; } }
const up = v => { const s = String(v ?? '').trim().toUpperCase(); return s || null; };
const num = v => v === '' || v == null ? null : (Number.isFinite(Number(v)) ? Math.round(Number(v) * 100) / 100 : null);
function syncFirst(sid) {
  const f = get('SELECT * FROM supplier_items WHERE supplier_id = ? AND active = 1 ORDER BY sort, id LIMIT 1', sid);
  if (f) run('UPDATE suppliers SET item = ?, grade = ?, hsn = ?, rate = ?, freight_rate = ? WHERE id = ?', f.item, f.grade, f.hsn, f.rate, f.freight_rate, sid);
}
function register(route) {
  route('GET', '/api/supplier-items', ({ q }) => all(`SELECT si.*, s.name AS supplier FROM supplier_items si JOIN suppliers s ON s.id = si.supplier_id WHERE si.active = 1 ${q.supplier_id ? 'AND si.supplier_id = ?' : ''} ORDER BY s.name, si.sort, si.id`, ...(q.supplier_id ? [Number(q.supplier_id)] : [])));
  // the whole list of a supplier's items at once (rows without an id are new; rows left out are removed)
  route('PUT', '/api/supplier-items/:sid', ({ p, body }) => {
    const sid = Number(p.sid); if (!get('SELECT 1 FROM suppliers WHERE id = ?', sid)) throw new E('Supplier not found.');
    const rows = (Array.isArray(body.items) ? body.items : []).map((r, i) => ({ id: Number(r.id) || null, item: up(r.item), grade: up(r.grade), hsn: String(r.hsn || '').trim() || null, rate: num(r.rate), freight_rate: num(r.freight_rate), sort: i }))
      .filter(r => r.item || r.grade || r.rate != null || r.freight_rate != null);
    const keep = rows.filter(r => r.id).map(r => r.id);
    run(`UPDATE supplier_items SET active = 0 WHERE supplier_id = ? ${keep.length ? `AND id NOT IN (${keep.map(() => '?').join(',')})` : ''}`, sid, ...keep);
    for (const r of rows) {
      if (r.id) run('UPDATE supplier_items SET item = ?, grade = ?, hsn = ?, rate = ?, freight_rate = ?, sort = ?, active = 1 WHERE id = ? AND supplier_id = ?', r.item, r.grade, r.hsn, r.rate, r.freight_rate, r.sort, r.id, sid);
      else run('INSERT INTO supplier_items(supplier_id, item, grade, hsn, rate, freight_rate, sort) VALUES(?,?,?,?,?,?,?)', sid, r.item, r.grade, r.hsn, r.rate, r.freight_rate, r.sort);
    }
    syncFirst(sid);
    return { saved: rows.length };
  });
}
module.exports = { register };
