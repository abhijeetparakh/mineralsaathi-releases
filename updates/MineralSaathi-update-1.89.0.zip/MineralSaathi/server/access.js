'use strict';
// Settings → Network & Login
//  • Windows Firewall: lets the other office PCs reach this main PC also when the network is "Public"
//    (only PCs of the same local network — remoteip=localsubnet).
//  • Login: other PCs log in with an ID and password (the main PC itself never needs to).
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { all, get, run, setting, setSetting } = require('./db');
const { DATA_DIR } = require('./paths');

run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, login TEXT NOT NULL UNIQUE, name TEXT, salt TEXT, hash TEXT, active INTEGER DEFAULT 1, created TEXT DEFAULT (datetime('now','localtime')))`);
run(`CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER, exp INTEGER, ip TEXT, at TEXT DEFAULT (datetime('now','localtime')))`);
class E extends Error { constructor(m, s = 400) { super(m); this.status = s; } }
const DAYS = 30;
const sha = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64).toString('hex');
const required = () => setting('login_required', '0') === '1';

// this PC's own addresses: requests from here are the main PC (never asked to log in)
function ownIps() { return new Set(['127.0.0.1', '::1', ...Object.values(os.networkInterfaces()).flat().filter(Boolean).map(i => i.address)]); }
const ipOf = req => String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
const isMain = req => ownIps().has(ipOf(req));
const cookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(x => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
function userOf(req) {
  const t = cookies(req).ms_s; if (!t) return null;
  const s = get('SELECT * FROM sessions WHERE token = ?', sha(t)); if (!s || s.exp < Date.now()) return null;
  const u = get('SELECT id, login, name FROM users WHERE id = ? AND active = 1', s.user_id); return u || null;
}
const tries = new Map();
const tooMany = ip => { const now = Date.now(), l = (tries.get(ip) || []).filter(t => now - t < 10 * 60e3); tries.set(ip, l); return l.length >= 8; };

const page = (msg = '', next = '/') => `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mineral Saathi — Log in</title><link rel="icon" href="/logo-icon.png">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#e9f0f2;font-family:"Segoe UI",Arial,sans-serif;color:#1d2b30}
.box{background:#fff;padding:34px 32px;border-radius:14px;box-shadow:0 2px 16px rgba(0,0,0,.12);width:min(360px,90vw);text-align:center}img{width:84px;border-radius:18px}
h1{font-size:21px;margin:10px 0 20px}input{width:100%;box-sizing:border-box;padding:12px 14px;border:1px solid #c9d6da;border-radius:8px;font-size:15px;margin-bottom:12px}
button{width:100%;padding:12px;border:0;border-radius:8px;background:#1c8fa8;color:#fff;font-size:15px;font-weight:600;cursor:pointer}.err{color:#c0392b;font-size:13.5px;margin:-4px 0 12px}.foot{color:#667;font-size:12px;margin-top:16px}</style></head>
<body><form class="box" method="post" action="/login"><img src="/logo-icon.png" alt=""><h1>Mineral Saathi</h1>${msg ? `<div class="err">${msg}</div>` : ''}
<input name="login" placeholder="User ID" autofocus required autocomplete="username"><input name="password" type="password" placeholder="Password" required autocomplete="current-password">
<input type="hidden" name="next" value="${String(next).replace(/[^\w/#:?=&.-]/g, '')}"><button type="submit">Log in</button><div class="foot">Ask the office for your ID and password.</div></form></body></html>`;

// before anything else: true = go on, false = answered here (login page / 401)
async function gate(req, res, url) {
  const p = url.pathname;
  if (p === '/logout') {
    const t = cookies(req).ms_s; if (t) run('DELETE FROM sessions WHERE token = ?', sha(t));
    res.writeHead(302, { 'Set-Cookie': 'ms_s=; Path=/; HttpOnly; Max-Age=0', Location: '/login' }); res.end(); return false;
  }
  if (p === '/login') {
    if (req.method === 'POST') {
      const body = await new Promise(r => { let d = ''; req.on('data', c => { d += c; if (d.length > 1e4) req.destroy(); }); req.on('end', () => r(new URLSearchParams(d))); });
      const ip = ipOf(req), login = String(body.get('login') || '').trim().toLowerCase(), next = body.get('next') || '/';
      if (tooMany(ip)) { res.writeHead(429, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(page('Too many tries — wait 10 minutes.', next)); return false; }
      const u = get('SELECT * FROM users WHERE lower(login) = ? AND active = 1', login);
      if (!u || !crypto.timingSafeEqual(Buffer.from(hashPw(body.get('password') || '', u.salt), 'hex'), Buffer.from(u.hash, 'hex'))) {
        (tries.get(ip) || tries.set(ip, []).get(ip)).push(Date.now());
        res.writeHead(401, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(page('Wrong user ID or password.', next)); return false;
      }
      const token = crypto.randomBytes(32).toString('hex');
      run('DELETE FROM sessions WHERE exp < ?', Date.now());
      run('INSERT INTO sessions(token, user_id, exp, ip) VALUES(?,?,?,?)', sha(token), u.id, Date.now() + DAYS * 864e5, ip);
      res.writeHead(302, { 'Set-Cookie': `ms_s=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${DAYS * 86400}`, Location: next.startsWith('/') ? next : '/' }); res.end(); return false;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(page('', url.searchParams.get('next') || '/')); return false;
  }
  if (!required() || isMain(req)) return true;
  if (/\.(css|png|ico|svg|webp|jpg)$/.test(p)) return true;          // pictures and the look of the login page
  if (userOf(req)) return true;
  if (p.startsWith('/api/')) { res.writeHead(401, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'Please log in again.', login: true })); return false; }
  res.writeHead(302, { Location: '/login?next=' + encodeURIComponent(p === '/' ? '/' : p + url.search) }); res.end(); return false;
}

// ---- Windows Firewall (main PC only) ----
const sh = (cmd, args) => new Promise(r => execFile(cmd, args, { windowsHide: true, timeout: 15000 }, (e, out) => r(e ? '' : String(out || ''))));
async function network(port) {
  if (process.platform !== 'win32') return { windows: false };
  const rule = await sh('netsh', ['advfirewall', 'firewall', 'show', 'rule', 'name=Mineral Saathi']);
  const field = k => { const m = rule.match(new RegExp('^' + k + ':\\s*(.+)$', 'mi')); return m ? m[1].trim() : ''; };
  let nets = [];
  try { const j = JSON.parse(await sh('powershell', ['-NoProfile', '-Command', 'Get-NetConnectionProfile | Select-Object Name,InterfaceAlias,NetworkCategory | ConvertTo-Json']) || '[]'); nets = (Array.isArray(j) ? j : [j]).map(n => ({ name: n.Name, via: n.InterfaceAlias, kind: ['Public', 'Private', 'DomainAuthenticated'][n.NetworkCategory] || String(n.NetworkCategory) })); } catch { /* old Windows */ }
  const profiles = field('Profiles'), remote = field('RemoteIP');
  return { windows: true, rule: !!rule && /Mineral Saathi/.test(rule), profiles, remote, public_ok: /Public|Any/i.test(profiles) || /Domain,Private,Public/i.test(profiles), nets, port,
    ips: Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address) };
}
function openFirewall(port) {
  if (process.platform !== 'win32') throw new E('This works on the Windows main PC.');
  const f = path.join(DATA_DIR, 'tmp', 'allow-office-pcs.cmd'); fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, ['@echo off', 'netsh advfirewall firewall delete rule name="Mineral Saathi" >nul 2>&1',
    `netsh advfirewall firewall add rule name="Mineral Saathi" dir=in action=allow protocol=TCP localport=${Number(port)} profile=any remoteip=localsubnet`, ''].join('\r\n'));
  // Windows asks "Do you want to allow this app to make changes?" on the main PC — press Yes. We wait for the answer (2 minutes at most).
  return new Promise(resolve => {
    execFile('powershell', ['-NoProfile', '-Command', `try { Start-Process -FilePath '${f.replace(/'/g, "''")}' -Verb RunAs -Wait -ErrorAction Stop; 'OK' } catch { 'ERR: ' + $_.Exception.Message }`],
      { windowsHide: false, timeout: 120000 }, (e, out) => {
        const o = String(out || '').trim();
        resolve(o === 'OK' ? { ok: true } : { ok: false, file: f, error: o.replace(/^ERR:\s*/, '') || (e ? e.message : 'Windows did not run it.') });
      });
  });
}

function register(route, { port }) {
  const mainOnly = req => { if (!isMain(req)) throw new E('This can be changed only on the main PC.', 403); };
  route('GET', '/api/access', ({ req }) => ({ required: required(), main: isMain(req), me: userOf(req),
    users: all('SELECT id, login, name, active, created FROM users ORDER BY login') }));
  route('PUT', '/api/access', ({ req, body }) => {
    mainOnly(req);
    if (Number(body.required) && !get('SELECT 1 FROM users WHERE active = 1')) throw new E('Make at least one user first.');
    setSetting('login_required', Number(body.required) ? '1' : '0'); return { required: required() };
  });
  const clean = (b, isNew) => {
    const o = {};
    if (b.login !== undefined || isNew) { o.login = String(b.login || '').trim().toLowerCase(); if (!/^[a-z0-9._-]{3,30}$/.test(o.login)) throw new E('User ID: 3 to 30 letters or digits (no spaces).'); }
    if (b.name !== undefined) o.name = String(b.name || '').trim().toUpperCase() || null;
    if (b.password || isNew) { if (String(b.password || '').length < 6) throw new E('The password needs at least 6 characters.'); o.salt = crypto.randomBytes(16).toString('hex'); o.hash = hashPw(b.password, o.salt); }
    if (b.active !== undefined) o.active = Number(b.active) ? 1 : 0;
    return o;
  };
  route('POST', '/api/access/users', ({ req, body }) => {
    mainOnly(req); const o = clean(body, true);
    if (get('SELECT 1 FROM users WHERE login = ?', o.login)) throw new E(`The user ID ${o.login} is already there.`);
    const k = Object.keys(o); return { id: Number(run(`INSERT INTO users(${k.join(',')}) VALUES(${k.map(() => '?').join(',')})`, ...k.map(x => o[x])).lastInsertRowid) };
  });
  route('PUT', '/api/access/users/:id', ({ req, p, body }) => {
    mainOnly(req); const o = clean(body, false), k = Object.keys(o);
    if (o.login && get('SELECT 1 FROM users WHERE login = ? AND id <> ?', o.login, p.id)) throw new E(`The user ID ${o.login} is already there.`);
    if (k.length) run(`UPDATE users SET ${k.map(x => x + ' = ?').join(', ')} WHERE id = ?`, ...k.map(x => o[x]), p.id);
    if (o.hash || o.active === 0) run('DELETE FROM sessions WHERE user_id = ?', p.id);      // a new password or a stopped user logs out everywhere
    return { id: Number(p.id) };
  });
  route('DELETE', '/api/access/users/:id', ({ req, p }) => {
    mainOnly(req); run('DELETE FROM sessions WHERE user_id = ?', p.id); run('DELETE FROM users WHERE id = ?', p.id);
    if (required() && !get('SELECT 1 FROM users WHERE active = 1')) setSetting('login_required', '0');
    return { deleted: true };
  });
  route('GET', '/api/access/network', async ({ req }) => { mainOnly(req); return { ...(await network(port())), folder: path.resolve(__dirname, '..') }; });
  route('POST', '/api/access/firewall', ({ req }) => { mainOnly(req); return openFirewall(port()); });
}
module.exports = { gate, register, isMain, userOf };
