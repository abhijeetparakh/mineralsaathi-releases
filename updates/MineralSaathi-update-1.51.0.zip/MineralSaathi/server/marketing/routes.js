'use strict';
// Marketing (Sampark Saathi) requests: /api/mkt/...
// Marketing data comes from marketing.db (./db). Settings are the shared Mineral Saathi settings,
// saved in mineral.db under names that start with "mkt." — they are settings, not marketing data.
const M = require('./db');
const { setting, setSetting, all: mAll } = require('../db');

const LIST_KEYS = {
  sample_size: 'Sample size',
  courier: 'Courier / sent by',
  response: 'Call response',
  followup_reason: 'Follow-up reason'
};

const SETTING_DEFAULTS = {
  enabled: '0',                                              // the Marketing menu stays hidden until switched on
  followup_days: '10',                                       // first "Did the sample arrive?" call after this many days
  calendar_url: '',                                          // Google Apps Script web-app link for the calendar push
  tracking_url: 'https://t.17track.net/en#nums={tracking_no}',
  default_firm: 'PM',                                        // sender on Marketing printouts (Settings -> Companies)
  next_ref: '434',                                           // first Ref No. of new enquiries (Excel ended at 433)
  signer: '',                                                // name printed under "Thank you" and as sender on postal forms
  sender_digipin: '',                                        // Digipin of the sender address (postal forms)
  delivery_time: '10 DAYS',                                  // on the sample sticker
  min_order_kg: '2 BAGS',                                    // minimum order when the rate is per KG
  min_order_mt: '1 TRUCK LOAD (25 MT TO 30 MT)',             // minimum order when the rate is per MT
  payment_terms: '100% IN ADVANCE',
  gst_note: 'PLUS 5% GST + FREIGHT'
};

function settings() {
  const o = {};
  for (const [k, d] of Object.entries(SETTING_DEFAULTS)) { const v = setting('mkt.' + k); o[k] = v == null ? d : v; }
  o.enabled = o.enabled === '1';
  o.followup_days = Number(o.followup_days) || 10;
  o.next_ref = Number(o.next_ref) || 1;
  return o;
}

const clean = v => String(v ?? '').trim().replace(/\s+/g, ' ');

module.exports = function register(route, helpers = {}) {
  // status + settings: always answer, even when marketing.db could not be opened (the screens show why)
  route('GET', '/api/mkt/status', () => ({ ...M.status(), settings: settings() }));
  route('GET', '/api/mkt/settings', () => ({ ...settings(), firms: mAll('SELECT code, name FROM firms ORDER BY id') }));
  route('PUT', '/api/mkt/settings', ({ body }) => {
    if (body.enabled !== undefined) setSetting('mkt.enabled', body.enabled ? '1' : '0');
    if (body.followup_days !== undefined) {
      const n = Math.round(Number(body.followup_days));
      if (!(n >= 0 && n <= 365)) throw new M.MktError('Days until the first call: enter 0 to 365.');
      setSetting('mkt.followup_days', String(n));
    }
    if (body.calendar_url !== undefined) {
      const u = String(body.calendar_url || '').trim();
      if (u && !/^https:\/\/script\.google\.com\//.test(u)) throw new M.MktError('The calendar link must be a Google Apps Script link (https://script.google.com/...).');
      setSetting('mkt.calendar_url', u || null);
    }
    if (body.tracking_url !== undefined) {
      const u = String(body.tracking_url || '').trim();
      if (u && (!/^https?:\/\//.test(u) || !u.includes('{tracking_no}'))) throw new M.MktError('The tracking link must start with http and contain {tracking_no}.');
      setSetting('mkt.tracking_url', u || null);
    }
    if (body.next_ref !== undefined) {
      const n = Math.round(Number(body.next_ref));
      if (!(n >= 1)) throw new M.MktError('First Ref No.: enter a number.');
      setSetting('mkt.next_ref', String(n));
    }
    for (const k of ['signer', 'sender_digipin', 'delivery_time', 'min_order_kg', 'min_order_mt', 'payment_terms', 'gst_note'])
      if (body[k] !== undefined) setSetting('mkt.' + k, String(body[k] || '').trim().replace(/\s+/g, ' ') || null);
    if (body.default_firm !== undefined) {
      const firms = mAll('SELECT code FROM firms');
      if (firms.length && !firms.some(f => f.code === body.default_firm)) throw new M.MktError('Choose a company from Settings → Companies.');
      setSetting('mkt.default_firm', body.default_firm);
    }
    return settings();
  });

  // ---- Google Calendar: test the Apps Script link by creating one clearly named test event ----
  route('POST', '/api/mkt/calendar/test', async ({ body }) => {
    const url = String((body && body.url) || settings().calendar_url || '').trim();
    if (!url) throw new M.MktError('Enter the Google Calendar link first.');
    if (!/^https:\/\/script\.google\.com\//.test(url)) throw new M.MktError('The calendar link must be a Google Apps Script link (https://script.google.com/...).');
    const p2 = n => String(n).padStart(2, '0'), d = new Date(Date.now() + 10 * 60000);
    const start = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}T${p2(d.getHours())}:${p2(d.getMinutes())}:00`;
    const payload = { title: 'Mineral Saathi — test connection (you can delete this)', startTime: start,
      description: 'Test event sent from Mineral Saathi → Settings → Data Location → Test connection.' };
    let r, text = '';
    try {
      r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), redirect: 'follow', signal: AbortSignal.timeout(25000) });
      text = (await r.text()).trim();
    } catch (e) {
      return { ok: false, message: 'Could not reach Google: ' + (e.name === 'TimeoutError' ? 'no answer in 25 seconds' : e.message) + '. Check the internet connection of the main PC.' };
    }
    const html = /^<!doctype html|^<html/i.test(text);
    if (r.ok && !html) return { ok: true, message: 'Connected. A test event was created for ' + start.replace('T', ' ').slice(0, 16) + ' — you can delete it from Google Calendar.', reply: text.slice(0, 300) };
    if (html && /accounts\.google\.com|ServiceLogin|sign in/i.test(text))
      return { ok: false, message: 'Google asked to sign in. In Apps Script: Deploy → Manage deployments → Edit → "Who has access" = Anyone, then Deploy again and copy the new link.' };
    if (html && /function not found|doPost/i.test(text))
      return { ok: false, message: 'The link works, but the script has no doPost function. Check the Apps Script code and deploy it again.' };
    return { ok: false, message: `Google answered with an error (${r.status}). Check that the link ends with /exec and the script is deployed as a web app.`, reply: text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 300) };
  });

  // ---- enquiries and samples (phase 2) ----
  require('./leads')(route, settings);
  require('./print').register(route, settings, helpers);

  // ---- Marketing lists ----
  route('GET', '/api/mkt/lists', () => {
    const out = Object.fromEntries(Object.keys(LIST_KEYS).map(k => [k, []]));
    for (const r of M.all('SELECT * FROM mkt_lists WHERE active = 1 ORDER BY list_key, sort, value')) if (out[r.list_key]) out[r.list_key].push(r);
    return out;
  });
  route('POST', '/api/mkt/lists', ({ body }) => {
    const key = body.list_key, value = clean(body.value).toUpperCase();
    if (!LIST_KEYS[key]) throw new M.MktError('Unknown list.');
    if (!value) throw new M.MktError('Enter a value.');
    const old = M.get('SELECT id, active FROM mkt_lists WHERE list_key = ? AND value = ?', key, value);
    if (old && old.active) throw new M.MktError(`"${value}" is already in the list.`);
    if (old) { M.run('UPDATE mkt_lists SET active = 1 WHERE id = ?', old.id); return { id: old.id }; }
    const sort = (M.get('SELECT MAX(sort) m FROM mkt_lists WHERE list_key = ?', key).m ?? -1) + 1;
    return { id: Number(M.run('INSERT INTO mkt_lists(list_key, value, sort) VALUES(?, ?, ?)', key, value, sort).lastInsertRowid) };
  });
  route('PUT', '/api/mkt/lists/:id', ({ p, body }) => {
    const r = M.get('SELECT * FROM mkt_lists WHERE id = ?', p.id);
    if (!r) throw new M.MktError('Not found.');
    const value = clean(body.value).toUpperCase();
    if (!value) throw new M.MktError('Enter a value.');
    if (M.get('SELECT 1 FROM mkt_lists WHERE list_key = ? AND value = ? AND id <> ? AND active = 1', r.list_key, value, r.id)) throw new M.MktError(`"${value}" is already in the list.`);
    M.run('DELETE FROM mkt_lists WHERE list_key = ? AND value = ? AND id <> ? AND active = 0', r.list_key, value, r.id);
    M.run('UPDATE mkt_lists SET value = ? WHERE id = ?', value, r.id);
    return { id: r.id };
  });
  route('DELETE', '/api/mkt/lists/:id', ({ p }) => { M.run('UPDATE mkt_lists SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

  // ---- WhatsApp message templates ----
  route('GET', '/api/mkt/templates', () => M.all('SELECT * FROM message_templates WHERE active = 1 ORDER BY sort, id'));
  const tpl = b => {
    const name = clean(b.name), body = String(b.body ?? '').replace(/\r\n/g, '\n').trim();
    if (!name) throw new M.MktError('Enter a name for the message.');
    if (!body) throw new M.MktError('Enter the message text.');
    return { name, body };
  };
  route('POST', '/api/mkt/templates', ({ body }) => {
    const t = tpl(body), sort = (M.get('SELECT MAX(sort) m FROM message_templates').m ?? -1) + 1;
    return { id: Number(M.run('INSERT INTO message_templates(name, body, sort) VALUES(?, ?, ?)', t.name, t.body, sort).lastInsertRowid) };
  });
  route('PUT', '/api/mkt/templates/:id', ({ p, body }) => {
    const t = tpl(body);
    if (!M.run('UPDATE message_templates SET name = ?, body = ? WHERE id = ?', t.name, t.body, p.id).changes) throw new M.MktError('Not found.');
    return { id: Number(p.id) };
  });
  route('DELETE', '/api/mkt/templates/:id', ({ p }) => { M.run('UPDATE message_templates SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });
};
module.exports.LIST_KEYS = LIST_KEYS;
module.exports.settings = settings;
