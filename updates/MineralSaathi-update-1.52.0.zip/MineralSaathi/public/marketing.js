'use strict';
/* Mineral Saathi — Marketing (Sampark Saathi) screens.
   Marketing data lives in its own file (marketing.db); items, companies, printers and the other settings
   are the shared Mineral Saathi ones. Uses the helpers of app.js ($, GET, POST, PAGES, SETTINGS …). */

const MKT_LISTS = [
  ['sample_size', 'Sample size', '100 gm, 500 gm, 1 kg …'],
  ['courier', 'Courier / sent by', 'India Post, DHL, Blue Dart …'],
  ['response', 'Call response', 'Called, no response, not reachable …'],
  ['followup_reason', 'Follow-up reason', 'Why the next call is made'],
  ['templates', 'WhatsApp messages', 'Ready texts for the Communication screen']
];
const MKT_PAGES = {
  calls: ["Today's Calls", 4, 'Calls due today (or any date), overdue calls in red; click a call to open Communication.'],
  new: ['New Sample Dispatch', 2, 'Customer, dispatch and its samples.'],
  leads: ['Enquiries', 2, 'All enquiries with search by ref. no., company, name, mobile and city, with their samples and calls.'],
  comm: ['Communication', 4, 'History, WhatsApp messages with QR, log the response and plan the next call (Google Calendar).'],
  quick: ['Quick Sticker', 4, 'A 4×6 QR sticker for a walk-in or phone enquiry.'],
  letters: ['Letters', 4, 'Letter Pad, Bus and blank envelope with the sender from Settings → Companies.'],
  reports: ['Marketing Reports', 5, 'Samples by month, grade and courier; pending and overdue calls; enquiries that became buyers.'],
  lists: ['Marketing Lists', 1, '']
};
const TPL_FIELDS = ['{name}', '{company}', '{ref}', '{courier}', '{tracking_no}', '{tracking_link}'];

// show or hide the 📣 Marketing menu (Settings → Marketing)
async function mktMenu() {
  try { const s = await GET('/api/mkt/status'); $('#nav-mkt').hidden = !s.settings.enabled; return s; } catch { return null; }
}
mktMenu();

PAGES.mkt = async (el, arg) => {
  const [page, sub] = String(arg || 'calls').split(':');
  const def = MKT_PAGES[page] || MKT_PAGES.calls;
  $('#title').textContent = def[0];
  const st = await GET('/api/mkt/status');
  if (!st.ok) {
    el.innerHTML = `<div class="card" style="max-width:720px"><h3>⚠ Marketing data cannot be opened</h3>
      <p style="white-space:pre-line">${esc(st.problem || '')}</p><p class="hint">File: ${esc(st.file)}</p></div>`;
    return;
  }
  if (page === 'lists') return mktListsPage(el, sub || 'sample_size');
  if (page === 'new') return mktSampleForm(el, sub || '');
  if (page === 'leads') return sub ? mktLeadPage(el, Number(sub)) : mktLeadsList(el);
  el.innerHTML = `<div class="card" style="max-width:720px"><h3>${esc(def[0])}</h3><p>${esc(def[2])}</p>
    <p><span class="badge amber">Coming in phase ${def[1]}</span></p>
    <p class="hint">Marketing data so far: ${st.counts.leads} enquiries · ${st.counts.samples} samples · ${st.counts.follow_ups_pending} calls pending.</p></div>`;
};

// ---------- Marketing Lists ----------
async function mktListsPage(box, key) {
  if (!MKT_LISTS.some(x => x[0] === key)) key = 'sample_size';
  if (key === 'templates') return mktTemplatesPage(box);
  const lists = await GET('/api/mkt/lists');
  const tpls = await GET('/api/mkt/templates');
  const def = MKT_LISTS.find(x => x[0] === key);
  const rows = lists[key] || [];
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide(key, lists, tpls)}
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="mlf" class="row" style="margin-bottom:14px">
        <label style="flex:1">New value<input name="value" autocomplete="off"></label>
        <button type="submit" id="mlsave">Add</button><button type="button" class="sec" id="mlcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>Value</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="2" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table>
      <p class="hint" style="margin-top:12px">Grade, mesh, colour, bag type, bag weight, packing type and unit are not kept here — Marketing uses
        <a href="#/itemlists">Master → Item List</a>, the same lists as billing.</p></div></div>`;
  const f = $('#mlf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault();
    await guard(() => editing ? PUT('/api/mkt/lists/' + editing, { value: f.value.value }) : POST('/api/mkt/lists', { list_key: key, value: f.value.value }));
    toast(editing ? 'Updated' : 'Added'); mktListsPage(box, key);
  };
  $('#mlcancel', box).onclick = () => mktListsPage(box, key);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value;
      $('#mlsave', box).textContent = 'Update'; $('#mlcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Samples and calls that already use it keep it.')) { await guard(() => DEL('/api/mkt/lists/' + rm.dataset.rm)); mktListsPage(box, key); }
  };
}

function mktListSide(key, lists, tpls) {
  return `<div class="card listside" style="padding:8px">${MKT_LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/mkt/lists:${k}')">
    <b>${t}</b><span class="badge grey">${k === 'templates' ? tpls.length : (lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>`;
}

// ---------- WhatsApp message templates ----------
function mktFill(body) {   // example of a filled message
  const ex = { '{name}': 'RAMESH KUMAR', '{company}': 'ABC MINERALS', '{ref}': '434', '{courier}': 'DHL', '{tracking_no}': 'RR123456789IN',
    '{tracking_link}': 'https://t.17track.net/en#nums=RR123456789IN' };
  return TPL_FIELDS.reduce((s, k) => s.split(k).join(ex[k]), body);
}
async function mktTemplatesPage(box) {
  const [lists, tpls] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/templates')]);
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide('templates', lists, tpls)}
    <div class="card"><h3>WhatsApp messages <span class="hint">— ready texts for the Communication screen</span></h3>
      <form id="mtf" class="grid" style="grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <label>Name<input name="name" autocomplete="off"></label>
        <div class="hint" style="align-self:end">Words filled in by themselves: ${TPL_FIELDS.map(x => `<code data-ins="${x}" style="cursor:pointer" title="Click to add">${x}</code>`).join(' ')}</div>
        <label style="grid-column:1/3">Message<textarea name="body" rows="5"></textarea></label>
        <div style="grid-column:1/3" class="row"><button type="submit" id="mtsave">Add</button><button type="button" class="sec" id="mtcancel" hidden>Cancel</button></div>
        <div style="grid-column:1/3" id="mtprev" class="hint" hidden></div>
      </form>
      <table class="t"><thead><tr><th style="width:190px">Name</th><th>Message</th><th style="width:150px"></th></tr></thead><tbody>
      ${tpls.map(t => `<tr><td><b>${esc(t.name)}</b></td><td style="white-space:pre-line">${esc(t.body)}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${t.id}">Edit</button> <button class="small sec" data-rm="${t.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="3" class="muted">No messages yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#mtf', box); let editing = null;
  const prev = () => { const p = $('#mtprev', box); p.hidden = !f.body.value.trim(); p.innerHTML = '<b>Example:</b><br>' + esc(mktFill(f.body.value)).replace(/\n/g, '<br>'); };
  f.body.oninput = prev;
  f.onsubmit = async e => {
    e.preventDefault(); const d = { name: f.name.value, body: f.body.value };
    await guard(() => editing ? PUT('/api/mkt/templates/' + editing, d) : POST('/api/mkt/templates', d));
    toast(editing ? 'Updated' : 'Added'); mktTemplatesPage(box);
  };
  $('#mtcancel', box).onclick = () => mktTemplatesPage(box);
  box.onclick = async e => {
    const ins = e.target.closest('[data-ins]'), ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ins) { const t = f.body, a = t.selectionStart ?? t.value.length; t.value = t.value.slice(0, a) + ins.dataset.ins + t.value.slice(t.selectionEnd ?? a); t.focus(); prev(); }
    if (ed) { const t = tpls.find(x => x.id === Number(ed.dataset.ed)); editing = t.id; f.name.value = t.name; f.body.value = t.body; prev();
      $('#mtsave', box).textContent = 'Update'; $('#mtcancel', box).hidden = false; f.name.focus(); }
    if (rm && confirm('Remove this message?')) { await guard(() => DEL('/api/mkt/templates/' + rm.dataset.rm)); mktTemplatesPage(box); }
  };
}

// ---------- Settings → Marketing ----------
SETTINGS.marketing = async box => {
  const [s, st] = await Promise.all([GET('/api/mkt/settings'), GET('/api/mkt/status')]);
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  box.innerHTML = `<div class="grid g2" style="align-items:start">
    <div class="card"><h3>📣 Marketing</h3>
      <form id="mkf" class="grid" style="gap:12px">
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="enabled" style="width:auto" ${s.enabled ? 'checked' : ''}> Show the Marketing menu</label>
        ${field({ name: 'default_firm', label: 'Sender on Marketing papers (Settings → Companies)', type: 'select', options: s.firms.map(x => [x.code, x.name]) }, s.default_firm)}
        ${field({ name: 'followup_days', label: 'Days until the first “Did the sample arrive?” call', type: 'number' }, s.followup_days)}
        ${field({ name: 'tracking_url', label: 'Tracking link — {tracking_no} is replaced by the number' }, s.tracking_url)}
        ${field({ name: 'next_ref', label: 'First Ref No. for new enquiries (your Excel ended at 433)', type: 'number' }, s.next_ref)}
        <h4 style="margin:6px 0 0">On the printed papers</h4>
        ${field({ name: 'signer', label: 'Name under “Thank you” and as sender on postal forms' }, s.signer)}
        ${field({ name: 'sender_digipin', label: 'Sender Digipin (postal forms)' }, s.sender_digipin)}
        ${field({ name: 'delivery_time', label: 'Delivery time (sample sticker, cover letter)' }, s.delivery_time)}
        ${field({ name: 'min_order_kg', label: 'Minimum order when the rate is per KG' }, s.min_order_kg)}
        ${field({ name: 'min_order_mt', label: 'Minimum order when the rate is per MT' }, s.min_order_mt)}
        ${field({ name: 'gst_note', label: 'Under the rate (e.g. PLUS 5% GST + FREIGHT)' }, s.gst_note)}
        ${field({ name: 'payment_terms', label: 'Payment terms (cover letter)' }, s.payment_terms)}
        <div class="row"><button type="submit">Save</button></div>
      </form>
      <p class="hint">The Google Calendar link is in <a href="#/settings/data">Settings → Data Location</a>.</p>
      <p class="hint">These are settings, saved with the other Mineral Saathi settings. Companies, printers, backup and data location are the same for billing and Marketing.</p></div>
    <div class="card"><h3>Marketing data</h3>
      ${st.ok ? `<p><span class="badge PM">Open</span> &nbsp;${esc(st.file)} · ${kb(st.size)}</p>
        <table class="t"><tbody>
          <tr><td>Enquiries</td><td class="num">${st.counts.leads}</td></tr>
          <tr><td>Samples</td><td class="num">${st.counts.samples}</td></tr>
          <tr><td>Calls pending</td><td class="num">${st.counts.follow_ups_pending}</td></tr>
          <tr><td>Calls and messages logged</td><td class="num">${st.counts.communications}</td></tr>
          <tr><td>Quick stickers</td><td class="num">${st.counts.quick_stickers}</td></tr></tbody></table>`
        : `<p><span class="badge red">Cannot open</span></p><p style="white-space:pre-line">${esc(st.problem || '')}</p>`}
      <p class="hint" style="margin-top:10px">Kept in its own file next to mineral.db — never mixed with billing data. It is in every backup
        (Marketing_yyyy-mm-dd.db) and moves with the data when the data location changes.</p></div></div>`;
  $('#mkf', box).onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    await guard(() => PUT('/api/mkt/settings', { enabled: f.enabled.checked, default_firm: f.default_firm.value, followup_days: f.followup_days.value,
      tracking_url: f.tracking_url.value, next_ref: f.next_ref.value,
      ...Object.fromEntries(['signer', 'sender_digipin', 'delivery_time', 'min_order_kg', 'min_order_mt', 'gst_note', 'payment_terms'].map(k => [k, f[k].value])) }));
    toast('Saved'); await mktMenu();
  };
};

// ---------- Settings → Data Location: Google Calendar link (Marketing follow-up calls) ----------
{
  const dataPage = SETTINGS.data;
  SETTINGS.data = async box => {
    await dataPage(box);
    const s = await GET('/api/mkt/settings');
    const card = document.createElement('div'); card.className = 'card';
    card.innerHTML = `<h3>📅 Google Calendar <span class="hint">— Marketing follow-up calls</span></h3>
      <p class="hint">The Apps Script web-app link (ends with <code>/exec</code>). Every planned call is sent to Google Calendar with the customer's phone and WhatsApp link.</p>
      <div class="row"><label style="flex:1">Calendar link<input id="calurl" value="${esc(s.calendar_url)}" placeholder="https://script.google.com/macros/s/…/exec" autocomplete="off"></label>
        <button id="calsave">Save</button><button class="sec" id="caltest">Test connection</button></div>
      <p class="hint" style="margin-top:8px">Test connection creates one event 10 minutes from now named “Mineral Saathi — test connection”; delete it afterwards.</p>
      <div id="calres" style="margin-top:8px" hidden></div>`;
    box.appendChild(card);
    const inp = $('#calurl', card), res = $('#calres', card);
    const show = (ok, msg, reply) => { res.hidden = false;
      res.innerHTML = `<span class="badge ${ok ? 'PM' : 'red'}">${ok ? '✓ Connected' : '✕ Not connected'}</span> ${esc(msg)}${reply ? `<br><span class="hint">Google replied: ${esc(reply)}</span>` : ''}`; };
    $('#calsave', card).onclick = async () => { await guard(() => PUT('/api/mkt/settings', { calendar_url: inp.value })); toast(inp.value.trim() ? 'Calendar link saved' : 'Calendar link removed'); };
    $('#caltest', card).onclick = async () => {
      const b = $('#caltest', card); b.disabled = true; b.textContent = 'Testing…'; res.hidden = true;
      try { const r = await guard(() => POST('/api/mkt/calendar/test', { url: inp.value })); show(r.ok, r.message, r.reply); }
      catch { /* message shown */ } finally { b.disabled = false; b.textContent = 'Test connection'; }
    };
  };
}

// =====================================================================
// Phase 2 — enquiries and samples
// =====================================================================
// =====================================================================
// Enquiries and dispatches — a dispatch holds one or more samples, like an invoice holds items
// =====================================================================
const MKT_UPPER = 'style="text-transform:uppercase"';
const mktOpts = (vals, blank = true) => [...(blank ? [''] : []), ...vals];
const mktDue = d => { if (!d) return '<span class="muted">—</span>'; const t = today();
  return d < t ? `<span class="badge red">${dmy(d)} · late</span>` : d === t ? `<span class="badge amber">${dmy(d)} · today</span>` : dmy(d); };
const mktTrack = (url, no) => no ? (url ? `<a href="${esc(url.split('{tracking_no}').join(encodeURIComponent(no)))}" target="_blank" rel="noopener">${esc(no)}</a>` : esc(no)) : '';
const mktName = l => esc(l.company || l.buyer_name || '');
const LEAD_KEYS = ['gst', 'name', 'buyer_name', 'email', 'mobile1', 'mobile2', 'address', 'pincode', 'city', 'state', 'digipin', 'note'];
const LINE_KEYS = ['item_name', 'colour', 'mesh', 'form', 'grade', 'sample_size', 'rate', 'unit', 'bag_type', 'packing_type', 'liner', 'bag_weight', 'note'];

// the enquiry fields: GSTIN first, with "Get details from GST" (the company box is called "name" so the GST helper fills it)
function mktLeadFields(l = {}) {
  return `<div class="grid g2" style="gap:10px">
    <label class="span2">GSTIN <span class="hint">— first, to fill the rest from the GST portal</span><input name="gst" value="${esc(l.gst)}" ${MKT_UPPER} autocomplete="off" maxlength="15"></label>
    <label class="span2">Company<input name="name" value="${esc(l.company)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Buyer name<input name="buyer_name" value="${esc(l.buyer_name)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Email<input name="email" type="email" value="${esc(l.email)}" autocomplete="off"></label>
    <label>Mobile<input name="mobile1" value="${esc(l.mobile1)}" inputmode="numeric" autocomplete="off" placeholder="10 digits"></label>
    <label>Mobile 2<input name="mobile2" value="${esc(l.mobile2)}" inputmode="numeric" autocomplete="off"></label>
    <label class="span2">Address<textarea name="address" rows="2">${esc(l.address)}</textarea></label>
    <label>Pincode <span class="hint">(fills city &amp; state)</span><input name="pincode" value="${esc(l.pincode)}" inputmode="numeric" autocomplete="off"></label>
    <label>City<input name="city" value="${esc(l.city)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>State<select name="state">${STATES().map(x => `<option ${x === (l.state || '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}${l.state && !STATES().includes(l.state) ? `<option selected>${esc(l.state)}</option>` : ''}</select></label>
    <label>Digipin<input name="digipin" value="${esc(l.digipin)}" ${MKT_UPPER} autocomplete="off"></label>
    <label class="span2">Note<input name="note" value="${esc(l.note)}" autocomplete="off"></label>
  </div><div class="hint" data-buyerhint style="margin-top:8px"></div>`;
}
// digits only, pincode → city & state, GST portal, "Also a buyer" (read-only look into billing buyers)
function mktWireLead(root) {
  const f = n => $(`[name=${n}]`, root);
  for (const n of ['mobile1', 'mobile2', 'pincode']) f(n).addEventListener('input', e => { const v = e.target.value.replace(/\D/g, ''); if (v !== e.target.value) e.target.value = v; });
  for (const n of ['mobile1', 'mobile2']) f(n).addEventListener('blur', e => { const v = e.target.value; if (v.length > 10 && v.startsWith('91')) e.target.value = v.slice(-10); });
  const pin = async () => {
    if (f('pincode').value.length !== 6) return;
    const r = await GET('/api/pincode/' + f('pincode').value).catch(() => null);
    if (!r || !r.found) return;
    if (!f('city').value) f('city').value = (r.city || r.district || '').toUpperCase();
    const st = f('state'), v = String(r.state || '').toUpperCase();
    if (v && ![...st.options].some(o => o.value === v)) st.add(new Option(v, v));
    if (v) st.value = v;
  };
  f('pincode').addEventListener('input', () => { f('city').value = ''; pin(); });
  gstFetchBox(f('gst'), root);
  const hint = $('[data-buyerhint]', root);
  const check = async () => {
    const m = f('mobile1').value, g = f('gst').value;
    if (m.length !== 10 && g.length !== 15) { hint.innerHTML = ''; return; }
    const r = await GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(m)}&gst=${encodeURIComponent(g)}`).catch(() => []);
    hint.innerHTML = r.length ? '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ') + ' <span class="muted">(billing data is not changed)</span>' : '';
  };
  f('mobile1').addEventListener('blur', check); f('gst').addEventListener('blur', check);
  check();
  return { check };
}
const mktLeadData = form => { const o = {}; for (const k of LEAD_KEYS) o[k] = form.elements[k] ? form.elements[k].value : ''; o.company = o.name; delete o.name; return o; };

// ---------- New Sample Dispatch (also: edit a saved dispatch) ----------
// arg: ''  new · 'L12' new dispatch for enquiry 12 · 'D5' edit dispatch 5
async function mktSampleForm(el, arg) {
  await loadLists(true);
  const [ml, ms] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/settings')]);
  const editId = /^D\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let leadId = /^L\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let lead = {}, disp = { date: today(), firm_code: ms.default_firm }, lines = [{}], lastDisp = null;
  if (editId) { const r = await GET('/api/mkt/dispatches/' + editId); disp = r.dispatch; lines = r.lines; lead = r.lead; leadId = lead.id; }
  else if (leadId) { const r = await GET('/api/mkt/leads/' + leadId); lead = r.lead; lastDisp = r.dispatches[0] || null; }
  const nextRef = editId || leadId ? null : (await GET('/api/mkt/next-ref')).ref_no;
  $('#title').textContent = editId ? `Edit dispatch · Ref ${lead.ref_no}` : 'New Sample Dispatch';
  const defUnit = lv('unit').includes('KG') ? 'KG' : '';

  const sel = (name, label, vals, v, extra = '') => `<label ${extra}>${label}<select name="${name}">${[...new Set([...vals, ...(v != null && v !== '' ? [String(v)] : [])])]
    .map(x => `<option value="${esc(x)}" ${String(x) === String(v ?? '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>`;
  const ms1 = k => (ml[k] || []).map(x => x.value);
  const lineHtml = (ln, i) => `<div class="mline" data-line style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:10px">
    <div class="row" style="justify-content:space-between;margin-bottom:6px"><b data-lno>Sample ${i + 1}</b>
      <span><button type="button" class="small sec" data-ldup title="Copy this sample into a new one">⧉ Duplicate</button> <button type="button" class="small sec" data-ldel>✕ Remove</button></span></div>
    <div class="grid g6" style="gap:8px">
      ${sel('item_name', 'Item', mktOpts(lv('product')), ln.item_name, 'class="span2"')}
      ${sel('colour', 'Colour', mktOpts(lv('colour')), ln.colour)}${sel('mesh', 'Mesh', mktOpts(lv('mesh')), ln.mesh)}${sel('form', 'Form', mktOpts(lv('form')), ln.form)}
      <label>Grade <span class="hint">(fills itself)</span><input name="grade" value="${esc(ln.grade)}" ${MKT_UPPER} autocomplete="off" data-auto="${ln.grade ? 0 : 1}"></label>
      ${sel('sample_size', 'Sample size', mktOpts(ms1('sample_size')), ln.sample_size)}
      <label>Rate ₹<input name="rate" type="number" step="0.01" value="${esc(ln.rate)}"></label>
      ${sel('unit', 'Per', mktOpts(lv('unit')), ln.unit ?? defUnit)}
      ${sel('bag_type', 'Bag type', mktOpts(lv('bag_type')), ln.bag_type)}
      ${sel('packing_type', 'Packing type', mktOpts(lv('packing_type')), ln.packing_type)}
      <label>Liner<select name="liner"><option value=""></option><option value="1" ${ln.liner === 1 || ln.liner === '1' ? 'selected' : ''}>With liner</option><option value="0" ${ln.liner === 0 || ln.liner === '0' ? 'selected' : ''}>Without liner</option></select></label>
      ${sel('bag_weight', 'Bag weight (kg)', mktOpts(lv('bag_weight')), ln.bag_weight)}
      <label style="grid-column:span 5">Note on this sample<input name="note" value="${esc(ln.note)}" autocomplete="off"></label>
    </div></div>`;

  el.innerHTML = `
  ${editId ? '' : `<div class="card" style="position:relative">
    <div class="row" style="align-items:end">
      <label style="flex:1">Find enquiry <span class="hint">— Ref No., mobile, company or name</span><input id="mfind" autocomplete="off" placeholder="Type to search…"></label>
      <div id="mstate" style="padding-bottom:9px"></div></div>
    <div id="mres" class="card" style="position:absolute;left:16px;right:16px;z-index:5;max-height:320px;overflow:auto;padding:4px" hidden></div>
  </div>`}
  <form id="msf" autocomplete="off">
  <div class="grid" style="grid-template-columns:minmax(380px,1fr) minmax(380px,1fr);align-items:start">
    <div class="card" id="mlead"><h3>Customer <span id="mref" class="hint"></span></h3>${mktLeadFields(lead)}</div>
    <div class="card" id="mdisp"><h3>Dispatch</h3>
      <div class="grid g2" style="gap:10px">
        <label>Date<input name="d_date" type="date" value="${esc(disp.date)}"></label>
        <label>Sender<select name="d_firm_code">${(ms.firms.length ? ms.firms : [{ code: disp.firm_code || 'PM', name: disp.firm_code || 'PM' }])
          .map(x => `<option value="${esc(x.code)}" ${x.code === disp.firm_code ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
        ${sel('d_courier', 'Sent by', mktOpts(ms1('courier')), disp.courier)}
        <label>Tracking no.<input name="d_tracking_no" value="${esc(disp.tracking_no)}" ${MKT_UPPER} autocomplete="off"></label>
        <label>No. of parcels / bags <span class="hint">(a bag sticker each)</span><input name="d_parcels" type="number" step="1" min="0" value="${esc(disp.parcels)}"></label>
        <label>Total weight (kg)<input name="d_total_weight" type="number" step="0.001" min="0" value="${esc(disp.total_weight)}"></label>
        <label style="display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:9px"><input type="checkbox" name="d_freight_to_pay" style="width:auto" ${disp.freight_to_pay ? 'checked' : ''}> Freight to pay</label>
        <label>Delivered on<input name="d_delivered_on" type="date" value="${esc(disp.delivered_on)}"></label>
        <label class="span2">Note on dispatch<input name="d_note" value="${esc(disp.note)}" autocomplete="off"></label>
      </div>
      <p class="hint" style="margin:10px 0 0">After saving, the print window opens: one <b>sample sticker for each sample</b> and <b>one cover letter</b> for the whole dispatch are ticked.</p></div>
  </div>
  <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px">
      <h3 style="margin:0">Samples in this dispatch <span class="badge grey" id="mcount"></span> <span class="hint">— item details from <a href="#/itemlists">Master → Item List</a></span></h3>
      <span id="mlast"></span></div>
    <div id="mlines">${lines.map(lineHtml).join('')}</div>
    <button type="button" class="sec" id="maddline">+ Add sample</button></div>
  <div class="card row" style="justify-content:space-between">
    <div class="row"><button type="submit">${editId ? 'Save changes' : 'Save dispatch'}</button>
      ${editId ? '' : '<button type="button" class="sec" id="monly">Save customer only</button>'}
      <button type="button" class="sec" id="mcancel">Cancel</button></div>
    <span class="hint">${editId ? '' : `Saving plans the first call “Did the sample arrive?” ${ms.followup_days} days after the dispatch date.`}</span>
  </div></form>`;

  const form = $('#msf', el), f = n => form.elements[n], linesBox = $('#mlines', el);
  markDirty(form); const lw = mktWireLead($('#mlead', el));

  // each sample line: grade fills itself from colour + mesh (same rule as Buyers → items), e.g. YELLOW + 300 → Y300 MESH
  const renumber = () => { const ls = $$('[data-line]', linesBox); ls.forEach((x, i) => { $('[data-lno]', x).textContent = `Sample ${i + 1}`; $('[data-ldel]', x).hidden = ls.length === 1; });
    $('#mcount', el).textContent = `${ls.length} sample${ls.length === 1 ? '' : 's'} · ${ls.length} sticker${ls.length === 1 ? '' : 's'}`; };
  linesBox.addEventListener('change', e => {
    const box = e.target.closest('[data-line]'); if (!box || !['colour', 'mesh', 'form'].includes(e.target.name)) return;
    const g = $('[name=grade]', box); if (g.dataset.auto !== '1') return;
    const form_ = $('[name=form]', box).value, mesh = $('[name=mesh]', box).value, col = $('[name=colour]', box).value;
    g.value = mesh && (!form_ || form_ === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form_ || '');
  });
  linesBox.addEventListener('input', e => { if (e.target.name === 'grade') e.target.dataset.auto = e.target.value ? '0' : '1'; });
  const lineVals = box => { const o = {}; for (const k of LINE_KEYS) o[k] = $(`[name=${k}]`, box).value; return o; };
  const addLine = (ln = {}) => { linesBox.insertAdjacentHTML('beforeend', lineHtml(ln, 0)); renumber(); S.dirty = true; return linesBox.lastElementChild; };
  linesBox.addEventListener('click', e => {
    const box = e.target.closest('[data-line]'); if (!box) return;
    if (e.target.closest('[data-ldel]') && $$('[data-line]', linesBox).length > 1) { box.remove(); renumber(); S.dirty = true; }
    if (e.target.closest('[data-ldup]')) { const v = lineVals(box); const nb = addLine(v); $('[name=grade]', nb).dataset.auto = '0'; $('[name=sample_size]', nb).focus(); }
  });
  $('#maddline', el).onclick = () => { const nb = addLine({ unit: defUnit }); $('[name=item_name]', nb).focus(); };
  renumber();

  const setLead = (l, last) => {
    leadId = l ? l.id : null; lead = l || {};
    const box = $('#mlead', el);
    for (const k of LEAD_KEYS) { const e = box.querySelector(`[name=${k}]`); if (!e) continue; const v = (k === 'name' ? lead.company : lead[k]) ?? '';
      if (e.tagName === 'SELECT' && v && ![...e.options].some(o => o.value === v)) e.add(new Option(v, v)); e.value = v; }
    $('#mref', el).innerHTML = leadId ? `· <b>Ref ${lead.ref_no}</b> — existing enquiry` : `· new, will be <b>Ref ${nextRef}</b>`;
    const st = $('#mstate', el); if (st) st.innerHTML = leadId ? `<button type="button" class="small sec" id="mnewlead">Start a new customer instead</button>` : '';
    const nb = $('#mnewlead', el); if (nb) nb.onclick = () => setLead(null, null);
    lastDisp = last || null;
    $('#mlast', el).innerHTML = lastDisp ? `<span class="hint">Last dispatch ${dmy(lastDisp.date)}: ${esc(lastDisp.lines.map(x => [x.grade || x.item_name, x.sample_size].filter(Boolean).join(' ')).join(', '))}</span>
      <button type="button" class="small sec" id="mcopy">Copy last dispatch</button>` : '';
    const cp = $('#mcopy', el); if (cp) cp.onclick = () => {
      linesBox.innerHTML = lastDisp.lines.map(lineHtml).join(''); $$('[name=grade]', linesBox).forEach(g => g.dataset.auto = '0'); renumber();
      f('d_courier').value = lastDisp.courier || ''; f('d_firm_code').value = lastDisp.firm_code || f('d_firm_code').value;
      S.dirty = true; toast(`Copied ${lastDisp.lines.length} sample${lastDisp.lines.length === 1 ? '' : 's'} — check the date and tracking no.`); };
    $('[data-buyerhint]', el).innerHTML = ''; lw.check();
  };
  if (!editId) setLead(leadId ? lead : null, lastDisp); else $('#mref', el).innerHTML = `· <b>Ref ${lead.ref_no}</b>`;
  S.dirty = false;
  f('gst').focus();

  // find an enquiry
  const fi = $('#mfind', el), res = $('#mres', el); let ft;
  if (fi) {
    fi.oninput = () => { clearTimeout(ft); ft = setTimeout(async () => {
      const q = fi.value.trim(); if (!q) { res.hidden = true; return; }
      const rows = await GET('/api/mkt/find?q=' + encodeURIComponent(q)).catch(() => []);
      res.hidden = false;
      res.innerHTML = rows.length ? rows.map(r => `<a class="listhead" data-lid="${r.id}"><b>Ref ${r.ref_no}</b> · ${mktName(r)}${r.company && r.buyer_name ? ` <span class="hint">${esc(r.buyer_name)}</span>` : ''}
        <span class="hint" style="float:right">${esc([r.city, r.state].filter(Boolean).join(', '))} · ${esc(r.mobile1 || '')}</span></a>`).join('')
        : '<div class="muted" style="padding:8px">No enquiry found — fill in the customer below for a new one.</div>';
    }, 220); };
    fi.onkeydown = e => { if (e.key === 'Escape') res.hidden = true; };
    res.onclick = async e => { const a = e.target.closest('[data-lid]'); if (!a) return;
      const r = await guard(() => GET('/api/mkt/leads/' + a.dataset.lid)); res.hidden = true; fi.value = '';
      setLead(r.lead, r.dispatches[0]); S.dirty = false; };
    document.addEventListener('click', e => { if (!e.target.closest('#mres') && e.target !== fi) res.hidden = true; });
  }

  const dispData = () => { const o = {}; for (const k of ['date', 'firm_code', 'courier', 'tracking_no', 'parcels', 'total_weight', 'delivered_on', 'note']) o[k] = f('d_' + k).value;
    o.freight_to_pay = f('d_freight_to_pay').checked ? 1 : 0; return o; };
  const linesData = () => $$('[data-line]', linesBox).map(lineVals);
  // the server refuses a second customer with the same mobile; the user may still choose to keep both
  const send = async fn => { try { return await fn(false); } catch (e) {
    if (/is already Ref \d+/.test(e.message) && !leadId && confirm(e.message + '\n\nSave it as a separate customer anyway?')) return guard(() => fn(true));
    toast(e.message, true); return null; } };

  form.onsubmit = async e => {
    e.preventDefault();
    const body = dup => ({ lead_id: leadId, lead: mktLeadData($('#mlead', el).closest('form')), dispatch: dispData(), lines: linesData(), allow_duplicate: dup });
    if (editId) {
      const r = await send(dup => PUT('/api/mkt/dispatches/' + editId, body(dup))); if (!r) return;
      S.dirty = false; toast('Dispatch changed'); go('#/mkt/leads:' + r.lead_id); return;
    }
    const r = await send(dup => POST('/api/mkt/dispatches', body(dup))); if (!r) return;
    S.dirty = false; S.mktPrint = r.dispatch_id; toast(`Dispatch saved · Ref ${r.ref_no} · ${r.samples} sample${r.samples === 1 ? '' : 's'} · first call ${dmy(r.follow_up.due_date)}`); go('#/mkt/leads:' + r.lead_id);
  };
  const only = $('#monly', el); if (only) only.onclick = async () => {
    const ld = mktLeadData(form);
    const r = await send(dup => leadId ? PUT('/api/mkt/leads/' + leadId, { lead: ld, allow_duplicate: dup }) : POST('/api/mkt/leads', { lead: ld, allow_duplicate: dup })); if (!r) return;
    S.dirty = false; toast(leadId ? 'Customer saved' : `Customer saved · Ref ${r.ref_no}`); go('#/mkt/leads:' + r.id);
  };
  $('#mcancel', el).onclick = () => { if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return; S.dirty = false; history.length > 1 ? history.back() : go('#/mkt/leads'); };
}

// ---------- Enquiries list ----------
async function mktLeadsList(el) {
  el.innerHTML = `<div class="card"><div class="row" style="justify-content:space-between">
      <div class="row"><input id="lq" placeholder="Search: Ref No., company, name, mobile, city or state" style="width:420px" autocomplete="off"><span class="hint" id="lcount"></span></div>
      <div class="row"><button class="sec" id="lcsv">Export CSV</button><button id="lnew">+ New sample dispatch</button></div></div>
    <div class="tablewrap" style="margin-top:10px"><table class="t"><thead><tr><th>Ref</th><th>Company / buyer</th><th>City, state</th><th>Mobile</th><th class="num">Samples</th><th>Last dispatch</th><th>Next call</th></tr></thead>
    <tbody id="lbody"><tr><td colspan="7" class="muted">Loading…</td></tr></tbody></table></div></div>`;
  let rows = [], t;
  const load = async () => {
    const q = $('#lq', el).value.trim();
    rows = await GET('/api/mkt/leads?limit=1000&q=' + encodeURIComponent(q));
    $('#lcount', el).textContent = `${rows.length}${rows.length === 1000 ? '+' : ''} enquir${rows.length === 1 ? 'y' : 'ies'}`;
    $('#lbody', el).innerHTML = rows.map(r => `<tr class="click" data-lid="${r.id}"><td><b>${r.ref_no}</b></td>
      <td><b>${mktName(r)}</b>${r.company && r.buyer_name ? `<br><span class="hint">${esc(r.buyer_name)}</span>` : ''}${r.became_buyer_id ? ' <span class="badge PM">buyer</span>' : ''}</td>
      <td>${esc([r.city, r.state].filter(Boolean).join(', '))}</td><td>${esc(r.mobile1 || '')}</td><td class="num">${r.samples || ''}</td>
      <td>${r.last_sample ? esc(dmy(r.last_sample.slice(0, 10)) + r.last_sample.slice(10)) : '<span class="muted">—</span>'}</td><td>${mktDue(r.next_call)}</td></tr>`).join('')
      || `<tr><td colspan="7" class="muted">${q ? 'Nothing found.' : 'No enquiries yet. Press “+ New sample dispatch” to add the first one.'}</td></tr>`;
  };
  $('#lq', el).oninput = () => { clearTimeout(t); t = setTimeout(load, 250); };
  $('#lq', el).focus();
  $('#lnew', el).onclick = () => go('#/mkt/new');
  $('#lcsv', el).onclick = () => downloadCsv('enquiries.csv', rows.map(r => ({ ref_no: r.ref_no, company: r.company, buyer: r.buyer_name, city: r.city, state: r.state, mobile: r.mobile1,
    samples: r.samples, last_dispatch: r.last_sample, next_call: r.next_call })));
  $('#lbody', el).onclick = e => { const tr = e.target.closest('[data-lid]'); if (tr) go('#/mkt/leads:' + tr.dataset.lid); };
  await load();
}

// ---------- one enquiry: details, dispatches with their samples, calls ----------
async function mktLeadPage(el, id) {
  const [d, ms] = await Promise.all([GET('/api/mkt/leads/' + id), GET('/api/mkt/settings')]);
  const l = d.lead, nS = d.dispatches.reduce((a, x) => a + x.lines.length, 0);
  $('#title').textContent = `Ref ${l.ref_no} · ${l.company || l.buyer_name || ''}`;
  const line = (k, v) => v ? `<tr><td class="hint" style="width:110px">${k}</td><td>${v}</td></tr>` : '';
  const firm = c => (ms.firms.find(x => x.code === c) || {}).name || c || '';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(320px,1fr) 2fr;align-items:start">
    <div class="card" id="ldet"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Customer · Ref ${l.ref_no}</h3>
        <span><button class="small sec" id="ledit">Edit</button>${d.dispatches.length || d.communications.length ? '' : ' <button class="small sec" id="ldel">Delete</button>'}</span></div>
      <table class="t" style="margin-top:8px"><tbody>
        ${line('GSTIN', esc(l.gst))}${line('Company', `<b>${esc(l.company || '')}</b>`)}${line('Buyer', esc(l.buyer_name))}
        ${line('Mobile', [l.mobile1, l.mobile2].filter(Boolean).map(m => `<a href="tel:${esc(m)}">${esc(m)}</a>`).join(', '))}
        ${line('Email', l.email ? `<a href="mailto:${esc(l.email)}">${esc(l.email)}</a>` : '')}
        ${line('Address', esc([l.address, [l.city, l.pincode].filter(Boolean).join(' - '), l.state].filter(Boolean).join('\n')).replace(/\n/g, '<br>'))}
        ${line('Digipin', esc(l.digipin))}${line('Note', esc(l.note))}
        ${line('Since', dmy(String(l.created_at || '').slice(0, 10)))}
      </tbody></table><div class="hint" data-buyerhint></div></div>
    <div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Dispatches · ${d.dispatches.length} <span class="hint">(${nS} sample${nS === 1 ? '' : 's'})</span></h3>
          <button id="lnewsample">+ New dispatch for this customer</button></div>
        ${d.dispatches.map(x => `<div style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-top:10px">
          <div class="row" style="justify-content:space-between"><div><b>${dmy(x.date)}</b> · ${esc(x.courier || '')} ${mktTrack(ms.tracking_url, x.tracking_no)}
            ${x.freight_to_pay ? '<span class="badge amber">to pay</span>' : ''} <span class="hint">${esc(firm(x.firm_code))}${x.parcels ? ` · ${x.parcels} parcel${x.parcels === 1 ? '' : 's'}` : ''}${x.total_weight ? ` · ${kg(x.total_weight)} kg` : ''}${x.delivered_on ? ` · delivered ${dmy(x.delivered_on)}` : ''}</span></div>
            <span style="white-space:nowrap"><button class="small" data-dprint="${x.id}">🖨 Print</button> <button class="small sec" data-ded="${x.id}">Edit</button> <button class="small sec" data-ddel="${x.id}">Delete</button></span></div>
          <table class="t" style="margin-top:6px"><thead><tr><th>#</th><th>Grade · item</th><th>Size</th><th class="num">Rate</th><th>Packing</th><th>Note</th></tr></thead><tbody>
          ${x.lines.map((s, i) => `<tr><td>${i + 1}</td><td><b>${esc(s.grade || '')}</b> <span class="hint">${esc(s.item_name || '')}</span></td><td>${esc(s.sample_size || '')}</td>
            <td class="num">${s.rate != null ? money(s.rate) + (s.unit ? ' / ' + esc(s.unit) : '') : ''}</td>
            <td>${esc([s.bag_type, s.packing_type, s.liner === 1 ? 'WITH LINER' : s.liner === 0 ? 'WITHOUT LINER' : '', s.bag_weight ? kg(s.bag_weight) + ' KG' : ''].filter(Boolean).join(' · '))}</td>
            <td>${esc(s.note || '')}</td></tr>`).join('')}</tbody></table>
          ${x.note ? `<p class="hint" style="margin:6px 0 0">${esc(x.note)}</p>` : ''}</div>`).join('') || '<p class="muted" style="margin-top:10px">No sample sent yet.</p>'}</div>
      <div class="card"><h3>Calls</h3>
        <table class="t"><thead><tr><th>Due</th><th>Reason</th><th>Status</th></tr></thead><tbody>
        ${d.follow_ups.map(x => `<tr><td>${x.status === 'PENDING' ? mktDue(x.due_date) : dmy(x.due_date)}</td><td>${esc(x.reason || '')}</td>
          <td>${x.status === 'PENDING' ? '<span class="badge amber">Pending</span>' : `<span class="badge grey">${esc(x.status)}</span>${x.done_on ? ' ' + dmy(x.done_on) : ''}`}</td></tr>`).join('')
          || '<tr><td colspan="3" class="muted">No calls planned.</td></tr>'}</tbody></table>
        ${d.communications.length ? `<h4 style="margin:14px 0 6px">History</h4><table class="t"><tbody>${d.communications.map(c => `<tr><td style="width:100px">${dmy(c.date)}</td>
          <td>${esc(c.channel || '')}</td><td>${esc([c.response, c.note].filter(Boolean).join(' — '))}</td></tr>`).join('')}</tbody></table>` : ''}
        <p class="hint" style="margin-top:8px">Logging calls, WhatsApp messages and planning the next call come with the Communication screen (phase 4).</p></div>
    </div></div>`;
  GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(l.mobile1 || '')}&gst=${encodeURIComponent(l.gst || '')}`).then(r => {
    if (r.length) $('[data-buyerhint]', el).innerHTML = '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ');
  }).catch(() => {});
  $('#lnewsample', el).onclick = () => go('#/mkt/new:L' + l.id);
  if (S.mktPrint && d.dispatches.some(x => x.id === S.mktPrint)) { const pid = S.mktPrint; S.mktPrint = null; mktPrintBox(pid, l); }
  $('#ledit', el).onclick = () => {
    const box = $('#ldet', el);
    box.innerHTML = `<h3>Edit customer · Ref ${l.ref_no}</h3><form id="lef" autocomplete="off">${mktLeadFields(l)}
      <div class="row" style="margin-top:10px"><button type="submit">Save</button><button type="button" class="sec" id="lecancel">Cancel</button></div></form>`;
    const fm = $('#lef', box); mktWireLead(fm); markDirty(fm);
    $('#lecancel', box).onclick = () => { S.dirty = false; mktLeadPage(el, id); };
    fm.onsubmit = async e => { e.preventDefault(); const o = mktLeadData(fm);
      try { await PUT('/api/mkt/leads/' + id, { lead: o }); }
      catch (err) { if (!(/is already Ref \d+/.test(err.message) && confirm(err.message + '\n\nKeep this number on both customers?'))) { toast(err.message, true); return; }
        await guard(() => PUT('/api/mkt/leads/' + id, { lead: o, allow_duplicate: true })); }
      S.dirty = false; toast('Customer saved'); mktLeadPage(el, id); };
  };
  const del = $('#ldel', el); if (del) del.onclick = async () => { if (!confirm(`Delete enquiry Ref ${l.ref_no}?`)) return; await guard(() => DEL('/api/mkt/leads/' + id)); toast('Enquiry deleted'); go('#/mkt/leads'); };
  el.onclick = async e => {
    const ed = e.target.closest('[data-ded]'), dl = e.target.closest('[data-ddel]'), pr = e.target.closest('[data-dprint]');
    if (pr) mktPrintBox(Number(pr.dataset.dprint), d.lead);
    if (ed) go('#/mkt/new:D' + ed.dataset.ded);
    if (dl && confirm('Delete this dispatch and all its samples? Its planned call is removed too.')) { await guard(() => DEL('/api/mkt/dispatches/' + dl.dataset.ddel)); toast('Dispatch deleted'); mktLeadPage(el, id); }
  };
}

// ---------- print the papers of a dispatch ----------
const MKT_KIND = { invoice: 'A4 printer', label: '4×6 label printer', envelope: 'Envelope printer' };
async function mktPrintBox(dispatchId, lead) {
  const [pd, last, drivers] = await Promise.all([GET('/api/mkt/print-docs'), GET(`/api/mkt/dispatches/${dispatchId}/freight`), GET('/api/m/local_drivers').catch(() => [])]);
  let ticked = JSON.parse(localStorage.getItem('mkt_print_ticks') || 'null') || pd.docs.filter(x => x.def).map(x => x.key);
  const kindLine = k => { const x = pd.kinds[k]; return x.printer ? `${esc(x.printer)} · ${esc(x.paper)}` : '<span class="badge amber">no printer chosen — opens the print window</span>'; };
  modal(`Print · Ref ${lead.ref_no} · ${lead.company || lead.buyer_name || ''}`, `
    <form id="mpf">
      <table class="t"><thead><tr><th style="width:30px"></th><th>Paper</th><th>Printer on this computer</th><th></th></tr></thead><tbody>
      ${pd.docs.map(x => `<tr><td><input type="checkbox" name="doc" value="${x.key}" style="width:auto" ${ticked.includes(x.key) ? 'checked' : ''}></td>
        <td><b>${esc(x.name)}</b>${x.note ? `<br><span class="hint">${esc(x.note)}</span>` : ''}</td>
        <td><span class="hint">${MKT_KIND[x.kind]}</span><br>${kindLine(x.kind)}</td>
        <td><a href="/print/mkt/${x.key}/${dispatchId}" target="_blank" class="small">${x.key === 'note' ? 'Open &amp; edit' : 'Preview'}</a></td></tr>`).join('')}
      </tbody></table>
      <div id="mpfr" class="card" style="margin-top:10px;background:#fafcfc" hidden><h4 style="margin:0 0 8px">Local freight letter</h4>
        <div class="grid g3" style="gap:8px">
          <label>Driver<input name="driver" list="mpdrv" value="${esc(last.driver || '')}" style="text-transform:uppercase"></label>
          ${datalist('mpdrv', drivers.map(x => x.name))}
          <label>Vehicle no.<input name="tempo_no" value="${esc(last.tempo_no || '')}" style="text-transform:uppercase"></label>
          <label>Mobile<input name="mobile" value="${esc(last.mobile || '')}" inputmode="numeric"></label>
          <label>Amount ₹<input name="amount" type="number" step="1" value="${esc(last.amount || '')}"></label>
          <label class="span2">From our factory at<input name="from_place" value="${esc(last.from_place || '')}"></label>
        </div><p class="hint">Drivers come from Master → Logistics → Local Freight.</p></div>
      <div class="row" style="margin-top:12px"><button type="submit" id="mpgo">🖨 Print ticked papers</button><button type="button" class="sec" id="mpclose">Close</button>
        <span class="hint">${pd.direct && pd.local ? 'Prints straight to the printers above.' : pd.direct ? 'This computer is not the main PC: the print window opens here.' : 'The print window opens for each paper.'}
          Printers: <a href="#/settings/printers">Settings → Printer Settings</a></span></div>
      <div id="mpres" style="margin-top:10px"></div>
    </form>`, root => {
    const fm = $('#mpf', root), fr = $('#mpfr', root);
    const showFr = () => { fr.hidden = !$$('[name=doc]', fm).some(c => c.value === 'freight' && c.checked); };
    showFr(); fm.addEventListener('change', showFr);
    const drv = fm.driver; drv.addEventListener('change', () => { const x = drivers.find(d => d.name === drv.value.toUpperCase()); if (x) { fm.tempo_no.value = x.tempo_no || ''; fm.mobile.value = x.mobile || ''; } });
    $('#mpclose', root).onclick = closeModal;
    fm.onsubmit = async e => {
      e.preventDefault();
      const docs = $$('[name=doc]', fm).filter(c => c.checked).map(c => c.value);
      if (!docs.length) return toast('Tick at least one paper.', true);
      try { localStorage.setItem('mkt_print_ticks', JSON.stringify(docs)); } catch { /* private */ }
      if (docs.includes('freight')) await guard(() => PUT(`/api/mkt/dispatches/${dispatchId}/freight`, { driver: fm.driver.value, tempo_no: fm.tempo_no.value, mobile: fm.mobile.value, amount: fm.amount.value, from_place: fm.from_place.value }));
      const b = $('#mpgo', root); b.disabled = true; b.textContent = 'Printing…';
      try {
        const r = await guard(() => POST('/api/mkt/print', { dispatch_id: dispatchId, docs }));
        $('#mpres', root).innerHTML = (r.printed.length ? `<p>✓ Sent to the printer: ${r.printed.map(x => `<b>${esc(x.name)}</b> (${x.pages} page${x.pages === 1 ? '' : 's'} · ${esc(x.printer)})`).join(', ')}</p>` : '')
          + (r.browser.length ? `<p class="hint">Open each paper and print it from its window:</p><div class="row" style="flex-wrap:wrap;gap:6px">${r.browser.map(x => `<a class="small" href="${esc(x.url)}" target="_blank"><button type="button" class="small sec">Open ${esc(x.name)}</button></a>`).join('')}</div>` : '');
        if (r.printed.length && !r.browser.length) toast('Printed');
      } catch { /* shown */ } finally { b.disabled = false; b.textContent = '🖨 Print ticked papers'; }
    };
  });
}
