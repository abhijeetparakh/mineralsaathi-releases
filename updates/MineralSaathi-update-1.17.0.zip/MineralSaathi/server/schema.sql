-- Mineral Saathi database schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- Billing firms: P.P.Enterprise, Parakh Marketing, Parakh Fertilizer
CREATE TABLE IF NOT EXISTS firms (
  id INTEGER PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,          -- PPE / PM / PF
  name TEXT NOT NULL,
  gstin TEXT, pan TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  phone TEXT, email TEXT,
  bank_name TEXT, bank_account TEXT, bank_ifsc TEXT, upi_id TEXT,
  smtp_host TEXT, smtp_port INTEGER, smtp_user TEXT, smtp_pass TEXT,
  terms TEXT
);

-- Plants where material is received / ground / dispatched
CREATE TABLE IF NOT EXISTS plants (
  id INTEGER PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,           -- PPI PLANT, KI PLANT
  full_name TEXT, address TEXT
);

CREATE TABLE IF NOT EXISTS parties (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  firm_code TEXT,                      -- which firm usually bills this party (PM / PF)
  gstin TEXT, pan TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  ship_address TEXT,
  email TEXT, mobile TEXT, phone TEXT,
  transporter TEXT, km INTEGER,
  group_name TEXT, payment_terms TEXT, notes TEXT,
  is_b2c INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_parties_name ON parties(name);

CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,                  -- DIATOMACEOUS EARTH
  grade TEXT,                          -- Y300 MESH
  hsn TEXT DEFAULT '2512',
  gst_rate REAL DEFAULT 5,
  unit TEXT DEFAULT 'MT',
  bag_type TEXT, pack_size REAL,
  rate REAL,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS transporters (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT, mobile TEXT, address TEXT, district TEXT, state TEXT,
  gstin TEXT, pan TEXT, email TEXT, contact TEXT,
  bank_name TEXT, bank_account TEXT, bank_ifsc TEXT
);

CREATE TABLE IF NOT EXISTS lorries (
  id INTEGER PRIMARY KEY,
  lorry_no TEXT UNIQUE NOT NULL,
  owner TEXT, pan TEXT, mobile TEXT, address TEXT,
  driver_name TEXT, driver_phone TEXT,
  bank_name TEXT, holder TEXT, bank_ifsc TEXT, bank_account TEXT, upi TEXT,
  tds_declaration TEXT
);

CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  grade TEXT, rate REAL, freight_rate REAL,
  type TEXT DEFAULT 'REG'              -- REG / URD
);

-- Inward challan + freight voucher
-- rawana_wt  = weight on the rawana (from mines)  -> printed on voucher, used for PPE bill
-- actual_wt  = weight actually received at plant -> freight is calculated on this
CREATE TABLE IF NOT EXISTS inwards (
  id INTEGER PRIMARY KEY,
  fy TEXT NOT NULL,
  voucher_no TEXT NOT NULL,
  date TEXT,                           -- ISO yyyy-mm-dd (date received)
  voucher_date TEXT,
  supplier TEXT, mines TEXT,
  lorry_no TEXT, grade TEXT, condition TEXT, plant TEXT,
  rawana_no TEXT, challan_no TEXT,
  rawana_wt REAL, actual_wt REAL,
  freight_rate REAL,                   -- rate per MT on actual weight
  freight_amt REAL,                    -- actual_wt * freight_rate
  advance REAL DEFAULT 0,
  pay_mode TEXT, cash_amt REAL DEFAULT 0, bank_amt REAL DEFAULT 0, chq_no TEXT,
  owner_name TEXT, pan TEXT, driver_name TEXT, driver_phone TEXT, upi TEXT,
  transporter TEXT, lr_no TEXT,
  royalty REAL, dmft REAL, nmet REAL,
  ppe_invoice_id INTEGER,              -- set when billed by P.P.Enterprise to Parakh Marketing
  remarks TEXT,
  legacy INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(fy, voucher_no)
);
CREATE INDEX IF NOT EXISTS ix_inwards_fy ON inwards(fy);
CREATE INDEX IF NOT EXISTS ix_inwards_lorry ON inwards(lorry_no);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY,
  firm_code TEXT NOT NULL,             -- seller: PPE / PM / PF
  fy TEXT NOT NULL,
  inv_no INTEGER NOT NULL,
  date TEXT,
  kind TEXT DEFAULT 'SALE',            -- SALE / PPE_BILL
  party_id INTEGER,
  party_name TEXT, party_gstin TEXT, party_pan TEXT,
  party_address TEXT, party_city TEXT, party_state TEXT, party_state_code TEXT, party_pincode TEXT,
  ship_address TEXT,
  supply_type TEXT DEFAULT 'B2B',      -- B2B / B2C
  lorry_no TEXT, transporter TEXT, lr_no TEXT, driver_phone TEXT,
  plant TEXT, ewb_no TEXT, freight_note TEXT, advance_freight REAL,
  taxable REAL, cgst REAL, sgst REAL, igst REAL, round_off REAL, total REAL,
  email_sent_at TEXT, notes TEXT,
  legacy INTEGER DEFAULT 0,
  cancelled INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(firm_code, fy, inv_no)
);
CREATE INDEX IF NOT EXISTS ix_invoices_fy ON invoices(firm_code, fy);

CREATE TABLE IF NOT EXISTS invoice_items (
  id INTEGER PRIMARY KEY,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  sl INTEGER,
  item_name TEXT, grade TEXT, hsn TEXT,
  qty REAL, unit TEXT DEFAULT 'MT', rate REAL, amount REAL, gst_rate REAL,
  bags INTEGER, pack_size REAL, bag_type TEXT,
  inward_id INTEGER,                   -- PPE bill line -> inward lorry
  lorry_no TEXT, rawana_no TEXT, challan_no TEXT
);
CREATE INDEX IF NOT EXISTS ix_items_inv ON invoice_items(invoice_id);

-- Items, rates and packing agreed with each buyer
CREATE TABLE IF NOT EXISTS party_items (
  id INTEGER PRIMARY KEY,
  party_id INTEGER NOT NULL REFERENCES parties(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL, grade TEXT,
  hsn TEXT, gst_rate REAL DEFAULT 5,
  rate REAL,                           -- rate per MT
  pack_size REAL,                      -- kg per bag
  bag_type TEXT,                       -- PLAIN, DEE-E, YELLOW DEE-E, PRINTED LAMINATED ...
  bag_supply TEXT,                     -- OUR = we supply bags, BUYER = buyer sends own bags
  liner INTEGER,                       -- 1 with liner, 0 without
  notes TEXT,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_party_items ON party_items(party_id);

-- Pick-lists used across the app (item colour, mesh, bag type, HSN ...)
CREATE TABLE IF NOT EXISTS lists (
  id INTEGER PRIMARY KEY,
  list_key TEXT NOT NULL,
  value TEXT NOT NULL,
  note TEXT,                           -- e.g. HSN description
  num REAL,                            -- e.g. GST % for an HSN, kg for a bag weight
  sort INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1,
  UNIQUE(list_key, value)
);

-- Delivery addresses (godowns / plants) of a buyer, each with its own pincode
CREATE TABLE IF NOT EXISTS party_addresses (
  id INTEGER PRIMARY KEY,
  party_id INTEGER NOT NULL REFERENCES parties(id) ON DELETE CASCADE,
  godown_name TEXT,
  address TEXT, city TEXT, state TEXT, state_code TEXT, pincode TEXT,
  contact TEXT, phone TEXT, km INTEGER,
  is_default INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_party_addresses ON party_addresses(party_id);
