'use strict';
// Sends email straight from the app (no Outlook needed), over SMTP with SSL.
// Gmail: host smtp.gmail.com, port 465, user = full address, password = Google "App password".
const tls = require('node:tls');
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function b64(s) { return Buffer.from(s).toString('base64'); }
function wrap(s) { return s.replace(/.{1,76}/g, '$&\r\n'); }
function encWord(s) { return /^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`; }

function buildMessage({ from, fromName, to, cc, subject, text, attachments = [] }) {
  const boundary = 'ms_' + crypto.randomBytes(12).toString('hex');
  const lines = [
    `From: ${fromName ? `"${encWord(fromName)}" ` : ''}<${from}>`,
    `To: ${to.join(', ')}`,
    cc.length ? `Cc: ${cc.join(', ')}` : null,
    `Subject: ${encWord(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomBytes(10).toString('hex')}@mineralsaathi>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap(b64(text)),
  ].filter(l => l !== null);
  for (const a of attachments) {
    const name = a.filename || path.basename(a.path);
    lines.push(`--${boundary}`, `Content-Type: application/pdf; name="${name}"`, 'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${name}"`, '', wrap(fs.readFileSync(a.path).toString('base64')));
  }
  lines.push(`--${boundary}--`, '');
  // dot-stuffing
  return lines.join('\r\n').replace(/\r\n\./g, '\r\n..');
}

function smtpSend(cfg, msg) {
  const { host, port = 465, user, pass } = cfg;
  const recipients = [...msg.to, ...msg.cc];
  return new Promise((resolve, reject) => {
    let sock;
    let buf = '';
    let step = 0;
    const secureNow = cfg.secure ?? Number(port) === 465;
    const timer = setTimeout(() => { fail(new Error('Email server did not answer (timeout).')); }, 30000);
    const fail = e => { clearTimeout(timer); try { sock.destroy(); } catch { } reject(e); };
    const send = l => sock.write(l + '\r\n');
    const queue = [];
    let waiting = null;
    const expect = (code) => new Promise((res, rej) => { waiting = { code, res, rej }; flush(); });

    function flush() {
      if (!waiting) return;
      const m = buf.match(/^(\d{3})[ ](.*)\r?\n/m);
      if (!m) return;
      const end = buf.indexOf(m[0]) + m[0].length;
      const reply = buf.slice(0, end);
      buf = buf.slice(end);
      const w = waiting; waiting = null;
      if (String(m[1]).startsWith(String(w.code))) w.res(reply);
      else w.rej(new Error('Email server said: ' + reply.trim().split('\n').pop()));
    }
    function attach(s) {
      sock = s;
      sock.setEncoding('utf8');
      sock.on('data', d => { buf += d; flush(); });
      sock.on('error', fail);
    }

    async function dialog(startTls) {
      try {
        if (!startTls) await expect(2);
        send('EHLO mineralsaathi'); await expect(2);
        if (!secureNow && !startTls) {
          send('STARTTLS'); await expect(2);
          const plain = sock; plain.removeAllListeners('data');
          const t = tls.connect({ socket: plain, servername: host }, () => { attach(t); dialog(true); });
          t.on('error', fail);
          return;
        }
        if (user) {
          send('AUTH LOGIN'); await expect(3);
          send(b64(user)); await expect(3);
          send(b64(pass || '')); await expect(2);
        }
        send(`MAIL FROM:<${msg.from}>`); await expect(2);
        for (const r of recipients) { send(`RCPT TO:<${r}>`); await expect(2); }
        send('DATA'); await expect(3);
        sock.write(buildMessage(msg) + '\r\n.\r\n'); await expect(2);
        send('QUIT');
        clearTimeout(timer);
        setTimeout(() => sock.end(), 200);
        resolve(true);
      } catch (e) { fail(e); }
    }

    if (secureNow) {
      const s = tls.connect({ host, port: Number(port), servername: host }, () => { attach(s); dialog(false); });
      s.on('error', fail);
    } else {
      const s = net.connect({ host, port: Number(port) }, () => { attach(s); dialog(false); });
      s.on('error', fail);
    }
  });
}

const splitAddr = s => String(s || '').split(/[;,\s]+/).map(x => x.trim()).filter(x => /.+@.+\..+/.test(x));

module.exports = { smtpSend, splitAddr, buildMessage };
