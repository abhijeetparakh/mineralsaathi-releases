'use strict';
// Printable pages (A4). The app opens these to print or save as PDF; email uses them to make the PDF.
const { get } = require('./db');
const { inWords, freightFigures, r2 } = require('./logic');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const qty = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 3 });
const dmy = iso => iso ? iso.split('-').reverse().join('.') : '';
const nl = s => esc(s).replace(/\n/g, '<br>');

const BASE_CSS = `
@page { size: A4; margin: 10mm; }
* { box-sizing: border-box; }
body { font-family: "Segoe UI", Arial, sans-serif; font-size: 11.5px; color: #1d2b31; margin: 0; }
.page { width: 190mm; margin: 0 auto; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #2F4F5A; padding: 4px 6px; vertical-align: top; }
th { background: #e8f1f3; font-weight: 600; text-align: left; }
.r { text-align: right; } .c { text-align: center; }
.head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #9A4A2A; padding-bottom: 6px; margin-bottom: 6px; }
.firm { font-size: 24px; font-weight: 800; color: #2F4F5A; letter-spacing: .5px; }
.muted { color: #5b6b70; }
.title { font-size: 15px; font-weight: 700; color: #9A4A2A; text-align: right; }
.box { border: 1px solid #2F4F5A; padding: 6px 8px; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 6px; }
.lbl { color: #5b6b70; font-size: 10px; text-transform: uppercase; letter-spacing: .4px; }
.big { font-size: 13px; font-weight: 700; }
.tot td { font-weight: 700; background: #f4ece7; white-space: nowrap; }
.sign { height: 60px; }
.no-print { background: #1A3E4A; padding: 10px; margin-bottom: 14px; text-align: center; }
.no-print button { font-size: 14px; padding: 8px 16px; background: #1A9BB5; color: #fff; border: 0; border-radius: 6px; cursor: pointer; margin-left: 6px; }
@media print { .no-print { display: none; } }
`;

const logoTag = f => f.logo && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo) ? `<img src="${f.logo}" style="max-height:62px;max-width:150px">` : '';

function shell(title, body, autoPrint) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${BASE_CSS}</style></head>
<body><div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>
${body}${autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

function invoiceHtml(inv, autoPrint) {
  const f = inv.firm;
  const intra = !(inv.igst > 0);
  const isPpe = inv.kind === 'PPE_BILL';
  const rows = inv.items.map(it => {
    const desc = [`<b>${esc(it.item_name)}</b>`];
    if (it.grade) desc.push(esc(it.grade));
    if (isPpe) desc.push(`Lorry ${esc(it.lorry_no || '')}${it.rawana_no ? ' · Rawana ' + esc(it.rawana_no) : ''}${it.challan_no ? ' · Challan ' + esc(it.challan_no) : ''}`);
    const pack = [
      (it.bags || it.pack_size) ? `${it.bags ? esc(it.bags) + ' bags' : ''}${it.pack_size ? ' × ' + esc(it.pack_size) + ' kg' : ''}` : '',
      it.bag_type ? esc(it.bag_type) : '',
      it.packing_type ? esc(it.packing_type) : '',
      it.liner === 1 ? 'with liner' : it.liner === 0 ? 'without liner' : '',
      it.bag_supply === 'BUYER' ? "in buyer's own bags" : ''
    ].filter(Boolean).join(' · ');
    if (pack) desc.push(pack);
    return `<tr><td class="c">${it.sl}</td><td>${desc.join('<br>')}</td><td class="c">${esc(it.hsn)}</td><td class="r">${qty(it.qty)}</td>
      <td class="c">${esc(it.unit)}</td><td class="r">${money(it.rate)}</td><td class="c">${it.gst_rate}%</td><td class="r">${money(it.amount)}</td></tr>`;
  }).join('');
  const totalQty = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);

  // HSN summary
  const hsn = {};
  for (const it of inv.items) {
    const k = it.hsn + '|' + it.gst_rate;
    hsn[k] = hsn[k] || { hsn: it.hsn, rate: it.gst_rate, taxable: 0 };
    hsn[k].taxable += it.amount;
  }
  const hsnRows = Object.values(hsn).map(h => {
    const tax = r2(h.taxable * h.rate / 100);
    return `<tr><td>${esc(h.hsn)}</td><td class="r">${money(h.taxable)}</td>
      ${intra ? `<td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td><td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td>`
        : `<td class="r">${h.rate}%</td><td class="r">${money(tax)}</td>`}<td class="r">${money(tax)}</td></tr>`;
  }).join('');

  const bank = [f.bank_name && `Bank: ${esc(f.bank_name)}`, f.bank_account && `A/c: ${esc(f.bank_account)}`, f.bank_ifsc && `IFSC: ${esc(f.bank_ifsc)}`, f.upi_id && `UPI: ${esc(f.upi_id)}`].filter(Boolean).join(' · ');

  const body = `<div class="page">
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div>
    <div class="muted">${esc(f.address)}, ${esc(f.city)} - ${esc(f.pincode)} (${esc(f.state)})<br>Ph: ${esc(f.phone)} · ${esc(f.email)}</div></div></div>
    <div><div class="title">${isPpe ? 'TAX INVOICE' : 'TAX INVOICE'}${inv.cancelled ? ' — CANCELLED' : ''}</div>
    <div class="r">GSTIN: <b>${esc(f.gstin)}</b><br>PAN: ${esc(f.pan)}</div></div></div>

  <div class="grid2">
    <div class="box"><div class="lbl">Bill to</div><div class="big">${esc(inv.party_name)}</div>
      ${nl(inv.party_address)}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}, ${esc(inv.party_state || '')}
      ${inv.party_state_code ? ' (Code ' + esc(inv.party_state_code) + ')' : ''}<br>
      ${inv.party_gstin ? 'GSTIN: <b>' + esc(inv.party_gstin) + '</b>' : 'Unregistered (B2C)'}${inv.party_pan ? ' · PAN: ' + esc(inv.party_pan) : ''}
      ${inv.ship_address ? `<div style="margin-top:4px"><span class="lbl">Ship to</span><br>${nl(inv.ship_address)}</div>` : ''}</div>
    <div class="box"><table style="border:0"><tbody>
      <tr><td style="border:0">Invoice No.</td><td style="border:0" class="big">${esc(inv.inv_no)}</td><td style="border:0">Date</td><td style="border:0" class="big">${dmy(inv.date)}</td></tr>
      <tr><td style="border:0">F.Y.</td><td style="border:0">${esc(inv.fy)}</td><td style="border:0">Lorry No.</td><td style="border:0"><b>${esc(isPpe ? '' : inv.lorry_no || '')}</b></td></tr>
      <tr><td style="border:0">Transporter</td><td style="border:0" colspan="3">${esc(inv.transporter || '')}${inv.transporter_gstin ? ' · GSTIN ' + esc(inv.transporter_gstin) : ''}</td></tr>
      <tr><td style="border:0">L.R. No.</td><td style="border:0">${esc(inv.lr_no || '')}</td><td style="border:0">E-way bill</td><td style="border:0">${esc(inv.ewb_no || '')}</td></tr>
      ${inv.driver_phone ? `<tr><td style="border:0">Driver Ph.</td><td style="border:0" colspan="3">${esc(inv.driver_phone)}</td></tr>` : ''}
    </tbody></table></div>
  </div>

  <table><thead><tr><th class="c" style="width:28px">#</th><th>Description of goods</th><th class="c">HSN</th><th class="r">Qty</th><th class="c">Unit</th><th class="r">Rate</th><th class="c">GST</th><th class="r">Amount</th></tr></thead>
  <tbody>${rows}
  <tr><td></td><td class="r"><b>Total quantity</b></td><td></td><td class="r"><b>${qty(totalQty)}</b></td><td class="c">MT</td><td></td><td class="r">Taxable</td><td class="r"><b>${money(inv.taxable)}</b></td></tr>
  ${intra ? `<tr><td colspan="7" class="r">CGST</td><td class="r">${money(inv.cgst)}</td></tr><tr><td colspan="7" class="r">SGST</td><td class="r">${money(inv.sgst)}</td></tr>`
           : `<tr><td colspan="7" class="r">IGST</td><td class="r">${money(inv.igst)}</td></tr>`}
  ${inv.round_off ? `<tr><td colspan="7" class="r">Round off</td><td class="r">${money(inv.round_off)}</td></tr>` : ''}
  <tr class="tot"><td colspan="7" class="r">Grand total</td><td class="r">₹ ${money(inv.total)}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(inv.total))}</b></div>

  <table style="margin-top:6px"><thead><tr><th>HSN</th><th class="r">Taxable</th>${intra ? '<th class="r">CGST %</th><th class="r">CGST</th><th class="r">SGST %</th><th class="r">SGST</th>' : '<th class="r">IGST %</th><th class="r">IGST</th>'}<th class="r">Total tax</th></tr></thead>
  <tbody>${hsnRows}</tbody></table>

  ${inv.freight_note || inv.notes ? `<div class="box" style="margin-top:6px">${inv.freight_note ? '<b>Freight:</b> ' + esc(inv.freight_note) + '<br>' : ''}${inv.notes ? esc(inv.notes) : ''}</div>` : ''}

  <div class="grid2" style="margin-top:6px">
    <div class="box"><div class="lbl">Terms of sale</div>${nl(f.terms || '')}${bank ? `<div style="margin-top:6px">${bank}</div>` : ''}</div>
    <div class="box r"><div>For <b>${esc(f.name.toUpperCase())}</b></div><div class="sign"></div><div>Authorised Signatory</div></div>
  </div>
  <div class="c muted" style="margin-top:4px">This is a computer generated invoice.</div>
</div>`;
  return shell(`${f.name} Invoice ${inv.inv_no}`, body, autoPrint);
}

function voucherHtml(w, autoPrint) {
  const isPpe = /^PPE/i.test(w.voucher_no);
  const f = get('SELECT * FROM firms WHERE code = ?', isPpe ? 'PPE' : 'PM');
  const { amount, shownRate } = freightFigures(w);
  const adv = Number(w.advance) || 0;
  const net = r2(amount - adv);
  const body = `<div class="page" style="max-width:190mm">
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div><div class="muted">${esc(f.address)}, ${esc(f.city)}</div></div></div>
  <div class="title">FREIGHT PAYMENT VOUCHER</div></div>
  <table><tbody>
    <tr><td>Voucher No.</td><td class="big">${esc(w.voucher_no)}</td><td>Voucher date</td><td>${dmy(w.voucher_date)}</td></tr>
    <tr><td>Plant</td><td>${esc(w.plant || '')}</td><td>Received on</td><td>${dmy(w.date)}</td></tr>
    <tr><td>Lorry No.</td><td class="big">${esc(w.lorry_no)}</td><td>Challan No.</td><td>${esc(w.challan_no || '')}</td></tr>
    <tr><td>Rawana No.</td><td>${esc(w.rawana_no || '')}</td><td>From → To</td><td><b>${esc(w.supplier || '')}</b> → <b>${esc(w.to_party || 'PARAKH MARKETING')}</b>${w.mines ? '<br>Mines: ' + esc(w.mines) : ''}</td></tr>
    <tr><td>Grade</td><td>${esc(w.grade || '')} ${esc(w.condition || '')}</td><td>Owner</td><td>${esc(w.owner_name || '')}${w.pan ? ' · PAN ' + esc(w.pan) : ''}</td></tr>
    <tr><td>Driver</td><td>${esc(w.driver_name || '')} ${esc(w.driver_phone || '')}</td><td>UPI</td><td>${esc(w.upi || '')}</td></tr>
  </tbody></table>
  <table style="margin-top:8px"><thead><tr><th>Particulars</th><th class="r">Weight (MT)</th><th class="r">Rate / MT</th><th class="r">Amount</th></tr></thead>
  <tbody><tr><td>Freight for ${esc(w.lorry_no)}</td><td class="r">${qty(w.rawana_wt)}</td><td class="r">${money(shownRate)}</td><td class="r">${money(amount)}</td></tr>
  ${adv ? `<tr><td colspan="3" class="r">Less advance</td><td class="r">${money(adv)}</td></tr>` : ''}
  <tr class="tot"><td colspan="3" class="r">Net payable</td><td class="r">₹ ${money(net)}</td></tr>
  <tr><td colspan="4">Paid: Cash ₹ ${money(w.cash_amt)} · Bank ₹ ${money(w.bank_amt)}${w.pay_mode ? ' (' + esc(w.pay_mode) + ')' : ''}${w.chq_no ? ' · Ref ' + esc(w.chq_no) : ''}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(net))}</b></div>
  <div class="grid2" style="margin-top:20px"><div class="box"><div class="sign"></div>Receiver's signature</div><div class="box r"><div class="sign"></div>For ${esc(f.name.toUpperCase())}</div></div>
</div>`;
  return shell(`Voucher ${w.voucher_no}`, body, autoPrint);
}

module.exports = { invoiceHtml, voucherHtml };
