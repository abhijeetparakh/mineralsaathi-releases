'use strict';
// Database access. Only the server process on the main PC touches the database file,
// so several PCs can work at the same time without clashes.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const { ROOT, DATA_DIR, DB_FILE, SHARED } = require('./paths');

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(DB_FILE);
// In a synced folder (Google Drive) the data must always be ONE complete file,
// so every change is written straight into mineral.db (no side files).
db.exec(SHARED ? 'PRAGMA journal_mode = DELETE; PRAGMA synchronous = FULL; PRAGMA busy_timeout = 5000;'
               : 'PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---- upgrades for databases made by older versions ----
function addColumn(table, col, type) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`);
}
addColumn('invoice_items', 'bag_supply', 'TEXT');
addColumn('invoice_items', 'liner', 'INTEGER');
addColumn('inwards', 'to_party', 'TEXT');
addColumn('firms', 'logo', 'TEXT');
for (const c of ['colour', 'mesh', 'form', 'packing_type']) { addColumn('items', c, 'TEXT'); addColumn('party_items', c, 'TEXT'); }
addColumn('invoice_items', 'packing_type', 'TEXT');
addColumn('party_items', 'plant', 'TEXT');            // fixed dispatch plant for this buyer item (blank = any)
for (const c of ['ship_name', 'ship_city', 'ship_state', 'ship_state_code', 'ship_pincode']) addColumn('invoices', c, 'TEXT');
addColumn('invoices', 'delivery_id', 'INTEGER');
addColumn('invoices', 'trans_type', 'INTEGER');      // e-way bill: 1 Regular, 2 Bill To-Ship To, 3 Bill From-Dispatch From, 4 Combination
// the old single "delivery address" text of a buyer becomes its first delivery address (once)
if (!db.prepare(`SELECT value FROM settings WHERE key = 'mig_ship_addr'`).get()) {
  const rows = db.prepare(`SELECT id, address, ship_address, city, state, state_code, pincode FROM parties
                           WHERE COALESCE(trim(ship_address),'') <> '' AND upper(trim(ship_address)) <> upper(trim(COALESCE(address,'')))`).all();
  const ins = db.prepare(`INSERT INTO party_addresses(party_id, godown_name, address, city, state, state_code, pincode, is_default) VALUES(?,?,?,?,?,?,?,1)`);
  for (const r of rows) {
    if (db.prepare('SELECT 1 FROM party_addresses WHERE party_id = ?').get(r.id)) continue;
    const pin = (String(r.ship_address).match(/\b(\d{6})\b/) || [])[1] || null;
    ins.run(r.id, 'DELIVERY', String(r.ship_address).trim(), pin ? null : r.city, pin ? null : r.state, pin ? null : r.state_code, pin);
  }
  db.prepare(`INSERT INTO settings(key, value) VALUES('mig_ship_addr', '1')`).run();
}
// delivery addresses with a pincode but no city/state: fill them from the pincode list
{
  const pinc = require('./pincode');
  for (const a of db.prepare(`SELECT id, pincode FROM party_addresses WHERE pincode IS NOT NULL AND (city IS NULL OR state IS NULL)`).all()) {
    const r = pinc.lookup(a.pincode); if (!r) continue;
    db.prepare('UPDATE party_addresses SET city = COALESCE(city, ?), state = COALESCE(state, ?) WHERE id = ?').run(r.city, r.state, a.id);
  }
}
// GST numbers and PAN always in capitals
db.exec(`UPDATE parties SET gstin = upper(trim(gstin)) WHERE gstin <> upper(trim(gstin));
         UPDATE parties SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE transporters SET gstin = upper(trim(gstin)) WHERE gstin <> upper(trim(gstin));
         UPDATE transporters SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE firms SET gstin = upper(trim(gstin)), pan = upper(trim(pan));
         UPDATE invoices SET party_gstin = upper(trim(party_gstin)) WHERE party_gstin <> upper(trim(party_gstin));
         UPDATE lorries SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));
         UPDATE inwards SET pan = upper(trim(pan)) WHERE pan <> upper(trim(pan));`);

// starting values for the pick-lists (only for a list that is still empty)
const SEED = {
  product: ['DIATOMACEOUS EARTH', 'DIATOMACEOUS EARTH (RAW)', 'ZEOCLAY', 'BENTONITE', 'GYPSUM', 'ORGASIL', 'DEE-E', 'SUPER-SIL', 'FOUNDASIL', 'S.R.FILLER'],
  colour: ['YELLOW', 'WHITE', 'GREY', 'BROWN'],
  mesh: ['150', '200', '300', '325', '400+', '500+'],
  form: ['POWDER', 'GRANULES', 'CHIPS 2MM TO 4MM', 'LUMPS', 'RAW'],
  bag_type: ['PLAIN', 'PLAIN LAMINATED', 'PRINTED LAMINATED', '4 COLOUR LAMINATED', 'DEE-E BAG', 'YELLOW DEE-E BAG', 'HDPE', 'JUMBO BAG'],
  hsn: [['251200', 'Diatomaceous earth / siliceous earths', 5], ['250810', 'Bentonite', 5], ['250840', 'Other clays (zeoclay)', 5], ['252010', 'Gypsum', 5], ['2512', 'Diatomaceous earth (4 digit)', 5]],
  bag_weight: [['1', '', 1], ['2', '', 2], ['5', '', 5], ['20', '', 20], ['22', '', 22], ['25', '', 25], ['30', '', 30], ['40', '', 40], ['50', '', 50], ['1000', 'Jumbo', 1000]],
  packing_type: ['SINGLE BAG', 'DOUBLE BAG', '5 KG x 6 (30 KG)', 'LOOSE / BULK'],
  unit: ['MT', 'KG', 'BAGS', 'NOS'],
  gst_rate: [['0', '', 0], ['5', '', 5], ['12', '', 12], ['18', '', 18]],
  condition: ['RAW', 'BROKEN', 'DRY', 'WET'],
  mines: ['BADIARA', 'MANDAI']
};
for (const [key, vals] of Object.entries(SEED)) {
  if (db.prepare('SELECT 1 FROM lists WHERE list_key = ? LIMIT 1').get(key)) continue;
  const ins = db.prepare('INSERT OR IGNORE INTO lists(list_key, value, note, num, sort) VALUES(?,?,?,?,?)');
  vals.forEach((v, i) => Array.isArray(v) ? ins.run(key, v[0], v[1] || null, v[2] ?? null, i) : ins.run(key, v, null, null, i));
}
// liner and who gives the bags have their own boxes now, so they leave the packing-type list
db.exec(`UPDATE lists SET active = 0 WHERE list_key = 'packing_type' AND value IN ('WITH LINER', 'WITHOUT LINER', 'BUYER''S OWN BAGS')`);
for (const v of ['SINGLE BAG', 'DOUBLE BAG']) db.prepare(`INSERT OR IGNORE INTO lists(list_key, value, sort) VALUES('packing_type', ?, 0)`).run(v);
// bag types already used in the data join the list
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'bag_type', upper(trim(bag_type)), 100 FROM items WHERE COALESCE(bag_type,'') <> ''`);
db.exec(`INSERT OR IGNORE INTO lists(list_key, value, sort) SELECT 'product', upper(trim(name)), 100 FROM items WHERE COALESCE(name,'') <> ''`);
// P.P. Enterprise vouchers: goods go FROM P.P. Enterprise TO Parakh Marketing
db.exec(`UPDATE inwards SET supplier = 'P.P.ENTERPRISE', to_party = 'PARAKH MARKETING'
         WHERE voucher_no LIKE 'PPE-V%' AND (to_party IS NULL OR supplier IS NOT 'P.P.ENTERPRISE')`);
// buyers without a usual transporter get the one from their latest invoice
db.exec(`UPDATE parties SET transporter = (SELECT i.transporter FROM invoices i WHERE i.party_id = parties.id AND COALESCE(i.transporter,'') <> ''
           ORDER BY i.date DESC, i.id DESC LIMIT 1) WHERE COALESCE(transporter,'') = ''`);
// e-mail addresses are always kept in small letters
db.exec(`UPDATE parties SET email = lower(email) WHERE email <> lower(email);
         UPDATE firms SET email = lower(email), smtp_user = lower(smtp_user) WHERE email <> lower(email) OR smtp_user <> lower(smtp_user);
         UPDATE transporters SET email = lower(email) WHERE email <> lower(email);`);

const fix = p => p.map(v => v === undefined ? null : (typeof v === 'boolean' ? (v ? 1 : 0) : v));
const all = (sql, ...p) => db.prepare(sql).all(...fix(p)).map(r => ({ ...r }));
const get = (sql, ...p) => { const r = db.prepare(sql).get(...fix(p)); return r ? { ...r } : null; };
const run = (sql, ...p) => db.prepare(sql).run(...fix(p));

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}

const colCache = {};
function columns(table) {
  if (!colCache[table]) colCache[table] = all(`PRAGMA table_info(${table})`).map(c => c.name);
  return colCache[table];
}

function setting(key, fallback = null) {
  const r = get('SELECT value FROM settings WHERE key = ?', key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value == null ? null : String(value));
}

module.exports = { db, all, get, run, tx, columns, setting, setSetting, DB_FILE, DATA_DIR, ROOT, SHARED };
