'use strict';
// one computer at a time: check the lock note before the data is opened
// a new installation (or data that could not be opened): first ask where the data is
if (require.main === module && require('./firstrun').needed()) { require('./firstrun').run(); return; }
if (require.main === module && require('./lock').acquireOrExit() === 'page') return;   // "take over?" page is showing
// Mineral Saathi server — runs on the main office PC. Every PC opens http://<main-pc>:7070 full screen.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { all, get, run, columns, setting, setSetting, ROOT, DATA_DIR } = require('./db');
const L = require('./logic');
const backup = require('./backup');
const { invoiceHtml, voucherHtml, labelHtml, envelopeHtml, setupFor, invoiceCopies, PAPERS, DEFAULT_SETUP } = require('./print');
const winprint = require('./winprint');
const { smtpSend, splitAddr } = require('./mailer');
const { makePdf } = require('./pdf');
const updater = require('./updater');
const lock = require('./lock');
const { db } = require('./db');
const { readConfig, writeConfig, DB_FILE: DBF, ROOT: APP_ROOT } = require('./paths');

function shutdown(code, releaseLock = true) {
  try { db.close(); } catch { /* already closed */ }
  if (releaseLock) lock.release();
  process.exit(code);
}

const PORT = Number(process.env.MS_PORT || 8765);
const PUBLIC = path.join(ROOT, 'public');
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;

const MASTER_TABLES = ['parties', 'items', 'transporters', 'lorries', 'suppliers', 'plants', 'firms'];
const SEARCH_COLS = {
  parties: ['name', 'city', 'gstin', 'group_name'], items: ['name', 'grade', 'hsn'], transporters: ['name', 'district', 'gstin'],
  lorries: ['lorry_no', 'owner', 'pan', 'driver_name'], suppliers: ['name', 'grade'], plants: ['name', 'full_name'], firms: ['name', 'code']
};
const ORDER = { parties: 'name', items: 'name, grade', transporters: 'name', lorries: 'lorry_no', suppliers: 'name', plants: 'name', firms: 'id' };

// ---------- helpers ----------
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', c => { d += c; if (d.length > 50e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { reject(new L.UserError('Bad data sent.')); } });
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

function serveStatic(res, urlPath) {
  const p = path.normalize(path.join(PUBLIC, urlPath === '/' ? 'index.html' : urlPath));
  if (!p.startsWith(PUBLIC) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) return send(res, 404, 'Not found', 'text/plain');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(p).pipe(res);
}

function cleanRow(table, body) {
  const cols = columns(table).filter(c => c !== 'id');
  const o = {};
  for (const c of cols) if (body[c] !== undefined) o[c] = body[c] === '' ? null : body[c];
  L.normalize(o);
  return o;
}

function checkParty(o, id) {
  if (o.name !== undefined && !String(o.name || '').trim()) throw new L.UserError('Enter the buyer name.');
  if (!id && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Choose the billing firm for this buyer (Parakh Marketing or Parakh Fertilizer).');
  if (o.firm_code !== undefined && !['PM', 'PF'].includes(o.firm_code)) throw new L.UserError('Billing firm must be Parakh Marketing or Parakh Fertilizer.');
  if (id && o.firm_code !== undefined) {
    const cur = get('SELECT firm_code FROM parties WHERE id = ?', id);
    const used = get('SELECT COUNT(*) AS n FROM invoices WHERE party_id = ? AND legacy = 0', id).n;
    if (cur && cur.firm_code && cur.firm_code !== o.firm_code && used)
      throw new L.UserError('This buyer already has invoices, so its billing firm is fixed.');
  }
  if (o.gstin) {
    o.gstin = String(o.gstin).toUpperCase().trim();
    if (!/^\d{2}[A-Z0-9]{13}$/.test(o.gstin)) throw new L.UserError('GSTIN should be 15 characters, like 08AIVPP2793C1ZQ.');
    o.state_code = o.gstin.slice(0, 2);
    if (!o.pan) o.pan = o.gstin.slice(2, 12);
  } else if (o.state) {
    o.state_code = L.stateCode(o.state) || o.state_code;
  }
  if (o.state) o.state = String(o.state).toUpperCase();
  o.is_b2c = o.gstin ? 0 : (o.is_b2c ?? 1);
}

function emailDraft(inv) {
  const f = inv.firm;
  const it = inv.items.map(i => `${i.item_name}${i.grade ? ' ' + i.grade : ''} — ${i.qty} ${i.unit}${i.bags ? ' (' + i.bags + ' bags)' : ''}`).join('\n');
  const d = inv.date ? inv.date.split('-').reverse().join('.') : '';
  const text = `Dear Sir / Madam,

Please find attached our invoice. Details of the dispatch are below${inv.ewb_no ? ', and the E-Way Bill No. is ' + inv.ewb_no : ''}.

Invoice No.: ${inv.inv_no}   Date: ${d}
${it}
Lorry No.: ${inv.lorry_no || '-'}
Transporter: ${inv.transporter || '-'}   L.R. No.: ${inv.lr_no || '-'}
Driver Ph.: ${inv.driver_phone || '-'}
${inv.freight_note || inv.freight_mode ? 'Freight: ' + [L.freightRate(inv.freight_note) > 0 ? 'Rs.' + L.freightRate(inv.freight_note) + ' per MT' : inv.freight_note, inv.freight_total ? 'total approx Rs.' + Number(inv.freight_total).toLocaleString('en-IN') : '', inv.freight_mode].filter(Boolean).join(', ') + '\n' : ''}Invoice amount: Rs. ${Number(inv.total).toLocaleString('en-IN')}

Kindly acknowledge receipt.

Regards,
${f.name}
${f.phone || ''}  ${f.email || ''}`;
  const to = inv.party ? splitAddr(inv.party.email) : [];
  return { to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '), subject: `Invoice ${inv.inv_no} dt ${d} — ${f.name}`, text };
}

function pdfFolder() { return setting('pdf_folder') || path.join(DATA_DIR, 'pdf'); }
function safeName(s) { return String(s).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80); }

// ---------- routes ----------
const routes = [];
const route = (method, pattern, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

route('GET', '/api/version', () => ({ version: VERSION }));

route('GET', '/api/meta', () => ({
  version: VERSION,
  firms: all('SELECT id, code, name, gstin, state_code FROM firms ORDER BY id'),
  plants: all('SELECT name, full_name FROM plants ORDER BY name'),
  current_fy: L.fyOf(),
  fys: all(`SELECT fy FROM (SELECT fy FROM invoices UNION SELECT fy FROM inwards) ORDER BY fy DESC`).map(r => r.fy),
  states: Object.keys(L.STATE_CODES),
  host: os.hostname(),
  shared: lock.status().shared
}));

route('GET', '/api/dashboard', ({ q }) => {
  const fy = q.fy || L.fyOf();
  const month = new Date().toISOString().slice(0, 7);
  return {
    fy,
    sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total, ROUND(SUM(taxable)) taxable FROM invoices WHERE fy = ? AND cancelled = 0 GROUP BY firm_code`, fy),
    month_sales: all(`SELECT firm_code, COUNT(*) n, ROUND(SUM(total)) total FROM invoices WHERE date LIKE ? AND cancelled = 0 GROUP BY firm_code`, month + '%'),
    inward: get(`SELECT COUNT(*) n, ROUND(SUM(actual_wt), 2) actual, ROUND(SUM(rawana_wt), 2) rawana, ROUND(SUM(freight_amt)) freight FROM inwards WHERE fy = ?`, fy),
    unbilled: get(`SELECT COUNT(*) n, ROUND(SUM(rawana_wt), 2) qty FROM inwards WHERE fy = ? AND ppe_invoice_id IS NULL AND supplier LIKE '%ENTERPRISE%'`, fy),
    recent: all(`SELECT id, firm_code, inv_no, date, party_name, total, kind FROM invoices WHERE cancelled = 0 ORDER BY date DESC, id DESC LIMIT 8`),
    last_backup: setting('last_backup'), backup_error: setting('last_backup_error')
  };
});

// masters
route('GET', '/api/m/:table', ({ p, q }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const where = []; const args = [];
  if (q.q) { where.push('(' + SEARCH_COLS[p.table].map(c => `${c} LIKE ?`).join(' OR ') + ')'); SEARCH_COLS[p.table].forEach(() => args.push('%' + q.q + '%')); }
  if (q.firm === 'NONE' && p.table === 'parties') where.push('firm_code IS NULL');
  else if (q.firm && p.table === 'parties') { where.push('firm_code = ?'); args.push(q.firm); }
  const limit = Math.min(Number(q.limit) || 500, 2000);
  const extra = p.table === 'parties' ? ', (SELECT COUNT(*) FROM party_items pi WHERE pi.party_id = parties.id AND pi.active = 1) AS item_count' : '';
  const rows = all(`SELECT *${extra} FROM ${p.table} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${ORDER[p.table]} LIMIT ${limit}`, ...args);
  if (p.table === 'firms') rows.forEach(r => delete r.smtp_pass);      // never send passwords to the screen
  return rows;
});
route('GET', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const r = get(`SELECT * FROM ${p.table} WHERE id = ?`, p.id);
  if (r && p.table === 'firms') delete r.smtp_pass;
  return r;
});
route('POST', '/api/m/:table', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table) || p.table === 'firms') throw new L.UserError('Cannot add here.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') checkParty(o);
  if (p.table === 'lorries') L.lorryUpi(o);
  const keys = Object.keys(o);
  if (!keys.length) throw new L.UserError('Nothing to save.');
  const r = run(`INSERT INTO ${p.table}(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
  return { id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/m/:table/:id', ({ p, body }) => {
  if (!MASTER_TABLES.includes(p.table)) throw new L.UserError('Unknown list.');
  const o = cleanRow(p.table, body);
  if (p.table === 'parties') checkParty(o, p.id);
  if (p.table === 'lorries') L.lorryUpi(o, get('SELECT * FROM lorries WHERE id = ?', p.id) || {});
  if (p.table === 'firms') {
    delete o.code; delete o.smtp_pass;
    if (o.state) { o.state = String(o.state).toUpperCase(); o.state_code = L.stateCode(o.state, o.gstin) || o.state_code; }
    if (o.gstin) o.gstin = String(o.gstin).toUpperCase().trim();
    if (o.pan) o.pan = String(o.pan).toUpperCase().trim();
    if (o.logo && !/^data:image\/(png|jpeg|webp);base64,/.test(o.logo)) throw new L.UserError('The logo must be a PNG or JPG picture.');
  }
  const keys = Object.keys(o);
  run(`UPDATE ${p.table} SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/m/:table/:id', ({ p }) => {
  if (!MASTER_TABLES.includes(p.table) || ['firms'].includes(p.table)) throw new L.UserError('Cannot delete here.');
  if (p.table === 'parties' && get('SELECT 1 FROM invoices WHERE party_id = ?', p.id)) {
    run('UPDATE parties SET active = 0 WHERE id = ?', p.id);
    return { hidden: true };
  }
  run(`DELETE FROM ${p.table} WHERE id = ?`, p.id);
  return { deleted: true };
});

// items, rates and packing for one buyer
const PI_COLS = ['plant', 'item_name', 'grade', 'colour', 'mesh', 'form', 'hsn', 'gst_rate', 'rate', 'pack_size', 'bag_type', 'packing_type', 'bag_supply', 'liner', 'notes', 'active'];
function cleanPartyItem(b) {
  const o = {};
  for (const c of PI_COLS) if (b[c] !== undefined) o[c] = b[c] === '' ? null : b[c];
  if (o.item_name !== undefined) { o.item_name = String(o.item_name || '').trim().toUpperCase(); if (!o.item_name) throw new L.UserError('Enter the item name.'); }
  if (o.grade) o.grade = String(o.grade).trim().toUpperCase();
  for (const c of ['bag_type', 'colour', 'mesh', 'form', 'packing_type']) if (o[c]) o[c] = String(o[c]).trim().toUpperCase();
  for (const c of ['gst_rate', 'rate', 'pack_size']) if (o[c] != null) o[c] = Number(o[c]);
  if (o.liner != null) o.liner = Number(o.liner) ? 1 : 0;
  L.normalize(o);
  if (o.bag_supply && !['OUR', 'BUYER'].includes(o.bag_supply)) o.bag_supply = null;
  return o;
}
route('GET', '/api/parties/:id/items', ({ p }) => all('SELECT * FROM party_items WHERE party_id = ? AND active = 1 ORDER BY item_name, grade', p.id));
route('POST', '/api/parties/:id/items', ({ p, body }) => {
  if (!get('SELECT 1 FROM parties WHERE id = ?', p.id)) throw new L.UserError('Buyer not found.');
  const o = cleanPartyItem(body);
  if (!o.item_name) throw new L.UserError('Enter the item name.');
  if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'') AND active = 1`, p.id, o.item_name, o.grade))
    throw new L.UserError('This buyer already has this item and grade. Use Edit to change it.');
  const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
  if (!o.hsn) o.hsn = m?.hsn || '2512';
  if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
  o.party_id = Number(p.id);
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/party-items/:id', ({ p, body }) => {
  const o = cleanPartyItem(body); const keys = Object.keys(o);
  run(`UPDATE party_items SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/party-items/:id', ({ p }) => { run('DELETE FROM party_items WHERE id = ?', p.id); return { deleted: true }; });

// pick-lists
const LIST_KEYS = ['product', 'colour', 'mesh', 'form', 'bag_type', 'hsn', 'bag_weight', 'packing_type', 'unit', 'gst_rate', 'condition', 'mines', 'freight_mode'];
route('GET', '/api/lists', () => {
  const out = Object.fromEntries(LIST_KEYS.map(k => [k, []]));
  for (const r of all('SELECT * FROM lists WHERE active = 1 ORDER BY list_key, sort, value')) if (out[r.list_key]) out[r.list_key].push(r);
  return out;
});
function cleanList(b) {
  const o = {};
  if (b.list_key !== undefined) { if (!LIST_KEYS.includes(b.list_key)) throw new L.UserError('Unknown list.'); o.list_key = b.list_key; }
  if (b.value !== undefined) {
    o.value = String(b.value || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (!o.value) throw new L.UserError('Enter a value.');
  }
  if (b.note !== undefined) o.note = String(b.note || '').trim() || null;
  if (b.num !== undefined) o.num = b.num === '' || b.num == null ? null : Number(b.num);
  if (b.sort !== undefined) o.sort = Number(b.sort) || 0;
  return o;
}
route('POST', '/api/lists', ({ body }) => {
  const o = cleanList(body);
  if (!o.list_key || !o.value) throw new L.UserError('Enter a value.');
  if (['hsn', 'bag_weight', 'gst_rate'].includes(o.list_key) && !/^\d+(\.\d+)?$/.test(o.value)) throw new L.UserError('This list takes numbers only.');
  if (o.list_key === 'bag_weight' && o.num == null) o.num = Number(o.value);
  if (o.list_key === 'gst_rate') o.num = Number(o.value);
  if (get('SELECT 1 FROM lists WHERE list_key = ? AND value = ? AND active = 1', o.list_key, o.value)) throw new L.UserError(`"${o.value}" is already in the list.`);
  const old = get('SELECT id FROM lists WHERE list_key = ? AND value = ?', o.list_key, o.value);
  if (old) { run('UPDATE lists SET active = 1, note = ?, num = ? WHERE id = ?', o.note ?? null, o.num ?? null, old.id); return { id: old.id }; }
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO lists(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/lists/:id', ({ p, body }) => {
  const o = cleanList(body); delete o.list_key;
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE lists SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/lists/:id', ({ p }) => { run('UPDATE lists SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });

// city & state from pincode (offline list of Indian pincodes)
const pincode = require('./pincode');
route('GET', '/api/pincode/:pin', ({ p }) => {
  const r = pincode.lookup(p.pin);
  return r ? { found: true, ...r, state_code: L.stateCode(r.state) } : { found: false };
});

// delivery addresses (godowns) of a buyer
const PA_COLS = ['godown_name', 'address', 'city', 'state', 'pincode', 'contact', 'phone', 'km', 'is_default', 'active'];
function cleanAddress(b) {
  const o = {};
  for (const c of PA_COLS) if (b[c] !== undefined) o[c] = b[c] === '' ? null : b[c];
  L.normalize(o);
  if (o.godown_name) o.godown_name = String(o.godown_name).trim().toUpperCase();
  if (o.city) o.city = String(o.city).trim().toUpperCase();
  if (o.state) o.state = String(o.state).trim().toUpperCase();
  if (o.pincode && !/^\d{6}$/.test(o.pincode)) throw new L.UserError('Pincode must be 6 digits.');
  if (o.pincode && (!o.state || !o.city)) { const r = pincode.lookup(o.pincode); if (r) { o.city = o.city || r.city; o.state = o.state || r.state; } }
  if (o.state || o.pincode) o.state_code = L.stateCode(o.state) || null;
  if (o.km != null) o.km = Number(o.km) || null;
  if (o.is_default != null) o.is_default = Number(o.is_default) ? 1 : 0;
  return o;
}
route('GET', '/api/parties/:id/addresses', ({ p }) => all('SELECT * FROM party_addresses WHERE party_id = ? AND active = 1 ORDER BY is_default DESC, godown_name', p.id));
route('POST', '/api/parties/:id/addresses', ({ p, body }) => {
  if (!get('SELECT 1 FROM parties WHERE id = ?', p.id)) throw new L.UserError('Buyer not found.');
  const o = cleanAddress(body);
  if (!o.address) throw new L.UserError('Enter the delivery address.');
  if (!o.pincode) throw new L.UserError('Enter the pincode of the delivery address.');
  o.party_id = Number(p.id);
  if (o.is_default) run('UPDATE party_addresses SET is_default = 0 WHERE party_id = ?', p.id);
  const keys = Object.keys(o);
  return { id: Number(run(`INSERT INTO party_addresses(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k])).lastInsertRowid) };
});
route('PUT', '/api/party-addresses/:id', ({ p, body }) => {
  const cur = get('SELECT * FROM party_addresses WHERE id = ?', p.id);
  if (!cur) throw new L.UserError('Address not found.');
  const o = cleanAddress(body);
  if (o.is_default) run('UPDATE party_addresses SET is_default = 0 WHERE party_id = ?', cur.party_id);
  const keys = Object.keys(o);
  if (keys.length) run(`UPDATE party_addresses SET ${keys.map(k => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map(k => o[k]), p.id);
  return { id: Number(p.id) };
});
route('DELETE', '/api/party-addresses/:id', ({ p }) => { run('UPDATE party_addresses SET active = 0, is_default = 0 WHERE id = ?', p.id); return { deleted: true }; });

route('GET', '/api/lorry/:no', ({ p }) => {
  const no = decodeURIComponent(p.no).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const l = get('SELECT * FROM lorries WHERE lorry_no = ?', no);
  const last = get('SELECT supplier, mines, grade, plant, freight_rate, owner_name, pan, driver_name, driver_phone, upi FROM inwards WHERE lorry_no = ? ORDER BY id DESC LIMIT 1', no);
  return { lorry: l, last };
});

// inwards
route('GET', '/api/inwards', ({ q }) => {
  const where = ['w.fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.q) { where.push('(w.lorry_no LIKE ? OR w.voucher_no LIKE ? OR w.rawana_no LIKE ? OR w.supplier LIKE ? OR w.owner_name LIKE ?)'); for (let i = 0; i < 5; i++) args.push('%' + q.q + '%'); }
  if (q.status === 'unbilled') where.push('w.ppe_invoice_id IS NULL');
  if (q.status === 'billed') where.push('w.ppe_invoice_id IS NOT NULL');
  if (q.supplier) { where.push('w.supplier LIKE ?'); args.push('%' + q.supplier + '%'); }
  return all(`SELECT w.*, i.inv_no AS ppe_inv_no FROM inwards w LEFT JOIN invoices i ON i.id = w.ppe_invoice_id
              WHERE ${where.join(' AND ')} ORDER BY w.date DESC, w.id DESC LIMIT 2000`, ...args);
});
route('GET', '/api/inwards/next', ({ q }) => ({ voucher_no: L.nextVoucherNo(q.fy || L.fyOf(q.date), q.firm) }));
route('GET', '/api/inwards/:id', ({ p }) => get('SELECT * FROM inwards WHERE id = ?', p.id));
route('POST', '/api/inwards', ({ body }) => ({ id: L.saveInward(body) }));
route('PUT', '/api/inwards/:id', ({ p, body }) => { checkEditPassword(body.edit_password); return { id: L.saveInward(body, Number(p.id)) }; });
route('DELETE', '/api/inwards/:id', ({ p, q }) => {
  checkEditPassword(q.pw);
  const w = get('SELECT * FROM inwards WHERE id = ?', p.id);
  if (!w) throw new L.UserError('Not found.');
  if (w.ppe_invoice_id) throw new L.UserError('This lorry is billed. Cancel the P.P. Enterprise bill first.');
  run('DELETE FROM inwards WHERE id = ?', p.id);
  return { deleted: true };
});

// invoices
route('GET', '/api/invoices', ({ q }) => {
  const where = ['fy = ?']; const args = [q.fy || L.fyOf()];
  if (q.firm) { where.push('firm_code = ?'); args.push(q.firm); }
  if (q.kind) { where.push('kind = ?'); args.push(q.kind); }
  if (q.q) { where.push('(party_name LIKE ? OR lorry_no LIKE ? OR CAST(inv_no AS TEXT) = ? OR ewb_no LIKE ?)'); args.push('%' + q.q + '%', '%' + q.q + '%', q.q, '%' + q.q + '%'); }
  return all(`SELECT id, firm_code, fy, inv_no, date, kind, party_name, party_gstin, supply_type, lorry_no, ewb_no, taxable, cgst, sgst, igst, total,
              email_sent_at, legacy, cancelled, (SELECT ROUND(SUM(qty), 3) FROM invoice_items WHERE invoice_id = invoices.id) AS qty,
              (SELECT COUNT(*) FROM invoice_items WHERE invoice_id = invoices.id) AS lines
              FROM invoices WHERE ${where.join(' AND ')} ORDER BY date DESC, inv_no DESC LIMIT 3000`, ...args);
});
route('GET', '/api/invoices/next', ({ q }) => ({ inv_no: L.nextInvoiceNo(q.firm, q.fy || L.fyOf(q.date)) }));
route('GET', '/api/invoices/:id', ({ p }) => L.invoiceFull(p.id));
route('POST', '/api/invoices', ({ body }) => { const id = L.saveSale(body); backup.backupSoon('invoice'); return { id }; });
// a saved invoice can be changed or cancelled only with the edit password (Settings → Security)
const crypto = require('node:crypto');
const pwHash = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
function checkEditPassword(pw) {
  const h = setting('edit_password_hash'), salt = setting('edit_password_salt');
  if (!h) throw new L.UserError('Set the invoice edit password first: Settings → Security.');
  if (!pw || !crypto.timingSafeEqual(Buffer.from(pwHash(pw, salt), 'hex'), Buffer.from(h, 'hex'))) throw new L.UserError('Wrong edit password.');
}
route('POST', '/api/edit-password/check', ({ body }) => { checkEditPassword(body.password); return { ok: true }; });
route('PUT', '/api/edit-password', ({ body }) => {
  if (setting('edit_password_hash')) {
    try { checkEditPassword(body.old); } catch { throw new L.UserError('The current password is wrong.'); }
  }
  const pw = String(body.password || '');
  if (pw.length < 4) throw new L.UserError('The password must have at least 4 characters.');
  const salt = crypto.randomBytes(16).toString('hex');
  setSetting('edit_password_salt', salt); setSetting('edit_password_hash', pwHash(pw, salt));
  return { ok: true };
});
route('PUT', '/api/invoices/:id', ({ p, body }) => { checkEditPassword(body.edit_password); const id = L.saveSale(body, Number(p.id)); backup.backupSoon('invoice'); return { id }; });
route('POST', '/api/invoices/:id/cancel', ({ p, body }) => { checkEditPassword(body.edit_password); L.cancelInvoice(p.id); backup.backupSoon('cancel'); return { ok: true }; });
route('POST', '/api/ppe-bills', ({ body }) => { const id = L.savePpeBill(body); backup.backupSoon('invoice'); return { id }; });
route('PUT', '/api/ppe-bills/:id', ({ p, body }) => { checkEditPassword(body.edit_password); const id = L.savePpeBill(body, Number(p.id)); backup.backupSoon('invoice'); return { id }; });
route('POST', '/api/ewaybill-json', ({ body }) => L.ewayBillJson(body));
route('POST', '/api/totals', ({ body }) => {
  // live preview of totals while typing an invoice
  const firmCode = body.firm_code || (body.party_id && get('SELECT firm_code FROM parties WHERE id = ?', body.party_id)?.firm_code) || 'PM';
  const f = get('SELECT * FROM firms WHERE code = ?', firmCode);
  const items = (body.items || []).map(it => ({ qty: Number(it.qty) || 0, rate: Number(it.rate) || 0, gst_rate: Number(it.gst_rate ?? 5) }));
  const t = L.computeTotals(items, f, L.stateCode(body.state, body.gstin) || body.state_code);
  return { ...t, words: L.inWords(t.total) };
});

route('GET', '/api/invoices/:id/email', ({ p }) => {
  const inv = L.invoiceFull(p.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  return { ...emailDraft(inv), from: inv.firm.smtp_user || inv.firm.email, ready: !!(inv.firm.smtp_user && inv.firm.smtp_pass), missing: L.missingDispatch(inv) };
});
route('POST', '/api/invoices/:id/email', async ({ p, body }) => {
  const inv = L.invoiceFull(p.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  const f = inv.firm;
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError(`Email is not set up for ${f.name}. Open Settings → Email.`);
  const miss = L.missingDispatch(inv);
  if (miss.length) throw new L.UserError(`Fill in ${miss.join(', ')} on the invoice and save it before emailing.`);
  const to = splitAddr(body.to), cc = splitAddr(body.cc);
  if (!to.length) throw new L.UserError('Enter the buyer email address.');
  const file = path.join(pdfFolder(), inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} ${inv.party_name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/invoice/${inv.id}?copy=0`, file);
  const attachments = [{ path: file, filename: path.basename(file) }];
  for (const extra of body.extra_files || []) if (extra && fs.existsSync(extra)) attachments.push({ path: extra });
  await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, to, cc, subject: body.subject || 'Invoice', text: body.text || '', attachments });
  const at = new Date().toLocaleString('en-IN');
  run('UPDATE invoices SET email_sent_at = ? WHERE id = ?', at, inv.id);
  return { sent: true, at, pdf: file };
});
route('POST', '/api/invoices/:id/pdf', async ({ p }) => {
  const inv = L.invoiceFull(p.id);
  const file = path.join(pdfFolder(), inv.fy, safeName(`${inv.firm_code} ${inv.inv_no} ${inv.party_name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${PORT}/print/invoice/${inv.id}?copy=0`, file);
  return { pdf: file };
});

// settings & backup
route('GET', '/api/settings', () => ({
  backup_folder: backup.folder(), pdf_folder: pdfFolder(), last_backup: setting('last_backup'), edit_password_set: !!setting('edit_password_hash'),
  last_backup_file: setting('last_backup_file'), last_backup_error: setting('last_backup_error'), backups: backup.list(), version: VERSION,
  firms: all(`SELECT id, code, name, smtp_host, smtp_port, smtp_user, CASE WHEN smtp_pass IS NULL OR smtp_pass = '' THEN 0 ELSE 1 END AS has_pass FROM firms`)
}));
route('PUT', '/api/settings', ({ body }) => {
  if (body.backup_folder !== undefined) {
    const dir = String(body.backup_folder).trim();
    if (!dir) throw new L.UserError('Enter a backup folder.');
    try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); }
    catch { throw new L.UserError('The main PC cannot write to that folder. Check the path.'); }
    setSetting('backup_folder', dir);
  }
  if (body.pdf_folder !== undefined) {
    const dir = String(body.pdf_folder).trim();
    if (dir) { try { fs.mkdirSync(dir, { recursive: true }); } catch { throw new L.UserError('Cannot use that PDF folder.'); } }
    setSetting('pdf_folder', dir || null);
  }
  return { ok: true };
});
route('PUT', '/api/settings/email/:code', ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f) throw new L.UserError('Unknown firm.');
  run('UPDATE firms SET smtp_host = ?, smtp_port = ?, smtp_user = ? WHERE id = ?', body.smtp_host || 'smtp.gmail.com', Number(body.smtp_port) || 465, body.smtp_user || null, f.id);
  if (body.smtp_pass) run('UPDATE firms SET smtp_pass = ? WHERE id = ?', String(body.smtp_pass).replace(/\s+/g, ''), f.id);
  return { ok: true };
});
route('POST', '/api/settings/email/:code/test', async ({ p, body }) => {
  const f = get('SELECT * FROM firms WHERE code = ?', p.code);
  if (!f.smtp_user || !f.smtp_pass) throw new L.UserError('Save the email and app password first.');
  await smtpSend({ host: f.smtp_host, port: f.smtp_port, user: f.smtp_user, pass: f.smtp_pass },
    { from: f.smtp_user, fromName: f.name, to: splitAddr(body.to || f.smtp_user), cc: [], subject: 'Mineral Saathi test email', text: 'Email from Mineral Saathi is working.' });
  return { sent: true };
});
route('POST', '/api/backup', () => ({ file: backup.backupNow('manual') }));

// Settings of THIS computer only (start with Windows, printers, label printer …).
// Kept in config.json in the program folder of this PC: not in the shared data, not touched by updates.
function pcSettings() { return readConfig().pc || {}; }
function savePcSettings(patch) { const cfg = readConfig(); cfg.pc = { ...(cfg.pc || {}), ...patch, updated: new Date().toISOString() }; writeConfig(cfg); return cfg.pc; }
route('GET', '/api/pc-settings', () => ({ pc: os.hostname(), file: path.join(APP_ROOT, 'config.json'), settings: pcSettings() }));
route('PUT', '/api/pc-settings', ({ body }) => {
  const allowed = {};
  for (const [k, v] of Object.entries(body || {})) if (/^[a-z_]{2,40}$/.test(k) && k !== 'updated') allowed[k] = v;
  return { pc: os.hostname(), settings: savePcSettings(allowed) };
});

// ---- printers of this computer (invoice A4, 4x6 bag sticker, envelope) ----
const PRINT_KINDS = ['invoice', 'label', 'envelope'];
function printSetup(kind) { return setupFor(kind, pcSettings()['print_' + kind]); }
function singleCopyMt() { return Number(setting('invoice_single_copy_mt', '9')) || 9; }
const isLocal = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
route('GET', '/api/print-setup', ({ req }) => ({
  pc: os.hostname(), local: isLocal(req), direct: winprint.supported(), single_copy_mt: singleCopyMt(),
  papers: PAPERS, kinds: Object.fromEntries(PRINT_KINDS.map(k => [k, printSetup(k)]))
}));
route('PUT', '/api/print-setup/:kind', ({ p, body }) => {
  if (!PRINT_KINDS.includes(p.kind)) throw new L.UserError('Unknown print.');
  const keep = ['printer', 'paper', 'w', 'h', 'landscape', 'margin', 'ox', 'oy', 'scale'];
  const o = {}; for (const k of keep) if (body[k] !== undefined) o[k] = k === 'printer' || k === 'paper' ? String(body[k] || '') : (k === 'landscape' ? !!body[k] : Number(body[k]) || 0);
  savePcSettings({ ['print_' + p.kind]: o });
  return printSetup(p.kind);
});
route('PUT', '/api/print-rules', ({ body }) => { if (body.single_copy_mt != null) setSetting('invoice_single_copy_mt', String(Number(body.single_copy_mt) || 9)); return { single_copy_mt: singleCopyMt() }; });
route('GET', '/api/printers', async () => ({ supported: winprint.supported(), ...(await winprint.printers().catch(e => ({ printers: [], error: e.message }))) }));
route('GET', '/api/printers/papers', async ({ q }) => ({ papers: await winprint.papers(q.name).catch(() => []) }));

// print: straight to the printer on this computer (or on the main PC when asked), otherwise the print window
route('POST', '/api/print', async ({ body, req }) => {
  const kind = body.kind;
  if (!PRINT_KINDS.includes(kind)) throw new L.UserError('Unknown print.');
  const inv = L.invoiceFull(body.id);
  if (!inv) throw new L.UserError('Invoice not found.');
  const s = printSetup(kind);
  const base = `/print/${kind}/${inv.id}`;
  let qs = '', count = 1;
  if (kind === 'invoice') count = (inv.kind === 'PPE_BILL' ? 1 : invoiceCopies(inv, singleCopyMt()).length);
  if (kind === 'label') {
    const of = Math.max(1, Number(body.of) || 1), from = Math.max(1, Number(body.from) || 1), to = Math.min(of, Math.max(from, Number(body.to) || of));
    qs = `from=${from}&to=${to}&of=${of}`; count = to - from + 1;
    if (count > 300) throw new L.UserError('Print at most 300 stickers at a time.');
  }
  const direct = winprint.supported() && s.printer && (isLocal(req) || body.where === 'main');
  if (!direct) return { browser: true, url: `${base}?print=1${qs ? '&' + qs : ''}`, reason: !s.printer ? 'no-printer' : 'not-this-pc' };
  // draw at most 10 sheets per picture
  const pages = [];
  if (kind === 'label') {
    const of = Number(new URLSearchParams(qs).get('of')), from = Number(new URLSearchParams(qs).get('from')), to = Number(new URLSearchParams(qs).get('to'));
    for (let a = from; a <= to; a += 10) { const b = Math.min(to, a + 9); pages.push({ url: `http://127.0.0.1:${PORT}${base}?shot=1&from=${a}&to=${b}&of=${of}`, w: s.w, h: s.h, count: b - a + 1 }); }
  } else pages.push({ url: `http://127.0.0.1:${PORT}${base}?shot=1`, w: s.w, h: s.h, count });
  await winprint.printPages(s.printer, pages, `${inv.firm_code} ${inv.inv_no} ${kind}`);
  return { printed: true, printer: s.printer, sheets: count };
});
route('POST', '/api/print/test/:kind', async ({ p }) => {
  const s = printSetup(p.kind);
  const inv = get(`SELECT id FROM invoices WHERE kind = 'SALE' AND cancelled = 0 ORDER BY id DESC LIMIT 1`);
  if (!inv) throw new L.UserError('Make one invoice first, then test.');
  const qs = p.kind === 'label' ? '&from=1&to=1&of=1' : p.kind === 'invoice' ? '&copy=0' : '';
  await winprint.printPages(s.printer, [{ url: `http://127.0.0.1:${PORT}/print/${p.kind}/${inv.id}?shot=1${qs}`, w: s.w, h: s.h, count: 1 }], 'Mineral Saathi test');
  return { printed: true, printer: s.printer };
});

// start with Windows (a shortcut in this PC's Startup folder)
const { execFileSync } = require('node:child_process');
function startupLink() {
  const appdata = process.env.APPDATA;
  return appdata ? path.join(appdata, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Mineral Saathi Server.lnk') : null;
}
route('GET', '/api/startup', () => {
  const lnk = startupLink();
  return { supported: process.platform === 'win32' && !!lnk, enabled: !!lnk && fs.existsSync(lnk), pc: os.hostname() };
});
route('PUT', '/api/startup', ({ body }) => {
  const lnk = startupLink();
  if (process.platform !== 'win32' || !lnk) throw new L.UserError('This works only on Windows.');
  if (body.enabled) {
    const bat = path.join(APP_ROOT, 'Start-Server.bat').replace(/'/g, "''");
    const dir = APP_ROOT.replace(/'/g, "''");
    const ps = `$s=(New-Object -ComObject WScript.Shell).CreateShortcut('${lnk.replace(/'/g, "''")}');$s.TargetPath='${bat}';$s.WorkingDirectory='${dir}';$s.WindowStyle=7;$s.Save()`;
    execFileSync('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true, stdio: 'ignore' });
  } else if (fs.existsSync(lnk)) fs.unlinkSync(lnk);
  savePcSettings({ start_with_windows: fs.existsSync(lnk) });
  return { supported: true, enabled: fs.existsSync(lnk), pc: os.hostname() };
});

// data location & one-computer-at-a-time
route('GET', '/api/data-location', ({ req }) => ({ ...lock.status(), local: isLocal(req), db_size: (() => { try { return fs.statSync(DBF).size; } catch { return 0; } })() }));
route('POST', '/api/close', () => {
  console.log('\n  Closed for today from the app. The data is free for another computer.\n');
  setTimeout(() => shutdown(2), 500);        // Start-Server.bat closes on code 2
  return { closed: true, pc: lock.PC };
});
route('POST', '/api/data-choose', ({ req }) => {
  if (!isLocal(req)) throw new L.UserError('Do this on the computer where the Mineral Saathi server runs.');
  require('./firstrun').askNextStart();
  console.log('\n  Choosing another data folder. Restarting...\n');
  setTimeout(() => shutdown(0), 600);        // Start-Server.bat starts again and shows "Where is the data?"
  return { ok: true };
});
route('POST', '/api/data-location', ({ body }) => {
  const local = !String(body.folder || '').trim();
  const target = local ? path.join(APP_ROOT, 'data') : path.resolve(String(body.folder).trim());
  if (path.resolve(target) === path.resolve(path.dirname(DBF))) throw new L.UserError('The data is already in that folder.');
  try { fs.mkdirSync(target, { recursive: true }); fs.accessSync(target, fs.constants.W_OK); }
  catch { throw new L.UserError('This PC cannot write to that folder. Check the path.'); }
  const dest = path.join(target, 'mineral.db');
  if (fs.existsSync(dest)) {
    if (!body.replace) throw new L.UserError('That folder already has Mineral Saathi data. Tick "replace" to keep the old file aside and move the current data there.');
    const p2 = n => String(n).padStart(2, '0'); const d = new Date();
    fs.renameSync(dest, path.join(target, `mineral-before-move-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.db`));
    try { fs.unlinkSync(path.join(target, 'mineral.lock')); } catch { /* none */ }
  }
  try { backup.backupNow('before-move'); } catch (e) { console.error(e.message); }
  db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
  const cfg = readConfig();
  if (local) delete cfg.data_folder; else cfg.data_folder = target;
  writeConfig(cfg);
  console.log(`\n  Data moved to ${target}. Restarting...\n`);
  setTimeout(() => shutdown(0), 800);        // Start-Server.bat starts again with the new folder
  return { moved: true, folder: target };
});

// automatic updates
route('GET', '/api/update', () => updater.status());
route('POST', '/api/update/check', ({ body }) => updater.check({ install: !!body.install, force: !!body.install }));
route('PUT', '/api/update/settings', ({ body }) => {
  if (body.auto !== undefined) setSetting('auto_update', body.auto ? '1' : '0');
  if (body.source !== undefined) setSetting('update_source', String(body.source || '').trim() || null);
  return updater.status();
});

// import data file made from an old Excel workbook (buyers + invoices).
// Safe to run twice: existing invoice numbers are skipped, existing buyers are never moved to another firm.
route('POST', '/api/import', ({ body }) => {
  if (body.kind === 'mineral-saathi-buyer-items') return importBuyerItems(body);
  if (body.kind === 'mineral-saathi-delivery-addresses') return importAddresses(body);
  if (body.kind !== 'mineral-saathi-import' || !['PM', 'PF'].includes(body.firm_code)) throw new L.UserError('This is not a Mineral Saathi data file.');
  const firm = body.firm_code;
  const BUYER_COLS = ['gstin', 'pan', 'address', 'city', 'state', 'state_code', 'pincode', 'ship_address', 'email', 'mobile', 'phone', 'transporter', 'km', 'group_name', 'payment_terms', 'notes'];
  const rep = { buyers_added: [], buyers_filled: 0, buyers_other_firm: [], buyers_no_firm: [], invoices_added: 0, invoices_skipped: [], invoices_existing: 0 };
  const findParty = (gstin, name, city) =>
    (gstin && get('SELECT * FROM parties WHERE upper(gstin) = upper(?)', gstin)) ||
    get(`SELECT * FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, name || '', city || '') ||
    (!city ? get('SELECT * FROM parties WHERE upper(name) = upper(?)', name || '') : null);

  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      if (!b.name || (!b.gstin && !b.city && !b.address)) continue;          // skip placeholder rows like "ONLINE"
      if (b.email) b.email = String(b.email).toLowerCase();
      const ex = findParty(b.gstin, b.name, b.city);
      if (!ex) {
        const o = { name: b.name, firm_code: firm, is_b2c: b.gstin ? 0 : 1 };
        for (const c of BUYER_COLS) if (b[c] != null && b[c] !== '') o[c] = b[c];
        const keys = Object.keys(o);
        run(`INSERT INTO parties(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.buyers_added.push(`${b.name}${b.city ? ' — ' + b.city : ''}`);
        continue;
      }
      // fill only empty fields, never overwrite what is already there
      const fill = BUYER_COLS.filter(c => (ex[c] == null || ex[c] === '') && b[c] != null && b[c] !== '');
      if (fill.length) { run(`UPDATE parties SET ${fill.map(c => c + ' = ?').join(', ')} WHERE id = ?`, ...fill.map(c => b[c]), ex.id); rep.buyers_filled++; }
      if (!ex.firm_code) rep.buyers_no_firm.push(ex.name);
      else if (ex.firm_code !== firm) rep.buyers_other_firm.push(`${ex.name}${ex.city ? ' — ' + ex.city : ''}`);
    }
    for (const inv of body.invoices || []) {
      const ex = get('SELECT legacy FROM invoices WHERE firm_code = ? AND fy = ? AND inv_no = ?', firm, inv.fy, inv.inv_no);
      if (ex) { if (ex.legacy) rep.invoices_existing++; else rep.invoices_skipped.push(`${inv.fy} no. ${inv.inv_no}`); continue; }
      const p = findParty(inv.party_gstin, inv.party_name, inv.party_city);
      const cols = ['fy', 'inv_no', 'date', 'party_name', 'party_gstin', 'party_address', 'party_city', 'party_state', 'party_state_code', 'ship_address',
        'supply_type', 'lorry_no', 'transporter', 'lr_no', 'driver_phone', 'plant', 'ewb_no', 'freight_note', 'email_sent_at', 'notes', 'taxable', 'cgst', 'sgst', 'igst', 'total'];
      const r = run(`INSERT INTO invoices(firm_code, kind, legacy, round_off, party_id, party_pan, ${cols.join(',')})
                     VALUES(?, 'SALE', 1, 0, ?, ?, ${cols.map(() => '?').join(',')})`, firm, p ? p.id : null, p ? p.pan : null, ...cols.map(c => inv[c] ?? null));
      const id = Number(r.lastInsertRowid);
      (inv.items || []).forEach((it, i) => run(`INSERT INTO invoice_items(invoice_id, sl, item_name, grade, hsn, qty, unit, rate, amount, gst_rate, bags, pack_size, bag_type, lorry_no)
        VALUES(?,?,?,?,?,?,'MT',?,?,?,?,?,?,?)`, id, i + 1, it.item_name, it.grade, it.hsn, it.qty, it.rate, it.amount, it.gst_rate, it.bags, it.pack_size, it.bag_type, it.lorry_no));
      rep.invoices_added++;
    }
  });
  backup.backupSoon('import');
  return rep;
});

// delivery addresses from the old Excel buyer lists (PLANT 1 … PLANT 11). Adds only addresses the buyer does not have.
function importAddresses(body) {
  const rep = { items_added: 0, buyers_touched: 0, items_existing: 0, buyers_not_found: [] };
  const key = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      const ex = (b.gstin && get('SELECT id, address FROM parties WHERE upper(gstin) = upper(?)', b.gstin)) ||
        get(`SELECT id, address FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, b.name || '', b.city || '');
      if (!ex) { rep.buyers_not_found.push(b.name); continue; }
      const have = all('SELECT address FROM party_addresses WHERE party_id = ? AND active = 1', ex.id).map(r => key(r.address));
      let touched = false;
      for (const a of b.addresses || []) {
        if (!a.address || key(a.address) === key(ex.address) || have.includes(key(a.address))) { rep.items_existing++; continue; }
        const o = cleanAddress({ godown_name: a.godown_name, address: a.address, pincode: a.pincode || null });
        o.party_id = ex.id;
        const keys = Object.keys(o);
        run(`INSERT INTO party_addresses(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        have.push(key(a.address)); rep.items_added++; touched = true;
      }
      if (touched) rep.buyers_touched++;
    }
  });
  backup.backupSoon('import');
  return { ...rep, buyers_added: [], buyers_other_firm: [], buyers_no_firm: [], invoices_skipped: [], invoices_added: 0, buyers_filled: 0, kind: 'items' };
}

// buyer items & rates from the old Excel buyer lists. Adds only item+grade pairs the buyer does not have yet.
function importBuyerItems(body) {
  const rep = { items_added: 0, buyers_touched: 0, items_existing: 0, buyers_not_found: [] };
  require('./db').tx(() => {
    for (const b of body.buyers || []) {
      const ex = (b.gstin && get('SELECT id FROM parties WHERE upper(gstin) = upper(?)', b.gstin)) ||
        get(`SELECT id FROM parties WHERE upper(name) = upper(?) AND upper(COALESCE(city,'')) = upper(?)`, b.name || '', b.city || '');
      if (!ex) { rep.buyers_not_found.push(b.name); continue; }
      let touched = false;
      for (const it of b.items || []) {
        const o = cleanPartyItem(it);
        if (!o.item_name) continue;
        if (get(`SELECT 1 FROM party_items WHERE party_id = ? AND item_name = ? AND COALESCE(grade,'') = COALESCE(?,'')`, ex.id, o.item_name, o.grade)) { rep.items_existing++; continue; }
        o.party_id = ex.id;
        const m = get('SELECT hsn, gst_rate FROM items WHERE name = ? ORDER BY grade = ? DESC LIMIT 1', o.item_name, o.grade || '');
        if (!o.hsn) o.hsn = m?.hsn || '2512';
        if (o.gst_rate == null) o.gst_rate = m?.gst_rate ?? 5;
        const keys = Object.keys(o);
        run(`INSERT INTO party_items(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, ...keys.map(k => o[k]));
        rep.items_added++; touched = true;
      }
      if (touched) rep.buyers_touched++;
    }
  });
  backup.backupSoon('import');
  return { ...rep, buyers_added: [], buyers_other_firm: [], buyers_no_firm: [], invoices_skipped: [], invoices_added: 0, buyers_filled: 0, kind: 'items' };
}

// reports
route('GET', '/api/reports/monthly', ({ q }) => {
  const fy = q.fy || L.fyOf();
  return {
    sales: all(`SELECT substr(date,1,7) ym, firm_code, COUNT(*) n, ROUND(SUM(qty),3) qty, ROUND(SUM(taxable)) taxable,
                ROUND(SUM(cgst+sgst+igst)) tax, ROUND(SUM(total)) total
                FROM (SELECT i.*, (SELECT SUM(qty) FROM invoice_items WHERE invoice_id = i.id) qty FROM invoices i WHERE fy = ? AND cancelled = 0)
                GROUP BY ym, firm_code ORDER BY ym, firm_code`, fy),
    inward: all(`SELECT substr(date,1,7) ym, COUNT(*) n, ROUND(SUM(rawana_wt),3) rawana, ROUND(SUM(actual_wt),3) actual, ROUND(SUM(freight_amt)) freight
                 FROM inwards WHERE fy = ? GROUP BY ym ORDER BY ym`, fy),
    hsn: all(`SELECT i.firm_code, it.hsn, it.gst_rate, ROUND(SUM(it.qty),3) qty, ROUND(SUM(it.amount),2) taxable
              FROM invoice_items it JOIN invoices i ON i.id = it.invoice_id WHERE i.fy = ? AND i.cancelled = 0 GROUP BY 1,2,3 ORDER BY 1,2`, fy)
  };
});

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const q = Object.fromEntries(url.searchParams);
  try {
    let m;
    if ((m = url.pathname.match(/^\/print\/(invoice|label|envelope)\/(\d+)$/))) {
      const inv = L.invoiceFull(m[2]);
      if (!inv) return send(res, 404, 'Not found', 'text/plain');
      const opts = { autoPrint: q.print === '1', shot: q.shot === '1', setup: printSetup(m[1]), singleFromMt: singleCopyMt() };
      const html = m[1] === 'invoice' ? invoiceHtml(inv, { ...opts, copy: q.copy })
        : m[1] === 'label' ? labelHtml(inv, { ...opts, from: q.from, to: q.to, of: q.of }) : envelopeHtml(inv, opts);
      return send(res, 200, html, 'text/html; charset=utf-8');
    }
    if ((m = url.pathname.match(/^\/print\/voucher\/(\d+)$/))) {
      const w = get('SELECT * FROM inwards WHERE id = ?', m[1]);
      return w ? send(res, 200, voucherHtml(w, q.print === '1'), 'text/html; charset=utf-8') : send(res, 404, 'Not found', 'text/plain');
    }
    if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const mm = url.pathname.match(r.re);
      if (!mm) continue;
      const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {};
      if (req.method !== 'GET' && !url.pathname.startsWith('/api/update')) updater.markWrite();
      const out = await r.fn({ p: mm.groups || {}, q, body, req });
      return send(res, 200, out ?? null);
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    if (!e.status) console.error(new Date().toISOString(), req.method, req.url, e);
    send(res, e.status || 500, { error: e.status ? e.message : 'Something went wrong: ' + e.message });
  }
});

if (require.main === module) {
  server.on('error', async e => {
    if (e.code !== 'EADDRINUSE') { console.error(e); process.exit(1); }
    let ours = false;
    try { const r = await fetch(`http://127.0.0.1:${PORT}/api/version`); ours = r.ok && !!(await r.json()).version; } catch { /* not ours */ }
    if (ours) {
      console.log(`\n  Mineral Saathi server is ALREADY RUNNING on this PC (port ${PORT}).`);
      console.log('  Nothing more to do — this extra window can be closed.\n');
      process.exit(2);
    }
    console.log(`\n  Port ${PORT} is used by another program on this PC.`);
    console.log('  Close that program, or restart the PC, then start Mineral Saathi again.\n');
    process.exit(3);
  });
  server.listen(PORT, '0.0.0.0', () => {
    const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
    console.log(`\n  Mineral Saathi server ${VERSION} is running.`);
    console.log(`  On this PC:      http://localhost:${PORT}`);
    for (const ip of ips) console.log(`  On other PCs:    http://${ip}:${PORT}`);
    console.log(`  Data folder:     ${path.dirname(DBF)}${lock.status().shared ? '  (shared — one computer at a time)' : ''}`);
    console.log(`  Backups go to:   ${backup.folder()}\n  Keep this window open (you can minimise it).\n`);
  });
  server.once('listening', () => {
    lock.claim();
    lock.startHeartbeat(lk => {
      console.log(`\n  The data has been opened on "${lk.pc}". This PC stops now so nothing is overwritten.\n`);
      shutdown(2, false);
    });
    for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) process.on(sig, () => shutdown(2));
    updater.start();
    backup.startHourly();
    try { backup.backupNow('start'); } catch (e) { console.error('Start-up backup failed:', e.message); }
  });
}

module.exports = { server, routes };
