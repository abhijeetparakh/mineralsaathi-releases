# Reads the text of an L.R. copy photo with the OCR built into Windows 10 / 11 (offline, no extra program).
# The photo is tried upright and turned 90 / 180 / 270 degrees; the way that gives the most real words is the right way up.
# With -Fix the photo is saved again turned the right way up.  Output: "ANGLE <n>" on the first line, then the text.
param([string]$Image, [switch]$Fix)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language("en-US"))) }
if (-not $engine) { Write-Output "NOOCR"; exit 2 }

function Read-Text([string]$path) {
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $res = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    return (($res.Lines | ForEach-Object { $_.Text }) -join "`n")
  } finally { $stream.Dispose() }
}
function Score([string]$t) { ([regex]::Matches($t, '\b[A-Za-z]{3,}\b')).Count }

$src = [System.Drawing.Image]::FromFile($Image)
$best = $null; $bestAngle = 0; $bestScore = -1
$turns = @{ 0 = [System.Drawing.RotateFlipType]::RotateNoneFlipNone; 90 = [System.Drawing.RotateFlipType]::Rotate90FlipNone; 180 = [System.Drawing.RotateFlipType]::Rotate180FlipNone; 270 = [System.Drawing.RotateFlipType]::Rotate270FlipNone }
try {
  foreach ($a in 0, 90, 270, 180) {
    $bmp = New-Object System.Drawing.Bitmap($src)
    $bmp.RotateFlip($turns[$a])
    $max = [Windows.Media.Ocr.OcrEngine]::MaxImageDimension
    if ($bmp.Width -gt $max -or $bmp.Height -gt $max) { $k = $max / [Math]::Max($bmp.Width, $bmp.Height); $small = New-Object System.Drawing.Bitmap($bmp, [int]($bmp.Width * $k), [int]($bmp.Height * $k)); $bmp.Dispose(); $bmp = $small }
    $tmp = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "ms-lr-ocr-$a-" + [guid]::NewGuid().ToString('N') + ".png")
    $bmp.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
    try { $t = Read-Text $tmp } finally { Remove-Item $tmp -ErrorAction SilentlyContinue }
    $s = Score $t
    if ($s -gt $bestScore) { $best = $t; $bestAngle = $a; $bestScore = $s }
    if ($a -eq 0 -and $s -ge 40) { break }        # clearly upright already
  }
} finally { $src.Dispose() }

if ($Fix -and $bestAngle -ne 0) {
  $img = [System.Drawing.Image]::FromFile($Image); $bmp = New-Object System.Drawing.Bitmap($img); $img.Dispose()
  $bmp.RotateFlip($turns[$bestAngle])
  $fmt = if ($Image -match '\.png$') { [System.Drawing.Imaging.ImageFormat]::Png } else { [System.Drawing.Imaging.ImageFormat]::Jpeg }
  $bmp.Save($Image, $fmt); $bmp.Dispose()
}
Write-Output "ANGLE $bestAngle"
Write-Output $best
