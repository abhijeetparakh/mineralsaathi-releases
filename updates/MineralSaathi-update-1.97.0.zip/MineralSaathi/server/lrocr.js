'use strict';
// L.R. copy: read its L.R. / docket number, and turn a sideways photo the right way up.
// Photos: the OCR built into Windows (lr-ocr.ps1, offline). PDFs: their own text. Elsewhere nothing is read.
const path = require('node:path');
const { execFile } = require('node:child_process');

function ocrImage(file, { fix = true } = {}) {
  if (process.platform !== 'win32') return Promise.resolve(null);
  const ps = path.join(__dirname, 'lr-ocr.ps1');
  return new Promise(resolve => {
    execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps, '-Image', file, ...(fix ? ['-Fix'] : [])],
      { windowsHide: true, timeout: 60000, maxBuffer: 4e6 }, (err, out) => {
        const m = String(out || '').match(/^ANGLE (\d+)\r?\n([\s\S]*)$/m);
        if (err || !m) return resolve(null);
        resolve({ angle: Number(m[1]), text: m[2] });
      });
  });
}

// the L.R. number in the text of an L.R. copy
//  1. a number written after "L.R. No.", "LR No", "G.R. No.", "C.N. No.", "Docket", "Consignment No.", "Bilty", "Waybill"
//  2. else a number of 6–12 digits printed twice (the bar code number is printed under the bar code and at the top)
//  3. else the longest 7–12 digit number that is not a phone number
function parseLrNo(text, known = {}) {
  const t = String(text || '').replace(/[|]/g, ' ');
  const skip = new Set([known.ewb_no, known.inv_no, known.total].filter(Boolean).map(v => String(v).replace(/\D/g, '')));
  const phone = d => d.length === 10 && /^[6-9]/.test(d) || d.length === 12 && /^91[6-9]/.test(d);
  const ok = d => d && d.length >= 4 && d.length <= 14 && !skip.has(d) && !phone(d) && !/^(19|20)\d{6}$/.test(d);
  const kw = /(?:\b(?:L\s*\.?\s*R|G\s*\.?\s*R|C\s*\.?\s*N|LR|GR|CN|AWB|POD)\s*\.?\s*(?:No|Number|#)?\b|Docket(?:\s*No)?|Consignment\s*(?:Note\s*)?No|Bilty(?:\s*No)?|Builty(?:\s*No)?|Way\s*Bill\s*No)[\s.:\-#]*([A-Z]{0,4}[-\/]?\d[\d\-\/ ]{2,15}\d)/gi;
  for (const m of t.matchAll(kw)) { const raw = m[1].replace(/\s+/g, ''), d = raw.replace(/\D/g, ''); if (ok(d) && !/^E\s*-?\s*WAY/i.test(m[0])) return raw.replace(/[-\/]+$/, ''); }
  const nums = [...t.matchAll(/(?<![\d])\d{6,12}(?![\d])/g)].map(x => x[0]).filter(ok);
  const count = new Map(); nums.forEach(n => count.set(n, (count.get(n) || 0) + 1));
  const twice = [...count].filter(([, c]) => c >= 2).map(([n]) => n).sort((a, b) => b.length - a.length);
  if (twice.length) return twice[0];
  const long = nums.filter(n => n.length >= 7).sort((a, b) => b.length - a.length);
  return long[0] || null;
}

module.exports = { ocrImage, parseLrNo };
