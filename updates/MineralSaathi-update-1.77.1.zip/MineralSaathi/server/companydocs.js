'use strict';
// Settings → Companies: each company's documents (GST certificate, PAN card, bank proof, MSME certificate) and its vendor form
// (questions with answers, printed on the letter head with the signature at half size).
// Master → Buyer: "📇 Send company details" emails them to a buyer with the "Company details" template.
const fs = require('node:fs');
const path = require('node:path');
const { all, get, run } = require('./db');
const mailer = require('./mailer');
const { makePdf } = require('./pdf');
const { DATA_DIR } = require('./paths');

run(`CREATE TABLE IF NOT EXISTS firm_docs (id INTEGER PRIMARY KEY, firm_code TEXT NOT NULL, kind TEXT NOT NULL, name TEXT, mime TEXT, data TEXT, at TEXT DEFAULT (datetime('now','localtime')))`);
try { run('ALTER TABLE firms ADD COLUMN vendor_form TEXT'); } catch { /* already there */ }
class E extends Error { constructor(m) { super(m); this.status = 400; } }
const KINDS = { GST: 'GST certificate', PAN: 'PAN card', BANK: 'Bank proof', MSME: 'MSME certificate' };

const COMPANY_VARS = ['Buyer name', 'Contact person', 'Seller name', 'Seller address', 'Seller GSTIN', 'Seller PAN', 'Udyam no.', 'Seller bank details', 'Seller phone', 'Seller email', 'Documents attached', 'Today'];
const STD = 'Dear {Contact person},\n\nGreetings from {Seller name}.\n\nPlease find attached our company details for your vendor registration:\n{Documents attached}\n\nGSTIN: {Seller GSTIN}\nPAN: {Seller PAN}\nUdyam (MSME) no.: {Udyam no.}\nBank: {Seller bank details}\n\nKindly add us to your vendor list. For anything more, please call {Seller phone} or write to {Seller email}.\n\nRegards,\n{Seller name}';
if (!get("SELECT 1 FROM email_templates WHERE purpose = 'COMPANY'"))
  run('INSERT INTO email_templates(name, purpose, body, html, is_default, auto_send) VALUES(?,?,?,?,1,0)', 'Company details', 'COMPANY', STD, mailer.textToHtml(STD));

const firmOf = code => get('SELECT * FROM firms WHERE code = ?', code);
const bankLine = f => [f.bank_name, f.bank_account && 'A/c ' + f.bank_account, f.bank_ifsc && 'IFSC ' + f.bank_ifsc, f.bank_branch].filter(Boolean).join(' - ');
// the vendor form: saved rows, or a first form filled from the company details
function vendorRows(f) {
  try { const r = JSON.parse(f.vendor_form || 'null'); if (Array.isArray(r)) return r; } catch { /* default */ }
  return [['Name Of the Vendor', f.name], ['Vendor Registration Number', f.udyam_no], ['Effective Date', ''], ['Manufacturing Unit Address', [f.address, f.city, f.state].filter(Boolean).join(', ')],
    ['Pincode', f.pincode], ['Name of Contact Person', ''], ['Contact No.', f.phone], ['Email ID', f.email], ['Billing Address (In case different)', ''], ['Pin code', ''],
    ['Company Website if any', ''], ['General Details of Goods / Services', 'Manufacturer & supplier of industrial minerals'], ['Date of company established', ''], ['Gross Annual Sale', ''],
    ['FSSAI License Number', ''], ['GST No', f.gstin], ['Pollution Control Board Consent Number', ''], ['Any other information', ''],
    ['Banking Information', ''], ['A) Bank Name', f.bank_name], ['B) Bank Address', f.bank_branch], ['C) IFSC Code', f.bank_ifsc], ['D) Account number', f.bank_account],
    ['E) Name Of beneficiary', f.name], ['F) MICR Number', ''], ['Any Other Certification Details', f.udyam_no ? 'Udyam (MSME): ' + f.udyam_no : '']].map(([q, a]) => [q, a || '']);
}
// a document as a file (for email): bank proof from the company picture, the others from firm_docs
function docFile(f, kind) {
  const tmp = path.join(DATA_DIR, 'tmp'); fs.mkdirSync(tmp, { recursive: true });
  const clean = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (kind === 'BANK') {
    const d = get("SELECT name, mime, data FROM firm_docs WHERE firm_code = ? AND kind = 'BANK' ORDER BY id DESC LIMIT 1", f.code);
    if (d) { const file = path.join(tmp, clean(`${f.name} ${KINDS.BANK}`) + path.extname(d.name || '')); fs.writeFileSync(file, Buffer.from(d.data, 'base64')); return file; }
    const m = String(f.bank_proof || '').match(/^data:image\/(png|jpeg|webp);base64,(.+)$/); if (!m) return null;
    const file = path.join(tmp, clean(`${f.name} ${KINDS.BANK}`) + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1])); fs.writeFileSync(file, Buffer.from(m[2], 'base64')); return file;
  }
  const d = get('SELECT name, mime, data FROM firm_docs WHERE firm_code = ? AND kind = ? ORDER BY id DESC LIMIT 1', f.code, kind); if (!d) return null;
  const file = path.join(tmp, clean(`${f.name} ${KINDS[kind]}`) + (path.extname(d.name || '') || (d.mime === 'application/pdf' ? '.pdf' : '.jpg')));
  fs.writeFileSync(file, Buffer.from(d.data, 'base64')); return file;
}
const has = (f, kind) => kind === 'BANK' ? !!(f.bank_proof || get("SELECT 1 FROM firm_docs WHERE firm_code = ? AND kind = 'BANK'", f.code)) : !!get('SELECT 1 FROM firm_docs WHERE firm_code = ? AND kind = ?', f.code, kind);

// ---- the vendor form on the letter head (same head as the invoice), signature at half size ----
function vendorHtml(f, opts = {}) {
  const P = require('./print'), esc = P.esc, rows = vendorRows(f).filter(r => r[0] || r[1]);
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10).split('-').reverse().join('.');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Company details — ${esc(f.name)}</title><style>
@page { size: A4; margin: 12mm; } * { box-sizing: border-box; } body { font-family: Arial, Helvetica, sans-serif; color: #1d2b30; margin: 0; font-size: 13px; }
.no-print { padding: 8px; background: #eef3f4; text-align: center; } .no-print button { font-size: 14px; padding: 6px 16px; margin: 0 4px; } @media print { .no-print { display: none; } }
@media screen { body { background: #e7edef; } .page { background: #fff; width: 210mm; min-height: 297mm; margin: 10px auto; padding: 12mm; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
.head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2F4F5A; padding-bottom: 8px; } .firm { font-size: 22px; font-weight: bold; color: #2F4F5A; }
.muted { color: #44575d; font-size: 12px; } .r { text-align: right; } .title { text-align: center; font-size: 18px; font-weight: bold; text-decoration: underline; margin: 20px 0 12px; font-family: Georgia, 'Times New Roman', serif; }
table.vf { width: 100%; border-collapse: collapse; } table.vf th, table.vf td { border: 1px solid #9fb1b6; padding: 7px 9px; vertical-align: top; font-size: 13.5px; } table.vf th { background: #eef3f4; text-align: left; }
.sign { margin-top: 34px; display: flex; justify-content: flex-end; } .sign img { max-height: 31px !important; max-width: 90px !important; }
</style></head><body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
<div class="page">
  <div class="head"><div style="display:flex;gap:14px;align-items:center">${P.brand(f) ? P.brandImg(f, 80, 300) + '<div>' : P.logoTag(f) + `<div><div class="firm">${esc(String(f.name || '').toUpperCase())}</div>`}
    <div class="muted">${esc(f.address || '')}, ${esc(f.city || '')}${f.pincode ? ' - ' + esc(f.pincode) : ''}${f.state ? ' (' + esc(f.state) + ')' : ''}<br>${f.phone ? 'Ph: ' + esc(f.phone) + ' · ' : ''}${esc(f.email || '')}</div></div></div>
    <div class="r" style="white-space:nowrap;padding-left:12px">${f.gstin ? `GSTIN: <b>${esc(f.gstin)}</b><br>` : ''}${f.pan ? 'PAN: ' + esc(f.pan) + '<br>' : ''}Date: <b>${today}</b></div></div>
  <div class="title">COMPANY DETAILS</div>
  <table class="vf"><thead><tr><th style="width:10%;white-space:nowrap">Sl No.</th><th style="width:38%">Particulars</th><th>Details</th></tr></thead>
    <tbody>${(() => { let n = 0; return rows.map(r => { const sub = /^[A-Za-z]\)\s*/.test(r[0]);
      return `<tr><td style="text-align:center">${sub ? '' : ++n + '.'}</td><td${sub ? ' style="padding-left:22px"' : ''}>${esc(r[0])}</td><td><b>${esc(r[1]).replace(/\n/g, '<br>')}</b></td></tr>`; }).join(''); })()}</tbody></table>
  <p class="muted" style="margin-top:12px">We confirm that the above details are true and correct.</p>
  <div class="sign"><div class="r">For <b>${esc(f.name || '')}</b><div style="height:36px;display:flex;justify-content:flex-end;align-items:center">${P.signTag(f)}</div>Authorised signatory</div></div>
</div>${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}
function serveVendor(code, q) { const f = firmOf(code); return f ? vendorHtml(f, { shot: q.shot === '1', autoPrint: q.print === '1' }) : null; }

// ---- the "Company details" email to a buyer ----
function buyerOf(q) {
  if (q.b2c) { const c = get('SELECT * FROM b2c_customers WHERE id = ?', q.b2c); if (!c) throw new E('Customer not found.'); return { name: c.name, contact: c.contact_person, email: c.email, firm: 'PM' }; }
  const p = get('SELECT * FROM parties WHERE id = ?', q.party); if (!p) throw new E('Buyer not found.'); return { name: p.name, contact: p.contact_person, email: p.email, firm: p.firm_code || 'PM' };
}
function values(f, b, attached) {
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10).split('-').reverse().join('.');
  return { 'buyer name': b.name, 'contact person': b.contact || 'Sir / Madam', 'seller name': f.name, 'seller address': [f.address, f.city, f.state, f.pincode].filter(Boolean).join(', '),
    'seller gstin': f.gstin || '', 'seller pan': f.pan || '', 'udyam no.': f.udyam_no || '', 'seller bank details': bankLine(f), 'seller phone': f.phone || '', 'seller email': f.email || '',
    'documents attached': attached.map((x, i) => `${i + 1}. ${x}`).join('\n'), today };
}
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// a line "Label: {Field}" whose field is empty is left out (e.g. no bank details yet)
function dropEmpty(tpl, v, html) {
  const empty = k => { const r = v[k.trim().toLowerCase()]; return r != null && !String(r).trim(); };
  if (!html) return String(tpl || '').split('\n').filter(l => { const m = l.match(/^[^{}]*:\s*\{([^{}]+)\}\s*$/); return !(m && empty(m[1])); }).join('\n');
  return String(tpl || '').replace(/(<br\s*\/?>)?[^<>{}]*:\s*\{([^{}<>]+)\}\s*(<br\s*\/?>)?/gi, (m, a, k, b) => empty(k) ? (a && b ? a : '') : m)
    .replace(/<p[^>]*>\s*<\/p>/gi, '');
}
function fill(tpl, v, html) { tpl = dropEmpty(tpl, v, html); return String(tpl || '').replace(/\{([^{}<>]+)\}/g, (m, k) => { const r = v[k.trim().toLowerCase()]; return r == null ? m : html ? esc(r).replace(/\n/g, '<br>') : r; }); }
const ATT = [['GST', KINDS.GST], ['PAN', KINDS.PAN], ['BANK', KINDS.BANK], ['MSME', KINDS.MSME], ['VENDOR', 'Vendor registration form']];

function register(route, { smtpSend, brandLogo, port, pdfFolder }) {
  route('GET', '/api/firm-docs/:code', ({ p }) => {
    const f = firmOf(p.code); if (!f) throw new E('Company not found.');
    const docs = all('SELECT id, kind, name, mime, at FROM firm_docs WHERE firm_code = ? ORDER BY id', f.code);
    return { kinds: KINDS, docs, bank_picture: !!f.bank_proof, vendor: vendorRows(f), vendor_saved: !!f.vendor_form };
  });
  route('POST', '/api/firm-docs/:code', ({ p, body }) => {
    const f = firmOf(p.code); if (!f) throw new E('Company not found.'); if (!KINDS[body.kind]) throw new E('Unknown document.');
    const m = String(body.data || '').match(/^data:([^;]+);base64,(.+)$/); if (!m) throw new E('No file.');
    if (!/^(application\/pdf|image\/(png|jpeg|webp))$/.test(m[1])) throw new E('Upload a PDF or a photo (JPG / PNG).');
    if (m[2].length > 14e6) throw new E('The file is too big (10 MB at most).');
    run('DELETE FROM firm_docs WHERE firm_code = ? AND kind = ?', f.code, body.kind);
    run('INSERT INTO firm_docs(firm_code, kind, name, mime, data) VALUES(?,?,?,?,?)', f.code, body.kind, String(body.name || KINDS[body.kind]).slice(0, 120), m[1], m[2]);
    return { ok: true };
  });
  route('DELETE', '/api/firm-docs/:id', ({ p }) => { run('DELETE FROM firm_docs WHERE id = ?', p.id); return { deleted: true }; });
  route('PUT', '/api/vendor-form/:code', ({ p, body }) => {
    const f = firmOf(p.code); if (!f) throw new E('Company not found.');
    const rows = (Array.isArray(body.rows) ? body.rows : []).map(r => [String((r || [])[0] ?? '').trim(), String((r || [])[1] ?? '').trim()]).filter(r => r[0] || r[1]);
    run('UPDATE firms SET vendor_form = ? WHERE code = ?', JSON.stringify(rows), f.code); return { ok: true };
  });
  route('GET', '/api/company-mail', ({ q }) => {
    const b = buyerOf(q), f = firmOf(q.firm || b.firm) || firmOf('PM');
    const tpl = q.tid ? get('SELECT * FROM email_templates WHERE id = ?', q.tid) : get("SELECT * FROM email_templates WHERE purpose = 'COMPANY' AND active = 1 ORDER BY is_default DESC, id LIMIT 1");
    const att = ATT.map(([k, label]) => ({ k, label, has: k === 'VENDOR' ? true : has(f, k) }));
    const v = values(f, b, att.filter(a => a.has).map(a => a.label)), to = mailer.splitAddr(b.email);
    return { firm_code: f.code, firm: f.name, from: f.smtp_user || f.email || '', ready: !!(f.smtp_user && f.smtp_pass), buyer: b.name, to: to.slice(0, 1).join('; '), cc: to.slice(1).join('; '),
      subject: `Company details for vendor registration — ${f.name}`, text: fill(tpl ? tpl.body : STD, v), html: fill(tpl && tpl.html ? tpl.html : mailer.textToHtml(tpl ? tpl.body : STD), v, true),
      template_name: tpl ? tpl.name : 'Company details', att, firms: all("SELECT code, name FROM firms WHERE code IN ('PM', 'PF') ORDER BY id"),
      templates: all("SELECT id, name, is_default FROM email_templates WHERE purpose = 'COMPANY' AND active = 1 ORDER BY is_default DESC, name") };
  });
  route('POST', '/api/company-mail', async ({ body }) => {
    const b = buyerOf(body), f = firmOf(body.firm || b.firm); if (!f) throw new E('Company not found.');
    const to = mailer.splitAddr(body.to), cc = mailer.splitAddr(body.cc), a = body.attach || {}, attachments = [], done = [];
    const log = (status, error) => run('INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)',
      f.code, f.name, b.name, to.join('; '), body.template_name || 'Company details', 'Company details', 'Company details', status, error || null, status === 'SENT' ? done.join(', ') : null);
    try {
      if (!f.smtp_user || !f.smtp_pass) throw new E(`Email is not set up for ${f.name}. Open Settings → Companies → Email.`);
      if (!to.length) throw new E('Enter the buyer email address.');
      for (const [k, label] of ATT) {
        if (!a[k]) continue;
        if (k === 'VENDOR') {
          const file = path.join(pdfFolder(), 'Company', String(`${f.name} Vendor registration form`).replace(/[\\/:*?"<>|]+/g, ' ') + '.pdf');
          await makePdf(`http://127.0.0.1:${port()}/print/vendorform/${f.code}?shot=1`, file); attachments.push({ path: file, filename: path.basename(file) }); done.push(label); continue;
        }
        const file = docFile(f, k); if (file) { attachments.push({ path: file, filename: path.basename(file) }); done.push(label); }
      }
      await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
        { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || `Company details — ${f.name}`, text: body.text || mailer.htmlToText(body.html || ''), html: body.html || undefined, attachments });
      log('SENT'); return { sent: true, attached: done };
    } catch (e) { log('FAILED', e.message); throw e; }
  });
}
// GET /firm-doc/:id — view an uploaded document
function serveDoc(id, res, send) {
  const d = get('SELECT * FROM firm_docs WHERE id = ?', id); if (!d) return send(res, 404, 'Not found', 'text/plain');
  res.writeHead(200, { 'Content-Type': d.mime, 'Content-Disposition': `inline; filename="${String(d.name || 'document').replace(/"/g, '')}"`, 'Cache-Control': 'no-cache' });
  res.end(Buffer.from(d.data, 'base64'));
}
module.exports = { register, serveVendor, serveDoc, COMPANY_VARS };
