'use strict';
/* Mineral Saathi — Marketing (Sampark Saathi) screens.
   Marketing data lives in its own file (marketing.db); items, companies, printers and the other settings
   are the shared Mineral Saathi ones. Uses the helpers of app.js ($, GET, POST, PAGES, SETTINGS …). */

const MKT_LISTS = [
  ['sample_size', 'Sample size', '100 gm, 500 gm, 1 kg …'],
  ['courier', 'Courier / sent by', 'India Post, DHL, Blue Dart …'],
  ['response', 'Call response', 'Called, no response, not reachable …'],
  ['followup_reason', 'Follow-up reason', 'Why the next call is made'],
  ['templates', 'WhatsApp messages', 'Ready texts for the Communication screen']
];
const MKT_PAGES = {
  calls: ["Today's Calls", 4, 'Calls due today (or any date), overdue calls in red; click a call to open Communication.'],
  new: ['New Sample Dispatch', 2, 'Enquiry and sample details, grade from Master → Item List, tick the papers to print and Print All.'],
  leads: ['Enquiries', 2, 'All enquiries with search by ref. no., company, name, mobile and city, with their samples and calls.'],
  comm: ['Communication', 4, 'History, WhatsApp messages with QR, log the response and plan the next call (Google Calendar).'],
  quick: ['Quick Sticker', 4, 'A 4×6 QR sticker for a walk-in or phone enquiry.'],
  letters: ['Letters', 4, 'Letter Pad, Bus and blank envelope with the sender from Settings → Companies.'],
  reports: ['Marketing Reports', 5, 'Samples by month, grade and courier; pending and overdue calls; enquiries that became buyers.'],
  lists: ['Marketing Lists', 1, '']
};
const TPL_FIELDS = ['{name}', '{company}', '{ref}', '{courier}', '{tracking_no}', '{tracking_link}'];

// show or hide the 📣 Marketing menu (Settings → Marketing)
async function mktMenu() {
  try { const s = await GET('/api/mkt/status'); $('#nav-mkt').hidden = !s.settings.enabled; return s; } catch { return null; }
}
mktMenu();

PAGES.mkt = async (el, arg) => {
  const [page, sub] = String(arg || 'calls').split(':');
  const def = MKT_PAGES[page] || MKT_PAGES.calls;
  $('#title').textContent = def[0];
  const st = await GET('/api/mkt/status');
  if (!st.ok) {
    el.innerHTML = `<div class="card" style="max-width:720px"><h3>⚠ Marketing data cannot be opened</h3>
      <p style="white-space:pre-line">${esc(st.problem || '')}</p><p class="hint">File: ${esc(st.file)}</p></div>`;
    return;
  }
  if (page === 'lists') return mktListsPage(el, sub || 'sample_size');
  el.innerHTML = `<div class="card" style="max-width:720px"><h3>${esc(def[0])}</h3><p>${esc(def[2])}</p>
    <p><span class="badge amber">Coming in phase ${def[1]}</span></p>
    <p class="hint">Marketing data so far: ${st.counts.leads} enquiries · ${st.counts.samples} samples · ${st.counts.follow_ups_pending} calls pending.</p></div>`;
};

// ---------- Marketing Lists ----------
async function mktListsPage(box, key) {
  if (!MKT_LISTS.some(x => x[0] === key)) key = 'sample_size';
  if (key === 'templates') return mktTemplatesPage(box);
  const lists = await GET('/api/mkt/lists');
  const tpls = await GET('/api/mkt/templates');
  const def = MKT_LISTS.find(x => x[0] === key);
  const rows = lists[key] || [];
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide(key, lists, tpls)}
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="mlf" class="row" style="margin-bottom:14px">
        <label style="flex:1">New value<input name="value" autocomplete="off"></label>
        <button type="submit" id="mlsave">Add</button><button type="button" class="sec" id="mlcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>Value</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="2" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table>
      <p class="hint" style="margin-top:12px">Grade, mesh, colour, bag type, bag weight, packing type and unit are not kept here — Marketing uses
        <a href="#/itemlists">Master → Item List</a>, the same lists as billing.</p></div></div>`;
  const f = $('#mlf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault();
    await guard(() => editing ? PUT('/api/mkt/lists/' + editing, { value: f.value.value }) : POST('/api/mkt/lists', { list_key: key, value: f.value.value }));
    toast(editing ? 'Updated' : 'Added'); mktListsPage(box, key);
  };
  $('#mlcancel', box).onclick = () => mktListsPage(box, key);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value;
      $('#mlsave', box).textContent = 'Update'; $('#mlcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Samples and calls that already use it keep it.')) { await guard(() => DEL('/api/mkt/lists/' + rm.dataset.rm)); mktListsPage(box, key); }
  };
}

function mktListSide(key, lists, tpls) {
  return `<div class="card listside" style="padding:8px">${MKT_LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/mkt/lists:${k}')">
    <b>${t}</b><span class="badge grey">${k === 'templates' ? tpls.length : (lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>`;
}

// ---------- WhatsApp message templates ----------
function mktFill(body) {   // example of a filled message
  const ex = { '{name}': 'RAMESH KUMAR', '{company}': 'ABC MINERALS', '{ref}': '434', '{courier}': 'DHL', '{tracking_no}': 'RR123456789IN',
    '{tracking_link}': 'https://t.17track.net/en#nums=RR123456789IN' };
  return TPL_FIELDS.reduce((s, k) => s.split(k).join(ex[k]), body);
}
async function mktTemplatesPage(box) {
  const [lists, tpls] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/templates')]);
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide('templates', lists, tpls)}
    <div class="card"><h3>WhatsApp messages <span class="hint">— ready texts for the Communication screen</span></h3>
      <form id="mtf" class="grid" style="grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <label>Name<input name="name" autocomplete="off"></label>
        <div class="hint" style="align-self:end">Words filled in by themselves: ${TPL_FIELDS.map(x => `<code data-ins="${x}" style="cursor:pointer" title="Click to add">${x}</code>`).join(' ')}</div>
        <label style="grid-column:1/3">Message<textarea name="body" rows="5"></textarea></label>
        <div style="grid-column:1/3" class="row"><button type="submit" id="mtsave">Add</button><button type="button" class="sec" id="mtcancel" hidden>Cancel</button></div>
        <div style="grid-column:1/3" id="mtprev" class="hint" hidden></div>
      </form>
      <table class="t"><thead><tr><th style="width:190px">Name</th><th>Message</th><th style="width:150px"></th></tr></thead><tbody>
      ${tpls.map(t => `<tr><td><b>${esc(t.name)}</b></td><td style="white-space:pre-line">${esc(t.body)}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${t.id}">Edit</button> <button class="small sec" data-rm="${t.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="3" class="muted">No messages yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#mtf', box); let editing = null;
  const prev = () => { const p = $('#mtprev', box); p.hidden = !f.body.value.trim(); p.innerHTML = '<b>Example:</b><br>' + esc(mktFill(f.body.value)).replace(/\n/g, '<br>'); };
  f.body.oninput = prev;
  f.onsubmit = async e => {
    e.preventDefault(); const d = { name: f.name.value, body: f.body.value };
    await guard(() => editing ? PUT('/api/mkt/templates/' + editing, d) : POST('/api/mkt/templates', d));
    toast(editing ? 'Updated' : 'Added'); mktTemplatesPage(box);
  };
  $('#mtcancel', box).onclick = () => mktTemplatesPage(box);
  box.onclick = async e => {
    const ins = e.target.closest('[data-ins]'), ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ins) { const t = f.body, a = t.selectionStart ?? t.value.length; t.value = t.value.slice(0, a) + ins.dataset.ins + t.value.slice(t.selectionEnd ?? a); t.focus(); prev(); }
    if (ed) { const t = tpls.find(x => x.id === Number(ed.dataset.ed)); editing = t.id; f.name.value = t.name; f.body.value = t.body; prev();
      $('#mtsave', box).textContent = 'Update'; $('#mtcancel', box).hidden = false; f.name.focus(); }
    if (rm && confirm('Remove this message?')) { await guard(() => DEL('/api/mkt/templates/' + rm.dataset.rm)); mktTemplatesPage(box); }
  };
}

// ---------- Settings → Marketing ----------
SETTINGS.marketing = async box => {
  const [s, st] = await Promise.all([GET('/api/mkt/settings'), GET('/api/mkt/status')]);
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  box.innerHTML = `<div class="grid g2" style="align-items:start">
    <div class="card"><h3>📣 Marketing</h3>
      <form id="mkf" class="grid" style="gap:12px">
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="enabled" style="width:auto" ${s.enabled ? 'checked' : ''}> Show the Marketing menu</label>
        ${field({ name: 'default_firm', label: 'Sender on Marketing papers (Settings → Companies)', type: 'select', options: s.firms.map(x => [x.code, x.name]) }, s.default_firm)}
        ${field({ name: 'followup_days', label: 'Days until the first “Did the sample arrive?” call', type: 'number' }, s.followup_days)}
        ${field({ name: 'tracking_url', label: 'Tracking link — {tracking_no} is replaced by the number' }, s.tracking_url)}
        <div class="row"><button type="submit">Save</button></div>
      </form>
      <p class="hint">The Google Calendar link is in <a href="#/settings/data">Settings → Data Location</a>.</p>
      <p class="hint">These are settings, saved with the other Mineral Saathi settings. Companies, printers, backup and data location are the same for billing and Marketing.</p></div>
    <div class="card"><h3>Marketing data</h3>
      ${st.ok ? `<p><span class="badge PM">Open</span> &nbsp;${esc(st.file)} · ${kb(st.size)}</p>
        <table class="t"><tbody>
          <tr><td>Enquiries</td><td class="num">${st.counts.leads}</td></tr>
          <tr><td>Samples</td><td class="num">${st.counts.samples}</td></tr>
          <tr><td>Calls pending</td><td class="num">${st.counts.follow_ups_pending}</td></tr>
          <tr><td>Calls and messages logged</td><td class="num">${st.counts.communications}</td></tr>
          <tr><td>Quick stickers</td><td class="num">${st.counts.quick_stickers}</td></tr></tbody></table>`
        : `<p><span class="badge red">Cannot open</span></p><p style="white-space:pre-line">${esc(st.problem || '')}</p>`}
      <p class="hint" style="margin-top:10px">Kept in its own file next to mineral.db — never mixed with billing data. It is in every backup
        (Marketing_yyyy-mm-dd.db) and moves with the data when the data location changes.</p></div></div>`;
  $('#mkf', box).onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    await guard(() => PUT('/api/mkt/settings', { enabled: f.enabled.checked, default_firm: f.default_firm.value, followup_days: f.followup_days.value,
      tracking_url: f.tracking_url.value }));
    toast('Saved'); await mktMenu();
  };
};

// ---------- Settings → Data Location: Google Calendar link (Marketing follow-up calls) ----------
{
  const dataPage = SETTINGS.data;
  SETTINGS.data = async box => {
    await dataPage(box);
    const s = await GET('/api/mkt/settings');
    const card = document.createElement('div'); card.className = 'card';
    card.innerHTML = `<h3>📅 Google Calendar <span class="hint">— Marketing follow-up calls</span></h3>
      <p class="hint">The Apps Script web-app link (ends with <code>/exec</code>). Every planned call is sent to Google Calendar with the customer's phone and WhatsApp link.</p>
      <div class="row"><label style="flex:1">Calendar link<input id="calurl" value="${esc(s.calendar_url)}" placeholder="https://script.google.com/macros/s/…/exec" autocomplete="off"></label>
        <button id="calsave">Save</button><button class="sec" id="caltest">Test connection</button></div>
      <p class="hint" style="margin-top:8px">Test connection creates one event 10 minutes from now named “Mineral Saathi — test connection”; delete it afterwards.</p>
      <div id="calres" style="margin-top:8px" hidden></div>`;
    box.appendChild(card);
    const inp = $('#calurl', card), res = $('#calres', card);
    const show = (ok, msg, reply) => { res.hidden = false;
      res.innerHTML = `<span class="badge ${ok ? 'PM' : 'red'}">${ok ? '✓ Connected' : '✕ Not connected'}</span> ${esc(msg)}${reply ? `<br><span class="hint">Google replied: ${esc(reply)}</span>` : ''}`; };
    $('#calsave', card).onclick = async () => { await guard(() => PUT('/api/mkt/settings', { calendar_url: inp.value })); toast(inp.value.trim() ? 'Calendar link saved' : 'Calendar link removed'); };
    $('#caltest', card).onclick = async () => {
      const b = $('#caltest', card); b.disabled = true; b.textContent = 'Testing…'; res.hidden = true;
      try { const r = await guard(() => POST('/api/mkt/calendar/test', { url: inp.value })); show(r.ok, r.message, r.reply); }
      catch { /* message shown */ } finally { b.disabled = false; b.textContent = 'Test connection'; }
    };
  };
}
