'use strict';
// GSTIN → name and address from the official GST portal ("Search Taxpayer", the same page as gst.gov.in).
// The portal asks for a captcha: its picture is shown in Mineral Saathi and the user types it.
const https = require('https');
const crypto = require('crypto');

const HOST = 'services.gst.gov.in';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';
const sessions = new Map();          // id → { cookies, at }

function req(method, path, { cookies = '', body = null } = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? Buffer.from(JSON.stringify(body)) : null;
    const r = https.request({ host: HOST, path, method, timeout: 20000, headers: {
      'User-Agent': UA, Accept: method === 'GET' ? 'image/png,image/*,*/*' : 'application/json, text/plain, */*', Origin: 'https://services.gst.gov.in',
      Referer: 'https://services.gst.gov.in/services/searchtp', ...(cookies ? { Cookie: cookies } : {}),
      ...(data ? { 'Content-Type': 'application/json;charset=UTF-8', 'Content-Length': data.length } : {}) } }, res => {
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    r.on('timeout', () => r.destroy(new Error('The GST portal did not answer. Try again.')));
    r.on('error', e => reject(/ENOTFOUND|EAI_AGAIN|ECONN/.test(e.code || e.message) ? new Error('Cannot reach the GST portal. Check the internet.') : e));
    if (data) r.write(data); r.end();
  });
}
const cookieOf = (headers, old = '') => {
  const jar = new Map(old.split(/;\s*/).filter(Boolean).map(c => { const i = c.indexOf('='); return [c.slice(0, i), c.slice(i + 1)]; }));
  for (const sc of [].concat(headers['set-cookie'] || [])) { const kv = sc.split(';')[0]; const i = kv.indexOf('='); if (i > 0) jar.set(kv.slice(0, i).trim(), kv.slice(i + 1)); }
  return [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
};

// a new captcha picture (and the portal session it belongs to)
async function captcha(oldId) {
  for (const [k, s] of sessions) if (Date.now() - s.at > 15 * 60e3) sessions.delete(k);
  let cookies = oldId && sessions.get(oldId) ? sessions.get(oldId).cookies : '';
  if (!cookies) { try { const home = await req('GET', '/services/searchtp'); cookies = cookieOf(home.headers); } catch { /* the captcha call sets the cookie too */ } }
  const r = await req('GET', `/services/captcha?rnd=${Math.random()}`, { cookies });
  if (r.status !== 200 || r.body.length < 100) throw new Error(`The GST portal did not give a captcha (${r.status}). Try again in a minute.`);
  cookies = cookieOf(r.headers, cookies);
  const id = oldId && sessions.has(oldId) ? oldId : crypto.randomBytes(8).toString('hex');
  sessions.set(id, { cookies, at: Date.now() });
  const type = /png/i.test(r.headers['content-type'] || '') || r.body[0] === 0x89 ? 'image/png' : 'image/jpeg';
  return { id, image: `data:${type};base64,${r.body.toString('base64')}` };
}

const T = s => String(s || '').replace(/\s+/g, ' ').trim();
const STATES = ['ANDHRA PRADESH', 'ARUNACHAL PRADESH', 'ASSAM', 'BIHAR', 'CHHATTISGARH', 'GOA', 'GUJARAT', 'HARYANA', 'HIMACHAL PRADESH', 'JHARKHAND', 'KARNATAKA', 'KERALA',
  'MADHYA PRADESH', 'MAHARASHTRA', 'MANIPUR', 'MEGHALAYA', 'MIZORAM', 'NAGALAND', 'ODISHA', 'PUNJAB', 'RAJASTHAN', 'SIKKIM', 'TAMIL NADU', 'TELANGANA', 'TRIPURA',
  'UTTAR PRADESH', 'UTTARAKHAND', 'WEST BENGAL', 'ANDAMAN AND NICOBAR ISLANDS', 'CHANDIGARH', 'DADRA AND NAGAR HAVELI AND DAMAN AND DIU', 'DELHI', 'JAMMU AND KASHMIR', 'LADAKH',
  'LAKSHADWEEP', 'PUDUCHERRY', 'ORISSA', 'UTTARANCHAL', 'PONDICHERRY', 'NCT OF DELHI'];
async function lookup(id, gstin, text) {
  const s = sessions.get(id); if (!s) throw new Error('The captcha has expired — press ↻ for a new one.');
  gstin = String(gstin || '').toUpperCase().replace(/\s/g, '');
  if (!/^\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]{3}$/.test(gstin)) throw new Error('The GSTIN is not right — 15 letters and numbers, e.g. 08AIVPP2793C1ZQ.');
  const r = await req('POST', '/services/api/search/taxpayerDetails', { cookies: s.cookies, body: { gstin, captcha: String(text || '').trim() } });
  let j; try { j = JSON.parse(r.body.toString('utf8')); } catch { throw new Error(`The GST portal answered something unexpected (${r.status}). Try again.`); }
  if (j.errorCode || j.error || !j.lgnm) {
    const code = String(j.errorCode || (j.error && j.error.error_cd) || '');
    if (/SWEB_9000|captcha/i.test(code + JSON.stringify(j))) throw Object.assign(new Error('The captcha was not right. Type the new one.'), { captcha: true });
    if (/FO8000|not found|invalid/i.test(code + JSON.stringify(j))) throw new Error('No taxpayer with this GSTIN on the GST portal.');
    throw new Error('The GST portal did not give the details' + (code ? ` (${code})` : '') + '. Try again.');
  }
  sessions.delete(id);
  const a = (j.pradr && (j.pradr.addr || j.pradr.address)) || {};
  const full = T(j.pradr && (j.pradr.adr || j.pradr.address_text)) || [a.bno, a.flno, a.bnm, a.st, a.loc, a.city, a.dst, a.stcd, a.pncd].map(T).filter(Boolean).join(', ');
  let street = [a.bno, a.flno, a.bnm, a.st, a.loc].map(T).filter(Boolean).join(', '), city = T(a.city || a.dst || a.loc), district = T(a.dst), state = T(a.stcd), pincode = T(a.pncd);
  // the portal often gives only one line: "F 106, RIICO, Mandore Road, …, Jodhpur, Rajasthan, 342304" → address / city / state / pincode
  if (!pincode || !state) {
    const parts = full.split(',').map(T).filter(Boolean);
    if (parts.length && /^\d{6}$/.test(parts[parts.length - 1])) pincode = pincode || parts.pop();
    const si = parts.findIndex((x, i) => i >= parts.length - 2 && STATES.includes(x.toUpperCase().replace(/&/g, 'AND')));
    if (si >= 0) { state = state || parts[si]; parts.splice(si); }
    if (parts.length > 1) { const c = parts.pop(); city = city || c; district = district || c; }
    if (!street) street = parts.join(', ');
  }
  return { gstin, legal_name: T(j.lgnm), trade_name: T(j.tradeNam), status: T(j.sts), type: T(j.dty), since: T(j.rgdt),
    address: street || full, city, district, state, pincode, full_address: full, pan: gstin.slice(2, 12) };
}

module.exports = { captcha, lookup };
