'use strict';
// Printable pages (A4). The app opens these to print or save as PDF; email uses them to make the PDF.
const { get } = require('./db');
const { inWords, freightFigures, freightRate, r2, bankUpi } = require('./logic');
const qr = require('./qr');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const qty = n => { const v = Math.round((Number(n) || 0) * 1000) / 1000; return v.toLocaleString('en-IN', Number.isInteger(v) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 3, maximumFractionDigits: 3 }); };   // 35 or 21.500
const dmy = iso => iso ? iso.split('-').reverse().join('.') : '';
const nl = s => esc(s).replace(/\n/g, '<br>');

const BASE_CSS = `
* { box-sizing: border-box; }
body { font-family: "Segoe UI", Arial, sans-serif; font-size: 11.5px; color: #1d2b31; margin: 0; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #2F4F5A; padding: 4px 6px; vertical-align: top; }
th { background: #e8f1f3; font-weight: 600; text-align: left; }
.r { text-align: right; } .c { text-align: center; }
.head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #9A4A2A; padding-bottom: 6px; margin-bottom: 6px; }
.firm { font-size: 24px; font-weight: 800; color: #2F4F5A; letter-spacing: .5px; }
.muted { color: #5b6b70; }
.title { font-size: 15px; font-weight: 700; color: #9A4A2A; text-align: right; }
.box { border: 1px solid #2F4F5A; padding: 6px 8px; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 6px; }
.lbl { color: #5b6b70; font-size: 10px; text-transform: uppercase; letter-spacing: .4px; }
.big { font-size: 13px; font-weight: 700; }
.tot td { font-weight: 700; background: #f4ece7; white-space: nowrap; }
.sign { height: 60px; }
.no-print { background: #1A3E4A; padding: 10px; margin-bottom: 14px; text-align: center; }
.no-print button { font-size: 14px; padding: 8px 16px; background: #1A9BB5; color: #fff; border: 0; border-radius: 6px; cursor: pointer; margin-left: 6px; }
@media print { .no-print { display: none; } }
/* A4 invoice: bigger type, spread over the whole page */
.invp { display: flex; flex-direction: column; font-size: 13.5px; line-height: 1.38; }
.invp td, .invp th { padding: 5px 8px; }
.invp .firm { font-size: 31px; } .invp .title { font-size: 20px; } .invp .big { font-size: 16px; }
.invp .lbl { font-size: 11px; } .invp .copyl { font-size: 11px; font-weight: 700; letter-spacing: .6px; color: #5b6b70; }
.invp .head { padding-bottom: 8px; margin-bottom: 8px; }
.invp .grid2 { gap: 8px; margin-bottom: 8px; }
.invp .box { padding: 8px 10px; }
.invp .kv td { border: 0; padding: 3px 6px; } .invp .kv td:nth-child(odd) { white-space: nowrap; color: #44575d; } .invp .kv td:nth-child(2) { white-space: nowrap; }
.invp .head > div:last-child { white-space: nowrap; padding-left: 12px; }
.invp .grow { flex: 1 0 auto; display: flex; }
.invp .items { height: 100%; }
.invp .items tbody tr:not(.fill) { height: 1px; }
.invp .items td { border-top-color: #c9d6da; border-bottom-color: #c9d6da; }
.invp .items .fx td { border-top-color: #2F4F5A; }
.invp .words, .invp .hsn, .invp .freight, .invp .foot, .invp .bankbox { margin-top: 8px; }
.invp .bankd { margin-top: 8px; padding-top: 6px; border-top: 1px dashed #9aa; font-size: 12.5px; }
.invp .freight { font-size: 14px; background: #fbf7f4; }
.invp .foot { display: grid; grid-template-columns: 1.5fr 1fr; gap: 8px; margin-top: auto !important; padding-top: 8px; }
.invp .foot.withqr { grid-template-columns: 1.45fr 140px 1fr; }
.invp .qrbox { text-align: center; padding: 6px; overflow-wrap: anywhere; } .invp .qrbox svg { display: block; margin: 2px auto; }
.invp .terms { font-size: 12px; } .invp .sigbox { display: flex; flex-direction: column; justify-content: space-between; } .invp .sign { height: 42px; display: flex; align-items: center; justify-content: flex-end; } .invp .sign img { max-height: 40px !important; max-width: 130px !important; }
`;

// the firm's signature (Settings → Companies), on its invoices and vouchers
const signTag = f => f.signature && /^data:image\/(png|jpeg|webp);base64,/.test(f.signature) ? `<img src="${f.signature}" style="max-height:62px;max-width:180px">` : '';
// Parakh Marketing / Parakh Fertilizer with a logo: the logo is printed instead of the name
const brand = f => f && ['PM', 'PF'].includes(f.code) && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo || '');
const brandImg = (f, h, w) => `<img src="${f.logo}" alt="" style="max-height:${h}px;max-width:${w}px;display:block">`;
// Code 128 barcode (SVG) — the e-way bill number on the invoice
const C128 = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
function barcode128(text, h = 34, unit = 1.3) {
  const s = String(text || '').replace(/\s/g, '');
  if (!s) return '';
  let codes;
  if (/^\d+$/.test(s) && s.length % 2 === 0) { codes = [105]; for (let i = 0; i < s.length; i += 2) codes.push(Number(s.slice(i, i + 2))); }      // Code C: digit pairs
  else { codes = [104]; for (const ch of s) codes.push(Math.max(0, Math.min(94, ch.charCodeAt(0) - 32))); }                                   // Code B
  codes.push(codes.reduce((sum, c, i) => sum + c * (i || 1), 0) % 103, 106);
  let x = 10 * unit, bars = '';
  for (const c of codes) { const pat = C128[c]; for (let i = 0; i < pat.length; i++) { const w = Number(pat[i]) * unit; if (i % 2 === 0) bars += `<rect x="${x.toFixed(2)}" y="0" width="${w.toFixed(2)}" height="${h}"/>`; x += w; } }
  const W = x + 10 * unit;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W.toFixed(1)}" height="${h}" viewBox="0 0 ${W.toFixed(1)} ${h}" style="display:block"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">${bars}</g></svg>`;
}
// UPI does not allow one payment above ₹1 lakh: such QR codes carry only the UPI id (no amount)
const UPI_LIMIT = 100000;
const logoTag = f => f.logo && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo) ? `<img src="${f.logo}" style="max-height:62px;max-width:150px">` : '';

// ---- page setup: paper size, margin, nudge and scale (Settings > This computer > Printers) ----
const PAPERS = {
  A4: [210, 297], A5: [148, 210], LETTER: [215.9, 279.4], LABEL4X6: [101.6, 152.4],
  ENV_DL: [220, 110], ENV_C5: [229, 162], ENV_10: [241, 105]
};
const DEFAULT_SETUP = {
  invoice: { paper: 'A4', w: 210, h: 297, margin: 10, ox: 0, oy: 0, scale: 100 },
  label: { paper: 'LABEL4X6', w: 101.6, h: 152.4, margin: 3, ox: 0, oy: 0, scale: 100 },
  envelope: { paper: 'ENV_DL', w: 220, h: 110, margin: 8, ox: 0, oy: 0, scale: 100 }
};
function setupFor(kind, s) {
  const d = { ...DEFAULT_SETUP[kind], ...(s || {}) };
  if (d.paper && PAPERS[d.paper]) { const [w, h] = PAPERS[d.paper]; d.w = w; d.h = h; }
  if (d.landscape) { const a = Math.max(d.w, d.h), b = Math.min(d.w, d.h); d.w = a; d.h = b; }
  for (const k of ['w', 'h', 'margin', 'ox', 'oy', 'scale']) d[k] = Number(d[k]) || (k === 'scale' ? 100 : 0);
  return d;
}
function sheetCss(s, shot) {
  const sc = (s.scale || 100) / 100;
  return `@page { size: ${s.w}mm ${s.h}mm; margin: 0; }
.sheet { width: ${s.w}mm; height: ${s.h}mm; padding: ${s.margin}mm; overflow: hidden; position: relative; background: #fff; break-after: page; page-break-after: always; }
.sheet:last-of-type { break-after: auto; page-break-after: auto; }
.inner { width: ${(s.w - 2 * s.margin) / sc}mm; transform: translate(${s.ox}mm, ${s.oy}mm) scale(${sc}); transform-origin: top left; }
@media screen { body { background: #e7edef; } .sheet { margin: 10px auto; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
${shot ? 'html, body { background: #fff !important; } .sheet { margin: 0 !important; box-shadow: none !important; } .no-print { display: none !important; }' : ''}`;
}

// =====================================================================================================
// Page setup (like OrderSaathi): every paper except the PM / PPE / PF invoices has its own setup on each
// computer. The paper is drawn at its own design size; the setup decides where and how big it lands:
// paper (A4, A5, Letter, 4x6, envelope, own size), portrait / landscape, print on the full page or a half or
// an own box, margins on each side, fit or scale %, shift, copies, and several labels on a roll / sticker sheet.
// =====================================================================================================
const PAGE_PAPERS = { A4: [210, 297], A5: [148, 210], LETTER: [215.9, 279.4], LABEL4X6: [101.6, 152.4], ENV_DL: [220, 110], ENV_C5: [229, 162], ENV_10: [241, 105] };
const LABEL_PRESETS = [
  { name: 'One label per row (normal roll)', across: 1, down: 1, w: 0, h: 0, gapx: 0, gapy: 0, sheet: 'roll', smx: 0, smy: 0 },
  { name: 'Roll: 2 labels across (e.g. 50 × 25 mm)', across: 2, down: 1, w: 50, h: 25, gapx: 2, gapy: 0, sheet: 'roll', smx: 0, smy: 0 },
  { name: 'Roll: 2 labels across, 4 × 2 in (100 × 50 mm)', across: 2, down: 1, w: 100, h: 50, gapx: 3, gapy: 0, sheet: 'roll', smx: 0, smy: 0 },
  { name: 'Roll: 3 labels across (e.g. 32 × 25 mm)', across: 3, down: 1, w: 32, h: 25, gapx: 2, gapy: 0, sheet: 'roll', smx: 0, smy: 0 },
  { name: 'A4 sheet: 2 × 4 (99.1 × 67.7 mm)', across: 2, down: 4, w: 99.1, h: 67.7, gapx: 2.5, gapy: 0, sheet: 'a4', smx: 4.65, smy: 13.1 },
  { name: 'A4 sheet: 2 × 7 (99.1 × 38.1 mm)', across: 2, down: 7, w: 99.1, h: 38.1, gapx: 2.5, gapy: 0, sheet: 'a4', smx: 4.65, smy: 15.15 },
  { name: 'A4 sheet: 3 × 7 (63.5 × 38.1 mm)', across: 3, down: 7, w: 63.5, h: 38.1, gapx: 2.5, gapy: 0, sheet: 'a4', smx: 7.2, smy: 15.15 },
  { name: 'A4 sheet: 3 × 8 (63.5 × 33.9 mm)', across: 3, down: 8, w: 63.5, h: 33.9, gapx: 2.5, gapy: 0, sheet: 'a4', smx: 7.2, smy: 13 },
  { name: 'A4 sheet: 4 × 10 (48.5 × 25.4 mm)', across: 4, down: 10, w: 48.5, h: 25.4, gapx: 0, gapy: 0, sheet: 'a4', smx: 8, smy: 21.5 }
];
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
// a setup with every value present and sane
function pageSetup(raw, def = {}) {
  const r = { ...def, ...(raw || {}) };
  const p = {
    printer: String(r.printer || ''), printer_paper: String(r.printer_paper || ''),
    paper: PAGE_PAPERS[r.paper] || r.paper === 'CUSTOM' ? r.paper : 'A4',
    cw: clamp(num(r.cw, 101.6), 10, 2000), ch: clamp(num(r.ch, 152.4), 10, 3000),
    landscape: !!r.landscape,
    area: ['full', 'left', 'right', 'top', 'bottom', 'own'].includes(r.area) ? r.area : 'full',
    ax: num(r.ax, 0), ay: num(r.ay, 0), aw: num(r.aw, 0), ah: num(r.ah, 0),
    mt: clamp(num(r.mt, num(r.margin, 5)), 0, 100), mb: clamp(num(r.mb, num(r.margin, 5)), 0, 100),
    ml: clamp(num(r.ml, num(r.margin, 5)), 0, 100), mr: clamp(num(r.mr, num(r.margin, 5)), 0, 100),
    fit: r.fit === undefined ? true : !!r.fit, scale: clamp(num(r.scale, 100), 10, 400),
    ox: clamp(num(r.ox, 0), -100, 100), oy: clamp(num(r.oy, 0), -100, 100),
    copies: clamp(Math.round(num(r.copies, 1)), 1, 50), turn: !!r.turn,
    across: clamp(Math.round(num(r.across, 1)), 1, 6), down: clamp(Math.round(num(r.down, 1)), 1, 12),
    gapx: clamp(num(r.gapx, 2), 0, 50), gapy: clamp(num(r.gapy, 0), 0, 50),
    sheet: r.sheet === 'a4' ? 'a4' : 'roll', smx: clamp(num(r.smx, 0), 0, 60), smy: clamp(num(r.smy, 0), 0, 60),
    fill: r.fill === 'row' ? 'row' : 'turn'
  };
  return p;
}
// paper (or ONE label) size after orientation
function paperSize(p) {
  const [w, h] = PAGE_PAPERS[p.paper] || [p.cw, p.ch];
  return p.landscape ? [Math.max(w, h), Math.min(w, h)] : (p.paper === 'CUSTOM' ? [w, h] : [Math.min(w, h), Math.max(w, h)]);
}
const isMulti = p => p.across * p.down > 1;
const isRoll = p => isMulti(p) ? p.sheet === 'roll' : (p.paper === 'CUSTOM' || p.paper === 'LABEL4X6');
// the printed page: the paper, or a whole row / block of the roll, or the A4 sticker sheet
function sheetSize(p) {
  if (!isMulti(p)) return paperSize(p);
  if (p.sheet === 'a4') return [210, 297];
  const [w, h] = paperSize(p);
  return [2 * p.smx + p.across * w + (p.across - 1) * p.gapx, 2 * p.smy + p.down * h + (p.down - 1) * p.gapy];
}
// where each label sits on the printed page, row by row
function slots(p) {
  const [w, h] = paperSize(p), out = [];
  for (let r = 0; r < p.down; r++) for (let c = 0; c < p.across; c++) out.push({ x: p.smx + c * (w + p.gapx), y: p.smy + r * (h + p.gapy), w, h });
  return out;
}
// which document goes in which place, page by page (-1 = empty)
function arrange(p, n) {
  const per = p.across * p.down, flat = [];
  for (let i = 0; i < n; i++) { if (p.fill === 'row') for (let c = 0; c < p.across; c++) flat.push(i); else flat.push(i); }
  const pages = [];
  for (let st = 0; st < flat.length; st += per) pages.push(Array.from({ length: per }, (_, k) => st + k < flat.length ? flat[st + k] : -1));
  return pages;
}
// the part of one paper / label the document goes into: area, margins and shift
function printable(p) {
  const [pw, ph] = paperSize(p);
  let x = 0, y = 0, w = pw, h = ph;
  if (p.area === 'left') w = pw / 2; else if (p.area === 'right') { x = pw / 2; w = pw / 2; }
  else if (p.area === 'top') h = ph / 2; else if (p.area === 'bottom') { y = ph / 2; h = ph / 2; }
  else if (p.area === 'own') { w = p.aw > 0 ? clamp(p.aw, 10, pw) : pw; h = p.ah > 0 ? clamp(p.ah, 10, ph) : ph; x = clamp(p.ax, 0, pw - w); y = clamp(p.ay, 0, ph - h); }
  const m = v => clamp(v, 0, Math.min(w, h) / 3);
  const l = m(p.ml), r = m(p.mr), t = m(p.mt), b = m(p.mb);
  return { x: x + l + p.ox, y: y + t + p.oy, w: Math.max(w - l - r, 1), h: Math.max(h - t - b, 1) };
}
// where a document of the design size lands: fitted (keeping its shape, centred) or scaled from the top left
function placeDoc(p, dw, dh) {
  const a = printable(p);
  const k = p.fit ? Math.min(a.w / dw, a.h / dh) : p.scale / 100;
  const w = dw * k, h = dh * k;
  return p.fit ? { x: a.x + (a.w - w) / 2, y: a.y + (a.h - h) / 2, w, h, k } : { x: a.x, y: a.y, w, h, k };
}
// how many sheets a print of n documents makes (copies included)
function sheetCount(p, n) { return arrange(p, n).length * p.copies; }
// the size and turn sent to the printer for one sheet
function mediaFor(p) { const [w, h] = sheetSize(p); return { w, h, noTurn: isRoll(p) && !p.turn, paperName: p.printer_paper || '' }; }

// docs: HTML of each document, drawn at design size (d.w × d.h mm, inner padding d.pad mm)
function pageShell(title, docs, d, p, opts = {}) {
  const [sw, sh] = sheetSize(p), multi = isMulti(p);
  const one = (html, x0 = 0, y0 = 0) => { const q = placeDoc(p, d.w, d.h);
    return `<div class="pdoc" style="left:${(x0 + q.x).toFixed(2)}mm;top:${(y0 + q.y).toFixed(2)}mm;width:${d.w}mm;height:${d.h}mm;padding:${d.pad || 0}mm;transform:scale(${q.k.toFixed(5)})">${html}</div>`; };
  const pagesHtml = [];
  for (let c = 0; c < p.copies; c++) {
    if (!multi) docs.forEach(h => pagesHtml.push(one(h)));
    else { const sl = slots(p); for (const pg of arrange(p, docs.length)) pagesHtml.push(pg.map((i, k) => i < 0 ? '' : one(docs[i], sl[k].x, sl[k].y)).join('')); }
  }
  const css = `@page { size: ${sw}mm ${sh}mm; margin: 0; }
.psheet { width: ${sw}mm; height: ${sh}mm; position: relative; overflow: hidden; background: #fff; break-after: page; page-break-after: always; }
.psheet:last-of-type { break-after: auto; page-break-after: auto; }
.pdoc { position: absolute; overflow: hidden; transform-origin: top left; box-sizing: border-box; }
@media screen { body { background: #e7edef; } .psheet { margin: 10px auto; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
${opts.shot ? 'html, body { background: #fff !important; } .psheet { margin: 0 !important; box-shadow: none !important; } .no-print { display: none !important; }' : ''}`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${BASE_CSS}${css}</style></head>
<body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
${pagesHtml.map(h => `<div class="psheet">${h}</div>`).join('')}${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

function shell(title, sheets, opts = {}) {
  // a page setup given: the papers are placed by it (design size = the paper's own setup)
  if (opts.page) { const s = opts.setup || {}; return pageShell(title, Array.isArray(sheets) ? sheets : [sheets], { w: s.w || 210, h: s.h || 297, pad: s.margin || 0 }, opts.page, opts); }
  const s = opts.setup;
  const pages = (Array.isArray(sheets) ? sheets : [sheets]).map(b => `<div class="sheet"><div class="inner">${b}</div></div>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${BASE_CSS}${sheetCss(s, opts.shot)}</style></head>
<body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
${pages}${opts.autoPrint ? '<script>window.onload=()=>{const go=()=>window.__ewbDone===false?setTimeout(go,200):window.print();setTimeout(go,300)}</script>' : ''}</body></html>`;
}

// Copies: one copy when the invoice is 9 MT or more, otherwise two (original + duplicate).
function invoiceCopies(inv, singleFromMt = 9) {
  if (inv.pf_source_id) return ['ORIGINAL FOR RECIPIENT', 'DUPLICATE FOR TRANSPORTER'];   // Parakh Marketing → Parakh Fertilizer: always 2
  const total = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);
  return total >= singleFromMt ? ['ORIGINAL FOR RECIPIENT'] : ['ORIGINAL FOR RECIPIENT', 'DUPLICATE FOR TRANSPORTER'];
}

// "Ship to" block: shown when the goods go to a delivery address (godown) other than the registered address
function shipTo(inv) {
  if (!inv.ship_address && !inv.ship_name) return '';
  const place = [inv.ship_city, inv.ship_pincode].filter(Boolean).join(' - ');
  const st = inv.ship_state ? esc(inv.ship_state) + (inv.ship_state_code ? ' (Code ' + esc(inv.ship_state_code) + ')' : '') : '';
  return `<div style="margin-top:5px;padding-top:4px;border-top:1px dashed #9aa"><span class="lbl">Ship to / Delivery at</span>
    ${inv.ship_name ? `<div><b>${esc(inv.ship_name)}</b></div>` : ''}${nl(inv.ship_address || '')}${place ? '<br>' + esc(place) : ''}${st ? (place ? ', ' : '<br>') + st : ''}
    ${Number(inv.trans_type) === 2 || Number(inv.trans_type) === 4 ? '<div class="muted" style="font-size:9px">E-way bill: Bill To - Ship To</div>' : ''}</div>`;
}

function invoiceHtml(inv, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const setup = setupFor('invoice', opts.setup);
  const f = inv.firm;
  const intra = !(inv.igst > 0);
  const isPpe = inv.kind === 'PPE_BILL';
  const rows = inv.items.map(it => {
    const desc = [`<b>${esc(it.item_name)}</b>`];
    if (it.grade) desc.push(esc(it.grade));
    if (isPpe) desc.push(`Lorry ${esc(it.lorry_no || '')}${it.rawana_no ? ' · Rawana ' + esc(it.rawana_no) : ''}${it.challan_no ? ' · Challan ' + esc(it.challan_no) : ''}`);
    const pack = [
      (it.bags || it.pack_size) ? `${it.bags ? esc(it.bags) + ' bags' : ''}${it.pack_size ? ' × ' + esc(it.pack_size) + ' kg' : ''}` : '',
      it.bag_type ? esc(it.bag_type) : '',
      it.packing_type ? esc(it.packing_type) : '',
      it.liner === 1 ? 'with liner' : it.liner === 0 ? 'without liner' : '',
      it.bag_supply === 'BUYER' ? "in buyer's own bags" : ''
    ].filter(Boolean).join(' · ');
    if (pack) desc.push(pack);
    if (it.lot_no) desc.push(`Lot No.: <b>${esc(it.lot_no)}</b>`);
    const pl = it.plant || (!isPpe && inv.plant);           // for our own use only: very small
    if (pl && !isPpe) desc.push(`<span style="font-size:7.5px;color:#8a979b;letter-spacing:.3px">${esc(pl)}</span>`);
    // B2C: quantity and rate per bag / pack (the invoice itself keeps MT)
    const perBag = inv.b2c_id && Number(it.bags) > 0 && Number(it.pack_size) > 0;
    return `<tr><td class="c">${it.sl}</td><td>${desc.join('<br>')}</td><td class="c">${esc(it.hsn)}</td><td class="r">${perBag ? esc(it.bags) : qty(it.qty)}</td>
      <td class="c">${perBag ? `PKT<br><span style="font-size:8px">(${esc(it.pack_size)} kg)</span>` : esc(it.unit)}</td><td class="r">${money(perBag ? it.rate * it.pack_size / 1000 : it.rate)}</td><td class="c">${it.gst_rate}%</td><td class="r">${money(it.amount)}</td></tr>`;
  }).join('');
  const totalQty = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);

  // HSN summary
  const hsn = {};
  for (const it of inv.items) {
    const k = it.hsn + '|' + it.gst_rate;
    hsn[k] = hsn[k] || { hsn: it.hsn, rate: it.gst_rate, taxable: 0 };
    hsn[k].taxable += it.amount;
  }
  const hsnRows = Object.values(hsn).map(h => {
    const tax = r2(h.taxable * h.rate / 100);
    return `<tr><td>${esc(h.hsn)}</td><td class="r">${money(h.taxable)}</td>
      ${intra ? `<td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td><td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td>`
        : `<td class="r">${h.rate}%</td><td class="r">${money(tax)}</td>`}<td class="r">${money(tax)}</td></tr>`;
  }).join('');

  const bank = [f.bank_name && `Bank: ${esc(f.bank_name)}`, f.bank_account && `A/c: ${esc(f.bank_account)}`, f.bank_ifsc && `IFSC: ${esc(f.bank_ifsc)}`, f.upi_id && `UPI: ${esc(f.upi_id)}`].filter(Boolean).join(' · ');

  // freight line: "Freight Rs.2600 per Metric Ton · Total Freight Approx Rs.(rate × qty)"
  // e-way bill: a barcode with its number under it
  const ewbRow = inv.ewb_no ? `<tr><td style="vertical-align:middle">E-way bill</td><td colspan="3"><div style="display:inline-block;text-align:center">${barcode128(inv.ewb_no, 30, 1.25)}
    <div style="font-size:11px;letter-spacing:1.5px;font-weight:600">${esc(String(inv.ewb_no).replace(/(\d{4})(?=\d)/g, '$1 '))}</div></div></td></tr>` : '';
  // freight in the dispatch box (right of Bill to)
  const freightRow = (() => {
    const n = String(inv.freight_note || '').trim(), mode = String(inv.freight_mode || '').trim();
    if (isPpe || (!n && !mode)) return '';
    const rate = freightRate(n);
    const what = rate > 0 ? `<b>Rs.${esc(rate.toLocaleString('en-IN'))} per MT</b>` : esc(n);
    return `<tr><td>Freight</td><td colspan="3">${what}${mode ? ` · <b>${esc(mode)}</b>` : ''}</td></tr>`;
  })();
  const freightLine = (() => {
    const n = String(inv.freight_note || '').trim(), mode = String(inv.freight_mode || '').trim();
    if (!n && !mode) return '';
    const rate = freightRate(n);
    const modeTxt = mode ? ` &nbsp;·&nbsp; Freight: <b>${esc(mode)}</b>` : '';
    if (!(rate > 0) || isPpe) return n && !/^(paid|to\s*pay)$/i.test(n) ? `<b>Freight:</b> ${esc(n)}${modeTxt}` : `<b>Freight:</b> ${esc(mode || n.toUpperCase())}`;
    const total = inv.freight_total > 0 ? inv.freight_total : rate * totalQty;
    return `<b>Freight Rs.${esc(rate.toLocaleString('en-IN'))} per Metric Ton</b> &nbsp;·&nbsp; Total Freight Approx <b>Rs.${money(total)}</b>${modeTxt}`;
  })();

  const payUpi = String(f.upi_id || '').trim() || bankUpi(f.bank_account, f.bank_ifsc) || '';
  // UPI QR: pay this invoice's exact amount; the transaction note has the invoice no. and the firm
  const upiQr = (() => {
    if (isPpe || inv.cancelled || !payUpi || !(inv.total > 0)) return '';
    const firmTag = String(f.name || '').replace(/[^A-Za-z]/g, '');
    const note = inv.is_proforma ? `PI ${inv.pi_no} ${firmTag}` : `Inv ${inv.inv_no} ${firmTag}`;
    // up to ₹1 lakh the QR asks for the exact amount; above it (UPI limit) it has only the UPI id — the buyer types the amount, in parts if needed
    const am = Number(inv.total) < UPI_LIMIT ? `&am=${Number(inv.total).toFixed(2)}` : '';
    const url = `upi://pay?pa=${encodeURIComponent(payUpi).replace(/%40/g, "@")}&pn=${encodeURIComponent(f.name)}${am}&cu=INR&tn=${encodeURIComponent(note)}`;
    return `<div class="box qrbox"><div class="lbl">Scan &amp; pay</div>${qr.svg(url, 112)}</div>`;
  })();

  const H = (setup.h - 2 * setup.margin) / ((setup.scale || 100) / 100);
  const page = copyLabel => `<div class="invp" style="height:${H}mm">
  <div class="head"><div style="display:flex;gap:14px;align-items:center">${brand(f) ? brandImg(f, 80, 300) + '<div>' : logoTag(f) + `<div><div class="firm">${esc(f.name.toUpperCase())}</div>`}
    <div class="muted">${esc(f.address)}, ${esc(f.city)} - ${esc(f.pincode)} (${esc(f.state)})<br>Ph: ${esc(f.phone)} · ${esc(f.email)}</div></div></div>
    <div>${copyLabel ? `<div class="r copyl">${esc(copyLabel)}</div>` : ''}<div class="title">${inv.is_proforma ? 'PROFORMA INVOICE' : 'TAX INVOICE'}${inv.cancelled ? ' — CANCELLED' : ''}</div>
    <div class="r">GSTIN: <b>${esc(f.gstin)}</b><br>PAN: ${esc(f.pan)}</div></div></div>

  <div class="grid2">
    <div class="box"><div class="lbl">Bill to</div><div class="big">${esc(inv.party_name)}</div>
      ${nl(inv.party_address)}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}, ${esc(inv.party_state || '')}
      ${inv.party_state_code ? ' (Code ' + esc(inv.party_state_code) + ')' : ''}<br>
      ${inv.b2c_id ? `GSTIN: <b>UNREGISTERED</b>${inv.customer && inv.customer.mobile ? ' · Ph: ' + esc(inv.customer.mobile) : ''}` : inv.party_gstin ? 'GSTIN: <b>' + esc(inv.party_gstin) + '</b>' : 'Unregistered (B2C)'}${!inv.b2c_id && inv.party_pan ? ' · PAN: ' + esc(inv.party_pan) : ''}
      ${shipTo(inv)}</div>
    <div class="box"><table class="kv"><tbody>
      <tr><td>${inv.is_proforma ? 'Proforma No.' : 'Invoice No.'}</td><td class="big">${esc(inv.is_proforma ? inv.pi_no : inv.inv_no)}</td><td>Date</td><td class="big">${dmy(inv.date)}</td></tr>
      ${inv.send_by === 'COURIER' ? `<tr><td>F.Y.</td><td>${esc(inv.fy)}</td><td>Sent by</td><td><b>COURIER</b></td></tr>
      <tr><td>Courier</td><td colspan="3"><b>${esc(inv.courier || '')}</b></td></tr>
      <tr><td>Docket No.</td><td colspan="3"><b>${esc(inv.docket_no || '')}</b></td></tr>${ewbRow}`
      : `<tr><td>F.Y.</td><td>${esc(inv.fy)}</td><td>Lorry No.</td><td><b>${esc(isPpe ? '' : inv.lorry_no || '')}</b></td></tr>
      <tr><td>Transporter</td><td colspan="3">${esc(inv.transporter || '')}</td></tr>
      <tr><td>L.R. No.</td><td colspan="3">${esc(inv.lr_no || '')}</td></tr>
      ${ewbRow}
      ${inv.driver_phone ? `<tr><td>Driver Ph.</td><td colspan="3">${esc(inv.driver_phone)}</td></tr>` : ''}`}
      ${inv.send_by === 'COURIER' ? '' : freightRow}
      ${inv.b2c_id && inv.sale_medium ? `<tr><td>Sale</td><td colspan="3">Online sale · ${esc(inv.sale_medium)}</td></tr>` : ''}
    </tbody></table></div>
  </div>

  <div class="grow"><table class="items"><thead><tr><th class="c" style="width:32px">#</th><th>Description of goods</th><th class="c">HSN</th><th class="r">Qty</th><th class="c">Unit</th><th class="r">Rate</th><th class="c">GST</th><th class="r">Amount</th></tr></thead>
  <tbody>${rows}
  <tr class="fill"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
  <tr class="fx"><td></td><td class="r"><b>Total quantity</b></td><td></td><td class="r"><b>${qty(totalQty)}</b></td><td class="c">MT</td><td></td><td class="r">Taxable</td><td class="r"><b>${money(inv.taxable)}</b></td></tr>
  ${intra ? `<tr class="fx"><td colspan="7" class="r">CGST</td><td class="r">${money(inv.cgst)}</td></tr><tr class="fx"><td colspan="7" class="r">SGST</td><td class="r">${money(inv.sgst)}</td></tr>`
           : `<tr class="fx"><td colspan="7" class="r">IGST</td><td class="r">${money(inv.igst)}</td></tr>`}
  ${inv.round_off ? `<tr class="fx"><td colspan="7" class="r">Round off</td><td class="r">${money(inv.round_off)}</td></tr>` : ''}
  <tr class="tot fx"><td colspan="7" class="r">Grand total</td><td class="r">₹ ${money(inv.total)}</td></tr>
  </tbody></table></div>
  <div class="box words"><span class="lbl">Amount in words</span><br><b>${esc(inWords(inv.total))}</b></div>

  <table class="hsn"><thead><tr><th>HSN</th><th class="r">Taxable</th>${intra ? '<th class="r">CGST %</th><th class="r">CGST</th><th class="r">SGST %</th><th class="r">SGST</th>' : '<th class="r">IGST %</th><th class="r">IGST</th>'}<th class="r">Total tax</th></tr></thead>
  <tbody>${hsnRows}</tbody></table>

  ${(isPpe && freightLine) || inv.notes ? `<div class="box freight">${isPpe ? freightLine : ''}${isPpe && freightLine && inv.notes ? '<br>' : ''}${inv.notes ? esc(inv.notes) : ''}</div>` : ''}

  <div class="foot ${upiQr ? 'withqr' : ''}">
    <div class="box"><div class="lbl">Terms of sale</div><div class="terms">${nl(f.terms || '')}</div>
      ${f.bank_name || f.bank_account ? `<div class="bankd"><div class="lbl">Bank details</div>A/c Name: <b>${esc(f.name.toUpperCase())}</b><br>
        ${f.bank_name ? `Bank: <b>${esc(f.bank_name)}</b>${f.bank_branch ? ', ' + esc(f.bank_branch) : ''}<br>` : ''}
        ${f.bank_account ? `A/c No.: <b>${esc(f.bank_account)}</b>` : ''}${f.bank_ifsc ? ` &nbsp; IFSC: <b>${esc(f.bank_ifsc)}</b>` : ''}
        ${payUpi ? `<br>UPI: ${esc(payUpi)}` : ''}</div>` : ''}</div>
    ${upiQr}
    <div class="box r sigbox"><div>For <b>${esc(f.name.toUpperCase())}</b></div><div class="sign">${signTag(f)}</div><div>Authorised Signatory</div></div>
  </div>
  <div class="c muted" style="margin-top:4px;font-size:10.5px">${inv.is_proforma ? 'This is a proforma invoice, not a tax invoice. The tax invoice is made at the time of dispatch.' : 'This is a computer generated invoice.'}</div>
</div>`;
  let copies = opts.copies || (isPpe || inv.is_proforma ? [''] : invoiceCopies(inv, opts.singleFromMt));
  if (opts.copy != null) copies = [copies[Number(opts.copy)] ?? copies[0]];
  // the e-way bill PDF is drawn on the back of each copy (both-side printing)
  const ewbSheet = opts.ewbUrl ? `<canvas class="ewbc" style="width:100%;display:block"></canvas>` : null;
  const ewbJs = opts.ewbUrl ? `<script type="module">
    window.__ewbDone = false;
    try {
      const pdfjs = await import('/vendor/pdf.min.mjs'); pdfjs.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.mjs';
      const doc = await pdfjs.getDocument({ url: ${JSON.stringify(opts.ewbUrl)} }).promise, pg = await doc.getPage(1);
      for (const c of document.querySelectorAll('.ewbc')) {
        const w = c.parentElement.clientWidth, v0 = pg.getViewport({ scale: 1 }), v = pg.getViewport({ scale: w * 3 / v0.width });
        c.width = v.width; c.height = v.height; await pg.render({ canvasContext: c.getContext('2d'), viewport: v }).promise;
      }
    } catch (e) { document.querySelectorAll('.ewbc').forEach(c => c.insertAdjacentHTML('afterend', '<p>E-way bill could not be drawn: ' + e.message + '</p>')); }
    window.__ewbDone = true; document.title += ' ✓';
  </script>` : '';
  const fit = `<script>(function(){document.querySelectorAll('.invp').forEach(function(p){var h=p.clientHeight,s=p.scrollHeight;if(s>h+1){var z=Math.max(.6,h/s);p.style.zoom=z;p.style.height=(h/z)+'px';}});})();</script>`;
  const pages = copies.flatMap(c => ewbSheet ? [page(c), ewbSheet] : [page(c)]); pages[pages.length - 1] += fit + ewbJs;
  return shell(`${f.name} Invoice ${inv.inv_no}`, pages, { ...opts, setup });
}

function voucherHtml(w, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const isPpe = /^PPE/i.test(w.voucher_no);
  const f = get('SELECT * FROM firms WHERE code = ?', isPpe ? 'PPE' : 'PM');
  const { amount, shownRate } = freightFigures(w);
  const adv = Number(w.advance) || 0;
  const net = r2(amount - adv);
  // UPI QR for the lorry owner: net freight, note = voucher no. + lorry no.
  const payQr = (() => {
    const l = get('SELECT * FROM lorries WHERE lorry_no = ?', String(w.lorry_no || '').toUpperCase().replace(/[^A-Z0-9]/g, '')) || {};
    const upi = String(w.upi || l.upi || bankUpi(l.bank_account, l.bank_ifsc) || '').trim();
    if (!upi || !/^[^@\s]+@[^@\s]+$/.test(upi) || !(net > 0)) return null;
    const name = w.owner_name || l.holder || l.owner || '';
    const note = `${w.voucher_no} ${w.lorry_no}`;
    const url = `upi://pay?pa=${encodeURIComponent(upi).replace(/%40/g, '@')}${name ? '&pn=' + encodeURIComponent(name) : ''}${net < UPI_LIMIT ? '&am=' + net.toFixed(2) : ''}&cu=INR&tn=${encodeURIComponent(note)}`;
    return { svg: qr.svg(url, 88), upi, name, note };
  })();
  const body = `<div>
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${brand(f) ? brandImg(f, 70, 260) + '<div>' : logoTag(f) + `<div><div class="firm">${esc(f.name.toUpperCase())}</div>`}<div class="muted">${esc(f.address)}, ${esc(f.city)}</div></div></div>
  <div class="title">FREIGHT PAYMENT VOUCHER</div></div>
  <table><tbody>
    <tr><td>Voucher No.</td><td class="big">${esc(w.voucher_no)}</td><td>Voucher date</td><td>${dmy(w.voucher_date)}</td></tr>
    <tr><td>Plant</td><td>${esc(w.plant || '')}</td><td>Received on</td><td>${dmy(w.date)}</td></tr>
    <tr><td>Lorry No.</td><td class="big">${esc(w.lorry_no)}</td><td>Challan No.</td><td>${esc(w.challan_no || '')}</td></tr>
    <tr><td>Rawana No.</td><td>${esc(w.rawana_no || '')}</td><td>From → To</td><td><b>${esc(w.supplier || '')}</b> → <b>${esc(w.to_party || 'PARAKH MARKETING')}</b>${w.mines ? '<br>Mines: ' + esc(w.mines) : ''}</td></tr>
    <tr><td>Grade</td><td>${esc(w.grade || '')} ${esc(w.condition || '')}</td><td>Owner</td><td>${esc(w.owner_name || '')}${w.pan ? ' · PAN ' + esc(w.pan) : ''}</td></tr>
    <tr><td>Driver</td><td>${esc(w.driver_name || '')} ${esc(w.driver_phone || '')}</td><td>UPI</td><td>${esc(w.upi || (payQr && payQr.upi) || '')}</td></tr>
  </tbody></table>
  <table style="margin-top:8px"><thead><tr><th>Particulars</th><th class="r">Weight (MT)</th><th class="r">Rate / MT</th><th class="r">Amount</th></tr></thead>
  <tbody><tr><td>Freight for ${esc(w.lorry_no)}</td><td class="r">${qty(w.rawana_wt)}</td><td class="r">${money(shownRate)}</td><td class="r">${money(amount)}</td></tr>
  ${adv ? `<tr><td colspan="3" class="r">Less advance</td><td class="r">${money(adv)}</td></tr>` : ''}
  <tr class="tot"><td colspan="3" class="r">Net payable</td><td class="r">₹ ${money(net)}</td></tr>
  <tr><td colspan="4">Paid: Cash ₹ ${money(w.cash_amt)} · Bank ₹ ${money(w.bank_amt)}${w.pay_mode ? ' (' + esc(w.pay_mode) + ')' : ''}${w.chq_no ? ' · Ref ' + esc(w.chq_no) : ''}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(net))}</b></div>
  <div class="box" style="margin-top:6px;display:flex;gap:10px;align-items:stretch;padding:5px 8px;font-size:10.5px">
    ${payQr ? `${payQr.svg}<div style="align-self:center;line-height:1.35"><div class="lbl">Scan &amp; pay by UPI</div><div style="font-size:13px;font-weight:800;margin:1px 0">₹ ${money(net)}</div>
    <div>To: <b>${esc(payQr.name || '')}</b><br>UPI: ${esc(payQr.upi)}<br>Note: ${esc(payQr.note)}</div></div>` : ''}
    <div style="margin-left:auto;display:flex;flex-direction:column;justify-content:space-between;text-align:right;min-height:70px;min-width:190px">
      <div>For <b>${esc(f.name.toUpperCase())}</b></div><div>Authorised Signatory</div></div>
  </div>
</div>`;
  return shell(`Voucher ${w.voucher_no}`, body, { ...opts, setup: setupFor('invoice', opts.setup) });
}

// ---- 4 x 6 bag / parcel sticker: To, Bag No. n / N, From ----
function labelHtml(inv, opts = {}) {
  const s = setupFor('label', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const of = Math.max(1, Number(opts.of) || 1);
  const from = Math.max(1, Number(opts.from) || 1), to = Math.min(of, Math.max(from, Number(opts.to) || of));
  const phone = p.mobile || p.phone || '';
  const items = inv.items.map(it => [it.item_name, it.grade].filter(Boolean).join(' ') + (it.pack_size ? ` · ${it.pack_size} kg bag` : '')).join('<br>');
  // two halves: upper = buyer (TO), lower = sender (FROM) with invoice and bag no. No logo.
  const one = n => `<div class="lbl4x6">
    <div class="half to"><div class="k">TO</div>
      <div class="nm">${esc(inv.party_name)}</div>
      ${inv.ship_address ? `${inv.ship_name ? `<div class="ad"><b>${esc(inv.ship_name)}</b></div>` : ''}<div class="ad">${nl(inv.ship_address)}<br>${esc(inv.ship_city || '')}${inv.ship_pincode ? ' - <b>' + esc(inv.ship_pincode) + '</b>' : ''}<br>${esc(inv.ship_state || '')}</div>`
        : `<div class="ad">${nl(inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - <b>' + esc(inv.party_pincode) + '</b>' : ''}<br>${esc(inv.party_state || '')}</div>`}
      ${phone ? `<div class="ph">Ph: <b>${esc(phone)}</b></div>` : ''}${inv.party_gstin ? `<div class="ph">GSTIN: <b>${esc(inv.party_gstin)}</b></div>` : ''}</div>
    <div class="half from"><div class="k">FROM</div>
      ${brand(f) ? `<div style="margin:1mm 0">${brandImg(f, 46, 220)}</div>` : `<div class="nm2">${esc(f.name.toUpperCase())}</div>`}
      <div class="ad2">${esc(f.address)}<br>${esc(f.city)}${f.pincode ? ' - ' + esc(f.pincode) : ''} · ${esc(f.state)}<br>Ph: ${esc(f.phone)}${f.gstin ? '<br>GSTIN ' + esc(f.gstin) : ''}</div>
      <div class="foot"><div class="info">Invoice <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>${items}${inv.transporter ? '<br>By ' + esc(inv.transporter) : ''}</div>
        <div class="bag"><span>BAG NO.</span><div><b>${n}</b> / <b>${of}</b></div></div></div></div>
  </div>`;
  const pages = []; for (let n = from; n <= to; n++) pages.push(one(n));
  const css = `<style>
    .lbl4x6 { height: ${s.h - 2 * s.margin}mm; display: flex; flex-direction: column; color: #000; }
    .lbl4x6 .half { flex: 1 1 0; min-height: 0; overflow: hidden; padding: 2.5mm; border: 2px solid #000; display: flex; flex-direction: column; }
    .lbl4x6 .to { border-bottom: 0; }
    .lbl4x6 .from { border-top: 2px dashed #000; }
    .lbl4x6 .k { font-size: 10px; font-weight: 800; letter-spacing: 1px; border-bottom: 1px solid #000; margin-bottom: 1.5mm; }
    .lbl4x6 .nm { font-size: 24px; font-weight: 800; line-height: 1.15; }
    .lbl4x6 .ad { font-size: 16px; line-height: 1.35; margin-top: 1mm; }
    .lbl4x6 .ph { font-size: 16px; margin-top: 1mm; }
    .lbl4x6 .nm2 { font-size: 16px; font-weight: 800; line-height: 1.15; }
    .lbl4x6 .ad2 { font-size: 12px; line-height: 1.35; margin-top: 1mm; }
    .lbl4x6 .foot { margin-top: auto; display: flex; gap: 2mm; align-items: flex-end; }
    .lbl4x6 .info { flex: 1; font-size: 11px; line-height: 1.3; }
    .lbl4x6 .bag { border: 2px solid #000; padding: 1mm 2.5mm; text-align: center; white-space: nowrap; }
    .lbl4x6 .bag span { font-size: 10px; font-weight: 700; display: block; } .lbl4x6 .bag b { font-size: 26px; }
  </style>`;
  pages[0] = css + pages[0];
  return shell(`Bag stickers ${inv.inv_no}`, pages, { ...opts, setup: s });
}

// ---- envelope: invoice, lorry, transporter, e-way bill, To M/s … ----
function envelopeHtml(inv, opts = {}) {
  const s = setupFor('envelope', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const phone = p.mobile || p.phone || '';
  const body = `<style>
    .env { height: ${s.h - 2 * s.margin}mm; display: grid; grid-template-columns: 1fr 1.25fr; gap: 6mm; font-size: 12px; color: #000; }
    .env .left { font-size: 11px; line-height: 1.45; }
    .env .left .firm2 { font-size: 15px; font-weight: 800; }
    .env .ref { margin-top: 3mm; border: 1px solid #000; padding: 2mm; line-height: 1.6; }
    .env .right { align-self: center; border-left: 2px solid #000; padding-left: 5mm; }
    .env .right .k { font-size: 11px; font-weight: 700; letter-spacing: 1px; }
    .env .right .nm { font-size: 17px; font-weight: 800; margin: 1mm 0; }
    .env .right .ad { font-size: 13px; line-height: 1.4; }
  </style><div class="env">
    <div class="left">${brand(f) ? brandImg(f, 56, 220) : `${logoTag(f)}<div class="firm2">${esc(f.name.toUpperCase())}</div>`}${esc(f.address)}<br>${esc(f.city)} - ${esc(f.pincode)}, ${esc(f.state)}<br>Ph: ${esc(f.phone)}
      <div class="ref">Invoice No. <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}<br>Lorry No. <b>${esc(inv.lorry_no || '')}</b><br>${esc(inv.transporter || '')}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>E-Way Bill No. <b>${esc(inv.ewb_no || '')}</b></div></div>
    <div class="right"><div class="k">TO</div><div class="nm">M/s. ${esc(inv.party_name)}</div>
      <div class="ad">${nl(inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}<br>${esc(inv.party_state || '')}${phone ? '<br>Ph. ' + esc(phone) : ''}</div></div>
  </div>`;
  return shell(`Envelope ${inv.inv_no}`, body, { ...opts, setup: s });
}

// Transporter invoice (freight bill from the transporter to the buyer): No. = L.R. no., amount = total freight
function trInvoiceHtml(inv, tr, opts = {}) {
  const title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const pan = tr.pan || (tr.gstin && tr.gstin.length >= 12 ? tr.gstin.slice(2, 12) : '');
  const phones = [tr.mobile, tr.phone].filter(Boolean).join(',');
  const qtyT = inv.items.reduce((s, i) => s + (Number(i.qty) || 0), 0), amt = Number(inv.freight_total) || 0;
  const destCity = inv.ship_city || inv.party_city, destState = inv.ship_state || inv.party_state;
  const party = inv.party || {}, ph = [party.mobile, party.phone].filter(Boolean)[0];
  const words = inWords(Math.round(amt)).replace(/^Rupees\s*/i, '').replace(/\s*only\.?$/i, '');
  const body = `<style>.trinv td, .trinv th { border: 0; padding: 0; background: none; }</style><div class="trinv" style="font-family:Calibri,Carlito,'Segoe UI',Arial,sans-serif;font-size:13.5px;color:#000;padding:6mm 4mm">
    <table style="width:100%;font-weight:bold;font-size:12.5px"><tr><td style="width:50%"><div style="padding-left:28px">GST NO</div>${esc(tr.gstin || '')}</td>
      <td style="text-align:right"><div style="padding-right:36px">PAN</div>${esc(pan)}</td></tr></table>
    <div style="text-align:center;margin-top:18px"><div style="font-size:27px;font-weight:bold;letter-spacing:.3px">${esc(String(tr.name || '').toUpperCase())}</div>
      <div style="font-size:11px;font-weight:bold">${esc(String([tr.address, tr.district, tr.state].filter(Boolean).join(', ')).toUpperCase())}</div>
      ${phones ? `<div style="font-size:11px">PH-${esc(phones)}</div>` : ''}</div>
    <table style="width:100%;margin-top:26px;font-weight:bold;font-size:14px"><tr><td style="width:70px">No.</td><td>${esc(inv.lr_no || '')}</td>
      <td style="text-align:right"><i style="border-bottom:1px solid #000;padding:0 2px 3px 20px">${esc(dmy(inv.date).replace(/\./g, '/'))}</i></td></tr></table>
    <div style="margin-top:34px">To</div>
    <div style="font-size:17px;font-weight:bold">${esc(inv.party_name)}</div>
    <div style="font-weight:bold">${esc([inv.party_address, ph ? 'Ph.' + ph : ''].filter(Boolean).join(' , '))}</div>
    <div style="font-weight:bold">${esc([inv.party_city, inv.party_state].filter(Boolean).join(',').toUpperCase())}</div>
    <table style="width:100%;border-collapse:collapse;margin-top:34px;border:1.5px solid #000">
      <tr style="font-weight:bold;font-size:14px;text-align:center"><td style="border:1px solid #000;width:13%;padding:3px">SL</td><td style="border:1px solid #000;padding:3px">Details</td>
        <td style="border:1px solid #000;width:12%;padding:3px">Qty</td><td style="border:1px solid #000;width:16%;padding:3px">Amount</td></tr>
      <tr style="vertical-align:top;height:100px"><td style="border:1px solid #000;text-align:center;vertical-align:middle">1</td>
        <td style="border:1px solid #000;padding:2px 4px;line-height:1.35">${esc(title(inv.firm.city || tr.district || ''))} To ${esc([destCity, destState].filter(Boolean).join(',').toUpperCase())}<br><br>
          Goods Sent By ${esc(inv.firm.name)}<br>Invoice No.${esc(inv.inv_no)}<br>Lorry No.${esc(inv.lorry_no || '')}</td>
        <td style="border:1px solid #000;padding:2px 4px">${qty(qtyT)}</td><td style="border:1px solid #000;padding:2px 4px;text-align:right;font-weight:bold">${money(amt)}</td></tr>
      <tr style="font-weight:bold"><td></td><td style="text-align:right;padding:2px 4px;border-right:1px solid #000;border-top:1px solid #000">TOTAL</td>
        <td style="border:1px solid #000;padding:2px 4px">${qty(qtyT)}</td><td style="border:1px solid #000;padding:2px 4px;text-align:right">${money(amt)}</td></tr></table>
    <div style="margin-top:20px;font-weight:bold;font-size:14px">Total Rs.&nbsp;&nbsp;&nbsp;&nbsp;${esc(words)} Only.</div>
    <div style="margin-left:96px;font-size:12px"><i>(Amount in Words)</i></div>
    <div style="margin-top:38px;font-size:15px">Kindly transfer the above amount to the bank account details mentioned below.</div>
    <div style="margin-top:24px;font-weight:bold;font-size:14px">Bank Details</div>
    <table style="font-size:12px;line-height:1.35"><tr><td style="width:90px">Name:</td><td>${esc(String(tr.name || '').toUpperCase())}</td></tr>
      <tr><td>Bank:</td><td>${esc(String(tr.bank_name || '').toUpperCase())}</td></tr><tr><td>Account No:</td><td>${esc(tr.bank_account || '')}</td></tr><tr><td>IFSC</td><td>${esc(tr.bank_ifsc || '')}</td></tr></table>
    <div style="margin-top:22px;font-size:12px">Thank You</div>
    <div style="margin-top:22px;font-size:12px">${esc(String(tr.proprietor || '').toUpperCase())}</div>
    <div style="font-size:12px;font-weight:bold"><i>${esc(String(tr.name || '').toUpperCase())}</i></div>
    <div style="font-size:12px;font-weight:bold"><i>${esc(title(tr.district || ''))}</i></div>
    <div style="margin-top:40px;text-align:center;font-weight:bold;font-size:12px"><i>( This is a computer generated Document )</i></div></div>`;
  return shell(`Transporter invoice ${inv.lr_no || ''}`, body, opts);
}

// Local freight letter: Parakh Marketing asks the transporter to pay the tempo that brings the goods to its godown
function localFreightHtml(inv, lf, tr, opts = {}) {
  const f = inv.firm, title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const d = new Date(), today = d.toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  const words = inWords(Math.round(lf.amount)).replace(/^Rupees\s*/i, '').replace(/\s*only\.?$/i, '');
  const groups = new Map();
  for (const it of inv.items) { const k = Number(it.pack_size) || 0; groups.set(k, (groups.get(k) || 0) + (Number(it.bags) || 0)); }
  const bagLine = [...groups].filter(([, b]) => b).map(([kg, b]) => `${b} Bags of ${qty(kg)} Kg`).join(' + ');
  const totalKg = [...groups].reduce((s, [kg, b]) => s + kg * b, 0);
  const place = [inv.ship_city || inv.party_city, inv.ship_pincode || inv.party_pincode].filter(Boolean).join('-');
  const row = (k, v) => `<tr><td style="width:86px;padding:5px 0">${k}</td><td style="padding:5px 0"><b><i>${v}</i></b></td></tr>`;
  const body = `<style>.lfl td { border: 0; padding: 0; background: none; }</style>
  <div class="lfl" style="font-family:'Bookman Old Style','Book Antiqua',Georgia,serif;font-size:13px;color:#000;padding:4mm 3mm;height:260mm;position:relative">
    ${brand(f) ? brandImg(f, 70, 280) : `<div style="font-family:'Old English Text MT','Engravers MT',Georgia,serif;font-size:22px;font-weight:bold;letter-spacing:.5px">${esc(String(f.name).toUpperCase())}</div>`}
    <div style="font-size:11px;margin-top:14px">${esc(today)}</div>
    <div style="margin-top:22px">To<br>The Manager<br><b>${esc(String(tr.name || '').toUpperCase())}</b><br>${esc(title(tr.district || ''))}</div>
    <div style="margin-top:34px">Dear Sir ,</div>
    <table style="margin-top:8px;border-collapse:collapse">
      <tr><td style="width:86px;padding:5px 0">Kindly pay</td><td style="padding:5px 0">Rs.${money(lf.amount)} ( ${esc(words)} Only.)</td></tr>
      ${row('Name', esc(lf.driver))}${lf.mobile ? row('Mobile No.', esc(lf.mobile)) : ''}${row('Taxi No.', esc(lf.tempo_no))}</table>
    <div style="margin-top:6px">For the delivery of goods from our factory (${esc(lf.from_place || 'Mandore Industrial Area')}) to</div>
    <div style="margin-top:14px"><b><i>${esc(String(tr.name || '').toUpperCase())}</i></b></div>
    <div style="margin-top:12px">${esc(title(tr.district || ''))}</div>
    <div style="margin-top:42px"><b><i>${esc(bagLine)}&nbsp;&nbsp;&nbsp;Total&nbsp;&nbsp;&nbsp;&nbsp;${qty(totalKg)} Kg.</i></b></div>
    <div style="margin-top:12px">for</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-size:17px;font-weight:bold">M/s. ${esc(inv.party_name)}</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-weight:bold">${esc(String(place).toUpperCase())}</div>
    <div style="margin-top:10px;font-family:Arial,sans-serif;font-weight:bold">${esc(String(inv.ship_state || inv.party_state || '').toUpperCase())}</div>
    <div style="margin-top:42px">Invoice No.&nbsp;&nbsp;&nbsp;<b><i style="display:inline-block;min-width:46px;text-align:center;border-bottom:1px solid #000;padding-bottom:4px">${esc(inv.inv_no)}</i></b>&nbsp;&nbsp;Dated&nbsp;&nbsp;<b><i style="display:inline-block;min-width:140px;text-align:center;border-bottom:1px solid #000;padding-bottom:4px">${esc(dmy(inv.date).replace(/\./g, '/'))}</i></b></div>
    <div style="margin-top:38px">Thank you</div>
    <div style="margin-top:20px">${esc(lf.signer || '')}</div>
    <div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:9.5px;font-weight:bold">${esc(f.address)}<br>${esc(title(f.city))} ${esc(f.pincode || '')} ${esc(title(f.state))}</div></div>`;
  return shell(`Local freight letter ${inv.inv_no}`, body, opts);
}

// Factory wages voucher of a month: one page per plant
function wagesHtml(d, firm, opts = {}) {
  const [y, m] = d.month.split('-'), mName = new Date(Number(y), Number(m) - 1, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  const td = 'border:1px solid #444;padding:4px 6px', num = td + ';text-align:right';
  const pages = d.plants.map(p => {
    const exp = [...p.fixed.map(x => ({ ...x, kind: 'Fixed' })), ...p.extra.map(x => ({ ...x, kind: 'Other' }))];
    return `<style>.wv td, .wv th { border: 0; padding: 0; background: none; }</style><div class="wv" style="font-family:Arial,sans-serif;font-size:12.5px;color:#000">
      <div style="text-align:center;border-bottom:2px solid #000;padding-bottom:6px">${brand(firm) ? `<div style="display:flex;justify-content:center">${brandImg(firm, 70, 280)}</div>` : `<div style="font-size:22px;font-weight:bold">${esc(String(firm.name).toUpperCase())}</div>`}
        <div style="font-size:11px">${esc(firm.address || '')}, ${esc(firm.city || '')}${firm.pincode ? ' - ' + esc(firm.pincode) : ''}</div></div>
      <div style="display:flex;justify-content:space-between;margin:10px 0 4px"><div style="font-size:17px;font-weight:bold">FACTORY WAGES VOUCHER</div>
        <div style="text-align:right">Month: <b>${esc(mName)}</b><br>Plant: <b>${esc(p.plant)}</b>${p.full_name ? ' (' + esc(p.full_name) + ')' : ''}</div></div>
      <div style="font-weight:bold;margin:10px 0 4px">1. Wages on dispatch (Parakh Marketing invoices)</div>
      <table style="width:100%;border-collapse:collapse"><tr style="background:#eee;font-weight:bold"><td style="${td}">Grade</td><td style="${td}">Form</td><td style="${num}">Dispatched MT</td><td style="${num}">Wages / MT</td><td style="${num}">Amount (₹)</td></tr>
        ${p.dispatch.map(g => `<tr><td style="${td}">${esc(g.grade)}</td><td style="${td}">${esc(g.form)}</td><td style="${num}">${qty(g.qty)}</td><td style="${num}">${g.rate ? money(g.rate) : '—'}</td><td style="${num}">${money(g.amount)}</td></tr>`).join('') || `<tr><td style="${td}" colspan="5">No dispatch.</td></tr>`}
        <tr style="font-weight:bold"><td style="${td}" colspan="2">Total</td><td style="${num}">${qty(p.qty)}</td><td style="${td}"></td><td style="${num}">${money(p.wages)}</td></tr></table>
      <div style="font-weight:bold;margin:14px 0 4px">2. Fixed & other expenses</div>
      <table style="width:100%;border-collapse:collapse"><tr style="background:#eee;font-weight:bold"><td style="${td}">Description</td><td style="${td}">Type</td><td style="${num}">Qty</td><td style="${num}">Rate</td><td style="${num}">Amount (₹)</td></tr>
        ${exp.map(x => `<tr><td style="${td}">${esc(x.description)}</td><td style="${td}">${x.kind}</td><td style="${num}">${x.qty != null ? qty(x.qty) : ''}</td><td style="${num}">${x.rate != null ? money(x.rate) : ''}</td><td style="${num}">${money(x.amount)}</td></tr>`).join('') || `<tr><td style="${td}" colspan="5">No expenses.</td></tr>`}
        <tr style="font-weight:bold"><td style="${td}" colspan="4">Total expenses</td><td style="${num}">${money(p.fixed_total + p.extra_total)}</td></tr></table>
      <table style="width:60%;margin:16px 0 0 auto;border-collapse:collapse;font-size:13px">
        <tr><td style="${td}">Wages on dispatch</td><td style="${num}">${money(p.wages)}</td></tr>
        <tr><td style="${td}">Fixed expenses</td><td style="${num}">${money(p.fixed_total)}</td></tr>
        <tr><td style="${td}">Other expenses</td><td style="${num}">${money(p.extra_total)}</td></tr>
        <tr style="font-weight:bold;font-size:15px"><td style="${td}">Total payable</td><td style="${num}">₹ ${money(p.total)}</td></tr></table>
      <div style="margin-top:10px"><b>In words:</b> ${esc(inWords(Math.round(p.total)))}</div>
      <div style="display:flex;justify-content:space-between;margin-top:70px;text-align:center">
        ${['Prepared by', 'Received by', `For ${esc(firm.name)}<br>Authorised signatory`].map(s => `<div style="width:30%;border-top:1px solid #000;padding-top:4px">${s}</div>`).join('')}</div>
      <div style="margin-top:20px;font-size:10px;color:#444">Saved on ${esc(d.saved_at || '')} · Printed ${esc(new Date().toLocaleString('en-IN'))}</div></div>`;
  });
  return shell(`Factory wages ${d.month}`, pages, opts);
}

module.exports = { wagesHtml, localFreightHtml, trInvoiceHtml, invoiceHtml, voucherHtml, labelHtml, envelopeHtml, setupFor, invoiceCopies, PAPERS, DEFAULT_SETUP, shell, barcode128,
  pageSetup, pageShell, paperSize, sheetSize, sheetCount, mediaFor, placeDoc, printable, slots, arrange, isMulti, PAGE_PAPERS, LABEL_PRESETS };
