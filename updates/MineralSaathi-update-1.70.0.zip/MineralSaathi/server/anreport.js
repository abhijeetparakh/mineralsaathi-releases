'use strict';
// Master → Analysis Reports: test reports (chemical & physical properties) of a grade, kept as templates.
// Each report is linked to Item + Colour + Form + Mesh (Item lists). With an invoice or a sample dispatch email,
// the report of the same combination as the item sent is attached as a PDF, printed on the firm's letter head.
const fs = require('node:fs');
const path = require('node:path');
const { all, get, run } = require('./db');
const mailer = require('./mailer');
const { makePdf } = require('./pdf');

run(`CREATE TABLE IF NOT EXISTS analysis_reports (id INTEGER PRIMARY KEY, name TEXT NOT NULL, heading TEXT, product TEXT, colour TEXT, form TEXT, mesh TEXT,
  rows TEXT, note TEXT, active INTEGER DEFAULT 1, updated_at TEXT DEFAULT (datetime('now','localtime')))`);
class E extends Error { constructor(m) { super(m); this.status = 400; } }

// the sample report (from the user's sheet)
if (!get('SELECT 1 FROM analysis_reports')) {
  const rows = [
    ['Silica (as SiO2)', '75.3', 'IS:9406-1980 guidelines'], ['Calcium oxide (CaO)', '5.9', 'IS:9406-1980 guidelines, ICP-OES'],
    ['Magnesium oxide (MgO)', '1.8', 'IS:9406-1980 guidelines, ICP-OES'], ['Alumina (Al2O3)', '4.6', 'IS:9406-1980 guidelines, ICP-OES'],
    ['Ferric oxide as (Fe2O3)', '0.93', 'IS:9406-1980 guidelines, ICP-OES'], ['Sodium oxide (Na2O)', '0.46', 'ASTM C-1240 guidelines & AAS'],
    ['Loss on ignition (at 950°C)', '10.5', 'ASTM C-1240 guidelines'], ['Water absorption', '82', 'IS 12292-1988 guidelines'],
    ['Oil absorption (gm/100gm)', '73', 'IS:9406-1980 guidelines'], ['pH (10% solution)', '9.0', 'IS:9406-1980 guidelines'],
    ['Specific gravity', '2.2', 'IS:9406-1980 guidelines'], ['Moisture', '11.3', 'ASTM-4574 guidelines']];
  run('INSERT INTO analysis_reports(name, heading, product, colour, form, mesh, rows, note) VALUES(?,?,?,?,?,?,?,?)',
    'Diatomaceous Earth Light Yellow', 'Chemical & Physical Properties', 'DIATOMACEOUS EARTH', 'YELLOW', 'POWDER', null, JSON.stringify(rows), null);
}

const up = v => { const s = String(v ?? '').trim().toUpperCase().replace(/\s+/g, ' '); return s || null; };
const parseRows = r => { try { const a = JSON.parse(r || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };
const full = r => r && { ...r, rows: parseRows(r.rows) };
function clean(b) {
  const o = {};
  if (b.name !== undefined) { o.name = String(b.name || '').trim().replace(/\s+/g, ' '); if (!o.name) throw new E('Enter the report name.'); }
  if (b.heading !== undefined) o.heading = String(b.heading || '').trim() || null;
  for (const k of ['product', 'colour', 'form', 'mesh']) if (b[k] !== undefined) o[k] = up(b[k]);
  if (b.rows !== undefined) o.rows = JSON.stringify((Array.isArray(b.rows) ? b.rows : []).map(r => [0, 1, 2].map(i => String((r || [])[i] ?? '').trim())).filter(r => r.some(Boolean)));
  if (b.note !== undefined) o.note = String(b.note || '').trim() || null;
  return o;
}

// ---- which report goes with an item line ----
const listVals = k => all("SELECT value FROM lists WHERE list_key = ? AND active = 1", k).map(r => String(r.value).toUpperCase());
const meshNo = s => { const m = String(s || '').match(/(\d{2,4})/); return m ? m[1] : null; };
// colour / form / mesh of an item line: from the line itself (samples), else Item List / buyer items, else read from the grade ("Y300 MESH")
function lineAttrs(l, partyId) {
  const name = up(l.item_name) || '', grade = up(l.grade) || '';
  const a = { product: name, colour: up(l.colour), form: up(l.form), mesh: up(l.mesh) };
  const fill = r => { if (!r) return; for (const k of ['colour', 'form', 'mesh']) if (!a[k] && r[k]) a[k] = up(r[k]); };
  fill(get('SELECT colour, form, mesh FROM items WHERE upper(trim(name)) = ? AND upper(trim(COALESCE(grade, \'\'))) = ? ORDER BY active DESC LIMIT 1', name, grade));
  if (partyId) fill(get('SELECT colour, form, mesh FROM party_items WHERE party_id = ? AND upper(trim(item_name)) = ? AND upper(trim(COALESCE(grade, \'\'))) = ? LIMIT 1', partyId, name, grade));
  const text = `${name} ${grade}`;
  if (!a.colour) {
    const cs = listVals('colour');
    a.colour = cs.find(c => new RegExp(`\\b${c.replace(/[^A-Z0-9 ]/g, '')}\\b`).test(text)) || null;
    const ini = grade.match(/^([A-Z])\s*\d/);                       // Y300 → YELLOW, W325 → WHITE
    if (!a.colour && ini) a.colour = cs.find(c => c[0] === ini[1]) || null;
  }
  if (!a.mesh) { const n = meshNo(grade); if (n) a.mesh = listVals('mesh').find(m => meshNo(m) === n) || n; }
  if (!a.form) {
    const fs_ = listVals('form');
    a.form = fs_.find(f => text.includes(f)) || fs_.find(f => f.split(' ')[0].length > 3 && text.includes(f.split(' ')[0])) || (a.mesh && fs_.includes('POWDER') ? 'POWDER' : null);
  }
  return a;
}
// the best report for a line: every field set on the report must agree; the report with most fields set wins
function reportFor(attrs, reports = all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY id')) {
  let best = null, score = 0;
  for (const r of reports) {
    let s = 0, ok = true;
    for (const k of ['product', 'colour', 'form', 'mesh']) {
      if (!r[k]) continue;
      const want = up(r[k]), have = attrs[k] || '';
      const same = k === 'mesh' ? (meshNo(want) && meshNo(want) === meshNo(have)) || want === have : k === 'product' ? have === want || have.startsWith(want + ' ') || have.startsWith(want + ' (') : want === have;
      if (!same) { ok = false; break; }
      s++;
    }
    if (ok && s > score) { best = r; score = s; }
  }
  return best;
}
function reportsForLines(lines, partyId) {
  const reports = all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY id'), out = new Map();
  for (const l of lines) { const r = reportFor(lineAttrs(l, partyId), reports); if (r && !out.has(r.id)) out.set(r.id, r); }
  return [...out.values()];
}

// ---- print (on the firm's letter head, the same head as the invoice) ----
function reportHtml(rep, f, opts = {}) {
  const P = require('./print'), esc = P.esc;
  const brand = P.brand(f);
  const rows = rep.rows.map((r, i) => `<tr><td class="c">${i + 1}.</td><td>${esc(r[0])}</td><td class="c">${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join('');
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10).split('-').reverse().join('.');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(rep.name)} — ${esc(f.name)}</title><style>
@page { size: A4; margin: 12mm; }
* { box-sizing: border-box; } body { font-family: Arial, Helvetica, sans-serif; color: #1d2b30; margin: 0; font-size: 13px; }
.no-print { padding: 8px; background: #eef3f4; text-align: center; } .no-print button { font-size: 14px; padding: 6px 16px; margin: 0 4px; }
@media print { .no-print { display: none; } }
@media screen { body { background: #e7edef; } .page { background: #fff; width: 210mm; min-height: 297mm; margin: 10px auto; padding: 12mm; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
.head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2F4F5A; padding-bottom: 8px; }
.firm { font-size: 22px; font-weight: bold; color: #2F4F5A; } .muted { color: #44575d; font-size: 12px; } .r { text-align: right; }
.title { text-align: center; margin: 22px 0 14px; } .title div { font-size: 18px; font-weight: bold; text-decoration: underline; margin: 3px 0; font-family: Georgia, 'Times New Roman', serif; }
table.rep { width: 100%; border-collapse: collapse; margin-top: 8px; } table.rep th, table.rep td { border: 1px solid #9fb1b6; padding: 7px 9px; vertical-align: top; }
table.rep th { background: #eef3f4; text-align: left; font-size: 13px; } td.c, th.c { text-align: center; } table.rep td { font-size: 13.5px; }
.note { margin-top: 16px; white-space: pre-wrap; line-height: 1.45; } .sign { margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; }
</style></head><body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
<div class="page">
  <div class="head"><div style="display:flex;gap:14px;align-items:center">${brand ? P.brandImg(f, 80, 300) + '<div>' : P.logoTag(f) + `<div><div class="firm">${esc(String(f.name || '').toUpperCase())}</div>`}
    <div class="muted">${esc(f.address || '')}, ${esc(f.city || '')}${f.pincode ? ' - ' + esc(f.pincode) : ''}${f.state ? ' (' + esc(f.state) + ')' : ''}<br>${f.phone ? 'Ph: ' + esc(f.phone) + ' · ' : ''}${esc(f.email || '')}</div></div></div>
    <div class="r" style="white-space:nowrap;padding-left:12px">${f.gstin ? `GSTIN: <b>${esc(f.gstin)}</b><br>` : ''}${f.pan ? 'PAN: ' + esc(f.pan) + '<br>' : ''}Date: <b>${today}</b></div></div>
  <div class="title">${rep.heading ? `<div>${esc(rep.heading)}</div>` : ''}<div>${esc(rep.name)}</div></div>
  <table class="rep"><thead><tr><th class="c" style="width:9%">Sl No.</th><th style="width:38%">Content</th><th class="c" style="width:18%">Observed Value in %</th><th>Protocol Adopted</th></tr></thead><tbody>${rows}</tbody></table>
  ${rep.note ? `<div class="note">${esc(rep.note)}</div>` : ''}
  <div class="sign"><div class="muted"></div><div class="r">For <b>${esc(f.name || '')}</b><div style="height:52px;display:flex;justify-content:flex-end;align-items:center">${P.signTag(f)}</div>Authorised signatory</div></div>
</div>${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

const firmOf = code => get('SELECT * FROM firms WHERE code = ?', code || 'PM') || get("SELECT * FROM firms WHERE code = 'PM'") || get('SELECT * FROM firms ORDER BY id LIMIT 1');
const safe = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
// the PDF of a report for a firm (kept in the PDF folder → Analysis Reports)
async function reportPdf(id, firmCode, { port, pdfFolder }) {
  const rep = get('SELECT * FROM analysis_reports WHERE id = ?', id); if (!rep) throw new E('Analysis report not found.');
  const f = firmOf(firmCode);
  const file = path.join(pdfFolder(), 'Analysis Reports', safe(`${rep.name} - ${f.name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${port()}/print/anreport/${id}?firm=${encodeURIComponent(f.code)}&shot=1`, file);
  return file;
}

function register(route, { smtpSend, brandLogo, port, pdfFolder }) {
  route('GET', '/api/anreports', () => all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY name').map(full));
  route('GET', '/api/anreports/:id', ({ p }) => { const r = full(get('SELECT * FROM analysis_reports WHERE id = ?', p.id)); if (!r) throw new E('Analysis report not found.'); return r; });
  route('POST', '/api/anreports', ({ body }) => {
    const o = clean(body || {}); if (!o.name) throw new E('Enter the report name.');
    const k = Object.keys(o); return { id: Number(run(`INSERT INTO analysis_reports(${k.join(', ')}) VALUES(${k.map(() => '?').join(', ')})`, ...k.map(x => o[x])).lastInsertRowid) };
  });
  route('PUT', '/api/anreports/:id', ({ p, body }) => {
    const o = clean(body || {}), k = Object.keys(o); if (!k.length) return { id: Number(p.id) };
    run(`UPDATE analysis_reports SET ${k.map(x => x + ' = ?').join(', ')}, updated_at = datetime('now','localtime') WHERE id = ?`, ...k.map(x => o[x]), p.id); return { id: Number(p.id) };
  });
  route('POST', '/api/anreports/:id/copy', ({ p }) => {
    const r = get('SELECT * FROM analysis_reports WHERE id = ?', p.id); if (!r) throw new E('Analysis report not found.');
    return { id: Number(run('INSERT INTO analysis_reports(name, heading, product, colour, form, mesh, rows, note) VALUES(?,?,?,?,?,?,?,?)', r.name + ' (copy)', r.heading, r.product, r.colour, r.form, r.mesh, r.rows, r.note).lastInsertRowid) };
  });
  route('DELETE', '/api/anreports/:id', ({ p }) => { run('UPDATE analysis_reports SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });
  // which report an item would get (to check the link): ?item=&grade=&colour=&form=&mesh=
  route('GET', '/api/anreports-match', ({ q }) => { const a = lineAttrs({ item_name: q.item, grade: q.grade, colour: q.colour, form: q.form, mesh: q.mesh }); const r = reportFor(a); return { attrs: a, report: r ? { id: r.id, name: r.name } : null }; });
  // email one report as a PDF
  route('POST', '/api/anreports/:id/email', async ({ p, body }) => {
    const rep = get('SELECT * FROM analysis_reports WHERE id = ?', p.id); if (!rep) throw new E('Analysis report not found.');
    const f = firmOf(body.firm_code), to = mailer.splitAddr(body.to), cc = mailer.splitAddr(body.cc);
    const log = (status, error) => run('INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)',
      f.code, f.name, to.join('; '), to.join('; '), 'Analysis report', rep.name, 'Analysis report', status, error || null, status === 'SENT' ? rep.name : null);
    try {
      if (!f.smtp_user || !f.smtp_pass) throw new E(`Email is not set up for ${f.name}. Open Settings → Companies → Email.`);
      if (!to.length) throw new E('Enter the email address.');
      const file = await reportPdf(rep.id, f.code, { port, pdfFolder });
      const text = String(body.text || `Dear Sir / Madam,\n\nPlease find attached the analysis report of ${rep.name}.\n\nRegards,\n${f.name}`);
      await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
        { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || `Analysis report — ${rep.name} — ${f.name}`, text, html: mailer.textToHtml(text), attachments: [{ path: file, filename: path.basename(file) }] });
      log('SENT'); return { sent: true };
    } catch (e) { log('FAILED', e.message); throw e; }
  });
  route('GET', '/api/anreports-firms', () => ({ firms: all('SELECT code, name, smtp_user FROM firms ORDER BY id').map(f => ({ code: f.code, name: f.name, email: !!f.smtp_user })) }));
}
// /print/anreport/:id?firm=PM
function serve(id, q) {
  const r = full(get('SELECT * FROM analysis_reports WHERE id = ?', id)); if (!r) return null;
  return reportHtml(r, firmOf(q.firm), { shot: q.shot === '1', autoPrint: q.print === '1' });
}
// attachments for an email: the reports of these item lines, as PDFs of this firm
async function attachFor(lines, partyId, firmCode, ctx) {
  const out = [];
  for (const r of reportsForLines(lines, partyId)) { const file = await reportPdf(r.id, firmCode, ctx); out.push({ path: file, filename: path.basename(file), name: r.name }); }
  return out;
}
module.exports = { register, serve, reportsForLines, attachFor, lineAttrs, reportFor };
