'use strict';
// Printable pages (A4). The app opens these to print or save as PDF; email uses them to make the PDF.
const { get } = require('./db');
const { inWords, freightFigures, r2 } = require('./logic');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const qty = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 3 });
const dmy = iso => iso ? iso.split('-').reverse().join('.') : '';
const nl = s => esc(s).replace(/\n/g, '<br>');

const BASE_CSS = `
* { box-sizing: border-box; }
body { font-family: "Segoe UI", Arial, sans-serif; font-size: 11.5px; color: #1d2b31; margin: 0; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #2F4F5A; padding: 4px 6px; vertical-align: top; }
th { background: #e8f1f3; font-weight: 600; text-align: left; }
.r { text-align: right; } .c { text-align: center; }
.head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #9A4A2A; padding-bottom: 6px; margin-bottom: 6px; }
.firm { font-size: 24px; font-weight: 800; color: #2F4F5A; letter-spacing: .5px; }
.muted { color: #5b6b70; }
.title { font-size: 15px; font-weight: 700; color: #9A4A2A; text-align: right; }
.box { border: 1px solid #2F4F5A; padding: 6px 8px; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 6px; }
.lbl { color: #5b6b70; font-size: 10px; text-transform: uppercase; letter-spacing: .4px; }
.big { font-size: 13px; font-weight: 700; }
.tot td { font-weight: 700; background: #f4ece7; white-space: nowrap; }
.sign { height: 60px; }
.no-print { background: #1A3E4A; padding: 10px; margin-bottom: 14px; text-align: center; }
.no-print button { font-size: 14px; padding: 8px 16px; background: #1A9BB5; color: #fff; border: 0; border-radius: 6px; cursor: pointer; margin-left: 6px; }
@media print { .no-print { display: none; } }
`;

const logoTag = f => f.logo && /^data:image\/(png|jpeg|webp);base64,/.test(f.logo) ? `<img src="${f.logo}" style="max-height:62px;max-width:150px">` : '';

// ---- page setup: paper size, margin, nudge and scale (Settings > This computer > Printers) ----
const PAPERS = {
  A4: [210, 297], A5: [148, 210], LETTER: [215.9, 279.4], LABEL4X6: [101.6, 152.4],
  ENV_DL: [220, 110], ENV_C5: [229, 162], ENV_10: [241, 105]
};
const DEFAULT_SETUP = {
  invoice: { paper: 'A4', w: 210, h: 297, margin: 10, ox: 0, oy: 0, scale: 100 },
  label: { paper: 'LABEL4X6', w: 101.6, h: 152.4, margin: 3, ox: 0, oy: 0, scale: 100 },
  envelope: { paper: 'ENV_DL', w: 220, h: 110, margin: 8, ox: 0, oy: 0, scale: 100 }
};
function setupFor(kind, s) {
  const d = { ...DEFAULT_SETUP[kind], ...(s || {}) };
  if (d.paper && PAPERS[d.paper]) { const [w, h] = PAPERS[d.paper]; d.w = w; d.h = h; }
  if (d.landscape) { const a = Math.max(d.w, d.h), b = Math.min(d.w, d.h); d.w = a; d.h = b; }
  for (const k of ['w', 'h', 'margin', 'ox', 'oy', 'scale']) d[k] = Number(d[k]) || (k === 'scale' ? 100 : 0);
  return d;
}
function sheetCss(s, shot) {
  const sc = (s.scale || 100) / 100;
  return `@page { size: ${s.w}mm ${s.h}mm; margin: 0; }
.sheet { width: ${s.w}mm; height: ${s.h}mm; padding: ${s.margin}mm; overflow: hidden; position: relative; background: #fff; break-after: page; page-break-after: always; }
.sheet:last-of-type { break-after: auto; page-break-after: auto; }
.inner { width: ${(s.w - 2 * s.margin) / sc}mm; transform: translate(${s.ox}mm, ${s.oy}mm) scale(${sc}); transform-origin: top left; }
@media screen { body { background: #e7edef; } .sheet { margin: 10px auto; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
${shot ? 'html, body { background: #fff !important; } .sheet { margin: 0 !important; box-shadow: none !important; } .no-print { display: none !important; }' : ''}`;
}

function shell(title, sheets, opts = {}) {
  const s = opts.setup;
  const pages = (Array.isArray(sheets) ? sheets : [sheets]).map(b => `<div class="sheet"><div class="inner">${b}</div></div>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${BASE_CSS}${sheetCss(s, opts.shot)}</style></head>
<body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
${pages}${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

// Copies: one copy when the invoice is 9 MT or more, otherwise two (original + duplicate).
function invoiceCopies(inv, singleFromMt = 9) {
  const total = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);
  return total >= singleFromMt ? ['ORIGINAL FOR RECIPIENT'] : ['ORIGINAL FOR RECIPIENT', 'DUPLICATE FOR TRANSPORTER'];
}

function invoiceHtml(inv, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const setup = setupFor('invoice', opts.setup);
  const f = inv.firm;
  const intra = !(inv.igst > 0);
  const isPpe = inv.kind === 'PPE_BILL';
  const rows = inv.items.map(it => {
    const desc = [`<b>${esc(it.item_name)}</b>`];
    if (it.grade) desc.push(esc(it.grade));
    if (isPpe) desc.push(`Lorry ${esc(it.lorry_no || '')}${it.rawana_no ? ' · Rawana ' + esc(it.rawana_no) : ''}${it.challan_no ? ' · Challan ' + esc(it.challan_no) : ''}`);
    const pack = [
      (it.bags || it.pack_size) ? `${it.bags ? esc(it.bags) + ' bags' : ''}${it.pack_size ? ' × ' + esc(it.pack_size) + ' kg' : ''}` : '',
      it.bag_type ? esc(it.bag_type) : '',
      it.packing_type ? esc(it.packing_type) : '',
      it.liner === 1 ? 'with liner' : it.liner === 0 ? 'without liner' : '',
      it.bag_supply === 'BUYER' ? "in buyer's own bags" : ''
    ].filter(Boolean).join(' · ');
    if (pack) desc.push(pack);
    return `<tr><td class="c">${it.sl}</td><td>${desc.join('<br>')}</td><td class="c">${esc(it.hsn)}</td><td class="r">${qty(it.qty)}</td>
      <td class="c">${esc(it.unit)}</td><td class="r">${money(it.rate)}</td><td class="c">${it.gst_rate}%</td><td class="r">${money(it.amount)}</td></tr>`;
  }).join('');
  const totalQty = inv.items.reduce((s, it) => s + (Number(it.qty) || 0), 0);

  // HSN summary
  const hsn = {};
  for (const it of inv.items) {
    const k = it.hsn + '|' + it.gst_rate;
    hsn[k] = hsn[k] || { hsn: it.hsn, rate: it.gst_rate, taxable: 0 };
    hsn[k].taxable += it.amount;
  }
  const hsnRows = Object.values(hsn).map(h => {
    const tax = r2(h.taxable * h.rate / 100);
    return `<tr><td>${esc(h.hsn)}</td><td class="r">${money(h.taxable)}</td>
      ${intra ? `<td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td><td class="r">${h.rate / 2}%</td><td class="r">${money(tax / 2)}</td>`
        : `<td class="r">${h.rate}%</td><td class="r">${money(tax)}</td>`}<td class="r">${money(tax)}</td></tr>`;
  }).join('');

  const bank = [f.bank_name && `Bank: ${esc(f.bank_name)}`, f.bank_account && `A/c: ${esc(f.bank_account)}`, f.bank_ifsc && `IFSC: ${esc(f.bank_ifsc)}`, f.upi_id && `UPI: ${esc(f.upi_id)}`].filter(Boolean).join(' · ');

  const page = copyLabel => `<div>
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div>
    <div class="muted">${esc(f.address)}, ${esc(f.city)} - ${esc(f.pincode)} (${esc(f.state)})<br>Ph: ${esc(f.phone)} · ${esc(f.email)}</div></div></div>
    <div>${copyLabel ? `<div class="r" style="font-size:9.5px;font-weight:700;letter-spacing:.5px;color:#5b6b70">${esc(copyLabel)}</div>` : ''}<div class="title">TAX INVOICE${inv.cancelled ? ' — CANCELLED' : ''}</div>
    <div class="r">GSTIN: <b>${esc(f.gstin)}</b><br>PAN: ${esc(f.pan)}</div></div></div>

  <div class="grid2">
    <div class="box"><div class="lbl">Bill to</div><div class="big">${esc(inv.party_name)}</div>
      ${nl(inv.party_address)}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}, ${esc(inv.party_state || '')}
      ${inv.party_state_code ? ' (Code ' + esc(inv.party_state_code) + ')' : ''}<br>
      ${inv.party_gstin ? 'GSTIN: <b>' + esc(inv.party_gstin) + '</b>' : 'Unregistered (B2C)'}${inv.party_pan ? ' · PAN: ' + esc(inv.party_pan) : ''}
      ${inv.ship_address ? `<div style="margin-top:4px"><span class="lbl">Ship to</span><br>${nl(inv.ship_address)}</div>` : ''}</div>
    <div class="box"><table style="border:0"><tbody>
      <tr><td style="border:0">Invoice No.</td><td style="border:0" class="big">${esc(inv.inv_no)}</td><td style="border:0">Date</td><td style="border:0" class="big">${dmy(inv.date)}</td></tr>
      <tr><td style="border:0">F.Y.</td><td style="border:0">${esc(inv.fy)}</td><td style="border:0">Lorry No.</td><td style="border:0"><b>${esc(isPpe ? '' : inv.lorry_no || '')}</b></td></tr>
      <tr><td style="border:0">Transporter</td><td style="border:0" colspan="3">${esc(inv.transporter || '')}${inv.transporter_gstin ? ' · GSTIN ' + esc(inv.transporter_gstin) : ''}</td></tr>
      <tr><td style="border:0">L.R. No.</td><td style="border:0">${esc(inv.lr_no || '')}</td><td style="border:0">E-way bill</td><td style="border:0">${esc(inv.ewb_no || '')}</td></tr>
      ${inv.driver_phone ? `<tr><td style="border:0">Driver Ph.</td><td style="border:0" colspan="3">${esc(inv.driver_phone)}</td></tr>` : ''}
    </tbody></table></div>
  </div>

  <table><thead><tr><th class="c" style="width:28px">#</th><th>Description of goods</th><th class="c">HSN</th><th class="r">Qty</th><th class="c">Unit</th><th class="r">Rate</th><th class="c">GST</th><th class="r">Amount</th></tr></thead>
  <tbody>${rows}
  <tr><td></td><td class="r"><b>Total quantity</b></td><td></td><td class="r"><b>${qty(totalQty)}</b></td><td class="c">MT</td><td></td><td class="r">Taxable</td><td class="r"><b>${money(inv.taxable)}</b></td></tr>
  ${intra ? `<tr><td colspan="7" class="r">CGST</td><td class="r">${money(inv.cgst)}</td></tr><tr><td colspan="7" class="r">SGST</td><td class="r">${money(inv.sgst)}</td></tr>`
           : `<tr><td colspan="7" class="r">IGST</td><td class="r">${money(inv.igst)}</td></tr>`}
  ${inv.round_off ? `<tr><td colspan="7" class="r">Round off</td><td class="r">${money(inv.round_off)}</td></tr>` : ''}
  <tr class="tot"><td colspan="7" class="r">Grand total</td><td class="r">₹ ${money(inv.total)}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(inv.total))}</b></div>

  <table style="margin-top:6px"><thead><tr><th>HSN</th><th class="r">Taxable</th>${intra ? '<th class="r">CGST %</th><th class="r">CGST</th><th class="r">SGST %</th><th class="r">SGST</th>' : '<th class="r">IGST %</th><th class="r">IGST</th>'}<th class="r">Total tax</th></tr></thead>
  <tbody>${hsnRows}</tbody></table>

  ${inv.freight_note || inv.notes ? `<div class="box" style="margin-top:6px">${inv.freight_note ? '<b>Freight:</b> ' + esc(inv.freight_note) + '<br>' : ''}${inv.notes ? esc(inv.notes) : ''}</div>` : ''}

  <div class="grid2" style="margin-top:6px">
    <div class="box"><div class="lbl">Terms of sale</div>${nl(f.terms || '')}${bank ? `<div style="margin-top:6px">${bank}</div>` : ''}</div>
    <div class="box r"><div>For <b>${esc(f.name.toUpperCase())}</b></div><div class="sign"></div><div>Authorised Signatory</div></div>
  </div>
  <div class="c muted" style="margin-top:4px">This is a computer generated invoice.</div>
</div>`;
  let copies = opts.copies || (isPpe ? [''] : invoiceCopies(inv, opts.singleFromMt));
  if (opts.copy != null) copies = [copies[Number(opts.copy)] ?? copies[0]];
  return shell(`${f.name} Invoice ${inv.inv_no}`, copies.map(page), { ...opts, setup });
}

function voucherHtml(w, opts = {}) {
  if (typeof opts === 'boolean') opts = { autoPrint: opts };
  const isPpe = /^PPE/i.test(w.voucher_no);
  const f = get('SELECT * FROM firms WHERE code = ?', isPpe ? 'PPE' : 'PM');
  const { amount, shownRate } = freightFigures(w);
  const adv = Number(w.advance) || 0;
  const net = r2(amount - adv);
  const body = `<div>
  <div class="head"><div style="display:flex;gap:12px;align-items:center">${logoTag(f)}<div><div class="firm">${esc(f.name.toUpperCase())}</div><div class="muted">${esc(f.address)}, ${esc(f.city)}</div></div></div>
  <div class="title">FREIGHT PAYMENT VOUCHER</div></div>
  <table><tbody>
    <tr><td>Voucher No.</td><td class="big">${esc(w.voucher_no)}</td><td>Voucher date</td><td>${dmy(w.voucher_date)}</td></tr>
    <tr><td>Plant</td><td>${esc(w.plant || '')}</td><td>Received on</td><td>${dmy(w.date)}</td></tr>
    <tr><td>Lorry No.</td><td class="big">${esc(w.lorry_no)}</td><td>Challan No.</td><td>${esc(w.challan_no || '')}</td></tr>
    <tr><td>Rawana No.</td><td>${esc(w.rawana_no || '')}</td><td>From → To</td><td><b>${esc(w.supplier || '')}</b> → <b>${esc(w.to_party || 'PARAKH MARKETING')}</b>${w.mines ? '<br>Mines: ' + esc(w.mines) : ''}</td></tr>
    <tr><td>Grade</td><td>${esc(w.grade || '')} ${esc(w.condition || '')}</td><td>Owner</td><td>${esc(w.owner_name || '')}${w.pan ? ' · PAN ' + esc(w.pan) : ''}</td></tr>
    <tr><td>Driver</td><td>${esc(w.driver_name || '')} ${esc(w.driver_phone || '')}</td><td>UPI</td><td>${esc(w.upi || '')}</td></tr>
  </tbody></table>
  <table style="margin-top:8px"><thead><tr><th>Particulars</th><th class="r">Weight (MT)</th><th class="r">Rate / MT</th><th class="r">Amount</th></tr></thead>
  <tbody><tr><td>Freight for ${esc(w.lorry_no)}</td><td class="r">${qty(w.rawana_wt)}</td><td class="r">${money(shownRate)}</td><td class="r">${money(amount)}</td></tr>
  ${adv ? `<tr><td colspan="3" class="r">Less advance</td><td class="r">${money(adv)}</td></tr>` : ''}
  <tr class="tot"><td colspan="3" class="r">Net payable</td><td class="r">₹ ${money(net)}</td></tr>
  <tr><td colspan="4">Paid: Cash ₹ ${money(w.cash_amt)} · Bank ₹ ${money(w.bank_amt)}${w.pay_mode ? ' (' + esc(w.pay_mode) + ')' : ''}${w.chq_no ? ' · Ref ' + esc(w.chq_no) : ''}</td></tr>
  </tbody></table>
  <div class="box" style="margin-top:6px"><b>${esc(inWords(net))}</b></div>
  <div class="grid2" style="margin-top:20px"><div class="box"><div class="sign"></div>Receiver's signature</div><div class="box r"><div class="sign"></div>For ${esc(f.name.toUpperCase())}</div></div>
</div>`;
  return shell(`Voucher ${w.voucher_no}`, body, { ...opts, setup: setupFor('invoice', opts.setup) });
}

// ---- 4 x 6 bag / parcel sticker: To, Bag No. n / N, From ----
function labelHtml(inv, opts = {}) {
  const s = setupFor('label', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const of = Math.max(1, Number(opts.of) || 1);
  const from = Math.max(1, Number(opts.from) || 1), to = Math.min(of, Math.max(from, Number(opts.to) || of));
  const phone = p.mobile || p.phone || '';
  const items = inv.items.map(it => [it.item_name, it.grade].filter(Boolean).join(' ') + (it.pack_size ? ` · ${it.pack_size} kg bag` : '')).join('<br>');
  const one = n => `<div class="lbl4x6">
    <div class="to"><div class="k">TO</div>
      <div class="nm">${esc(inv.party_name)}</div>
      <div class="ad">${nl(inv.ship_address || inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - <b>' + esc(inv.party_pincode) + '</b>' : ''}<br>${esc(inv.party_state || '')}</div>
      ${phone ? `<div class="ph">Ph: <b>${esc(phone)}</b></div>` : ''}</div>
    <div class="bag"><span>BAG NO.</span><b>${n}</b><span>/</span><b>${of}</b><span>BAGS</span></div>
    <div class="info">Invoice <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>${items}${inv.transporter ? '<br>By ' + esc(inv.transporter) : ''}</div>
    <div class="from"><div class="k">FROM</div><b>${esc(f.name.toUpperCase())}</b><br>${esc(f.address)}<br>${esc(f.city)} - ${esc(f.pincode)} · ${esc(f.state)}<br>Ph: ${esc(f.phone)}${f.gstin ? ' · GSTIN ' + esc(f.gstin) : ''}</div>
  </div>`;
  const pages = []; for (let n = from; n <= to; n++) pages.push(one(n));
  const css = `<style>
    .lbl4x6 { height: ${s.h - 2 * s.margin}mm; display: flex; flex-direction: column; gap: 2.5mm; font-size: 12px; }
    .lbl4x6 .k { font-size: 10px; font-weight: 800; letter-spacing: 1px; color: #000; border-bottom: 1px solid #000; margin-bottom: 1mm; }
    .lbl4x6 .to { border: 2px solid #000; padding: 2.5mm; flex: 1; }
    .lbl4x6 .nm { font-size: 20px; font-weight: 800; line-height: 1.15; color: #000; }
    .lbl4x6 .ad { font-size: 14px; line-height: 1.35; margin-top: 1mm; color: #000; }
    .lbl4x6 .ph { font-size: 14px; margin-top: 1mm; color: #000; }
    .lbl4x6 .bag { border: 2px solid #000; display: flex; align-items: baseline; justify-content: center; gap: 3mm; padding: 1.5mm; color: #000; }
    .lbl4x6 .bag span { font-size: 13px; font-weight: 700; } .lbl4x6 .bag b { font-size: 34px; }
    .lbl4x6 .info { font-size: 11.5px; color: #000; }
    .lbl4x6 .from { border-top: 2px dashed #000; padding-top: 2mm; font-size: 11px; line-height: 1.35; color: #000; }
  </style>`;
  pages[0] = css + pages[0];
  return shell(`Bag stickers ${inv.inv_no}`, pages, { ...opts, setup: s });
}

// ---- envelope: invoice, lorry, transporter, e-way bill, To M/s … ----
function envelopeHtml(inv, opts = {}) {
  const s = setupFor('envelope', opts.setup);
  const f = inv.firm, p = inv.party || {};
  const phone = p.mobile || p.phone || '';
  const body = `<style>
    .env { height: ${s.h - 2 * s.margin}mm; display: grid; grid-template-columns: 1fr 1.25fr; gap: 6mm; font-size: 12px; color: #000; }
    .env .left { font-size: 11px; line-height: 1.45; }
    .env .left .firm2 { font-size: 15px; font-weight: 800; }
    .env .ref { margin-top: 3mm; border: 1px solid #000; padding: 2mm; line-height: 1.6; }
    .env .right { align-self: center; border-left: 2px solid #000; padding-left: 5mm; }
    .env .right .k { font-size: 11px; font-weight: 700; letter-spacing: 1px; }
    .env .right .nm { font-size: 17px; font-weight: 800; margin: 1mm 0; }
    .env .right .ad { font-size: 13px; line-height: 1.4; }
  </style><div class="env">
    <div class="left">${logoTag(f)}<div class="firm2">${esc(f.name.toUpperCase())}</div>${esc(f.address)}<br>${esc(f.city)} - ${esc(f.pincode)}, ${esc(f.state)}<br>Ph: ${esc(f.phone)}
      <div class="ref">Invoice No. <b>${esc(inv.inv_no)}</b> · ${dmy(inv.date)}<br>Lorry No. <b>${esc(inv.lorry_no || '')}</b><br>${esc(inv.transporter || '')}${inv.lr_no ? ' · L.R. ' + esc(inv.lr_no) : ''}<br>E-Way Bill No. <b>${esc(inv.ewb_no || '')}</b></div></div>
    <div class="right"><div class="k">TO</div><div class="nm">M/s. ${esc(inv.party_name)}</div>
      <div class="ad">${nl(inv.party_address || '')}<br>${esc(inv.party_city || '')}${inv.party_pincode ? ' - ' + esc(inv.party_pincode) : ''}<br>${esc(inv.party_state || '')}${phone ? '<br>Ph. ' + esc(phone) : ''}</div></div>
  </div>`;
  return shell(`Envelope ${inv.inv_no}`, body, { ...opts, setup: s });
}

module.exports = { invoiceHtml, voucherHtml, labelHtml, envelopeHtml, setupFor, invoiceCopies, PAPERS, DEFAULT_SETUP };
