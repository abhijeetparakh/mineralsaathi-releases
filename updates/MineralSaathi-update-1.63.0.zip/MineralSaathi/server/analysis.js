'use strict';
// Reports → Buyer Chart, Sales Analysis, Expected Orders: the sales of all years, ready for the charts.
// Amounts are before GST (taxable value); quantities in MT. Cancelled invoices are left out.
// Sales between our own firms (PPE → PM, PM → PF …) are marked "own" — the screens leave them out unless asked.
const { all } = require('./db');

function data() {
  const own = new Set(all("SELECT upper(COALESCE(gstin, '')) g FROM firms WHERE COALESCE(gstin, '') <> ''").map(r => r.g));
  const ownNames = new Set(all('SELECT upper(trim(name)) n FROM firms').map(r => r.n));
  const parties = {};
  const pkOf = r => r.party_id ? 'p' + r.party_id : 'n' + String(r.party_name || '').trim().toUpperCase();
  const pinfo = new Map(all('SELECT id, name, city, mobile, phone, email, gstin FROM parties').map(p => [p.id, p]));
  const invs = all(`SELECT i.id, i.fy, i.date, i.firm_code, i.kind, i.party_id, i.party_name, i.party_city, i.party_gstin, i.taxable
    FROM invoices i WHERE COALESCE(i.cancelled, 0) = 0 AND i.kind IN ('SALE', 'PPE_BILL') AND i.date IS NOT NULL ORDER BY i.date, i.id`);
  const byInv = new Map(invs.map(i => [i.id, i]));
  for (const i of invs) {
    const pk = pkOf(i);
    if (!parties[pk]) {
      const p = i.party_id ? pinfo.get(i.party_id) : null;
      const g = String((p && p.gstin) || i.party_gstin || '').toUpperCase();
      const name = (p && p.name) || i.party_name || '?';
      parties[pk] = { name, city: (p && p.city) || i.party_city || '', mobile: (p && (p.mobile || p.phone)) || '', email: (p && p.email) || '',
        own: (g && own.has(g)) || ownNames.has(String(name).trim().toUpperCase()) ? 1 : 0 };
    }
  }
  // one row per invoice line, summed by year-month / firm / buyer / item / grade
  const agg = new Map();
  const invRows = new Map();
  for (const it of all('SELECT invoice_id, item_name, grade, qty, amount FROM invoice_items')) {
    const i = byInv.get(it.invoice_id); if (!i) continue;
    const pk = pkOf(i), ym = i.date.slice(0, 7), item = String(it.item_name || '').trim().toUpperCase() || '—', grade = String(it.grade || '').trim().toUpperCase();
    const k = [i.fy, ym, i.firm_code, pk, item, grade].join('\u0001');
    const a = agg.get(k) || [i.fy, ym, i.firm_code, pk, item, grade, 0, 0, 0];
    a[6] += Number(it.qty) || 0; a[7] += Number(it.amount) || 0; agg.set(k, a);
    const v = invRows.get(i.id) || { pk, date: i.date, firm: i.firm_code, qty: 0, amt: 0, items: new Set() };
    v.qty += Number(it.qty) || 0; v.amt += Number(it.amount) || 0; v.items.add(item + (grade ? ' ' + grade : '')); invRows.set(i.id, v);
  }
  // invoices counted once per row group
  const cnt = new Map();
  for (const i of invs) { const k = [i.fy, i.date.slice(0, 7), i.firm_code, pkOf(i)].join('\u0001'); cnt.set(k, (cnt.get(k) || 0) + 1); }
  const lines = [...agg.values()].map(a => [a[0], a[1], a[2], a[3], a[4], a[5], Math.round(a[6] * 1000) / 1000, Math.round(a[7])]);
  const orders = [...invRows.values()].map(v => [v.pk, v.date, v.firm, Math.round(v.qty * 1000) / 1000, Math.round(v.amt), [...v.items].join(', ')]);
  const counts = [...cnt.entries()].map(([k, n]) => [...k.split('\u0001'), n]);
  const fys = [...new Set(invs.map(i => i.fy))].sort();
  return { fys, parties, lines, orders, counts, today: new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10) };
}

module.exports = function register(route) {
  let cache = null, at = 0;
  route('GET', '/api/analysis', () => {
    if (!cache || Date.now() - at > 60e3) { cache = data(); at = Date.now(); }     // the screens ask often; one minute is fresh enough
    return cache;
  });
};
