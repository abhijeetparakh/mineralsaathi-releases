MINERAL SAATHI  —  version 1.0.0
Billing software for P.P. Enterprise, Parakh Marketing and Parakh Fertilizer
=============================================================================

HOW IT WORKS
  * The MAIN OFFICE PC keeps the data and runs a small server.
  * Every PC (the main PC too) opens Mineral Saathi FULL SCREEN in Microsoft Edge.
  * Other PCs install nothing. They load the app from the main PC, so when the
    main PC is updated, every PC gets the new version automatically.
  * Backups go to the folder you choose (Settings & Backup) after every invoice
    and every hour.


ONE-TIME SETUP — MAIN OFFICE PC
  1. Install "Node.js LTS" from https://nodejs.org  (just click Next ... Finish).
  2. Copy this whole "MineralSaathi" folder to the main PC, e.g. D:\MineralSaathi
     (do not keep it inside Google Drive — only the BACKUP folder should be there).
  3. Right-click  Setup-Main-PC.bat  ->  Run as administrator.
     It opens the firewall for the office network, makes the server start with
     Windows, puts a "Mineral Saathi" icon on the desktop, and shows this PC's
     address (for example 192.168.1.10:8765). Note it down.
  4. Double-click  Start-Server.bat  (only this first time; later it starts by itself).
     Keep that black window open — you can minimise it.
  5. Open "Mineral Saathi" from the desktop.
  6. In the app: Settings & Backup -> set the backup folder, e.g.
        G:\My Drive\Mineral Saathi Backup
     and set up email for Parakh Marketing and Parakh Fertilizer.

ONE-TIME SETUP — EVERY OTHER OFFICE PC
  1. Copy only  Setup-Other-PC.bat  and the  windows  folder to that PC.
  2. Double-click Setup-Other-PC.bat and type the main PC address from step 3.
  3. Open "Mineral Saathi" from the desktop.
  The main PC must be switched on and the server running.

FULL SCREEN
  The app always opens full screen. F11 leaves / returns to full screen.
  Alt+F4 closes the app.

EMAIL (no Outlook needed)
  Settings & Backup -> Email. For Gmail: turn on 2-Step Verification on the
  Google account, create an "App password", paste it in, press Save, then
  "Send test". On any saved invoice press "Email to buyer": the app makes the
  PDF and sends it with the message.

UPDATING TO A NEW VERSION
  1. Close the server window on the main PC.
  2. Copy the new  server, public, windows  folders and  version.json  over the old ones.
     NEVER replace the  data  folder — it holds all your entries.
  3. Start-Server.bat again. All PCs switch to the new version within a minute.

RESTORING A BACKUP
  Close the server, copy the backup file you want into the  data  folder,
  rename it to  mineral.db  (replace the old one), start the server again.

WHAT IS IN VERSION 1.0
  * Data imported from the old Excel files: buyers, items, transporters,
    lorry owners & PAN, suppliers, inward 2018-19 onwards, Parakh Marketing
    invoices 2014-15 onwards, P.P. Enterprise bills 2020-21 onwards.
    Old invoices are view & print only.
  * Inward & freight voucher: rawana weight + actual weight. Freight is paid on
    actual weight; the voucher prints rawana weight with the matching rate.
  * P.P. Enterprise -> Parakh Marketing bill: tick inward lorries, quantity is
    the rawana weight.
  * Sales invoices for Parakh Marketing and Parakh Fertilizer with many items
    per invoice. One shared buyer list; each buyer is fixed to one billing firm.
    CGST+SGST inside Rajasthan, IGST outside, automatic round off.
  * Print / PDF, email with PDF, month-wise / inward / HSN reports, CSV export.
