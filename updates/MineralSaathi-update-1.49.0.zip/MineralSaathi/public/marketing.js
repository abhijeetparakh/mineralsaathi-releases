'use strict';
/* Mineral Saathi — Marketing (Sampark Saathi) screens.
   Marketing data lives in its own file (marketing.db); items, companies, printers and the other settings
   are the shared Mineral Saathi ones. Uses the helpers of app.js ($, GET, POST, PAGES, SETTINGS …). */

const MKT_LISTS = [
  ['sample_size', 'Sample size', '100 gm, 500 gm, 1 kg …'],
  ['courier', 'Courier / sent by', 'India Post, DHL, Blue Dart …'],
  ['response', 'Call response', 'Called, no response, not reachable …'],
  ['followup_reason', 'Follow-up reason', 'Why the next call is made'],
  ['templates', 'WhatsApp messages', 'Ready texts for the Communication screen']
];
const MKT_PAGES = {
  calls: ["Today's Calls", 4, 'Calls due today (or any date), overdue calls in red; click a call to open Communication.'],
  new: ['New Sample Dispatch', 2, 'Enquiry and sample details, grade from Master → Item List, tick the papers to print and Print All.'],
  leads: ['Enquiries', 2, 'All enquiries with search by ref. no., company, name, mobile and city, with their samples and calls.'],
  comm: ['Communication', 4, 'History, WhatsApp messages with QR, log the response and plan the next call (Google Calendar).'],
  quick: ['Quick Sticker', 4, 'A 4×6 QR sticker for a walk-in or phone enquiry.'],
  letters: ['Letters', 4, 'Letter Pad, Bus and blank envelope with the sender from Settings → Companies.'],
  reports: ['Marketing Reports', 5, 'Samples by month, grade and courier; pending and overdue calls; enquiries that became buyers.'],
  lists: ['Marketing Lists', 1, '']
};
const TPL_FIELDS = ['{name}', '{company}', '{ref}', '{courier}', '{tracking_no}', '{tracking_link}'];

// show or hide the 📣 Marketing menu (Settings → Marketing)
async function mktMenu() {
  try { const s = await GET('/api/mkt/status'); $('#nav-mkt').hidden = !s.settings.enabled; return s; } catch { return null; }
}
mktMenu();

PAGES.mkt = async (el, arg) => {
  const [page, sub] = String(arg || 'calls').split(':');
  const def = MKT_PAGES[page] || MKT_PAGES.calls;
  $('#title').textContent = def[0];
  const st = await GET('/api/mkt/status');
  if (!st.ok) {
    el.innerHTML = `<div class="card" style="max-width:720px"><h3>⚠ Marketing data cannot be opened</h3>
      <p style="white-space:pre-line">${esc(st.problem || '')}</p><p class="hint">File: ${esc(st.file)}</p></div>`;
    return;
  }
  if (page === 'lists') return mktListsPage(el, sub || 'sample_size');
  if (page === 'new') return mktSampleForm(el, sub || '');
  if (page === 'leads') return sub ? mktLeadPage(el, Number(sub)) : mktLeadsList(el);
  el.innerHTML = `<div class="card" style="max-width:720px"><h3>${esc(def[0])}</h3><p>${esc(def[2])}</p>
    <p><span class="badge amber">Coming in phase ${def[1]}</span></p>
    <p class="hint">Marketing data so far: ${st.counts.leads} enquiries · ${st.counts.samples} samples · ${st.counts.follow_ups_pending} calls pending.</p></div>`;
};

// ---------- Marketing Lists ----------
async function mktListsPage(box, key) {
  if (!MKT_LISTS.some(x => x[0] === key)) key = 'sample_size';
  if (key === 'templates') return mktTemplatesPage(box);
  const lists = await GET('/api/mkt/lists');
  const tpls = await GET('/api/mkt/templates');
  const def = MKT_LISTS.find(x => x[0] === key);
  const rows = lists[key] || [];
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide(key, lists, tpls)}
    <div class="card"><h3>${def[1]} <span class="hint">— ${def[2]}</span></h3>
      <form id="mlf" class="row" style="margin-bottom:14px">
        <label style="flex:1">New value<input name="value" autocomplete="off"></label>
        <button type="submit" id="mlsave">Add</button><button type="button" class="sec" id="mlcancel" hidden>Cancel</button>
      </form>
      <table class="t"><thead><tr><th>Value</th><th style="width:150px"></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.value)}</b></td>
        <td style="text-align:right"><button class="small sec" data-ed="${r.id}">Edit</button> <button class="small sec" data-rm="${r.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="2" class="muted">Nothing in this list yet.</td></tr>'}
      </tbody></table>
      <p class="hint" style="margin-top:12px">Grade, mesh, colour, bag type, bag weight, packing type and unit are not kept here — Marketing uses
        <a href="#/itemlists">Master → Item List</a>, the same lists as billing.</p></div></div>`;
  const f = $('#mlf', box); let editing = null;
  f.value.focus();
  f.onsubmit = async e => {
    e.preventDefault();
    await guard(() => editing ? PUT('/api/mkt/lists/' + editing, { value: f.value.value }) : POST('/api/mkt/lists', { list_key: key, value: f.value.value }));
    toast(editing ? 'Updated' : 'Added'); mktListsPage(box, key);
  };
  $('#mlcancel', box).onclick = () => mktListsPage(box, key);
  box.onclick = async e => {
    const ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ed) { const r = rows.find(x => x.id === Number(ed.dataset.ed)); editing = r.id; f.value.value = r.value;
      $('#mlsave', box).textContent = 'Update'; $('#mlcancel', box).hidden = false; f.value.focus(); }
    if (rm && confirm('Remove this value from the list? Samples and calls that already use it keep it.')) { await guard(() => DEL('/api/mkt/lists/' + rm.dataset.rm)); mktListsPage(box, key); }
  };
}

function mktListSide(key, lists, tpls) {
  return `<div class="card listside" style="padding:8px">${MKT_LISTS.map(([k, t, h]) => `<a class="listhead ${k === key ? 'on' : ''}" onclick="go('#/mkt/lists:${k}')">
    <b>${t}</b><span class="badge grey">${k === 'templates' ? tpls.length : (lists[k] || []).length}</span><br><span class="hint">${h}</span></a>`).join('')}</div>`;
}

// ---------- WhatsApp message templates ----------
function mktFill(body) {   // example of a filled message
  const ex = { '{name}': 'RAMESH KUMAR', '{company}': 'ABC MINERALS', '{ref}': '434', '{courier}': 'DHL', '{tracking_no}': 'RR123456789IN',
    '{tracking_link}': 'https://t.17track.net/en#nums=RR123456789IN' };
  return TPL_FIELDS.reduce((s, k) => s.split(k).join(ex[k]), body);
}
async function mktTemplatesPage(box) {
  const [lists, tpls] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/templates')]);
  box.innerHTML = `<div class="grid listgrid" style="grid-template-columns:260px 1fr;align-items:start">
    ${mktListSide('templates', lists, tpls)}
    <div class="card"><h3>WhatsApp messages <span class="hint">— ready texts for the Communication screen</span></h3>
      <form id="mtf" class="grid" style="grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <label>Name<input name="name" autocomplete="off"></label>
        <div class="hint" style="align-self:end">Words filled in by themselves: ${TPL_FIELDS.map(x => `<code data-ins="${x}" style="cursor:pointer" title="Click to add">${x}</code>`).join(' ')}</div>
        <label style="grid-column:1/3">Message<textarea name="body" rows="5"></textarea></label>
        <div style="grid-column:1/3" class="row"><button type="submit" id="mtsave">Add</button><button type="button" class="sec" id="mtcancel" hidden>Cancel</button></div>
        <div style="grid-column:1/3" id="mtprev" class="hint" hidden></div>
      </form>
      <table class="t"><thead><tr><th style="width:190px">Name</th><th>Message</th><th style="width:150px"></th></tr></thead><tbody>
      ${tpls.map(t => `<tr><td><b>${esc(t.name)}</b></td><td style="white-space:pre-line">${esc(t.body)}</td>
        <td style="text-align:right"><button class="small sec" data-ed="${t.id}">Edit</button> <button class="small sec" data-rm="${t.id}">Remove</button></td></tr>`).join('')
        || '<tr><td colspan="3" class="muted">No messages yet.</td></tr>'}
      </tbody></table></div></div>`;
  const f = $('#mtf', box); let editing = null;
  const prev = () => { const p = $('#mtprev', box); p.hidden = !f.body.value.trim(); p.innerHTML = '<b>Example:</b><br>' + esc(mktFill(f.body.value)).replace(/\n/g, '<br>'); };
  f.body.oninput = prev;
  f.onsubmit = async e => {
    e.preventDefault(); const d = { name: f.name.value, body: f.body.value };
    await guard(() => editing ? PUT('/api/mkt/templates/' + editing, d) : POST('/api/mkt/templates', d));
    toast(editing ? 'Updated' : 'Added'); mktTemplatesPage(box);
  };
  $('#mtcancel', box).onclick = () => mktTemplatesPage(box);
  box.onclick = async e => {
    const ins = e.target.closest('[data-ins]'), ed = e.target.closest('[data-ed]'), rm = e.target.closest('[data-rm]');
    if (ins) { const t = f.body, a = t.selectionStart ?? t.value.length; t.value = t.value.slice(0, a) + ins.dataset.ins + t.value.slice(t.selectionEnd ?? a); t.focus(); prev(); }
    if (ed) { const t = tpls.find(x => x.id === Number(ed.dataset.ed)); editing = t.id; f.name.value = t.name; f.body.value = t.body; prev();
      $('#mtsave', box).textContent = 'Update'; $('#mtcancel', box).hidden = false; f.name.focus(); }
    if (rm && confirm('Remove this message?')) { await guard(() => DEL('/api/mkt/templates/' + rm.dataset.rm)); mktTemplatesPage(box); }
  };
}

// ---------- Settings → Marketing ----------
SETTINGS.marketing = async box => {
  const [s, st] = await Promise.all([GET('/api/mkt/settings'), GET('/api/mkt/status')]);
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  box.innerHTML = `<div class="grid g2" style="align-items:start">
    <div class="card"><h3>📣 Marketing</h3>
      <form id="mkf" class="grid" style="gap:12px">
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="enabled" style="width:auto" ${s.enabled ? 'checked' : ''}> Show the Marketing menu</label>
        ${field({ name: 'default_firm', label: 'Sender on Marketing papers (Settings → Companies)', type: 'select', options: s.firms.map(x => [x.code, x.name]) }, s.default_firm)}
        ${field({ name: 'followup_days', label: 'Days until the first “Did the sample arrive?” call', type: 'number' }, s.followup_days)}
        ${field({ name: 'tracking_url', label: 'Tracking link — {tracking_no} is replaced by the number' }, s.tracking_url)}
        ${field({ name: 'next_ref', label: 'First Ref No. for new enquiries (your Excel ended at 433)', type: 'number' }, s.next_ref)}
        <div class="row"><button type="submit">Save</button></div>
      </form>
      <p class="hint">The Google Calendar link is in <a href="#/settings/data">Settings → Data Location</a>.</p>
      <p class="hint">These are settings, saved with the other Mineral Saathi settings. Companies, printers, backup and data location are the same for billing and Marketing.</p></div>
    <div class="card"><h3>Marketing data</h3>
      ${st.ok ? `<p><span class="badge PM">Open</span> &nbsp;${esc(st.file)} · ${kb(st.size)}</p>
        <table class="t"><tbody>
          <tr><td>Enquiries</td><td class="num">${st.counts.leads}</td></tr>
          <tr><td>Samples</td><td class="num">${st.counts.samples}</td></tr>
          <tr><td>Calls pending</td><td class="num">${st.counts.follow_ups_pending}</td></tr>
          <tr><td>Calls and messages logged</td><td class="num">${st.counts.communications}</td></tr>
          <tr><td>Quick stickers</td><td class="num">${st.counts.quick_stickers}</td></tr></tbody></table>`
        : `<p><span class="badge red">Cannot open</span></p><p style="white-space:pre-line">${esc(st.problem || '')}</p>`}
      <p class="hint" style="margin-top:10px">Kept in its own file next to mineral.db — never mixed with billing data. It is in every backup
        (Marketing_yyyy-mm-dd.db) and moves with the data when the data location changes.</p></div></div>`;
  $('#mkf', box).onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    await guard(() => PUT('/api/mkt/settings', { enabled: f.enabled.checked, default_firm: f.default_firm.value, followup_days: f.followup_days.value,
      tracking_url: f.tracking_url.value, next_ref: f.next_ref.value }));
    toast('Saved'); await mktMenu();
  };
};

// ---------- Settings → Data Location: Google Calendar link (Marketing follow-up calls) ----------
{
  const dataPage = SETTINGS.data;
  SETTINGS.data = async box => {
    await dataPage(box);
    const s = await GET('/api/mkt/settings');
    const card = document.createElement('div'); card.className = 'card';
    card.innerHTML = `<h3>📅 Google Calendar <span class="hint">— Marketing follow-up calls</span></h3>
      <p class="hint">The Apps Script web-app link (ends with <code>/exec</code>). Every planned call is sent to Google Calendar with the customer's phone and WhatsApp link.</p>
      <div class="row"><label style="flex:1">Calendar link<input id="calurl" value="${esc(s.calendar_url)}" placeholder="https://script.google.com/macros/s/…/exec" autocomplete="off"></label>
        <button id="calsave">Save</button><button class="sec" id="caltest">Test connection</button></div>
      <p class="hint" style="margin-top:8px">Test connection creates one event 10 minutes from now named “Mineral Saathi — test connection”; delete it afterwards.</p>
      <div id="calres" style="margin-top:8px" hidden></div>`;
    box.appendChild(card);
    const inp = $('#calurl', card), res = $('#calres', card);
    const show = (ok, msg, reply) => { res.hidden = false;
      res.innerHTML = `<span class="badge ${ok ? 'PM' : 'red'}">${ok ? '✓ Connected' : '✕ Not connected'}</span> ${esc(msg)}${reply ? `<br><span class="hint">Google replied: ${esc(reply)}</span>` : ''}`; };
    $('#calsave', card).onclick = async () => { await guard(() => PUT('/api/mkt/settings', { calendar_url: inp.value })); toast(inp.value.trim() ? 'Calendar link saved' : 'Calendar link removed'); };
    $('#caltest', card).onclick = async () => {
      const b = $('#caltest', card); b.disabled = true; b.textContent = 'Testing…'; res.hidden = true;
      try { const r = await guard(() => POST('/api/mkt/calendar/test', { url: inp.value })); show(r.ok, r.message, r.reply); }
      catch { /* message shown */ } finally { b.disabled = false; b.textContent = 'Test connection'; }
    };
  };
}

// =====================================================================
// Phase 2 — enquiries and samples
// =====================================================================
const MKT_UPPER = 'style="text-transform:uppercase"';
const mktOpts = (vals, blank = true) => [...(blank ? [''] : []), ...vals];
const mktDue = d => { if (!d) return '<span class="muted">—</span>'; const t = today();
  return d < t ? `<span class="badge red">${dmy(d)} · late</span>` : d === t ? `<span class="badge amber">${dmy(d)} · today</span>` : dmy(d); };
const mktTrack = (url, no) => no ? (url ? `<a href="${esc(url.split('{tracking_no}').join(encodeURIComponent(no)))}" target="_blank" rel="noopener">${esc(no)}</a>` : esc(no)) : '';
const mktName = l => esc(l.company || l.buyer_name || '');

// the enquiry fields (also used on the enquiry page to edit it)
function mktLeadFields(l = {}) {
  return `<div class="grid g2" style="gap:10px">
    <label class="span2">Company<input name="company" value="${esc(l.company)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Buyer name<input name="buyer_name" value="${esc(l.buyer_name)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Email<input name="email" type="email" value="${esc(l.email)}" autocomplete="off"></label>
    <label>Mobile<input name="mobile1" value="${esc(l.mobile1)}" inputmode="numeric" autocomplete="off" placeholder="10 digits"></label>
    <label>Mobile 2<input name="mobile2" value="${esc(l.mobile2)}" inputmode="numeric" autocomplete="off"></label>
    <label class="span2">Address<textarea name="address" rows="2">${esc(l.address)}</textarea></label>
    <label>Pincode <span class="hint">(fills city &amp; state)</span><input name="pincode" value="${esc(l.pincode)}" inputmode="numeric" autocomplete="off"></label>
    <label>City<input name="city" value="${esc(l.city)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>State<select name="state">${STATES().map(x => `<option ${x === (l.state || '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}${l.state && !STATES().includes(l.state) ? `<option selected>${esc(l.state)}</option>` : ''}</select></label>
    <label>Digipin<input name="digipin" value="${esc(l.digipin)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>GST no.<input name="gst" value="${esc(l.gst)}" ${MKT_UPPER} autocomplete="off"></label>
    <label>Note<input name="note" value="${esc(l.note)}" autocomplete="off"></label>
  </div><div class="hint" data-buyerhint style="margin-top:8px"></div>`;
}
// digits only, pincode → city & state, "Also a buyer" (read-only look into billing buyers)
function mktWireLead(root) {
  const f = n => $(`[name=${n}]`, root);
  for (const n of ['mobile1', 'mobile2', 'pincode']) f(n).addEventListener('input', e => { const v = e.target.value.replace(/\D/g, ''); if (v !== e.target.value) e.target.value = v; });
  for (const n of ['mobile1', 'mobile2']) f(n).addEventListener('blur', e => { const v = e.target.value; if (v.length > 10 && v.startsWith('91')) e.target.value = v.slice(-10); });
  f('pincode').addEventListener('input', async e => {
    if (e.target.value.length !== 6) return;
    const r = await GET('/api/pincode/' + e.target.value).catch(() => null);
    if (!r || !r.found) return;
    f('city').value = (r.city || r.district || '').toUpperCase();
    const st = f('state'), v = String(r.state || '').toUpperCase();
    if (v && ![...st.options].some(o => o.value === v)) st.add(new Option(v, v));
    st.value = v;
  });
  const hint = $('[data-buyerhint]', root);
  const check = async () => {
    const m = f('mobile1').value, g = f('gst').value;
    if (m.length !== 10 && g.length !== 15) { hint.innerHTML = ''; return; }
    const r = await GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(m)}&gst=${encodeURIComponent(g)}`).catch(() => []);
    hint.innerHTML = r.length ? '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ') + ' <span class="muted">(billing data is not changed)</span>' : '';
  };
  f('mobile1').addEventListener('blur', check); f('gst').addEventListener('blur', check);
  check();
}

// ---------- New Sample Dispatch (also: edit a saved sample) ----------
// arg: ''  new · 'L12' new sample for enquiry 12 · 'S5' edit sample 5
async function mktSampleForm(el, arg) {
  await loadLists(true);
  const [ml, ms] = await Promise.all([GET('/api/mkt/lists'), GET('/api/mkt/settings')]);
  const editId = /^S\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let leadId = /^L\d+$/.test(arg) ? Number(arg.slice(1)) : null;
  let lead = {}, sample = { date: today(), firm_code: ms.default_firm, unit: lv('unit').includes('KG') ? 'KG' : '' }, lastSample = null;
  if (editId) { const r = await GET('/api/mkt/samples/' + editId); sample = r.sample; lead = r.lead; leadId = lead.id; }
  else if (leadId) { const r = await GET('/api/mkt/leads/' + leadId); lead = r.lead; lastSample = r.samples[0] || null; }
  const nextRef = editId || leadId ? null : (await GET('/api/mkt/next-ref')).ref_no;
  $('#title').textContent = editId ? `Edit sample · Ref ${lead.ref_no}` : 'New Sample Dispatch';

  const sel = (name, label, vals, v, extra = '') => `<label ${extra}>${label}<select name="${name}">${[...new Set([...vals, ...(v != null && v !== '' ? [String(v)] : [])])]
    .map(x => `<option value="${esc(x)}" ${String(x) === String(v ?? '') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>`;
  const ms1 = k => (ml[k] || []).map(x => x.value);
  el.innerHTML = `
  ${editId ? '' : `<div class="card" style="position:relative">
    <div class="row" style="align-items:end">
      <label style="flex:1">Find enquiry <span class="hint">— Ref No., mobile, company or name</span><input id="mfind" autocomplete="off" placeholder="Type to search…"></label>
      <div id="mstate" style="padding-bottom:9px"></div></div>
    <div id="mres" class="card" style="position:absolute;left:16px;right:16px;z-index:5;max-height:320px;overflow:auto;padding:4px" hidden></div>
  </div>`}
  <form id="msf">
  <div class="grid g2" style="align-items:start">
    <div class="card"><h3>Enquiry <span id="mref" class="hint"></span></h3>${mktLeadFields(lead)}</div>
    <div class="card"><h3>Sample <span class="hint">— item details from <a href="#/itemlists">Master → Item List</a></span></h3>
      <div class="grid g3" style="gap:10px">
        <label>Date<input name="date" type="date" value="${esc(sample.date)}"></label>
        <label class="span2">Sender<select name="firm_code">${(ms.firms.length ? ms.firms : [{ code: sample.firm_code || 'PM', name: sample.firm_code || 'PM' }])
          .map(x => `<option value="${esc(x.code)}" ${x.code === sample.firm_code ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
        ${sel('item_name', 'Item', mktOpts(lv('product')), sample.item_name, 'class="span3"')}
        ${sel('colour', 'Colour', mktOpts(lv('colour')), sample.colour)}${sel('mesh', 'Mesh', mktOpts(lv('mesh')), sample.mesh)}${sel('form', 'Form', mktOpts(lv('form')), sample.form)}
        <label>Grade <span class="hint">(fills itself)</span><input name="grade" value="${esc(sample.grade)}" ${MKT_UPPER} autocomplete="off"></label>
        ${sel('sample_size', 'Sample size', mktOpts(ms1('sample_size')), sample.sample_size)}
        ${sel('courier', 'Sent by', mktOpts(ms1('courier')), sample.courier)}
        <label class="span2">Tracking no.<input name="tracking_no" value="${esc(sample.tracking_no)}" ${MKT_UPPER} autocomplete="off"></label>
        <label style="display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:9px"><input type="checkbox" name="freight_to_pay" style="width:auto" ${sample.freight_to_pay ? 'checked' : ''}> Freight to pay</label>
        <label>Rate ₹<input name="rate" type="number" step="0.01" value="${esc(sample.rate)}"></label>
        ${sel('unit', 'Per', mktOpts(lv('unit')), sample.unit)}
        ${sel('bag_type', 'Bag type', mktOpts(lv('bag_type')), sample.bag_type)}
        ${sel('packing_type', 'Packing type', mktOpts(lv('packing_type')), sample.packing_type)}
        <label>Liner<select name="liner"><option value=""></option><option value="1" ${sample.liner === 1 ? 'selected' : ''}>With liner</option><option value="0" ${sample.liner === 0 ? 'selected' : ''}>Without liner</option></select></label>
        ${sel('bag_weight', 'Bag weight (kg)', mktOpts(lv('bag_weight')), sample.bag_weight)}
        <label>No. of bags<input name="bag_qty" type="number" step="1" min="0" value="${esc(sample.bag_qty)}"></label>
        <label>Total weight (kg)<input name="total_weight" type="number" step="0.001" min="0" value="${esc(sample.total_weight)}"></label>
        <label>Delivered on<input name="delivered_on" type="date" value="${esc(sample.delivered_on)}"></label>
        <label class="span3">Note on sample<input name="snote" value="${esc(sample.note)}" autocomplete="off"></label>
      </div>
      <div id="mlast" style="margin-top:10px"></div></div>
  </div>
  <div class="card row" style="justify-content:space-between">
    <div class="row"><button type="submit">${editId ? 'Save changes' : 'Save sample'}</button>
      ${editId ? '' : '<button type="button" class="sec" id="monly">Save enquiry only</button>'}
      <button type="button" class="sec" id="mcancel">Cancel</button></div>
    <span class="hint">${editId ? 'Printing the papers comes in phase 3.' : `Saving plans the first call “Did the sample arrive?” ${ms.followup_days} days after the sample date. Printing comes in phase 3.`}</span>
  </div></form>`;

  const form = $('#msf', el), f = n => form.elements[n];
  markDirty(form); mktWireLead(form);
  // grade fills itself from colour + mesh (same rule as Buyers → items), e.g. YELLOW + 300 → Y300 MESH
  let autoGrade = !sample.grade;
  const mkGrade = () => { if (!autoGrade) return; const form_ = f('form').value, mesh = f('mesh').value, col = f('colour').value;
    f('grade').value = mesh && (!form_ || form_ === 'POWDER') ? `${col ? col[0] : ''}${mesh} MESH` : (form_ || ''); };
  ['colour', 'mesh', 'form'].forEach(n => f(n).addEventListener('change', mkGrade));
  f('grade').addEventListener('input', () => { autoGrade = !f('grade').value; });

  const setLead = (l, last) => {
    leadId = l ? l.id : null; lead = l || {};
    for (const k of ['company', 'buyer_name', 'email', 'mobile1', 'mobile2', 'address', 'pincode', 'city', 'digipin', 'gst', 'note']) f(k).value = lead[k] ?? '';
    const st = f('state'), v = lead.state || ''; if (v && ![...st.options].some(o => o.value === v)) st.add(new Option(v, v)); st.value = v;
    $('#mref', el).innerHTML = leadId ? `· <b>Ref ${lead.ref_no}</b> — existing enquiry` : `· new, will be <b>Ref ${nextRef}</b>`;
    const ms_ = $('#mstate', el); if (ms_) ms_.innerHTML = leadId ? `<button type="button" class="small sec" id="mnewlead">Start a new enquiry instead</button>` : '';
    const nb = $('#mnewlead', el); if (nb) nb.onclick = () => setLead(null, null);
    lastSample = last || null;
    $('#mlast', el).innerHTML = lastSample ? `<span class="hint">Last sample ${dmy(lastSample.date)}: ${esc([lastSample.item_name, lastSample.grade, lastSample.sample_size, lastSample.courier].filter(Boolean).join(' · '))}</span>
      <button type="button" class="small sec" id="mcopy">Copy last sample</button>` : '';
    const cp = $('#mcopy', el); if (cp) cp.onclick = () => {
      for (const k of ['item_name', 'colour', 'mesh', 'form', 'grade', 'sample_size', 'courier', 'rate', 'unit', 'bag_type', 'packing_type', 'bag_weight', 'bag_qty', 'total_weight', 'firm_code']) {
        const e = f(k); if (!e) continue; const v = lastSample[k] ?? '';
        if (e.tagName === 'SELECT' && v !== '' && ![...e.options].some(o => o.value === String(v))) e.add(new Option(v, v)); e.value = v; }
      f('liner').value = lastSample.liner == null ? '' : String(lastSample.liner); f('freight_to_pay').checked = !!lastSample.freight_to_pay; autoGrade = false;
      toast('Copied — check the date and tracking no.'); };
    form.dispatchEvent(new Event('input'));
    $('[data-buyerhint]', form).innerHTML = ''; f('mobile1').dispatchEvent(new Event('blur'));
  };
  if (!editId) setLead(leadId ? lead : null, lastSample); else $('#mref', el).innerHTML = `· <b>Ref ${lead.ref_no}</b>`;
  S.dirty = false;

  // find an enquiry
  const fi = $('#mfind', el), res = $('#mres', el); let ft;
  if (fi) {
    fi.oninput = () => { clearTimeout(ft); ft = setTimeout(async () => {
      const q = fi.value.trim(); if (!q) { res.hidden = true; return; }
      const rows = await GET('/api/mkt/find?q=' + encodeURIComponent(q)).catch(() => []);
      res.hidden = false;
      res.innerHTML = rows.length ? rows.map(r => `<a class="listhead" data-lid="${r.id}"><b>Ref ${r.ref_no}</b> · ${mktName(r)}${r.company && r.buyer_name ? ` <span class="hint">${esc(r.buyer_name)}</span>` : ''}
        <span class="hint" style="float:right">${esc([r.city, r.state].filter(Boolean).join(', '))} · ${esc(r.mobile1 || '')}</span></a>`).join('')
        : '<div class="muted" style="padding:8px">No enquiry found — fill in the details below for a new one.</div>';
    }, 220); };
    fi.onkeydown = e => { if (e.key === 'Escape') res.hidden = true; };
    res.onclick = async e => { const a = e.target.closest('[data-lid]'); if (!a) return;
      const r = await guard(() => GET('/api/mkt/leads/' + a.dataset.lid)); res.hidden = true; fi.value = '';
      setLead(r.lead, r.samples[0]); S.dirty = false; };
    document.addEventListener('click', e => { if (!e.target.closest('#mres') && e.target !== fi) res.hidden = true; });
  }

  const leadData = () => { const o = {}; for (const k of ['company', 'buyer_name', 'email', 'mobile1', 'mobile2', 'address', 'pincode', 'city', 'state', 'digipin', 'gst', 'note']) o[k] = f(k).value; return o; };
  const sampleData = () => { const o = {}; for (const k of ['date', 'firm_code', 'item_name', 'colour', 'mesh', 'form', 'grade', 'sample_size', 'courier', 'tracking_no', 'rate', 'unit', 'bag_type', 'packing_type', 'liner', 'bag_weight', 'bag_qty', 'total_weight', 'delivered_on']) o[k] = f(k).value;
    o.freight_to_pay = f('freight_to_pay').checked ? 1 : 0; o.note = f('snote').value; return o; };
  // the server refuses a second enquiry with the same mobile; the user may still choose to keep both
  const send = async (fn) => { try { return await fn(false); } catch (e) {
    if (/is already Ref \d+/.test(e.message) && !leadId && confirm(e.message + '\n\nSave it as a separate enquiry anyway?')) return guard(() => fn(true));
    toast(e.message, true); return null; } };

  form.onsubmit = async e => {
    e.preventDefault();
    if (editId) {
      const r = await send(dup => PUT('/api/mkt/samples/' + editId, { sample: sampleData(), lead: leadData(), allow_duplicate: dup })); if (!r) return;
      S.dirty = false; toast('Sample changed'); go('#/mkt/leads:' + r.lead_id); return;
    }
    const r = await send(dup => POST('/api/mkt/samples', { lead_id: leadId, lead: leadData(), sample: sampleData(), allow_duplicate: dup })); if (!r) return;
    S.dirty = false; toast(`Sample saved · Ref ${r.ref_no} · first call ${dmy(r.follow_up.due_date)}`); go('#/mkt/leads:' + r.lead_id);
  };
  const only = $('#monly', el); if (only) only.onclick = async () => {
    const r = await send(dup => leadId ? PUT('/api/mkt/leads/' + leadId, { lead: leadData(), allow_duplicate: dup }) : POST('/api/mkt/leads', { lead: leadData(), allow_duplicate: dup })); if (!r) return;
    S.dirty = false; toast(leadId ? 'Enquiry saved' : `Enquiry saved · Ref ${r.ref_no}`); go('#/mkt/leads:' + r.id);
  };
  $('#mcancel', el).onclick = () => { if (S.dirty && !confirm('You have unsaved changes. Leave this screen?')) return; S.dirty = false; history.length > 1 ? history.back() : go('#/mkt/leads'); };
}

// ---------- Enquiries list ----------
async function mktLeadsList(el) {
  el.innerHTML = `<div class="card"><div class="row" style="justify-content:space-between">
      <div class="row"><input id="lq" placeholder="Search: Ref No., company, name, mobile, city or state" style="width:420px" autocomplete="off"><span class="hint" id="lcount"></span></div>
      <div class="row"><button class="sec" id="lcsv">Export CSV</button><button id="lnew">+ New sample</button></div></div>
    <div class="tablewrap" style="margin-top:10px"><table class="t"><thead><tr><th>Ref</th><th>Company / buyer</th><th>City, state</th><th>Mobile</th><th class="num">Samples</th><th>Last sample</th><th>Next call</th></tr></thead>
    <tbody id="lbody"><tr><td colspan="7" class="muted">Loading…</td></tr></tbody></table></div></div>`;
  let rows = [], t;
  const load = async () => {
    const q = $('#lq', el).value.trim();
    rows = await GET('/api/mkt/leads?limit=1000&q=' + encodeURIComponent(q));
    $('#lcount', el).textContent = `${rows.length}${rows.length === 1000 ? '+' : ''} enquir${rows.length === 1 ? 'y' : 'ies'}`;
    $('#lbody', el).innerHTML = rows.map(r => `<tr class="click" data-lid="${r.id}"><td><b>${r.ref_no}</b></td>
      <td><b>${mktName(r)}</b>${r.company && r.buyer_name ? `<br><span class="hint">${esc(r.buyer_name)}</span>` : ''}${r.became_buyer_id ? ' <span class="badge PM">buyer</span>' : ''}</td>
      <td>${esc([r.city, r.state].filter(Boolean).join(', '))}</td><td>${esc(r.mobile1 || '')}</td><td class="num">${r.samples || ''}</td>
      <td>${r.last_sample ? esc(dmy(r.last_sample.slice(0, 10)) + r.last_sample.slice(10)) : '<span class="muted">—</span>'}</td><td>${mktDue(r.next_call)}</td></tr>`).join('')
      || `<tr><td colspan="7" class="muted">${q ? 'Nothing found.' : 'No enquiries yet. Press “+ New sample” to add the first one.'}</td></tr>`;
  };
  $('#lq', el).oninput = () => { clearTimeout(t); t = setTimeout(load, 250); };
  $('#lq', el).focus();
  $('#lnew', el).onclick = () => go('#/mkt/new');
  $('#lcsv', el).onclick = () => downloadCsv('enquiries.csv', rows.map(r => ({ ref_no: r.ref_no, company: r.company, buyer: r.buyer_name, city: r.city, state: r.state, mobile: r.mobile1,
    samples: r.samples, last_sample: r.last_sample, next_call: r.next_call })));
  $('#lbody', el).onclick = e => { const tr = e.target.closest('[data-lid]'); if (tr) go('#/mkt/leads:' + tr.dataset.lid); };
  await load();
}

// ---------- one enquiry: details, samples, calls ----------
async function mktLeadPage(el, id) {
  const [d, ms] = await Promise.all([GET('/api/mkt/leads/' + id), GET('/api/mkt/settings')]);
  const l = d.lead;
  $('#title').textContent = `Ref ${l.ref_no} · ${l.company || l.buyer_name || ''}`;
  const line = (k, v) => v ? `<tr><td class="hint" style="width:110px">${k}</td><td>${v}</td></tr>` : '';
  el.innerHTML = `<div class="grid" style="grid-template-columns:minmax(320px,1fr) 2fr;align-items:start">
    <div class="card" id="ldet"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Enquiry · Ref ${l.ref_no}</h3>
        <span><button class="small sec" id="ledit">Edit</button>${d.samples.length || d.communications.length ? '' : ' <button class="small sec" id="ldel">Delete</button>'}</span></div>
      <table class="t" style="margin-top:8px"><tbody>
        ${line('Company', `<b>${esc(l.company || '')}</b>`)}${line('Buyer', esc(l.buyer_name))}
        ${line('Mobile', [l.mobile1, l.mobile2].filter(Boolean).map(m => `<a href="tel:${esc(m)}">${esc(m)}</a>`).join(', '))}
        ${line('Email', l.email ? `<a href="mailto:${esc(l.email)}">${esc(l.email)}</a>` : '')}
        ${line('Address', esc([l.address, [l.city, l.pincode].filter(Boolean).join(' - '), l.state].filter(Boolean).join('\n')).replace(/\n/g, '<br>'))}
        ${line('Digipin', esc(l.digipin))}${line('GST', esc(l.gst))}${line('Note', esc(l.note))}
        ${line('Since', dmy(String(l.created_at || '').slice(0, 10)))}
      </tbody></table><div class="hint" data-buyerhint></div></div>
    <div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Samples · ${d.samples.length}</h3>
          <button id="lnewsample">+ New sample for this enquiry</button></div>
        <div class="tablewrap" style="margin-top:8px"><table class="t"><thead><tr><th>Date</th><th>Item · grade</th><th>Size</th><th>Sent by</th><th>Tracking no.</th><th class="num">Rate</th><th>Bags · weight</th><th></th></tr></thead><tbody>
        ${d.samples.map(s => `<tr><td>${dmy(s.date)}</td><td><b>${esc(s.grade || '')}</b><br><span class="hint">${esc(s.item_name || '')}</span></td><td>${esc(s.sample_size || '')}</td>
          <td>${esc(s.courier || '')}${s.freight_to_pay ? ' <span class="badge amber">to pay</span>' : ''}</td><td>${mktTrack(ms.tracking_url, s.tracking_no)}${s.delivered_on ? `<br><span class="hint">delivered ${dmy(s.delivered_on)}</span>` : ''}</td>
          <td class="num">${s.rate != null ? money(s.rate) + (s.unit ? ' / ' + esc(s.unit) : '') : ''}</td>
          <td>${[s.bag_qty ? s.bag_qty + ' × ' + (s.bag_weight ? kg(s.bag_weight) + ' kg' : 'bags') : '', s.total_weight ? kg(s.total_weight) + ' kg total' : ''].filter(Boolean).join('<br>')}</td>
          <td style="white-space:nowrap;text-align:right"><button class="small sec" data-sed="${s.id}">Edit</button> <button class="small sec" data-sdel="${s.id}">Delete</button></td></tr>`).join('')
          || '<tr><td colspan="8" class="muted">No sample sent yet.</td></tr>'}</tbody></table></div></div>
      <div class="card"><h3>Calls</h3>
        <table class="t"><thead><tr><th>Due</th><th>Reason</th><th>Status</th></tr></thead><tbody>
        ${d.follow_ups.map(x => `<tr><td>${x.status === 'PENDING' ? mktDue(x.due_date) : dmy(x.due_date)}</td><td>${esc(x.reason || '')}</td>
          <td>${x.status === 'PENDING' ? '<span class="badge amber">Pending</span>' : `<span class="badge grey">${esc(x.status)}</span>${x.done_on ? ' ' + dmy(x.done_on) : ''}`}</td></tr>`).join('')
          || '<tr><td colspan="3" class="muted">No calls planned.</td></tr>'}</tbody></table>
        ${d.communications.length ? `<h4 style="margin:14px 0 6px">History</h4><table class="t"><tbody>${d.communications.map(c => `<tr><td style="width:100px">${dmy(c.date)}</td>
          <td>${esc(c.channel || '')}</td><td>${esc([c.response, c.note].filter(Boolean).join(' — '))}</td></tr>`).join('')}</tbody></table>` : ''}
        <p class="hint" style="margin-top:8px">Logging calls, WhatsApp messages and planning the next call come with the Communication screen (phase 4).</p></div>
    </div></div>`;
  // read-only "Also a buyer" hint
  GET(`/api/mkt/buyer-match?mobile=${encodeURIComponent(l.mobile1 || '')}&gst=${encodeURIComponent(l.gst || '')}`).then(r => {
    if (r.length) $('[data-buyerhint]', el).innerHTML = '🔗 Also a buyer: ' + r.map(x => `<b>${esc(x.name)}</b> <span class="badge grey">${esc(x.kind)}</span>`).join(', ');
  }).catch(() => {});
  $('#lnewsample', el).onclick = () => go('#/mkt/new:L' + l.id);
  $('#ledit', el).onclick = () => {
    const box = $('#ldet', el);
    box.innerHTML = `<h3>Edit enquiry · Ref ${l.ref_no}</h3><form id="lef">${mktLeadFields(l)}
      <div class="row" style="margin-top:10px"><button type="submit">Save</button><button type="button" class="sec" id="lecancel">Cancel</button></div></form>`;
    const fm = $('#lef', box); mktWireLead(fm); markDirty(fm);
    $('#lecancel', box).onclick = () => { S.dirty = false; mktLeadPage(el, id); };
    fm.onsubmit = async e => { e.preventDefault(); const o = formData(fm);
      try { await PUT('/api/mkt/leads/' + id, { lead: o }); }
      catch (err) { if (!(/is already Ref \d+/.test(err.message) && confirm(err.message + '\n\nKeep this number on both enquiries?'))) { toast(err.message, true); return; }
        await guard(() => PUT('/api/mkt/leads/' + id, { lead: o, allow_duplicate: true })); }
      S.dirty = false; toast('Enquiry saved'); mktLeadPage(el, id); };
  };
  const del = $('#ldel', el); if (del) del.onclick = async () => { if (!confirm(`Delete enquiry Ref ${l.ref_no}?`)) return; await guard(() => DEL('/api/mkt/leads/' + id)); toast('Enquiry deleted'); go('#/mkt/leads'); };
  el.onclick = async e => {
    const ed = e.target.closest('[data-sed]'), dl = e.target.closest('[data-sdel]');
    if (ed) go('#/mkt/new:S' + ed.dataset.sed);
    if (dl && confirm('Delete this sample? Its planned call is removed too.')) { await guard(() => DEL('/api/mkt/samples/' + dl.dataset.sdel)); toast('Sample deleted'); mktLeadPage(el, id); }
  };
}
