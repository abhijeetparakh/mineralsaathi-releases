'use strict';
// Marketing data (Sampark Saathi) — kept in its OWN file, marketing.db, next to mineral.db.
// Enquiries, samples, follow-up calls and marketing lists live only here; nothing is ever written
// into mineral.db from Marketing, and billing never writes here. Settings (companies, printers,
// data location, backup, security) stay in mineral.db and are shared.
// If this file cannot be opened, billing keeps working and only the Marketing screens show the problem.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { DatabaseSync } = require('node:sqlite');
const { DATA_DIR, MKT_DB_FILE, LOCK_FILE, SHARED } = require('../paths');

const SCHEMA_VERSION = 3;
let db = null;
let problem = null;            // text shown on the Marketing screens when the file cannot be used

// Same Google Drive safety as mineral.db: side files brought by Drive from ANOTHER computer that
// closed properly are old leftovers and would mix two states of the data, so they are moved aside.
function moveAsideOldSideFiles() {
  if (!SHARED) return;
  let lk = null; try { lk = JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8')); } catch { /* no lock yet */ }
  if (lk && !lk.released && lk.pc === os.hostname()) return;     // our own unfinished session: keep them
  for (const ext of ['-journal', '-wal', '-shm']) {
    const f = MKT_DB_FILE + ext;
    if (fs.existsSync(f)) { try { fs.renameSync(f, f + '.old-' + Date.now()); console.log('  Moved aside an old side file: ' + path.basename(f)); } catch { /* in use */ } }
  }
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS leads (               -- one enquiry / prospect (was: DATA sheet + one numbered sheet each)
  id INTEGER PRIMARY KEY,
  ref_no INTEGER UNIQUE NOT NULL,                -- the old SL / Ref No., printed on every paper
  buyer_name TEXT, company TEXT,
  address TEXT, city TEXT, state TEXT, pincode TEXT, digipin TEXT,
  mobile1 TEXT, mobile2 TEXT, gst TEXT, email TEXT,
  note TEXT,
  became_buyer_id INTEGER,                       -- id in Master -> Buyer B2B after "Make Buyer" (a one-time copy)
  legacy INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_leads_company ON leads(company);
CREATE INDEX IF NOT EXISTS ix_leads_mobile ON leads(mobile1);

CREATE TABLE IF NOT EXISTS dispatches (          -- one parcel / dispatch to an enquiry, holding one or more samples (like an invoice)
  id INTEGER PRIMARY KEY,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  date TEXT,                                     -- yyyy-mm-dd
  firm_code TEXT,                                -- sender company (Settings -> Companies)
  courier TEXT, tracking_no TEXT,
  freight_to_pay INTEGER DEFAULT 0,
  parcels INTEGER,                               -- bags / parcels in this dispatch (one bag sticker each)
  total_weight REAL,                             -- kg
  delivered_on TEXT,
  note TEXT,
  legacy INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_disp_lead ON dispatches(lead_id);
CREATE INDEX IF NOT EXISTS ix_disp_date ON dispatches(date);

CREATE TABLE IF NOT EXISTS samples (             -- the sample lines of a dispatch (one sample sticker each)
  id INTEGER PRIMARY KEY,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  date TEXT,                                     -- yyyy-mm-dd
  firm_code TEXT,                                -- sender company (Settings -> Companies)
  item_name TEXT, grade TEXT, mesh TEXT, colour TEXT, form TEXT,   -- copied from Master -> Item List when saved
  sample_size TEXT, courier TEXT, tracking_no TEXT,
  rate REAL, unit TEXT,
  bag_type TEXT, packing_type TEXT, bag_weight REAL, bag_qty INTEGER, total_weight REAL,
  freight_to_pay INTEGER DEFAULT 0,
  delivered_on TEXT,
  note TEXT,
  legacy INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_samples_lead ON samples(lead_id);
CREATE INDEX IF NOT EXISTS ix_samples_date ON samples(date);

CREATE TABLE IF NOT EXISTS communications (      -- calls and WhatsApp messages (was: rows 20+ of each numbered sheet)
  id INTEGER PRIMARY KEY,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  date TEXT,
  channel TEXT,                                  -- CALL / WHATSAPP / OTHER
  response TEXT, note TEXT,
  follow_up_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_comm_lead ON communications(lead_id);

CREATE TABLE IF NOT EXISTS follow_ups (          -- calls to make (was: CALL UPDATE + columns O-Q + today list)
  id INTEGER PRIMARY KEY,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  due_date TEXT NOT NULL,
  reason TEXT,
  status TEXT DEFAULT 'PENDING',                 -- PENDING / DONE / SKIPPED
  done_on TEXT,
  calendar_status TEXT,                          -- null / QUEUED / SENT / FAILED
  calendar_error TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_fu_due ON follow_ups(due_date, status);
CREATE INDEX IF NOT EXISTS ix_fu_lead ON follow_ups(lead_id);

CREATE TABLE IF NOT EXISTS quick_stickers (      -- walk-in / phone enquiries printed without an enquiry record (was: un_reg)
  id INTEGER PRIMARY KEY,
  date TEXT, ref TEXT,
  name TEXT, company TEXT, mobile TEXT, pincode TEXT, city TEXT, state TEXT,
  item TEXT, rate REAL, unit TEXT, remark TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS sample_freight (      -- local freight letter for sample bags (drivers come from Master -> Local Freight)
  id INTEGER PRIMARY KEY,
  sample_id INTEGER NOT NULL REFERENCES samples(id),
  driver TEXT, tempo_no TEXT, mobile TEXT, amount REAL, from_place TEXT,
  at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS mkt_lists (           -- Marketing pick-lists (separate from Master -> Item List)
  id INTEGER PRIMARY KEY,
  list_key TEXT NOT NULL,                        -- sample_size / courier / response / followup_reason
  value TEXT NOT NULL,
  sort INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1,
  UNIQUE(list_key, value)
);

CREATE TABLE IF NOT EXISTS message_templates (   -- WhatsApp messages; {name} {company} {ref} {courier} {tracking_no} {tracking_link}
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  body TEXT NOT NULL,
  sort INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS print_log (           -- what was printed for each sample
  id INTEGER PRIMARY KEY,
  sample_id INTEGER, document TEXT, printer TEXT,
  at TEXT DEFAULT (datetime('now','localtime'))
);
`;

// first-time lists: the values used in the Sample Dispatch workbook (ITEMS sheet, whatapp QR sheet)
const SEED_LISTS = {
  sample_size: ['100 GM', '500 GM', '1 KG', '5 KG'],
  courier: ['INDIAN POSTAL SERVICE', 'DHL', 'BLUE DART', 'VRL LOGISTICS LIMITED', 'V K EXPRESS'],
  response: ['CALLED', 'NO RESPONSE', 'WHATSAPP MESSAGE SENT', 'PHONE NOT REACHABLE'],
  followup_reason: ['CHECK IF SAMPLE RECEIVED', 'CALL FOR RECALL', 'ORDER REMINDER', 'ANY UPDATE REGARDING TRIALS']
};
const SEED_TEMPLATES = [
  ['Sample dispatched', 'We have dispatched the sample as per our telephonic conversation by {courier}, tracking no. {tracking_no}.\nYour communication Ref. No. {ref}.\nYou can track it after 12 hours: {tracking_link}\n\nThank you!'],
  ['Sample received?', 'Hope you have received the sample? (Ref. No. {ref})'],
  ['Trials update', 'Any updates on your trials? (Ref. No. {ref})'],
  ['Next order', 'Any updates on your next order? (Ref. No. {ref})'],
  ['Please confirm receipt', 'Your sample has been dispatched. Kindly confirm once you have received the sample.\nThank you'],
  ['Hello', 'Hello, how are you doing? (Ref. No. {ref})']
];

function seed() {
  const ins = db.prepare('INSERT OR IGNORE INTO mkt_lists(list_key, value, sort) VALUES(?, ?, ?)');
  for (const [k, vals] of Object.entries(SEED_LISTS)) vals.forEach((v, i) => ins.run(k, v, i));
  const t = db.prepare('INSERT INTO message_templates(name, body, sort) VALUES(?, ?, ?)');
  SEED_TEMPLATES.forEach(([n, b], i) => t.run(n, b, i));
}

function open() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    moveAsideOldSideFiles();
    const isNew = !fs.existsSync(MKT_DB_FILE) || fs.statSync(MKT_DB_FILE).size === 0;
    db = new DatabaseSync(MKT_DB_FILE);
    if (!isNew) {
      const r = db.prepare('PRAGMA quick_check').all().map(x => Object.values(x)[0]);
      if (!(r.length === 1 && r[0] === 'ok')) throw new Error('check failed: ' + r.slice(0, 3).join(' | '));
    }
    // in a synced folder (Google Drive) the file must always be ONE complete file: no side files
    db.exec(SHARED ? 'PRAGMA journal_mode = DELETE; PRAGMA synchronous = FULL; PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;'
                   : 'PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;');
    db.exec(SCHEMA);
    const v = db.prepare('PRAGMA user_version').get().user_version;
    if (v < 1) { db.exec('BEGIN'); try { seed(); db.exec('PRAGMA user_version = 1; COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; } }
    if (v < 2) {          // 1.49: liner on samples; each automatic call knows its sample
      const has = (t, c) => db.prepare(`PRAGMA table_info(${t})`).all().some(x => x.name === c);
      if (!has('samples', 'liner')) db.exec('ALTER TABLE samples ADD COLUMN liner INTEGER');
      if (!has('follow_ups', 'sample_id')) db.exec('ALTER TABLE follow_ups ADD COLUMN sample_id INTEGER');
      db.exec('PRAGMA user_version = 2');
    }
    if (v < 3) {          // 1.50: a dispatch holds several samples; every 1.49 sample becomes its own dispatch
      const has = (t, c) => db.prepare(`PRAGMA table_info(${t})`).all().some(x => x.name === c);
      db.exec('BEGIN');
      try {
        if (!has('samples', 'dispatch_id')) db.exec('ALTER TABLE samples ADD COLUMN dispatch_id INTEGER');
        if (!has('follow_ups', 'dispatch_id')) db.exec('ALTER TABLE follow_ups ADD COLUMN dispatch_id INTEGER');
        const ins = db.prepare(`INSERT INTO dispatches(lead_id, date, firm_code, courier, tracking_no, freight_to_pay, parcels, total_weight, delivered_on, legacy, created_at)
          VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
        for (const x of db.prepare('SELECT * FROM samples WHERE dispatch_id IS NULL').all()) {
          const did = Number(ins.run(x.lead_id, x.date, x.firm_code, x.courier, x.tracking_no, x.freight_to_pay || 0, x.bag_qty, x.total_weight, x.delivered_on, x.legacy || 0, x.created_at).lastInsertRowid);
          db.prepare('UPDATE samples SET dispatch_id = ? WHERE id = ?').run(did, x.id);
          db.prepare('UPDATE follow_ups SET dispatch_id = ? WHERE sample_id = ?').run(did, x.id);
        }
        db.exec('PRAGMA user_version = 3; COMMIT');
      } catch (e) { db.exec('ROLLBACK'); throw e; }
    }
    // later versions upgrade here: if (v < 4) { ... PRAGMA user_version = 4 }
    problem = null;
  } catch (e) {
    try { db && db.close(); } catch { /* not open */ }
    db = null;
    problem = `The Marketing data file could not be opened: ${e.message}\n` +
      (SHARED ? 'If the data is in Google Drive, wait until Drive has finished syncing and start Mineral Saathi again. ' : '') +
      `If it still does not open, restore the newest Marketing backup (Marketing_yyyy-mm-dd.db) over ${MKT_DB_FILE}. Billing is not affected.`;
    console.error('\n  ' + problem.replace(/\n/g, '\n  ') + '\n');
  }
}
open();

class MktError extends Error { constructor(m) { super(m); this.status = 400; } }
function need() { if (!db) throw new MktError(problem || 'Marketing data is not open.'); return db; }

const all = (sql, ...a) => need().prepare(sql).all(...a);
const get = (sql, ...a) => need().prepare(sql).get(...a);
const run = (sql, ...a) => need().prepare(sql).run(...a);
function tx(fn) {
  const d = need(); d.exec('BEGIN');
  try { const r = fn(); d.exec('COMMIT'); return r; } catch (e) { d.exec('ROLLBACK'); throw e; }
}

// copy for the backup folder (same moment as the mineral.db backup)
function backupInto(file) {
  if (!db) return null;
  const tmp = file + '.part';
  try { fs.unlinkSync(tmp); } catch { /* none */ }
  db.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
  fs.renameSync(tmp, file);
  return file;
}

function close() { try { db && db.close(); } catch { /* already closed */ } db = null; }

function status() {
  let size = 0; try { size = fs.statSync(MKT_DB_FILE).size; } catch { /* none */ }
  if (!db) return { ok: false, problem, file: MKT_DB_FILE, size };
  const n = t => db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n;
  return { ok: true, file: MKT_DB_FILE, size, schema: SCHEMA_VERSION,
    counts: { leads: n('leads'), dispatches: n('dispatches'), samples: n('samples'), follow_ups_pending: db.prepare("SELECT COUNT(*) n FROM follow_ups WHERE status = 'PENDING'").get().n,
      communications: n('communications'), quick_stickers: n('quick_stickers') } };
}

module.exports = { all, get, run, tx, backupInto, close, status, MktError, isOpen: () => !!db, file: MKT_DB_FILE };
