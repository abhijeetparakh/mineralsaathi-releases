'use strict';
// Master → Analysis Reports: test reports (chemical & physical properties) of a grade, kept as templates.
// Each report is linked to Item + Colour + Form + Mesh (Item lists). With an invoice or a sample dispatch email,
// the report of the same combination as the item sent is attached as a PDF, printed on the firm's letter head.
const fs = require('node:fs');
const path = require('node:path');
const { all, get, run } = require('./db');
const mailer = require('./mailer');
const { makePdf } = require('./pdf');

run(`CREATE TABLE IF NOT EXISTS analysis_reports (id INTEGER PRIMARY KEY, name TEXT NOT NULL, heading TEXT, product TEXT, colour TEXT, form TEXT, mesh TEXT,
  rows TEXT, note TEXT, active INTEGER DEFAULT 1, updated_at TEXT DEFAULT (datetime('now','localtime')))`);
class E extends Error { constructor(m) { super(m); this.status = 400; } }
// 1.71: a report for one buyer or one group of companies; Certificate of Analysis block (J K group)
// 1.73: Item groups (Item List → Item group): a name with several item names; a report can be linked to a group
run(`CREATE TABLE IF NOT EXISTS item_groups (id INTEGER PRIMARY KEY, name TEXT NOT NULL, items TEXT, active INTEGER DEFAULT 1)`);
for (const [c, t] of [['item_group_id', 'INTEGER'], ['party_id', 'INTEGER'], ['group_name', 'TEXT'], ['coa', 'INTEGER DEFAULT 0'], ['brand_name', 'TEXT'], ['material_code', 'TEXT']]) {
  try { run(`ALTER TABLE analysis_reports ADD COLUMN ${c} ${t}`); } catch { /* already there */ }
}

// the sample report (from the user's sheet)
if (!get('SELECT 1 FROM analysis_reports')) {
  const rows = [
    ['Silica (as SiO2)', '75.3', 'IS:9406-1980 guidelines'], ['Calcium oxide (CaO)', '5.9', 'IS:9406-1980 guidelines, ICP-OES'],
    ['Magnesium oxide (MgO)', '1.8', 'IS:9406-1980 guidelines, ICP-OES'], ['Alumina (Al2O3)', '4.6', 'IS:9406-1980 guidelines, ICP-OES'],
    ['Ferric oxide as (Fe2O3)', '0.93', 'IS:9406-1980 guidelines, ICP-OES'], ['Sodium oxide (Na2O)', '0.46', 'ASTM C-1240 guidelines & AAS'],
    ['Loss on ignition (at 950°C)', '10.5', 'ASTM C-1240 guidelines'], ['Water absorption', '82', 'IS 12292-1988 guidelines'],
    ['Oil absorption (gm/100gm)', '73', 'IS:9406-1980 guidelines'], ['pH (10% solution)', '9.0', 'IS:9406-1980 guidelines'],
    ['Specific gravity', '2.2', 'IS:9406-1980 guidelines'], ['Moisture', '11.3', 'ASTM-4574 guidelines']];
  run('INSERT INTO analysis_reports(name, heading, product, colour, form, mesh, rows, note) VALUES(?,?,?,?,?,?,?,?)',
    'Diatomaceous Earth Light Yellow', 'Chemical & Physical Properties', 'DIATOMACEOUS EARTH', 'YELLOW', 'POWDER', null, JSON.stringify(rows), null);
}

// J K group report: Certificate of Analysis, for every buyer of the J K group (S.R. Filler Code 7777)
function seedJk() {
  if (get("SELECT 1 FROM settings WHERE key = 'anrep_jk_seeded'")) return;
  const g = (all("SELECT DISTINCT group_name AS v FROM parties WHERE group_name IS NOT NULL").map(r => r.v).concat(all("SELECT value AS v FROM lists WHERE list_key = 'group_company'").map(r => r.v)))
    .find(v => /^\s*J\.?\s*K\b/i.test(v || '')) || 'J K TYERS';
  if (!get('SELECT 1 FROM analysis_reports WHERE active = 1 AND upper(group_name) = upper(?)', g)) {
    const rows = [['HEAT LOSS, 2HR@105 DEG C', '5', 'ASTM D-'], ['p H (5.0% WATER SOLUTION)', '8.6', 'ASTM D-'], ['HF SOLUBLE (SILCA)', '75.7', 'ASTM D-'], ['RESIDUE ON 45 MICROMETER SIEVE', '1', 'ASTM D-']];
    run('INSERT INTO analysis_reports(name, heading, product, group_name, coa, material_code, rows, note) VALUES(?,?,?,?,?,?,?,?)', 'JK GROUP', 'Chemical & Physical Properties', null, g, 1, 'SR FILLER CODE 7777',
      JSON.stringify(rows), 'THE ABOVE TEST REPORT IS THE AVERAGE OF FIVE DIFFERENT SAMPLES. AS THIS IS A NATURAL MINERAL IT MAY VARY.');
  }
  run("INSERT OR REPLACE INTO settings(key, value) VALUES('anrep_jk_seeded', '1')");
}
try { seedJk(); } catch (e) { console.error('Analysis report (J K group):', e.message); }
const up = v => { const s = String(v ?? '').trim().toUpperCase().replace(/\s+/g, ' '); return s || null; };
const parseRows = r => { try { const a = JSON.parse(r || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };
const full = r => r && { ...r, rows: parseRows(r.rows) };
// the name printed on the letter head: "Diatomaceous Earth" in the report name becomes the linked Item (S.R.Filler Code 7777 Off White Calcined)
const titleCase = s => String(s || '').toLowerCase().replace(/(^|[\s(\-\/.])([a-z])/g, (m, a, b) => a + b.toUpperCase());
function printName(r) {
  const name = String(r.name || '').trim(), item = String(r.product || '').trim();
  if (!item || /^diatomaceous earth\b/i.test(item)) return name;
  const re = /diatomaceous\s+earth/i;
  return re.test(name) ? name.replace(re, titleCase(item)).replace(/\s+/g, ' ').trim() : name;
}
function clean(b) {
  const o = {};
  if (b.name !== undefined) { o.name = String(b.name || '').trim().replace(/\s+/g, ' '); if (!o.name) throw new E('Enter the report name.'); }
  if (b.heading !== undefined) o.heading = String(b.heading || '').trim() || null;
  for (const k of ['product', 'colour', 'form', 'mesh']) if (b[k] !== undefined) o[k] = up(b[k]);
  if (b.rows !== undefined) o.rows = JSON.stringify((Array.isArray(b.rows) ? b.rows : []).map(r => [0, 1, 2].map(i => String((r || [])[i] ?? '').trim())).filter(r => r.some(Boolean)));
  if (b.note !== undefined) o.note = String(b.note || '').trim() || null;
  if (b.party_id !== undefined) o.party_id = Number(b.party_id) || null;
  if (b.item_group_id !== undefined) o.item_group_id = Number(b.item_group_id) || null;
  if (b.group_name !== undefined) o.group_name = up(b.group_name);
  if (b.coa !== undefined) o.coa = Number(b.coa) ? 1 : 0;
  for (const k of ['brand_name', 'material_code']) if (b[k] !== undefined) o[k] = String(b[k] || '').trim() || null;
  return o;
}

// ---- which report goes with an item line ----
const listVals = k => all("SELECT value FROM lists WHERE list_key = ? AND active = 1", k).map(r => String(r.value).toUpperCase());
const meshNo = s => { const m = String(s || '').match(/(\d{2,4})/); return m ? m[1] : null; };
// colour / form / mesh of an item line: from the line itself (samples), else Item List / buyer items, else read from the grade ("Y300 MESH")
function lineAttrs(l, partyId) {
  const name = up(l.item_name) || '', grade = up(l.grade) || '';
  const a = { product: name, colour: up(l.colour), form: up(l.form), mesh: up(l.mesh) };
  const fill = r => { if (!r) return; for (const k of ['colour', 'form', 'mesh']) if (!a[k] && r[k]) a[k] = up(r[k]); };
  fill(get('SELECT colour, form, mesh FROM items WHERE upper(trim(name)) = ? AND upper(trim(COALESCE(grade, \'\'))) = ? ORDER BY active DESC LIMIT 1', name, grade));
  if (partyId) fill(get('SELECT colour, form, mesh FROM party_items WHERE party_id = ? AND upper(trim(item_name)) = ? AND upper(trim(COALESCE(grade, \'\'))) = ? LIMIT 1', partyId, name, grade));
  const text = `${name} ${grade}`;
  if (!a.colour) {
    const cs = listVals('colour');
    a.colour = cs.find(c => new RegExp(`\\b${c.replace(/[^A-Z0-9 ]/g, '')}\\b`).test(text)) || null;
    const ini = grade.match(/^([A-Z])\s*\d/);                       // Y300 → YELLOW, W325 → WHITE
    if (!a.colour && ini) a.colour = cs.find(c => c[0] === ini[1]) || null;
  }
  if (!a.mesh) { const n = meshNo(grade); if (n) a.mesh = listVals('mesh').find(m => meshNo(m) === n) || n; }
  if (!a.form) {
    const fs_ = listVals('form');
    a.form = fs_.find(f => text.includes(f)) || fs_.find(f => f.split(' ')[0].length > 3 && text.includes(f.split(' ')[0])) || (a.mesh && fs_.includes('POWDER') ? 'POWDER' : null);
  }
  return a;
}
// the best report for a line: every field set on the report must agree; the report with most fields set wins
// who: { party_id, group } — a report for one buyer / group goes only to it, and wins over the general reports
function reportFor(attrs, reports = all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY id'), who = {}) {
  let best = null, score = 0;
  for (const r of reports) {
    let s = 0, ok = true;
    if (r.party_id) { if (Number(r.party_id) !== Number(who.party_id)) continue; s += 100; }
    if (r.group_name) { if (!who.group || up(r.group_name) !== up(who.group)) continue; s += 50; }
    if (r.item_group_id) {          // item group: the item of the line must be one of the group's items
      const g = groupItems(r.item_group_id), have = attrs.product || '';
      if (!g.some(n => have === n || have.startsWith(n + ' ') || have.startsWith(n + ' ('))) continue;
      s++;
    }
    for (const k of ['product', 'colour', 'form', 'mesh']) {
      if (!r[k]) continue;
      const want = up(r[k]), have = attrs[k] || '';
      const same = k === 'mesh' ? (meshNo(want) && meshNo(want) === meshNo(have)) || want === have : k === 'product' ? have === want || have.startsWith(want + ' ') || have.startsWith(want + ' (') : want === have;
      if (!same) { ok = false; break; }
      s++;
    }
    if (ok && s > score) { best = r; score = s; }
  }
  return best;
}
const parseItems = t => { try { const a = JSON.parse(t || '[]'); return Array.isArray(a) ? a.map(up).filter(Boolean) : []; } catch { return []; } };
function groupItems(id) { const g = get('SELECT items FROM item_groups WHERE id = ? AND active = 1', id); return g ? parseItems(g.items) : []; }
function reportsForLines(lines, partyId) {
  const reports = all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY id'), out = new Map();
  const p = partyId ? get('SELECT id, group_name FROM parties WHERE id = ?', partyId) : null, who = { party_id: p && p.id, group: p && p.group_name };
  for (const l of lines) { const r = reportFor(lineAttrs(l, partyId), reports, who); if (r && !out.has(r.id)) out.set(r.id, { ...r, lots: [] }); if (r && l.lot_no) out.get(r.id).lots.push(l.lot_no); }
  return [...out.values()];
}

// ---- print (on the firm's letter head, the same head as the invoice) ----
function reportHtml(rep, f, opts = {}, c = {}) {
  const P = require('./print'), esc = P.esc;
  const brand = P.brand(f);
  const rows = rep.rows.map((r, i) => `<tr><td class="c">${i + 1}.</td><td>${esc(r[0])}</td><td class="c">${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join('');
  const dmy = iso => iso ? String(iso).slice(0, 10).split('-').reverse().join('.') : '';
  // J K group style: Certificate of Analysis block before the test table
  const coaRow = (k, v) => `<tr><td class="k">${k} :</td><td class="v">${v ? `<u><b>${esc(v)}</b></u>` : ''}</td></tr>`;
  const coa = rep.coa ? `<div class="coa"><div class="coat">CERTIFICATE OF ANALYSIS</div>
    <table class="coak">${coaRow('Report No.', c.inv_no)}${coaRow('Brand Name Of Product', rep.brand_name)}${coaRow('Material JKI Code No.', rep.material_code)}${coaRow('Name of the Customer', c.company)}${coaRow('PLANT', c.plant)}</table>
    <div class="coa2"><table class="coak">${coaRow('Batch / Lot No.', c.lots)}${coaRow('Date of Mfg', '')}</table>
      <table class="coak">${coaRow('Order No. / Date', c.order)}${coaRow('Date of Dispatch', dmy(c.date))}${coaRow('Invoice No.', c.inv_no)}</table></div></div>` : '';
  // other reports: the buyer first (contact person, company, address), then the table
  const addr = [c.address, [c.city, c.pincode].filter(Boolean).join(' - '), c.state].filter(Boolean);
  const toBox = !rep.coa && c.company ? `<div class="to">To,<br>${c.contact ? `Kind Attn.: <b>${esc(c.contact)}</b><br>` : ''}<b>${esc(c.company)}</b>${addr.map(a => '<br>' + esc(a).replace(/\n/g, '<br>')).join('')}
    ${c.inv_no ? `<div class="muted" style="margin-top:4px">Ref.: Invoice No. <b>${esc(c.inv_no)}</b> dated ${dmy(c.date)}</div>` : ''}</div>` : '';
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60e3).toISOString().slice(0, 10).split('-').reverse().join('.');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(printName(rep))} — ${esc(f.name)}</title><style>
@page { size: A4; margin: 12mm; }
* { box-sizing: border-box; } body { font-family: Arial, Helvetica, sans-serif; color: #1d2b30; margin: 0; font-size: 13px; }
.no-print { padding: 8px; background: #eef3f4; text-align: center; } .no-print button { font-size: 14px; padding: 6px 16px; margin: 0 4px; }
@media print { .no-print { display: none; } }
@media screen { body { background: #e7edef; } .page { background: #fff; width: 210mm; min-height: 297mm; margin: 10px auto; padding: 12mm; box-shadow: 0 2px 14px rgba(0,0,0,.18); } }
.head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2F4F5A; padding-bottom: 8px; }
.firm { font-size: 22px; font-weight: bold; color: #2F4F5A; } .muted { color: #44575d; font-size: 12px; } .r { text-align: right; }
.title { text-align: center; margin: 22px 0 14px; } .title div { font-size: 18px; font-weight: bold; text-decoration: underline; margin: 3px 0; font-family: Georgia, 'Times New Roman', serif; }
table.rep { width: 100%; border-collapse: collapse; margin-top: 8px; } table.rep th, table.rep td { border: 1px solid #9fb1b6; padding: 7px 9px; vertical-align: top; }
table.rep th { background: #eef3f4; text-align: left; font-size: 13px; } td.c, th.c { text-align: center; } table.rep td { font-size: 13.5px; }
.coa { border: 1.5px dashed #2e6b3f; padding: 6px 10px 8px; margin-top: 14px; } .coat { text-align: center; font-size: 19px; font-weight: bold; text-decoration: underline; margin-bottom: 6px; }
.coak { border-collapse: collapse; } .coak td { padding: 3px 6px; font-size: 13.5px; vertical-align: top; } .coak td.k { white-space: nowrap; width: 190px; } .coak td.v { min-width: 160px; }
.coa2 { display: flex; justify-content: space-between; border-top: 1px solid #555; margin-top: 6px; padding-top: 4px; }
.to { margin-top: 14px; line-height: 1.45; font-size: 13.5px; }
.note { margin-top: 16px; white-space: pre-wrap; line-height: 1.45; } .sign { margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; }
</style></head><body>${opts.shot ? '' : '<div class="no-print"><button onclick="window.print()">Print / Save PDF</button><button onclick="window.close()">Close</button></div>'}
<div class="page">
  <div class="head"><div style="display:flex;gap:14px;align-items:center">${brand ? P.brandImg(f, 80, 300) + '<div>' : P.logoTag(f) + `<div><div class="firm">${esc(String(f.name || '').toUpperCase())}</div>`}
    <div class="muted">${esc(f.address || '')}, ${esc(f.city || '')}${f.pincode ? ' - ' + esc(f.pincode) : ''}${f.state ? ' (' + esc(f.state) + ')' : ''}<br>${f.phone ? 'Ph: ' + esc(f.phone) + ' · ' : ''}${esc(f.email || '')}</div></div></div>
    <div class="r" style="white-space:nowrap;padding-left:12px">${f.gstin ? `GSTIN: <b>${esc(f.gstin)}</b><br>` : ''}${f.pan ? 'PAN: ' + esc(f.pan) + '<br>' : ''}Date: <b>${today}</b></div></div>
  ${coa}${toBox}
  <div class="title">${rep.heading ? `<div>${esc(rep.heading)}</div>` : ''}<div>${esc(printName(rep))}</div></div>
  <table class="rep"><thead><tr><th class="c" style="width:9%">Sl No.</th><th style="width:38%">Content</th><th class="c" style="width:18%">Observed Value in %</th><th>Protocol Adopted</th></tr></thead><tbody>${rows}</tbody></table>
  ${rep.note ? `<div class="note">${esc(rep.note)}</div>` : ''}
  <div class="sign"><div class="muted"></div><div class="r">For <b>${esc(f.name || '')}</b><div style="height:52px;display:flex;justify-content:flex-end;align-items:center">${P.signTag(f)}</div>Authorised signatory</div></div>
</div>${opts.autoPrint ? '<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>' : ''}</body></html>`;
}

const firmOf = code => get('SELECT * FROM firms WHERE code = ?', code || 'PM') || get("SELECT * FROM firms WHERE code = 'PM'") || get('SELECT * FROM firms ORDER BY id LIMIT 1');
const safe = s => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
// the PDF of a report for a firm (kept in the PDF folder → Analysis Reports)
async function reportPdf(id, firmCode, { port, pdfFolder }, ref = {}) {
  const rep = get('SELECT * FROM analysis_reports WHERE id = ?', id); if (!rep) throw new E('Analysis report not found.');
  const f = firmOf(firmCode), qs = Object.entries(ref).filter(([, v]) => v).map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join('');
  const c = context(ref, full(rep)), tag = c.inv_no ? ` - Inv ${c.inv_no}` : '', who = c.company ? ` - ${c.company}` : '';
  const file = path.join(pdfFolder(), 'Analysis Reports', safe(`${printName(rep)}${tag}${who} - ${f.name}`) + '.pdf');
  await makePdf(`http://127.0.0.1:${port()}/print/anreport/${id}?firm=${encodeURIComponent(f.code)}${qs}&shot=1`, file);
  return file;
}

function register(route, { smtpSend, brandLogo, port, pdfFolder }) {
  route('GET', '/api/anreports', () => all('SELECT * FROM analysis_reports WHERE active = 1 ORDER BY name').map(r => ({ ...full(r), print_name: printName(r) })));
  route('GET', '/api/anreports/:id', ({ p }) => { const r = full(get('SELECT * FROM analysis_reports WHERE id = ?', p.id)); if (!r) throw new E('Analysis report not found.'); return r; });
  route('POST', '/api/anreports', ({ body }) => {
    const o = clean(body || {}); if (!o.name) throw new E('Enter the report name.');
    const k = Object.keys(o); return { id: Number(run(`INSERT INTO analysis_reports(${k.join(', ')}) VALUES(${k.map(() => '?').join(', ')})`, ...k.map(x => o[x])).lastInsertRowid) };
  });
  route('PUT', '/api/anreports/:id', ({ p, body }) => {
    const o = clean(body || {}), k = Object.keys(o); if (!k.length) return { id: Number(p.id) };
    run(`UPDATE analysis_reports SET ${k.map(x => x + ' = ?').join(', ')}, updated_at = datetime('now','localtime') WHERE id = ?`, ...k.map(x => o[x]), p.id); return { id: Number(p.id) };
  });
  route('POST', '/api/anreports/:id/copy', ({ p }) => {
    const r = get('SELECT * FROM analysis_reports WHERE id = ?', p.id); if (!r) throw new E('Analysis report not found.');
    return { id: Number(run('INSERT INTO analysis_reports(name, heading, product, colour, form, mesh, rows, note) VALUES(?,?,?,?,?,?,?,?)', r.name + ' (copy)', r.heading, r.product, r.colour, r.form, r.mesh, r.rows, r.note).lastInsertRowid) };
  });
  route('DELETE', '/api/anreports/:id', ({ p }) => { run('UPDATE analysis_reports SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });
  // which report an item would get (to check the link): ?item=&grade=&colour=&form=&mesh=
  route('GET', '/api/anreports-match', ({ q }) => { const a = lineAttrs({ item_name: q.item, grade: q.grade, colour: q.colour, form: q.form, mesh: q.mesh }); const r = reportFor(a); return { attrs: a, report: r ? { id: r.id, name: r.name } : null }; });
  // email one report as a PDF
  route('POST', '/api/anreports/:id/email', async ({ p, body }) => {
    const rep = get('SELECT * FROM analysis_reports WHERE id = ?', p.id); if (!rep) throw new E('Analysis report not found.');
    const f = firmOf(body.firm_code), to = mailer.splitAddr(body.to), cc = mailer.splitAddr(body.cc);
    const log = (status, error) => run('INSERT INTO email_log(firm_code, seller, to_name, to_addr, template, doc_no, kind, status, error, attachments) VALUES(?,?,?,?,?,?,?,?,?,?)',
      f.code, f.name, to.join('; '), to.join('; '), 'Analysis report', rep.name, 'Analysis report', status, error || null, status === 'SENT' ? rep.name : null);
    try {
      if (!f.smtp_user || !f.smtp_pass) throw new E(`Email is not set up for ${f.name}. Open Settings → Companies → Email.`);
      if (!to.length) throw new E('Enter the email address.');
      const file = await reportPdf(rep.id, f.code, { port, pdfFolder }, { party: body.party_id || null });
      const text = String(body.text || `Dear Sir / Madam,\n\nPlease find attached the analysis report of ${printName(rep)}.\n\nRegards,\n${f.name}`);
      await smtpSend({ host: f.smtp_host || 'smtp.gmail.com', port: f.smtp_port || 465, user: f.smtp_user, pass: f.smtp_pass },
        { from: f.smtp_user, fromName: f.name, logo: brandLogo(f), to, cc, subject: body.subject || `Analysis report — ${printName(rep)} — ${f.name}`, text, html: mailer.textToHtml(text), attachments: [{ path: file, filename: path.basename(file) }] });
      log('SENT'); return { sent: true };
    } catch (e) { log('FAILED', e.message); throw e; }
  });
  // Item List → Item group
  route('GET', '/api/item-groups', () => ({ groups: all('SELECT * FROM item_groups WHERE active = 1 ORDER BY name').map(g => ({ ...g, items: parseItems(g.items) })),
    names: [...new Set([...all("SELECT value FROM lists WHERE list_key = 'product' AND active = 1").map(r => up(r.value)), ...all('SELECT DISTINCT name FROM items WHERE active = 1').map(r => up(r.name))].filter(Boolean))].sort() }));
  const cleanGroup = b => { const name = up(b.name); if (!name) throw new E('Enter the group name.'); const items = [...new Set((Array.isArray(b.items) ? b.items : []).map(up).filter(Boolean))];
    if (!items.length) throw new E('Tick at least one item for the group.'); return { name, items: JSON.stringify(items) }; };
  route('POST', '/api/item-groups', ({ body }) => { const o = cleanGroup(body || {});
    if (get('SELECT 1 FROM item_groups WHERE active = 1 AND name = ?', o.name)) throw new E(`There is already a group ${o.name}.`);
    return { id: Number(run('INSERT INTO item_groups(name, items) VALUES(?,?)', o.name, o.items).lastInsertRowid) }; });
  route('PUT', '/api/item-groups/:id', ({ p, body }) => { const o = cleanGroup(body || {});
    if (get('SELECT 1 FROM item_groups WHERE active = 1 AND name = ? AND id <> ?', o.name, p.id)) throw new E(`There is already a group ${o.name}.`);
    run('UPDATE item_groups SET name = ?, items = ? WHERE id = ?', o.name, o.items, p.id); return { id: Number(p.id) }; });
  route('DELETE', '/api/item-groups/:id', ({ p }) => {
    const used = all('SELECT name FROM analysis_reports WHERE active = 1 AND item_group_id = ?', p.id);
    if (used.length) throw new E(`This group is used by the analysis report ${used.map(r => r.name).join(', ')} — change that report first.`);
    run('UPDATE item_groups SET active = 0 WHERE id = ?', p.id); return { deleted: true }; });
  route('GET', '/api/anreports-firms', () => ({ firms: all('SELECT code, name, smtp_user FROM firms ORDER BY id').map(f => ({ code: f.code, name: f.name, email: !!f.smtp_user })) }));
}
// /print/anreport/:id?firm=PM
// who the report is for: an invoice (inv=), a buyer (party= / b2c=) or a sample dispatch (dispatch=)
function context(q, rep) {
  const c = {};
  const buyer = b => { if (!b) return; c.company = b.name; c.contact = b.contact_person || ''; c.address = b.address || ''; c.city = b.city || ''; c.state = b.state || ''; c.pincode = b.pincode || ''; };
  if (q.inv) {
    const inv = require('./logic').invoiceFull(q.inv);
    if (inv) {
      c.firm_code = inv.firm_code; c.inv_no = String(inv.inv_no); c.date = inv.date; c.company = inv.party_name;
      const who = inv.b2c_id ? inv.customer || {} : inv.party || {};
      c.contact = who.contact_person || ''; c.address = inv.party_address || ''; c.city = inv.party_city || ''; c.state = inv.party_state || ''; c.pincode = inv.party_pincode || '';
      c.plant = inv.ship_city || inv.party_city || '';
      const mine = reportsForLines(inv.items, inv.party_id).find(x => x.id === rep.id);
      c.lots = [...new Set(((mine && mine.lots.length ? mine.lots : inv.items.map(i => i.lot_no)) || []).filter(Boolean))].join(', ');
    }
  } else if (q.party) { buyer(get('SELECT * FROM parties WHERE id = ?', q.party)); c.plant = c.city; }
  else if (q.b2c) buyer(get('SELECT * FROM b2c_customers WHERE id = ?', q.b2c));
  else if (q.dispatch) {
    try { const d = require('./marketing/print').dispatchFull(Number(q.dispatch)), L = d.lead || {};
      c.company = L.company || L.buyer_name || ''; c.contact = L.company ? L.buyer_name || '' : ''; c.address = L.address || ''; c.city = L.city || ''; c.state = L.state || ''; c.pincode = L.pincode || ''; c.plant = L.city || ''; c.date = d.dispatch.date; c.firm_code = d.firm && d.firm.code;
    } catch { /* marketing not open */ }
  }
  return c;
}
function serve(id, q) {
  const r = full(get('SELECT * FROM analysis_reports WHERE id = ?', id)); if (!r) return null;
  const c = context(q, r);
  return reportHtml(r, firmOf(q.firm || c.firm_code), { shot: q.shot === '1', autoPrint: q.print === '1' }, c);
}
// attachments for an email: the reports of these item lines, as PDFs of this firm
async function attachFor(lines, partyId, firmCode, ctx, ref = {}) {
  const out = [];
  for (const r of reportsForLines(lines, partyId)) { const file = await reportPdf(r.id, firmCode, ctx, ref); out.push({ path: file, filename: path.basename(file), name: printName(r) }); }
  return out;
}
module.exports = { printName, register, serve, reportsForLines, attachFor, lineAttrs, reportFor };
