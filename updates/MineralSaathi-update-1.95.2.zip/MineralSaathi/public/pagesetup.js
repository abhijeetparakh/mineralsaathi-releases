'use strict';
/* Settings → Page Setup (like OrderSaathi): printer, paper and position of every paper except the PM / PPE / PF
   sales invoices, on this computer. Uses the helpers of app.js ($, GET, PUT, POST, SETTINGS, toast, esc …). */

const PS_PAPERS = [['A4', 'A4 (210 × 297)'], ['A5', 'A5 (148 × 210)'], ['LETTER', 'Letter (216 × 279)'], ['LABEL4X6', '4 × 6 inch label (101.6 × 152.4)'],
  ['ENV_DL', 'Envelope DL (220 × 110)'], ['ENV_C5', 'Envelope C5 (229 × 162)'], ['ENV_10', 'Envelope No.10 (241 × 105)'], ['CUSTOM', 'Own size …']];
const PS_AREAS = [['full', 'Whole page'], ['left', 'Left half'], ['right', 'Right half'], ['top', 'Top half'], ['bottom', 'Bottom half'], ['own', 'My own position …']];

SETTINGS.pagesetup = async (box, key) => {
  const [d, pl] = await Promise.all([GET('/api/page-setup'), GET('/api/printers').catch(() => ({ printers: [] }))]);
  const paper = d.papers.find(x => x.key === key) || d.papers[0];
  const groups = [...new Set(d.papers.map(x => x.group))];
  box.innerHTML = `<div class="grid" style="grid-template-columns:250px 1fr;align-items:start">
    <div class="card listside" style="padding:8px">${groups.map(g => `<div class="hint" style="padding:6px 10px 2px;font-weight:700">${esc(g)}</div>` +
      d.papers.filter(x => x.group === g).map(x => `<a class="listhead ${x.key === paper.key ? 'on' : ''}" onclick="go('#/settings/pagesetup:${x.key}')"><b>${esc(x.name)}</b>
        <br><span class="hint">${x.setup.printer ? esc(x.setup.printer) : 'no printer chosen'}</span></a>`).join('')).join('')}
      <p class="hint" style="padding:8px 10px">The PM, PPE and PF sales invoices keep their setup in Printer Settings.</p></div>
    <div class="grid" style="grid-template-columns:minmax(420px,1.2fr) minmax(300px,1fr);align-items:start">
      <form class="card" id="psf" autocomplete="off" novalidate><h3>${esc(paper.name)} <span class="hint">— drawn at ${paper.design.w} × ${paper.design.h} mm, placed on the paper as set here</span></h3>
        <div id="psrows"></div>
        <div class="row" style="margin-top:12px"><button type="submit">Save</button><button type="button" class="sec" id="pstest">Print a test</button>
          <button type="button" class="sec" id="psreset">Start again</button><span class="hint" id="psmsg"></span></div>
        <p class="hint" style="margin-top:8px">Saved on this computer only (${d.local ? 'the main PC' : 'from the main PC'}), so each computer can use its own printers and papers.
          ${d.direct ? '' : 'Direct printing works when Mineral Saathi runs on Windows; here the print window uses these sizes.'}</p></form>
      <div class="card" style="position:sticky;top:10px"><h3>Preview <span class="hint" id="psinfo"></span></h3>
        <div id="pswrap" style="background:#e7edef;border-radius:8px;padding:10px;overflow:hidden;display:flex;justify-content:center"></div>
        <p class="hint" style="margin-top:8px">The brown box is where the paper's content is printed; 10 mm squares. "Print a test" prints this page.</p></div>
    </div></div>`;
  const f = $('#psf', box);
  let s = { ...paper.setup };
  const row = (label, html, hint = '') => `<div style="display:grid;grid-template-columns:150px 1fr;gap:8px;align-items:center;margin:6px 0"><span style="color:var(--muted);font-size:13px">${label}</span>
    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;min-width:0">${html}${hint ? `<span class="hint">${hint}</span>` : ''}</div></div>`;
  const num = (n, w = 80, step = 'any') => `<input name="${n}" type="number" step="${step}" style="width:${w}px">`;     // 'any': sizes like 101.6 mm must not block saving
  const sel = (n, opts, w = 260) => `<select name="${n}" style="width:100%;max-width:${w}px">${opts.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join('')}</select>`;
  const isLabel = paper.design.w < 150 && paper.design.h < 200;
  $('#psrows', box).innerHTML =
    row('Printer', `<select name="printer" style="width:100%;max-width:340px"><option value="">— choose —</option>${(pl.printers || []).map(n => `<option>${esc(n)}</option>`).join('')}${s.printer && !(pl.printers || []).includes(s.printer) ? `<option>${esc(s.printer)}</option>` : ''}</select>`,
      pl.default ? 'Windows default: ' + esc(pl.default) : '') +
    row('Paper in the printer', `<select name="printer_paper" style="width:100%;max-width:340px"><option value="">— size typed by hand —</option></select>`, 'from the printer driver') +
    row('Paper', sel('paper', PS_PAPERS)) +
    `<div id="pscustom">${row('Own size (mm)', num('cw') + ' × ' + num('ch'), 'width × height')}</div>` +
    row('Orientation', sel('landscape', [['0', 'Portrait (tall)'], ['1', 'Landscape (wide)']], 200)) +
    row('Turn the content', sel('rotate', [['0', 'Not turned'], ['90', 'Turn 90° right ↻'], ['270', 'Turn 90° left ↺'], ['180', 'Upside down (180°)']], 220), 'the whole paper turned — e.g. to print on a half-cut sheet') +
    row('Print on', sel('area', PS_AREAS, 200)) +
    `<div id="psown">${row('From left / top (mm)', num('ax') + ' / ' + num('ay'))}${row('Width / height (mm)', num('aw') + ' / ' + num('ah'))}
      ${row('Quick place', ['Left half', 'Right half', 'Top half', 'Bottom half', 'Whole page'].map((t, i) => `<button type="button" class="small sec" data-qp="${i}">${t}</button>`).join(' '))}</div>` +
    row('Margin top / bottom (mm)', num('mt') + ' / ' + num('mb')) +
    row('Margin left / right (mm)', num('ml') + ' / ' + num('mr')) +
    row('Size', `<label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" name="fit" style="width:auto"> Fit the paper's content into the area</label>&nbsp; or scale % ${num('scale', 70, '1')}`) +
    row('Shift right / down (mm)', num('ox') + ' / ' + num('oy'), 'minus = left / up, for a printer that prints off-centre') +
    row('Copies', num('copies', 70, '1')) +
    row('Label printer', `<label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" name="turn" style="width:auto"> Print comes out sideways? Tick to send the paper turned (old way)</label>`) +
    `<details id="pslabels" ${s.across * s.down > 1 ? 'open' : ''} style="margin-top:8px"><summary style="cursor:pointer;font-weight:600">Label paper — several labels on a roll or an A4 sticker sheet</summary>
      <p class="hint">The paper size above is then the size of ONE label.</p>
      ${row('Ready-made', `<select id="pspreset" style="width:100%;max-width:340px"><option value="">— choose to fill in —</option>${d.presets.map((p, i) => `<option value="${i}">${esc(p.name)}</option>`).join('')}</select>`)}
      ${row('Labels across / down', num('across', 60, '1') + ' / ' + num('down', 60, '1'))}
      ${row('Gap across / down (mm)', num('gapx') + ' / ' + num('gapy'))}
      ${row('Paper', sel('sheet', [['roll', 'Roll (one row per page)'], ['a4', 'A4 sticker sheet']], 220))}
      ${row('Edge margin side / top (mm)', num('smx') + ' / ' + num('smy'))}
      ${row('Fill', sel('fill', [['turn', 'Each label in turn'], ['row', 'Same label across the row']], 220))}</details>`;
  if (!isLabel) $('#pslabels', box).open = false;
  // stickers: one click for the same sticker twice side by side on an A4 sticker sheet
  if (isLabel) $('#pslabels', box).insertAdjacentHTML('beforebegin', row('A4 sticker sheet', d.presets.map((p, i) => p.fill === 'row' ? `<button type="button" class="small sec" data-twin="${i}">${esc(p.name.replace('A4 sheet: ', ''))}</button>` : '').join(' ')));

  const keys = ['printer', 'printer_paper', 'paper', 'cw', 'ch', 'landscape', 'area', 'ax', 'ay', 'aw', 'ah', 'mt', 'mb', 'ml', 'mr', 'fit', 'scale', 'ox', 'oy', 'copies', 'turn', 'across', 'down', 'gapx', 'gapy', 'sheet', 'smx', 'smy', 'fill', 'rotate'];
  const put = () => { for (const k of keys) { const e = f.elements[k]; if (!e) continue;
    if (e.type === 'checkbox') e.checked = !!s[k]; else if (k === 'landscape') e.value = s[k] ? '1' : '0'; else e.value = s[k] ?? ''; }
    $('#pscustom', box).hidden = f.paper.value !== 'CUSTOM'; $('#psown', box).hidden = f.area.value !== 'own'; f.scale.disabled = f.fit.checked; };
  const read = () => { const o = {}; for (const k of keys) { const e = f.elements[k]; if (!e) continue;
    o[k] = e.type === 'checkbox' ? e.checked : k === 'landscape' ? e.value === '1' : ['printer', 'printer_paper', 'paper', 'area', 'sheet', 'fill'].includes(k) ? e.value : Number(e.value); } return o; };
  // the printer's own papers
  const loadPapers = async () => {
    const ps = f.printer_paper; ps.length = 1;
    if (!f.printer.value) return;
    const r = await GET('/api/printers/papers?name=' + encodeURIComponent(f.printer.value)).catch(() => ({ papers: [] }));
    for (const p of r.papers || []) ps.add(new Option(`${p.name} (${Math.round(p.w)} × ${Math.round(p.h)} mm)`, p.name));
    ps.value = s.printer_paper || ''; ps._papers = r.papers || [];
  };
  // preview: the test page drawn by the server with this (not yet saved) setup, made small
  let pt;
  const preview = () => { clearTimeout(pt); pt = setTimeout(async () => {
    s = read(); put();
    const c = await POST(`/api/page-setup/${paper.key}/check`, s).catch(() => null); if (!c) return;
    $('#psinfo', box).textContent = `— paper ${Math.round(c.paper[0] * 10) / 10} × ${Math.round(c.paper[1] * 10) / 10} mm${c.sheet[0] !== c.paper[0] || c.sheet[1] !== c.paper[1] ? ` · printed page ${Math.round(c.sheet[0])} × ${Math.round(c.sheet[1])} mm` : ''} · content at ${c.scale}%`;
    const wrap = $('#pswrap', box), maxW = wrap.clientWidth - 20 || 320, px = 3.7795;
    const W = c.sheet[0] * px, H = c.sheet[1] * px, k = Math.min(maxW / W, 460 / H);
    wrap.style.height = Math.ceil(H * k + 20) + 'px';
    wrap.innerHTML = `<div style="width:${W * k}px;height:${H * k}px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.2);background:#fff">
      <iframe src="/print/pagetest/${paper.key}?shot=1&s=${encodeURIComponent(JSON.stringify(s))}" style="border:0;width:${W + 4}px;height:${H + 4}px;transform:scale(${k});transform-origin:0 0;pointer-events:none"></iframe></div>`;
  }, 250); };
  put(); await loadPapers(); preview();
  f.addEventListener('input', preview); f.addEventListener('change', preview);
  f.printer.addEventListener('change', async () => { s.printer_paper = ''; await loadPapers(); preview(); });
  // a paper from the printer's list sets the paper size (labels: the label size)
  f.printer_paper.addEventListener('change', () => {
    const p = (f.printer_paper._papers || []).find(x => x.name === f.printer_paper.value); if (!p) return;
    const near = (a, b) => Math.abs(a - b) < 1.5, sw = Math.min(p.w, p.h), lg = Math.max(p.w, p.h);
    const std = near(sw, 210) && near(lg, 297) ? 'A4' : near(sw, 148) && near(lg, 210) ? 'A5' : near(sw, 215.9) && near(lg, 279.4) ? 'LETTER' : near(sw, 101.6) && near(lg, 152.4) ? 'LABEL4X6' : 'CUSTOM';
    f.paper.value = std; if (std === 'CUSTOM') { f.cw.value = Math.round(p.w * 10) / 10; f.ch.value = Math.round(p.h * 10) / 10; f.landscape.value = p.w > p.h ? '1' : '0'; }
    preview();
  });
  $$('[data-qp]', box).forEach(b => b.onclick = async () => {
    const c = await POST(`/api/page-setup/${paper.key}/check`, { ...read(), area: 'full', mt: 0, mb: 0, ml: 0, mr: 0, ox: 0, oy: 0 }); const [pw, ph] = c.paper;
    const q = [[0, 0, pw / 2, ph], [pw / 2, 0, pw / 2, ph], [0, 0, pw, ph / 2], [0, ph / 2, pw, ph / 2], [0, 0, pw, ph]][Number(b.dataset.qp)];
    [f.ax.value, f.ay.value, f.aw.value, f.ah.value] = q.map(v => Math.round(v * 10) / 10); preview();
  });
  $$('[data-twin]', box).forEach(b => b.onclick = () => { const sel = $('#pspreset', box); sel.value = b.dataset.twin; sel.onchange({ target: sel }); $('#pslabels', box).open = true; });
  $('#pspreset', box).onchange = e => { const p = d.presets[Number(e.target.value)]; if (!p) return;
    f.across.value = p.across; f.down.value = p.down; if (p.fill) f.fill.value = p.fill; f.gapx.value = p.gapx; f.gapy.value = p.gapy; f.sheet.value = p.sheet; f.smx.value = p.smx; f.smy.value = p.smy;
    if (p.w && p.h) { f.paper.value = 'CUSTOM'; f.cw.value = p.w; f.ch.value = p.h; f.landscape.value = p.w > p.h ? '1' : '0'; }
    preview(); };
  f.onsubmit = async e => { e.preventDefault(); s = await guard(() => PUT('/api/page-setup/' + paper.key, read())); toast('Page setup saved on this computer'); SETTINGS.pagesetup(box, paper.key); };
  $('#psreset', box).onclick = async () => { if (!confirm('Start this paper again from the usual setup?')) return; await guard(() => PUT('/api/page-setup/' + paper.key, {})); SETTINGS.pagesetup(box, paper.key); };
  $('#pstest', box).onclick = async () => {
    await guard(() => PUT('/api/page-setup/' + paper.key, read()));
    const r = await guard(() => POST(`/api/page-setup/${paper.key}/test`, { where: typeof printWhere === 'function' ? printWhere(paper.key) : '' }));
    if (r.browser) window.open(r.url, '_blank'); else toast('Test sent to ' + r.printer);
  };
};
