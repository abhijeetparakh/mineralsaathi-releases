'use strict';
// Factory wages: Parakh Marketing invoices ONLY. Dispatch of each plant in a month, grouped by grade,
// wages = qty x wage rate of the item's form (Item lists → Item form), plus fixed and other expenses.
const { all, get, run, tx } = require('./db');
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const K = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

function formRates() {
  return all(`SELECT value, num FROM lists WHERE list_key = 'form' AND active = 1 ORDER BY sort, value`);
}
// form of an invoice line: the buyer's item → the item master → a guess from the grade
function formOf(line, ctx) {
  const pi = line.party_id && (ctx.pitems[line.party_id] || []).find(x => K(x.item_name) === K(line.item_name) && K(x.grade) === K(line.grade));
  let f = pi && pi.form;
  if (!f) { const it = ctx.items.find(x => K(x.name) === K(line.item_name) && K(x.grade) === K(line.grade)); f = it && it.form; }
  if (!f) {
    const g = K(line.grade) + ' ' + K(line.item_name);
    f = /GRANU/.test(g) ? 'GRANULES' : /CHIP/.test(g) ? 'CHIPS' : /LUMP/.test(g) ? 'LUMPS' : /RAW/.test(g) ? 'RAW' : 'POWDER';
  }
  const fk = K(f);
  const hit = ctx.forms.find(x => K(x.value) === fk) || ctx.forms.find(x => K(x.value).startsWith(fk) || fk.startsWith(K(x.value)));
  return hit ? { form: hit.value, rate: Number(hit.num) || 0 } : { form: String(f).toUpperCase(), rate: 0 };
}

function month(m) {
  if (!/^\d{4}-\d{2}$/.test(m || '')) throw Object.assign(new Error('Choose the month.'), { status: 400 });
  const plants = all('SELECT name, full_name, address FROM plants ORDER BY name DESC');   // PPI PLANT, KI PLANT
  const ctx = { forms: formRates(), items: all('SELECT name, grade, form FROM items'), pitems: {} };
  for (const p of all('SELECT party_id, item_name, grade, form FROM party_items WHERE active = 1')) (ctx.pitems[p.party_id] = ctx.pitems[p.party_id] || []).push(p);
  const lines = all(`SELECT COALESCE(it.plant, i.plant) AS plant, i.party_id, it.item_name, it.grade, it.qty FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
                     WHERE i.firm_code = 'PM' AND i.kind = 'SALE' AND COALESCE(i.cancelled, 0) = 0 AND substr(i.date, 1, 7) = ?`, m);
  const saved = all('SELECT * FROM wage_entries WHERE month = ? ORDER BY id', m);
  const out = plants.map(pl => {
    const groups = {};
    for (const l of lines.filter(x => x.plant === pl.name)) {
      const { form, rate } = formOf(l, ctx);
      const key = [l.item_name, l.grade].filter(Boolean).join(' ').toUpperCase();
      const g = groups[key] = groups[key] || { grade: key, form, rate, qty: 0 };
      g.qty = Math.round((g.qty + (Number(l.qty) || 0)) * 1000) / 1000;
    }
    const disp = Object.values(groups).sort((a, b) => a.grade.localeCompare(b.grade)).map(g => ({ ...g, qty: Math.round(g.qty * 1000) / 1000, amount: r2(g.qty * g.rate) }));
    const mine = saved.filter(s => s.plant === pl.name);
    const fixedSaved = mine.filter(s => s.kind === 'FIXED');
    const fixed = fixedSaved.length ? fixedSaved.map(s => ({ description: s.description, qty: s.qty, rate: s.rate, amount: s.amount, saved: true }))
      : all('SELECT name, amount FROM factory_fixed WHERE plant = ? AND active = 1 AND amount > 0 ORDER BY name', pl.name).map(f => ({ description: f.name, qty: null, rate: null, amount: f.amount, saved: false }));
    const extra = mine.filter(s => s.kind === 'EXTRA').map(s => ({ description: s.description, qty: s.qty, rate: s.rate, amount: s.amount }));
    const qty = Math.round(disp.reduce((s, d) => s + d.qty, 0) * 1000) / 1000, wages = r2(disp.reduce((s, d) => s + d.amount, 0));
    const fx = r2(fixed.reduce((s, x) => s + (Number(x.amount) || 0), 0)), ex = r2(extra.reduce((s, x) => s + (Number(x.amount) || 0), 0));
    return { plant: pl.name, full_name: pl.full_name, dispatch: disp, qty, wages, fixed, extra, fixed_total: fx, extra_total: ex, total: r2(wages + fx + ex) };
  });
  const noPlant = lines.filter(l => !l.plant || !plants.some(p => p.name === l.plant));
  const sm = get('SELECT saved_at FROM wage_months WHERE month = ?', m);
  return { month: m, plants: out, saved: !!sm || saved.length > 0, saved_at: sm ? sm.saved_at : null, no_plant_qty: Math.round(noPlant.reduce((s, l) => s + (Number(l.qty) || 0), 0) * 1000) / 1000,
    forms_without_rate: ctx.forms.filter(f => !(Number(f.num) > 0)).map(f => f.value) };
}

// save the fixed and other expense rows of a month (dispatch is never saved: it always comes from the invoices)
function save(m, rows) {
  if (!/^\d{4}-\d{2}$/.test(m || '')) throw Object.assign(new Error('Choose the month.'), { status: 400 });
  const plants = all('SELECT name FROM plants').map(p => p.name);
  const clean = (rows || []).map((r, i) => {
    const kind = r.kind === 'FIXED' ? 'FIXED' : 'EXTRA';
    const description = String(r.description || '').trim().toUpperCase();
    const qty = r.qty === '' || r.qty == null ? null : Number(r.qty), rate = r.rate === '' || r.rate == null ? null : Number(r.rate);
    let amount = r.amount === '' || r.amount == null ? null : Number(r.amount);
    if (qty != null && rate != null && (amount == null || !r.amount_typed)) amount = r2(qty * rate);
    if (!plants.includes(r.plant)) throw Object.assign(new Error(`Row ${i + 1}: choose the plant.`), { status: 400 });
    if (!description && !amount) return null;
    if (!description) throw Object.assign(new Error(`Row ${i + 1}: enter the description.`), { status: 400 });
    return { plant: r.plant, kind, description, qty, rate, amount: r2(amount) };
  }).filter(Boolean);
  tx(() => {
    run(`INSERT INTO wage_months(month, saved_at) VALUES(?, datetime('now','localtime')) ON CONFLICT(month) DO UPDATE SET saved_at = excluded.saved_at`, m);
    run('DELETE FROM wage_entries WHERE month = ?', m);
    for (const r of clean) run('INSERT INTO wage_entries(month, plant, kind, description, qty, rate, amount) VALUES(?,?,?,?,?,?,?)', m, r.plant, r.kind, r.description, r.qty, r.rate, r.amount);
  });
  return { saved: clean.length };
}

// every saved month (the wages vouchers), newest first, with its totals
function savedMonths() {
  return all('SELECT month, saved_at FROM wage_months ORDER BY month DESC').map(r => {
    const d = month(r.month);
    return { month: r.month, saved_at: r.saved_at, qty: Math.round(d.plants.reduce((s, p) => s + p.qty, 0) * 1000) / 1000,
      plants: d.plants.map(p => ({ plant: p.plant, total: p.total })), total: r2(d.plants.reduce((s, p) => s + p.total, 0)) };
  });
}

module.exports = { month, save, savedMonths };
