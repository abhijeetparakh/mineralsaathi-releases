'use strict';
/* Factory → Bags: stock of empty bags (PM + PF together). Tabs: Stock · Entries · Bag types · Used by invoices. */
TITLES.bags = 'Bags';
const BAG_KINDS = [['PURCHASE', 'Purchase of bags'], ['BUYER', 'Bags received from a buyer'], ['ADJUST', 'Adjustment (damaged / count)'], ['OPENING', '🔒 Opening stock']];
const BAG_TYPE_KINDS = [['OUTER', 'Bag'], ['INNER', '5 kg inner bag'], ['COMBO', 'Combo (1 outer + 4 / 6 inner)'], ['LINER', 'Liner']];
PAGES.bags = async (el, tab) => {
  tab = tab || 'stock';
  el.innerHTML = `<div class="tabs" style="margin-bottom:14px">${[['stock', 'Stock'], ['entries', 'Bag entries'], ['used', 'Used by invoices']].map(([k, t]) =>
    `<button class="${tab === k ? 'on' : ''}" onclick="go('#/bags/${k}')">${t}</button>`).join('')}<button onclick="go('#/itemlists/bag_type')">⚙ Bag types (Item List)</button></div><div id="bgb"></div>`;
  const box = $('#bgb', el);
  if (tab === 'entries') return bagEntries(box);
  if (tab === 'types') return go('#/itemlists/bag_type');
  if (tab === 'used') return bagUsed(box);
  return bagStock(box);
};
const bagN = n => (Math.round((Number(n) || 0) * 1000) / 1000).toLocaleString('en-IN');

async function bagStock(box) {
  const [d, s] = await Promise.all([GET('/api/bags/stock'), GET('/api/bags/settings')]);
  const own = d.list.filter(x => !x.owner && x.kind !== 'LINER'), buyers = d.list.filter(x => x.owner), liner = d.list.filter(x => x.kind === 'LINER');
  const value = d.list.reduce((t, x) => t + (x.value || 0), 0), low = d.list.filter(x => x.low);
  const rowsHtml = list => list.map(x => `<tr${x.low ? ' style="background:#fff4e5"' : ''}><td><b>${esc(x.name)}</b>${x.kind === 'INNER' ? ' <span class="badge slate">5 kg inner</span>' : ''}${!x.in_list ? ' <a class="badge amber" href="#/itemlists/bag_type" title="Join it to a bag type with Same as, or add it to the list">not in Item List</a>' : ''}${x.owner ? `<br><span class="hint">${esc(x.owner)}'s bags</span>` : ''}</td>
    <td class="num">${bagN(x.opening) || ''}</td><td class="num">${x.purchased ? bagN(x.purchased) : ''}</td><td class="num">${x.from_buyers ? bagN(x.from_buyers) : ''}</td><td class="num">${x.adjust ? bagN(x.adjust) : ''}</td>
    <td class="num">${x.used ? bagN(x.used) : ''}</td><td class="num">${x.wastage ? bagN(x.wastage) : ''}</td>
    <td class="num"><b style="color:${x.in_hand < 0 ? 'var(--bad)' : 'inherit'}">${bagN(x.in_hand)}</b>${x.low ? ' <span class="badge amber">⚠ low</span>' : ''}</td>
    <td class="num">${x.avg_cost != null ? money(x.avg_cost) : ''}</td><td class="num">${x.value != null ? rs(x.value) : ''}</td></tr>`).join('');
  const head = `<thead><tr><th>Bag type</th><th class="num">Opening</th><th class="num">Purchased</th><th class="num">From buyers</th><th class="num">Adjust</th><th class="num">Used</th><th class="num">Wastage</th><th class="num">In hand</th><th class="num">Avg cost / bag</th><th class="num">Value</th></tr></thead>`;
  box.innerHTML = `<div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
      <div class="stat"><div class="k">Bags in hand (ours)</div><div class="v">${bagN(own.reduce((t, x) => t + Math.max(0, x.in_hand), 0))}</div><div class="hint">${own.length} bag types</div></div>
      <div class="stat"><div class="k">Value of our bags</div><div class="v">${rs(value)}</div><div class="hint">at the average purchase cost</div></div>
      <div class="stat"><div class="k">Low stock</div><div class="v" style="color:${low.length ? 'var(--amber)' : 'inherit'}">${low.length}</div><div class="hint">${low.map(x => esc(x.name)).slice(0, 3).join(', ') || 'below the minimum you set'}</div></div>
      <div class="stat"><div class="k">Counting from</div><div class="v" style="font-size:20px">${dmy(d.start)}</div><div class="hint">PM + PF invoices use bags by themselves</div></div></div>
    ${d.no_type ? `<div class="firmbox" style="margin:10px 0">⚠ ${d.no_type} invoice line(s) (${bagN(d.no_type_bags)} bags) have no bag type, so they are not counted. See “Used by invoices”.</div>` : ''}
    <div class="card"><div class="toolbar"><h3 style="margin:0">Our bags</h3><span class="spacer"></span><button onclick="go('#/bags/entries')">+ Bag entry</button><button class="sec" id="bgx">Export</button></div>
      <div class="tablewrap"><table class="t">${head}<tbody>${rowsHtml(own) || '<tr><td colspan="10" class="muted">No bags yet — fill in the opening stock and the purchases (Bag entries).</td></tr>'}</tbody></table></div></div>
    ${liner.length ? `<div class="card"><h3>Liners</h3><table class="t">${head}<tbody>${rowsHtml(liner)}</tbody></table></div>` : ''}
    <div class="card"><h3>Buyers' own bags <span class="hint">— used only for that buyer's orders</span></h3><table class="t">${head}<tbody>${rowsHtml(buyers) || '<tr><td colspan="10" class="muted">None. Mark a bag type as a buyer\'s own in Master → Item List → Bag type.</td></tr>'}</tbody></table></div>
    <div class="card" style="max-width:640px"><h3>Wastage</h3><div class="row" style="gap:10px;align-items:end"><label style="width:160px">Wastage % of bags used<input id="bgw" type="number" step="0.1" min="0" max="20" value="${s.wastage_pct}"></label><button id="bgws" class="sec">Save</button></div>
      <p class="hint">Bags torn while filling are taken off by this %. Count corrections and damaged bags go in Bag entries → Adjustment.</p></div>`;
  $('#bgws', box).onclick = async () => { await guard(() => PUT('/api/bags/settings', { wastage_pct: $('#bgw', box).value })); toast('Wastage saved'); bagStock(box); };
  $('#bgx', box).onclick = () => downloadCsv('bag_stock.csv', d.list.map(x => ({ bag_type: x.name, owner: x.owner, opening: x.opening, purchased: x.purchased, from_buyers: x.from_buyers, adjust: x.adjust, used: x.used, wastage: x.wastage, in_hand: x.in_hand, avg_cost: x.avg_cost, value: x.value })));
}

async function bagEntries(box, editId) {
  const [moves, T, sups, bs] = await Promise.all([GET('/api/bags/moves'), GET('/api/bags/types'), GET('/api/m/suppliers').catch(() => []), GET('/api/bags/settings').catch(() => ({}))]);
  // only packing material suppliers (Master → Suppliers → Supplier type)
  const supNames = [...new Set(sups.filter(x => x.supply_kind === 'PACKING').map(x => x.name).filter(Boolean).sort())];
  const cur = editId ? moves.find(m => String(m.id) === String(editId)) : null;
  // one bill / invoice can hold several bag types: they are saved together and changed together
  const group = cur ? (cur.grp ? moves.filter(m => m.grp === cur.grp) : [cur]) : [];
  const typeNames = T.types.filter(t => t.in_list && !t.same_as && t.kind !== 'COMBO').map(t => t.name);
  const v = cur || { date: today(), kind: 'PURCHASE', rate_per: 'BAG' };
  const lineHtml = l => `<tr class="bgl"><td><input name="bag_type" list="dl-bgt" value="${esc(l.name || '')}" placeholder="Type or choose"></td>
    <td><input name="bags" type="number" step="1" value="${l.bags ?? ''}" style="width:90px"></td><td><input name="weight_kg" type="number" step="0.001" value="${l.weight_kg ?? ''}" style="width:100px"></td>
    <td class="k-rate"><input name="rate" type="number" step="0.01" value="${l.rate ?? ''}" style="width:90px"></td>
    <td class="k-rate"><select name="rate_per"><option value="BAG" ${l.rate_per !== 'KG' ? 'selected' : ''}>per bag</option><option value="KG" ${l.rate_per === 'KG' ? 'selected' : ''}>per kg</option></select></td>
    <td class="hint bgc" style="min-width:110px"></td><td><button type="button" class="small sec" data-bgx title="Remove this line">✕</button></td></tr>`;
  const firstMove = new Map();       // the row of a bill shows the bill once
  box.innerHTML = `<form id="bgf" class="card" autocomplete="off"><div class="row" style="justify-content:space-between"><h3 style="margin:0">${cur ? 'Change bag entry' : 'New bag entry'} <span class="hint">— one bill or invoice can have many bag types: press “+ Add bag type”</span></h3>
      ${cur ? '' : '<button type="button" class="sec" id="bgopen">🔒 Add opening stock</button>'}</div>
      <p class="firmbox k-open" style="margin:10px 0 0">🔒 <b>Opening stock</b> — the bags in hand on <b>${bs.start ? dmy(bs.start) : 'the counting date'}</b> (invoices use bags from that day). Put every bag type as a line, then Save — the edit password is asked.</p>
      <div class="grid g4">
        <label>Entry<select name="kind">${BAG_KINDS.map(([k, t]) => `<option value="${k}" ${v.kind === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label>Date<input name="date" type="date" value="${esc(v.date)}"></label>
        <label class="k-pur">Supplier <span class="hint">${supNames.length ? '(packing material — Master → Suppliers)' : '— no packing material supplier yet: Master → Item List → Suppliers, Supplier type'}</span><input name="supplier" list="dl-bgs" value="${esc(v.supplier || '')}" placeholder="Choose the bag supplier"><datalist id="dl-bgs">${supNames.map(n => `<option value="${esc(n)}">`).join('')}</datalist></label>
        <label class="k-pur">Bill / invoice no.<input name="bill_no" value="${esc(v.bill_no || '')}"></label>
        <label class="span2 k-buy">Buyer who sent the bags<select name="party_id"><option value="">— choose —</option>${T.parties.map(p => `<option value="${p.id}" ${Number(v.party_id) === p.id ? 'selected' : ''}>${esc(p.name)}${p.city ? ' — ' + esc(p.city) : ''}</option>`).join('')}</select></label>
        <label class="span2">Note<input name="note" value="${esc(v.note || '')}"></label></div>
      <datalist id="dl-bgt">${typeNames.map(n => `<option value="${esc(n)}">`).join('')}</datalist>
      <div class="tablewrap" style="margin-top:10px"><table class="t"><thead><tr><th>Bag type</th><th>No. of bags <span class="k-adj">(− to take off)</span></th><th>Weight (kg)</th><th class="k-rate">Rate (₹)</th><th class="k-rate">Rate is</th><th></th><th></th></tr></thead>
        <tbody id="bglines">${(group.length ? group : [{}]).map(lineHtml).join('')}</tbody></table></div>
      <div class="row" style="margin-top:8px;justify-content:space-between"><button type="button" class="sec" id="bgadd">+ Add bag type</button><span id="bgtot" class="hint"></span></div>
      <div class="row" style="margin-top:10px"><button type="submit">${cur ? 'Save changes' : 'Save entry'}</button>${cur ? '<button type="button" class="sec" id="bgcancel">Cancel</button>' : ''}</div>
      <p class="hint">Only the weight on the bill? Leave the number of bags empty — it is worked out from the empty weight of one bag (Item List → Bag type). Both given: the empty weight is learnt from them. The opening stock needs the edit password.</p></form>
    <div class="card"><div class="toolbar"><h3 style="margin:0">Bag entries</h3><span class="spacer"></span><button class="sec" id="bgex">Export</button></div>
      <div class="tablewrap" style="max-height:70vh"><table class="t"><thead><tr><th>Date</th><th>Entry</th><th>Bag type</th><th class="num">Bags</th><th class="num">Kg</th><th class="num">Cost / bag</th><th class="num">Amount</th><th>From</th><th></th></tr></thead><tbody>
      ${moves.map(m => { const n = m.grp ? moves.filter(x => x.grp === m.grp).length : 1, first = !m.grp || !firstMove.has(m.grp); if (m.grp) firstMove.set(m.grp, 1);
        return `<tr${m.grp && !first ? ' style="border-top:0"' : ''}><td>${first ? dmy(m.date) : ''}</td><td>${first ? (m.kind === 'OPENING' ? '🔒 Opening' : m.kind === 'PURCHASE' ? 'Purchase' : m.kind === 'BUYER' ? 'From buyer' : 'Adjustment') : ''}</td><td><b>${esc(m.name)}</b></td>
        <td class="num">${bagN(m.bags)}</td><td class="num">${m.weight_kg ? bagN(m.weight_kg) : ''}</td><td class="num">${m.amount ? money(m.amount / m.bags) : ''}</td><td class="num">${m.amount ? rs(m.amount) : ''}</td>
        <td class="hint">${first ? `${esc(m.party_name || m.supplier || '')}${m.bill_no ? ' · bill ' + esc(m.bill_no) : ''}${m.note ? ' · ' + esc(m.note) : ''}${n > 1 ? ` · <b>${n} bag types</b>` : ''}` : ''}</td>
        <td style="white-space:nowrap">${first ? `<button class="small sec" data-bge="${m.id}">Edit</button> ` : ''}<button class="small sec" data-bgd="${m.id}">✕</button></td></tr>`; }).join('') || '<tr><td colspan="9" class="muted">No entries yet.</td></tr>'}</tbody></table></div></div>`;
  const f = $('#bgf', box), body = $('#bglines', box);
  const show = () => { const k = f.kind.value;
    $$('.k-pur', f).forEach(x => x.hidden = k !== 'PURCHASE'); $$('.k-buy', f).forEach(x => x.hidden = k !== 'BUYER'); $$('.k-rate', f).forEach(x => x.hidden = k === 'BUYER' || k === 'ADJUST'); $$('.k-adj', f).forEach(x => x.hidden = k !== 'ADJUST'); $$('.k-open', f).forEach(x => x.hidden = k !== 'OPENING');
    let tb = 0, ta = 0;
    $$('.bgl', body).forEach(tr => { const g = n => $(`[name=${n}]`, tr).value, name = g('bag_type').trim();
      const t = T.types.find(x => x.name === name.toUpperCase() || x.names.includes(name));
      const w = Number(g('weight_kg')), bags = Number(g('bags')) || (w && t && t.empty_g ? Math.round(w * 1000 / t.empty_g) : 0), rate = k === 'BUYER' || k === 'ADJUST' ? 0 : Number(g('rate'));
      const amt = rate ? (g('rate_per') === 'KG' ? rate * w : rate * bags) : 0; tb += bags; ta += amt;
      $('.bgc', tr).innerHTML = [bags && !g('bags') && w ? `${bagN(bags)} bags (from weight)` : '', t && !t.empty_g && w && !g('bags') ? 'empty weight not set' : '', amt && bags ? `${rs(amt)} · ${money(amt / bags)}/bag` : ''].filter(Boolean).join('<br>'); });
    $('#bgtot', box).innerHTML = tb ? `Total <b>${bagN(tb)} bags</b>${ta ? ` · ${rs(ta)}` : ''}` : ''; };
  f.oninput = show; f.kind.onchange = () => { if (f.kind.value === 'OPENING' && bs.start) f.date.value = bs.start; show(); }; show();
  const bo = $('#bgopen', box); if (bo) bo.onclick = () => { f.kind.value = 'OPENING'; if (bs.start) f.date.value = bs.start; show(); f.scrollIntoView({ behavior: 'smooth' }); $('[name=bag_type]', body).focus(); };
  $('#bgadd', box).onclick = () => { body.insertAdjacentHTML('beforeend', lineHtml({ rate_per: ($$('[name=rate_per]', body).pop() || {}).value })); show(); $$('[name=bag_type]', body).pop().focus(); };
  body.onclick = e => { if (e.target.closest('[data-bgx]')) { if ($$('.bgl', body).length > 1) e.target.closest('tr').remove(); else $$('input', e.target.closest('tr')).forEach(i => i.value = ''); show(); } };
  f.onsubmit = async e => { e.preventDefault();
    const head = Object.fromEntries(['kind', 'date', 'supplier', 'bill_no', 'party_id', 'note'].map(k => [k, f[k].value.trim()]));
    const lines = $$('.bgl', body).map(tr => Object.fromEntries(['bag_type', 'bags', 'weight_kg', 'rate', 'rate_per'].map(k => [k, $(`[name=${k}]`, tr).value.trim()])));
    if (head.kind === 'OPENING' || group.some(m => m.kind === 'OPENING')) { const pw = await askEditPassword('change the opening stock of bags'); if (!pw) return; head.edit_password = pw; }
    const r = await guard(() => POST('/api/bags/batch', { head, lines, ids: group.map(m => m.id) }));
    toast(`Saved · ${r.saved} bag type${r.saved === 1 ? '' : 's'} · ${bagN(r.bags)} bags`); bagEntries(box); };
  const c = $('#bgcancel', box); if (c) c.onclick = () => bagEntries(box);
  $('#bgex', box).onclick = () => downloadCsv('bag_entries.csv', moves.map(m => ({ date: m.date, entry: m.kind, bag_type: m.name, bags: m.bags, weight_kg: m.weight_kg, rate: m.rate, rate_per: m.rate_per, amount: m.amount, supplier: m.supplier, buyer: m.party_name, bill_no: m.bill_no, note: m.note })));
  box.onclick = async e => {
    const ed = e.target.closest('[data-bge]'), dl = e.target.closest('[data-bgd]');
    if (ed) { await bagEntries(box, ed.dataset.bge); box.scrollIntoView({ behavior: 'smooth' }); }
    if (dl) { const m = moves.find(x => String(x.id) === dl.dataset.bgd); let q = '';
      if (m.kind === 'OPENING') { const pw = await askEditPassword('delete an opening stock entry'); if (!pw) return; q = '?pw=' + encodeURIComponent(pw); }
      else if (!confirm(`Delete this line (${m.name})?`)) return;
      await guard(() => DEL('/api/bags/moves/' + m.id + q)); toast('Entry deleted'); bagEntries(box); }
  };
}

// Master → Item List → Bag type: the list itself, plus the stock settings of each bag type and the other names used
async function bagListExtras(box) {
  const T = await GET('/api/bags/types');
  const list = T.types.filter(t => t.in_list), others = T.types.filter(t => !t.in_list && !t.same_as), joined = T.types.filter(t => !t.in_list && t.same_as);
  const nameOf = k => (T.types.find(t => t.nkey === k) || {}).name || k;
  const kindTxt = t => t.kind === 'COMBO' ? `1 ${esc(nameOf(t.combo_outer))} + ${t.combo_count} × ${esc(nameOf(t.combo_inner))}` : (BAG_TYPE_KINDS.find(k => k[0] === t.kind) || [, 'Bag'])[1];
  const ids = new Map((S.lists && S.lists.bag_type || []).map(r => [String(r.value).toUpperCase().replace(/LINNER/g, 'LINER').replace(/[^A-Z0-9]/g, ''), r.id]));
  const tbl = $('table.t', box); if (!tbl) return;
  tbl.innerHTML = `<thead><tr><th>Bag type</th><th>Kind</th><th class="num">Empty weight</th><th class="num">Min. stock</th><th style="width:250px"></th></tr></thead><tbody>
    ${list.filter(t => t.kind !== 'LINER' || ids.has(t.nkey)).map(t => `<tr><td><b>${esc(t.name)}</b>${t.owner ? `<br><span class="hint">${esc(t.owner)}'s own bags</span>` : ''}${joined.filter(j => j.same_as === t.nkey).length ? `<br><span class="hint">also written: ${esc(joined.filter(j => j.same_as === t.nkey).map(j => j.name).join(' · '))}</span>` : ''}</td>
      <td>${kindTxt(t)}${t.has_liner ? ' <span class="badge grey">with liner</span>' : ''}</td><td class="num">${t.empty_g ? t.empty_g + ' g' : '<span class="hint">—</span>'}</td><td class="num">${t.min_stock ?? ''}</td>
      <td style="text-align:right;white-space:nowrap"><button class="small" data-bset="${esc(t.nkey)}">⚙ Stock settings</button>${ids.has(t.nkey) ? ` <button class="small sec" data-ed="${ids.get(t.nkey)}">Edit</button> <button class="small sec" data-rm="${ids.get(t.nkey)}">Remove</button>` : ''}</td></tr>`).join('')}
    <tr><td><b>LINER</b><br><span class="hint">plastic liner inside a bag (WITH LINER items)</span></td><td>Liner</td><td class="num">${(T.types.find(t => t.nkey === 'LINER') || {}).empty_g || '—'}</td><td class="num">${(T.types.find(t => t.nkey === 'LINER') || {}).min_stock ?? ''}</td>
      <td style="text-align:right"><button class="small" data-bset="LINER">⚙ Stock settings</button></td></tr></tbody>`;
  const card = document.createElement('div'); card.className = 'card';
  card.innerHTML = `<h3>Other bag names used <span class="hint">${others.length} · written on buyers' items or invoices but not in this list</span></h3>
    <p class="hint" style="margin-top:0">For the bag stock, join each to the bag type it really is (“Same as”), or add it to the list. Names that differ only in spaces or capitals are joined by themselves.</p>
    <div class="tablewrap" style="max-height:360px"><table class="t"><tbody>${others.map(t => `<tr><td><b>${esc(t.name)}</b> <span class="hint">${esc(t.src.join(', '))}</span></td>
      <td style="width:280px"><select data-join="${esc(t.nkey)}"><option value="">Same as …</option>${list.filter(x => x.kind !== 'COMBO' || true).map(x => `<option value="${esc(x.nkey)}">${esc(x.name)}</option>`).join('')}</select></td>
      <td style="width:120px;text-align:right"><button class="small sec" data-badd="${esc(t.name)}">+ Add to list</button></td></tr>`).join('') || '<tr><td class="muted">None — every bag name is in the list.</td></tr>'}</tbody></table></div>`;
  card.style.cssText = 'margin:18px 0 0;padding:14px;background:#f7fafb;box-shadow:none'; tbl.closest('.card').appendChild(card);
  if (box._bagH) box.removeEventListener('click', box._bagH);      // one handler, even after the list is drawn again
  box._bagH = async e => {
    const st = e.target.closest('[data-bset]'), ad = e.target.closest('[data-badd]');
    if (st) bagTypeModal(T.types.find(t => t.nkey === st.dataset.bset) || { nkey: 'LINER', name: 'LINER', kind: 'LINER' }, T, () => listsPage(box, 'bag_type'));
    if (ad) { await guard(() => POST('/api/lists', { list_key: 'bag_type', value: ad.dataset.badd })); toast('Added to the list'); S.lists = null; listsPage(box, 'bag_type'); }
  };
  box.addEventListener('click', box._bagH);
  $$('[data-join]', card).forEach(sel => sel.onchange = async () => { if (!sel.value) return; const t = T.types.find(x => x.nkey === sel.dataset.join);
    await guard(() => PUT('/api/bags/types/' + encodeURIComponent(t.nkey), { ...t, same_as: sel.value })); toast(`${t.name} = ${nameOf(sel.value)}`); listsPage(box, 'bag_type'); });
}
function bagTypeModal(cur, T, after) {
  const roots = T.types.filter(t => t.in_list && !t.same_as);
  const opt = (sel, filt = () => true) => '<option value=""></option>' + roots.filter(filt).map(t => `<option value="${esc(t.nkey)}" ${sel === t.nkey ? 'selected' : ''}>${esc(t.name)}</option>`).join('');
  modal(`Stock settings · ${cur.name}`, `<form id="btf" autocomplete="off"><div class="grid g2">
      <label>Kind<select name="kind">${BAG_TYPE_KINDS.map(([k, n]) => `<option value="${k}" ${cur.kind === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label>Empty weight of one bag (g)<input name="empty_g" type="number" step="0.1" value="${cur.empty_g ?? ''}"></label>
      <label class="cmb">Outer bag<select name="combo_outer">${opt(cur.combo_outer, t => t.kind === 'OUTER')}</select></label>
      <label class="cmb">Inner bag (5 kg)<select name="combo_inner">${opt(cur.combo_inner, t => t.kind === 'INNER')}</select></label>
      <label class="cmb">Inner bags in one<select name="combo_count">${[2, 3, 4, 5, 6, 8, 10].map(n => `<option ${Number(cur.combo_count) === n ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label>Minimum stock <span class="hint">(⚠ below this)</span><input name="min_stock" type="number" step="1" value="${cur.min_stock ?? ''}"></label>
      <label class="span2">Buyer's own bags <span class="hint">— only for this buyer</span><select name="owner_party_id"><option value="">No — our bags</option>${T.parties.map(p => `<option value="${p.id}" ${Number(cur.owner_party_id) === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>
      <label class="span2" style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="has_liner" style="width:auto" ${cur.has_liner ? 'checked' : ''}> This bag has a liner in it (uses one liner a bag)</label></div>
    <div class="row" style="margin-top:12px"><button type="submit">Save</button></div>
    <p class="hint">Combo (e.g. PLAIN 5KG X6): not kept in stock — each combo bag on an invoice uses 1 outer bag + its inner bags. Set the 5 kg bag first (Kind = 5 kg inner bag). Empty weight: the count is worked out from the kg on the bill.</p></form>`, root => {
    const f = $('#btf', root), show = () => $$('.cmb', f).forEach(x => x.hidden = f.kind.value !== 'COMBO'); f.kind.onchange = show; show();
    f.onsubmit = async e => { e.preventDefault(); await guard(() => PUT('/api/bags/types/' + encodeURIComponent(cur.nkey), { ...formData(f), name: cur.name, same_as: '' })); closeModal(); toast('Saved'); after && after(); };
  });
}

async function bagUsed(box) {
  const st = S.bgu = S.bgu || { from: '', to: '' };
  const rows = await GET(`/api/bags/usage?from=${st.from}&to=${st.to}`);
  const by = new Map(); rows.forEach(r => by.set(r.name, (by.get(r.name) || 0) + r.bags));
  box.innerHTML = `<div class="card"><div class="toolbar"><h3 style="margin:0">Bags used by invoices</h3>
      <label>From<input type="date" id="bgf1" value="${esc(st.from)}"></label><label>To<input type="date" id="bgf2" value="${esc(st.to)}"></label><span class="spacer"></span><button class="sec" id="bgux">Export</button></div>
      <div class="row" style="gap:8px;flex-wrap:wrap;margin:8px 0">${[...by.entries()].sort((a, b) => b[1] - a[1]).map(([n, b]) => `<span class="badge ${n === '(no bag type)' ? 'amber' : 'slate'}">${esc(n)}: ${bagN(b)}</span>`).join('') || '<span class="muted">No invoices yet.</span>'}</div>
      <div class="tablewrap" style="max-height:66vh"><table class="t"><thead><tr><th>Date</th><th>Invoice</th><th>Buyer</th><th>Item</th><th>Bag type</th><th class="num">Bags</th></tr></thead><tbody>
      ${rows.map(r => `<tr class="click" onclick="openInvoice(${r.invoice_id}, 'SALE')"><td>${dmy(r.date)}</td><td>${esc(r.inv)}</td><td>${esc(r.party)}</td><td class="hint">${esc(r.item)}</td>
        <td>${esc(r.name)}${r.part ? ` <span class="hint">(${r.part})</span>` : ''}</td><td class="num">${bagN(r.bags)}</td></tr>`).join('')}</tbody></table></div>
      <p class="hint">Parakh Marketing and Parakh Fertilizer sales invoices from the start date. A combo uses its outer and inner bags; WITH LINER uses a liner a bag.</p></div>`;
  $('#bgf1', box).onchange = e => { st.from = e.target.value; bagUsed(box); }; $('#bgf2', box).onchange = e => { st.to = e.target.value; bagUsed(box); };
  $('#bgux', box).onclick = () => downloadCsv('bags_used.csv', rows);
}
