"""Reads an old billing workbook (e.g. Parakh Fertilizer) and writes a data file that
Mineral Saathi can import from Settings -> Import data file.

Usage: python export_firm_excel.py <workbook.xlsm> <FIRM_CODE PM|PF> <out.json>
"""
import sys, re, json, datetime, warnings
import openpyxl

warnings.filterwarnings("ignore")
SRC, FIRM, OUT = sys.argv[1:4]
FIRM_NAME = {"PM": "PARAKH MARKETING", "PF": "PARAKH FERTILIZER"}[FIRM]
wb = openpyxl.load_workbook(SRC, read_only=True, data_only=True)


def s(v):
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    t = str(v).replace("_x000D_", "").replace("\t", " ").strip()
    return t or None


def num(v):
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"[^0-9.\-]", "", str(v))
    try:
        return float(t) if t not in ("", ".", "-") else None
    except ValueError:
        return None


def dt(v):
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    m = re.match(r"\s*(\d{1,2})[./\-](\d{1,2})[./\-](\d{2,5})", str(v or ""))
    if not m:
        return None
    y = m.group(3)
    y = int(y[:4]) if len(y) >= 4 else 2000 + int(y)
    try:
        return datetime.date(y, int(m.group(2)), int(m.group(1))).isoformat()
    except ValueError:
        return None


def rows(ws):
    it = ws.iter_rows(values_only=True, max_col=70)
    head = [str(c).strip().upper() if c is not None else "" for c in next(it)]
    for r in it:
        if not r or all(c in (None, "") for c in r):
            continue
        rec = {}
        for i, h in enumerate(head):
            if h and h not in rec and i < len(r):
                rec[h] = r[i]
        yield rec


buyers = []
for r in rows(wb["MAIN DATA"]):
    name = s(r.get("ORGANIZATIONNAME"))
    if not name:
        continue
    gst = (s(r.get("GST NO")) or "").upper()
    if not re.match(r"^\d\d[A-Z0-9]{13}$", gst):
        gst = None
    sc = gst[:2] if gst else s(r.get("STATE CODE"))
    buyers.append({
        "name": name, "gstin": gst, "pan": (s(r.get("BUYER PAN")) or "").upper() or None,
        "address": s(r.get("DELIVERY ADDRESS")), "city": s(r.get("CITY")), "state": (s(r.get("STATE")) or "").upper() or None,
        "state_code": sc.zfill(2) if sc and sc.isdigit() else sc, "pincode": s(r.get("PINCODE2")),
        "ship_address": s(r.get("SHIPPING ADDRESS")) or s(r.get("PLANT 1")),
        "email": s(r.get("EMAIL")), "mobile": s(r.get("MOBILE NO.")), "phone": s(r.get("TEL NO.")),
        "transporter": s(r.get("TRANSPORT")), "km": int(num(r.get("KM")) or 0) or None,
        "group_name": s(r.get("GROUP OF COMPANY")), "payment_terms": s(r.get("PAYMENT TERMS")), "notes": s(r.get("NOTE")),
    })

invoices = {}
for sh in wb.sheetnames:
    m = re.match(r"^INVOICE DATA (20\d\d)-(\d\d)$", sh)
    if not m:
        continue
    fy = f"{m.group(1)}-{m.group(2)}"
    for r in rows(wb[sh]):
        if s(r.get("FIRM")) != FIRM_NAME:
            continue
        no = num(r.get("INVOICENO"))
        if not no:
            continue
        no = int(no)
        amt = num(r.get("AMOUNT")) or 0
        sg, cg, ig = num(r.get("SGST")) or 0, num(r.get("CGST")) or 0, num(r.get("IGST")) or 0
        tax = num(r.get("TAX")) or 0
        if not (sg or cg or ig) and tax:
            if (s(r.get("STATE")) or "RAJASTHAN").upper() == "RAJASTHAN":
                sg = cg = round(tax / 2, 2)
            else:
                ig = tax
        taxable = round(amt - (sg + cg + ig), 2)      # AMOUNT column is the grand total incl. tax
        key = (fy, no)
        gst = s(r.get("GST NO"))
        inv = invoices.get(key)
        if not inv:
            inv = invoices[key] = {
                "fy": fy, "inv_no": no, "date": dt(r.get("DATE")), "party_name": s(r.get("PARTY")), "party_gstin": gst,
                "party_address": s(r.get("ADDRESS")), "party_city": s(r.get("CITY")) or s(r.get("PARTYPLANT")),
                "party_state": s(r.get("STATE")), "party_state_code": gst[:2] if gst else None,
                "ship_address": s(r.get("DELIVERY ADDRESS")), "supply_type": "B2B" if gst else "B2C",
                "lorry_no": s(r.get("LORRYNO.")), "transporter": s(r.get("TRANSPOTOR")), "lr_no": s(r.get("LRNO")),
                "driver_phone": s(r.get("DRIVERNO")), "plant": s(r.get("PLANT")), "ewb_no": s(r.get("WAY BILL NO")),
                "freight_note": s(r.get("FREIGHTPMT")), "email_sent_at": s(r.get("EMAILSENTDATETIME")), "notes": s(r.get("NOTE")),
                "taxable": 0, "cgst": 0, "sgst": 0, "igst": 0, "total": 0, "items": []}
        inv["taxable"] = round(inv["taxable"] + taxable, 2)
        inv["cgst"] = round(inv["cgst"] + cg, 2); inv["sgst"] = round(inv["sgst"] + sg, 2); inv["igst"] = round(inv["igst"] + ig, 2)
        inv["total"] = round(inv["total"] + taxable + cg + sg + ig, 2)
        inv["items"].append({
            "item_name": s(r.get("ITMENAME")) or s(r.get("PARTICULERS")), "grade": s(r.get("GRADE")),
            "hsn": (s(r.get("HSN CODE")) or "2512")[:8], "qty": num(r.get("WEG")), "rate": num(r.get("RATE")), "amount": taxable,
            "gst_rate": round((cg + sg + ig) / taxable * 100) if taxable else 5,
            "bags": int(num(r.get("NOOFBAGS")) or 0) or None, "pack_size": num(r.get("PACKING")), "bag_type": s(r.get("PACKINGTYPE")),
            "lorry_no": s(r.get("LORRYNO."))})

data = {"kind": "mineral-saathi-import", "firm_code": FIRM, "source": SRC.split("/")[-1],
        "made": datetime.datetime.now().isoformat(timespec="seconds"),
        "buyers": buyers, "invoices": sorted(invoices.values(), key=lambda x: (x["fy"], x["inv_no"]))}
json.dump(data, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
by = {}
for i in data["invoices"]:
    by[i["fy"]] = by.get(i["fy"], 0) + 1
print("buyers", len(buyers), "invoices", len(data["invoices"]), by)
