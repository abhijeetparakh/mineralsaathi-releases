'use strict';
// Where the data lives. config.json (next to Start-Server.bat) can point the data to a shared
// folder such as Google Drive, so the same data can be used on the office PC, home PC or laptop.
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const CONFIG_FILE = path.join(ROOT, 'config.json');

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8').replace(/^﻿/, '')); } catch { return {}; }
}
function writeConfig(cfg) { fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2)); }

const config = readConfig();
const DATA_DIR = process.env.MS_DATA_DIR || config.data_folder || path.join(ROOT, 'data');
const SHARED = !process.env.MS_DATA_DIR && !!config.data_folder;     // data in a synced folder
const DB_FILE = path.join(DATA_DIR, 'mineral.db');
const LOCK_FILE = path.join(DATA_DIR, 'mineral.lock');

module.exports = { ROOT, CONFIG_FILE, readConfig, writeConfig, DATA_DIR, SHARED, DB_FILE, LOCK_FILE };
