'use strict';
// One computer at a time.
// While Mineral Saathi is open on a PC it keeps a small "lock" note in the data folder and refreshes
// it every minute. Another PC will not open the data while that note is fresh. "Close for today"
// writes the note as released, together with a fingerprint of the data file, so the next PC can
// wait until Google Drive has brought it the complete, latest data.
const fs = require('node:fs');
const os = require('node:os');
const crypto = require('node:crypto');
const { DB_FILE, LOCK_FILE, DATA_DIR, SHARED } = require('./paths');

const PC = os.hostname();
const STALE_MIN = 10;            // a lock not refreshed for this many minutes is old
const SYNC_WAIT_MIN = 10;        // how long to wait for Google Drive to finish syncing

const sleep = ms => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
const read = () => { try { return JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8')); } catch { return null; } };
const write = o => { try { fs.writeFileSync(LOCK_FILE, JSON.stringify(o, null, 1)); } catch (e) { console.error('Could not write the lock note:', e.message); } };
const when = iso => iso ? new Date(iso).toLocaleString('en-IN') : '?';

function fingerprint() {
  try { return crypto.createHash('sha1').update(fs.readFileSync(DB_FILE)).digest('hex'); } catch { return null; }
}

function stop(lines) {
  console.log('\n  ' + lines.join('\n  ') + '\n');
  process.exit(3);                       // Start-Server.bat waits for a key and closes
}

// Called before the data is opened.
function acquireOrExit() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const takeover = process.env.MS_TAKEOVER === '1';
  let lk = read();
  if (!lk || lk.pc === PC || takeover) return;

  if (!lk.released) {
    const age = (Date.now() - new Date(lk.heartbeat || lk.started).getTime()) / 60000;
    if (age < STALE_MIN) stop([
      `Mineral Saathi data is OPEN on "${lk.pc}" (since ${when(lk.started)}).`,
      `Only one computer can use the data at a time.`,
      `On ${lk.pc}: Settings → Data location → "Close for today". Wait a minute, then start again here.`]);
    console.log(`\n  The data was last used on "${lk.pc}" (last seen ${when(lk.heartbeat)}) and was not closed properly.\n  Choose in the window that opens.\n`);
    if (require.main && /server\.js$/.test(require.main.filename || '')) { require('./firstrun').run({ takeover: lk }); return 'page'; }
    stop([
      `The data was last used on "${lk.pc}" (last seen ${when(lk.heartbeat)}) and was not closed properly.`,
      `If ${lk.pc} is switched off or Mineral Saathi is not running there,`,
      `double-click  windows\\Take-Over-Data.bat  to open the data on this PC.`]);
  }

  // released by another PC: make sure Google Drive has brought the same data here
  if (SHARED && lk.db_hash) {
    const until = Date.now() + SYNC_WAIT_MIN * 60000;
    let shown = false;
    while (fingerprint() !== lk.db_hash) {
      if (Date.now() > until) stop([
        `Google Drive has not yet brought the latest data from "${lk.pc}" (closed ${when(lk.released_at)}).`,
        `Check that Google Drive is running and online, then start again.`,
        `To open the data anyway, double-click  windows\\Take-Over-Data.bat.`]);
      if (!shown) { console.log(`\n  Waiting for Google Drive to bring the latest data from ${lk.pc}...`); shown = true; }
      sleep(5000);
      lk = read() || lk;
      if (!lk.released && lk.pc !== PC) return acquireOrExit();   // opened there again
    }
    if (shown) console.log('  Latest data is here.\n');
  }
}

function claim() {
  write({ pc: PC, user: os.userInfo().username, started: new Date().toISOString(), heartbeat: new Date().toISOString(), released: false });
}

// refresh every minute; if another PC has taken the data over, stop at once without writing anything
function startHeartbeat(onLost) {
  setInterval(() => {
    const lk = read();
    if (lk && lk.pc !== PC && !lk.released) { onLost(lk); return; }
    write({ ...(lk && lk.pc === PC ? lk : { pc: PC, started: new Date().toISOString() }), heartbeat: new Date().toISOString(), released: false });
  }, 60000).unref();
}

// after the database is closed
function release() {
  write({ pc: PC, released: true, released_at: new Date().toISOString(), db_hash: fingerprint(), db_size: (() => { try { return fs.statSync(DB_FILE).size; } catch { return 0; } })() });
}

function status() {
  return { pc: PC, lock: read(), shared: SHARED, data_folder: DATA_DIR };
}

module.exports = { acquireOrExit, claim, startHeartbeat, release, status, PC };
