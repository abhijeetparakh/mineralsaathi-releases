'use strict';
// Backups: a full copy of the database goes to the chosen backup folder
// after every new / changed invoice and every hour.
const fs = require('node:fs');
const path = require('node:path');
const { db, setting, setSetting, DATA_DIR } = require('./db');

const KEEP = 300;            // newest backup files kept in the folder
let pending = null;

function folder() {
  return setting('backup_folder') || path.join(DATA_DIR, 'backups');
}

function stamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function backupNow(reason = 'manual') {
  const dir = folder();
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `MineralSaathi_${stamp()}_${reason}.db`);
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  setSetting('last_backup', new Date().toISOString());
  setSetting('last_backup_file', file);
  prune(dir);
  return file;
}

function prune(dir) {
  const files = fs.readdirSync(dir).filter(f => /^MineralSaathi_.*\.db$/.test(f)).sort();
  for (const f of files.slice(0, Math.max(0, files.length - KEEP))) {
    try { fs.unlinkSync(path.join(dir, f)); } catch { /* ignore */ }
  }
}

// Called after every invoice save. Waits a few seconds so a burst of saves makes one backup.
function backupSoon(reason = 'invoice') {
  clearTimeout(pending);
  pending = setTimeout(() => {
    try { backupNow(reason); } catch (e) { console.error('Backup failed:', e.message); setSetting('last_backup_error', e.message); }
  }, 3000);
}

function list() {
  const dir = folder();
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(f => /^MineralSaathi_.*\.db$/.test(f)).sort().reverse().slice(0, 50)
    .map(f => ({ name: f, size: fs.statSync(path.join(dir, f)).size }));
}

function startHourly() {
  setInterval(() => {
    try { backupNow('hourly'); } catch (e) { console.error('Hourly backup failed:', e.message); setSetting('last_backup_error', e.message); }
  }, 60 * 60 * 1000);
}

module.exports = { backupNow, backupSoon, list, folder, startHourly };
