'use strict';
// Silent printing on the computer that runs Mineral Saathi (main office PC, home PC, laptop).
// Each page is drawn by Microsoft Edge as a sharp picture at the exact paper size, then sent by
// Windows straight to the chosen printer — no print window, nothing extra to install.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile } = require('node:child_process');

const PS = (args, timeout = 60000) => new Promise((resolve, reject) => {
  execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args], { windowsHide: true, timeout, maxBuffer: 4e6 }, (err, out, errOut) => {
    if (err && !out) return reject(new Error((errOut || err.message || '').toString().trim().split('\n').pop()));
    resolve(String(out || '').trim());
  });
});

const supported = () => process.platform === 'win32';

async function printers() {
  if (!supported()) return { printers: [], default: null };
  const out = await PS(['-Command', `Add-Type -AssemblyName System.Drawing; $d=(New-Object System.Drawing.Printing.PrinterSettings).PrinterName; [System.Drawing.Printing.PrinterSettings]::InstalledPrinters | ForEach-Object { if ($_ -eq $d) { "*" + $_ } else { $_ } }`]);
  const lines = out.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  return { printers: lines.map(s => s.replace(/^\*/, '')), default: (lines.find(s => s.startsWith('*')) || '').slice(1) || null };
}

async function papers(name) {
  if (!supported() || !name) return [];
  const n = name.replace(/'/g, "''");
  const out = await PS(['-Command', `Add-Type -AssemblyName System.Drawing; $p=New-Object System.Drawing.Printing.PrinterSettings; $p.PrinterName='${n}'; if(-not $p.IsValid){exit}; $c=$p.DefaultPageSettings.PaperSize.PaperName; foreach($s in $p.PaperSizes){ if($s.Width -gt 0){ "{0}|{1}|{2}|{3}" -f $s.PaperName,([Math]::Round($s.Width*0.254,1)),([Math]::Round($s.Height*0.254,1)),($s.PaperName -eq $c) } }`]);
  return out.split(/\r?\n/).filter(Boolean).map(l => { const [n2, w, h, cur] = l.split('|'); return { name: n2.trim(), w: Number(w), h: Number(h), current: cur === 'True' }; });
}

function browser() {
  const c = [process.env.MS_BROWSER, 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', '/opt/google/chrome/chrome', '/usr/bin/chromium'].filter(Boolean);
  const b = c.find(p => { try { return fs.existsSync(p); } catch { return false; } });
  if (!b) throw new Error('Microsoft Edge was not found, so the page could not be drawn for printing.');
  return b;
}

// draw one page (url must render exactly one sheet in "shot" mode) as a PNG
function snapshot(url, wMm, hMm, out) {
  const px = mm => Math.round(mm / 25.4 * 96);
  const args = ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--force-device-scale-factor=3',
    `--window-size=${px(wMm)},${px(hMm)}`, `--screenshot=${out}`, url];
  if (process.platform !== 'win32') args.unshift('--no-sandbox');
  return new Promise((resolve, reject) => {
    execFile(browser(), args, { timeout: 60000, windowsHide: true }, err => {
      if (fs.existsSync(out) && fs.statSync(out).size > 1000) resolve(out);
      else reject(new Error('The page could not be drawn for printing' + (err ? ': ' + err.message : '.')));
    });
  });
}

// pages: [{ url, w, h, count }] → each url shows `count` sheets one under the other; printed in order on `printer`
async function printPages(printer, pages, job) {
  if (!supported()) throw new Error('Direct printing works only on Windows.');
  if (!printer) throw new Error('No printer is chosen for this. Choose one in Settings → This computer → Printers.');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ms-print-'));
  try {
    for (let i = 0; i < pages.length; i++) {
      const pg = pages[i];
      const png = path.join(dir, `p${i}.png`);
      const count = Math.max(1, pg.count || 1);
      await snapshot(pg.url, pg.w, pg.h * count, png);
      const res = await PS(['-File', path.join(__dirname, 'print-image.ps1'), '-Printer', printer, '-Image', png, '-WidthMm', String(pg.w), '-HeightMm', String(pg.h),
        '-Copies', String(pg.copies || 1), '-Pages', String(count), '-Job', job], 180000);
      if (/NOPRINTER/.test(res)) throw new Error(`The printer "${printer}" isn't available on this computer. Check that it is on, or choose another in Settings → This computer.`);
    }
  } finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ } }
}

module.exports = { supported, printers, papers, printPages, snapshot };
